/* SCORM 2004 CMI API Wrapper */
(function() {
  function findAPI(win) {
    var findAttempts = 0;
    while ((!win.API_1484_11) && (win.parent) && (win.parent != win) && (findAttempts <= 10)) {
      findAttempts++;
      win = win.parent;
    }
    return win.API_1484_11;
  }
  
  var api = findAPI(window) || (window.opener ? findAPI(window.opener) : null);
  if (api) {
    api.Initialize("");
    api.SetValue("cmi.completion_status", "incomplete");
    api.Commit("");
    
    window.addEventListener("beforeunload", function() {
      api.SetValue("cmi.completion_status", "completed");
      api.SetValue("cmi.success_status", "passed");
      api.Commit("");
      api.Terminate("");
    });
  }
})();