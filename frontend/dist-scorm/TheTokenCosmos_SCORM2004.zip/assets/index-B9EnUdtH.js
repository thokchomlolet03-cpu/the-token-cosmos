(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))r(a);new MutationObserver(a=>{for(const l of a)if(l.type==="childList")for(const u of l.addedNodes)u.tagName==="LINK"&&u.rel==="modulepreload"&&r(u)}).observe(document,{childList:!0,subtree:!0});function t(a){const l={};return a.integrity&&(l.integrity=a.integrity),a.referrerPolicy&&(l.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?l.credentials="include":a.crossOrigin==="anonymous"?l.credentials="omit":l.credentials="same-origin",l}function r(a){if(a.ep)return;a.ep=!0;const l=t(a);fetch(a.href,l)}})();function og(s){return s&&s.__esModule&&Object.prototype.hasOwnProperty.call(s,"default")?s.default:s}var ud={exports:{}},so={},dd={exports:{}},Nt={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Im;function Ov(){if(Im)return Nt;Im=1;var s=Symbol.for("react.element"),e=Symbol.for("react.portal"),t=Symbol.for("react.fragment"),r=Symbol.for("react.strict_mode"),a=Symbol.for("react.profiler"),l=Symbol.for("react.provider"),u=Symbol.for("react.context"),h=Symbol.for("react.forward_ref"),p=Symbol.for("react.suspense"),f=Symbol.for("react.memo"),g=Symbol.for("react.lazy"),b=Symbol.iterator;function v(F){return F===null||typeof F!="object"?null:(F=b&&F[b]||F["@@iterator"],typeof F=="function"?F:null)}var S={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},M=Object.assign,E={};function x(F,Y,Ce){this.props=F,this.context=Y,this.refs=E,this.updater=Ce||S}x.prototype.isReactComponent={},x.prototype.setState=function(F,Y){if(typeof F!="object"&&typeof F!="function"&&F!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,F,Y,"setState")},x.prototype.forceUpdate=function(F){this.updater.enqueueForceUpdate(this,F,"forceUpdate")};function _(){}_.prototype=x.prototype;function N(F,Y,Ce){this.props=F,this.context=Y,this.refs=E,this.updater=Ce||S}var P=N.prototype=new _;P.constructor=N,M(P,x.prototype),P.isPureReactComponent=!0;var C=Array.isArray,k=Object.prototype.hasOwnProperty,D={current:null},U={key:!0,ref:!0,__self:!0,__source:!0};function T(F,Y,Ce){var qe,we={},ie=null,xe=null;if(Y!=null)for(qe in Y.ref!==void 0&&(xe=Y.ref),Y.key!==void 0&&(ie=""+Y.key),Y)k.call(Y,qe)&&!U.hasOwnProperty(qe)&&(we[qe]=Y[qe]);var ve=arguments.length-2;if(ve===1)we.children=Ce;else if(1<ve){for(var te=Array(ve),Se=0;Se<ve;Se++)te[Se]=arguments[Se+2];we.children=te}if(F&&F.defaultProps)for(qe in ve=F.defaultProps,ve)we[qe]===void 0&&(we[qe]=ve[qe]);return{$$typeof:s,type:F,key:ie,ref:xe,props:we,_owner:D.current}}function I(F,Y){return{$$typeof:s,type:F.type,key:Y,ref:F.ref,props:F.props,_owner:F._owner}}function z(F){return typeof F=="object"&&F!==null&&F.$$typeof===s}function O(F){var Y={"=":"=0",":":"=2"};return"$"+F.replace(/[=:]/g,function(Ce){return Y[Ce]})}var H=/\/+/g;function fe(F,Y){return typeof F=="object"&&F!==null&&F.key!=null?O(""+F.key):Y.toString(36)}function re(F,Y,Ce,qe,we){var ie=typeof F;(ie==="undefined"||ie==="boolean")&&(F=null);var xe=!1;if(F===null)xe=!0;else switch(ie){case"string":case"number":xe=!0;break;case"object":switch(F.$$typeof){case s:case e:xe=!0}}if(xe)return xe=F,we=we(xe),F=qe===""?"."+fe(xe,0):qe,C(we)?(Ce="",F!=null&&(Ce=F.replace(H,"$&/")+"/"),re(we,Y,Ce,"",function(Se){return Se})):we!=null&&(z(we)&&(we=I(we,Ce+(!we.key||xe&&xe.key===we.key?"":(""+we.key).replace(H,"$&/")+"/")+F)),Y.push(we)),1;if(xe=0,qe=qe===""?".":qe+":",C(F))for(var ve=0;ve<F.length;ve++){ie=F[ve];var te=qe+fe(ie,ve);xe+=re(ie,Y,Ce,te,we)}else if(te=v(F),typeof te=="function")for(F=te.call(F),ve=0;!(ie=F.next()).done;)ie=ie.value,te=qe+fe(ie,ve++),xe+=re(ie,Y,Ce,te,we);else if(ie==="object")throw Y=String(F),Error("Objects are not valid as a React child (found: "+(Y==="[object Object]"?"object with keys {"+Object.keys(F).join(", ")+"}":Y)+"). If you meant to render a collection of children, use an array instead.");return xe}function q(F,Y,Ce){if(F==null)return F;var qe=[],we=0;return re(F,qe,"","",function(ie){return Y.call(Ce,ie,we++)}),qe}function de(F){if(F._status===-1){var Y=F._result;Y=Y(),Y.then(function(Ce){(F._status===0||F._status===-1)&&(F._status=1,F._result=Ce)},function(Ce){(F._status===0||F._status===-1)&&(F._status=2,F._result=Ce)}),F._status===-1&&(F._status=0,F._result=Y)}if(F._status===1)return F._result.default;throw F._result}var oe={current:null},Z={transition:null},ee={ReactCurrentDispatcher:oe,ReactCurrentBatchConfig:Z,ReactCurrentOwner:D};function ce(){throw Error("act(...) is not supported in production builds of React.")}return Nt.Children={map:q,forEach:function(F,Y,Ce){q(F,function(){Y.apply(this,arguments)},Ce)},count:function(F){var Y=0;return q(F,function(){Y++}),Y},toArray:function(F){return q(F,function(Y){return Y})||[]},only:function(F){if(!z(F))throw Error("React.Children.only expected to receive a single React element child.");return F}},Nt.Component=x,Nt.Fragment=t,Nt.Profiler=a,Nt.PureComponent=N,Nt.StrictMode=r,Nt.Suspense=p,Nt.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=ee,Nt.act=ce,Nt.cloneElement=function(F,Y,Ce){if(F==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+F+".");var qe=M({},F.props),we=F.key,ie=F.ref,xe=F._owner;if(Y!=null){if(Y.ref!==void 0&&(ie=Y.ref,xe=D.current),Y.key!==void 0&&(we=""+Y.key),F.type&&F.type.defaultProps)var ve=F.type.defaultProps;for(te in Y)k.call(Y,te)&&!U.hasOwnProperty(te)&&(qe[te]=Y[te]===void 0&&ve!==void 0?ve[te]:Y[te])}var te=arguments.length-2;if(te===1)qe.children=Ce;else if(1<te){ve=Array(te);for(var Se=0;Se<te;Se++)ve[Se]=arguments[Se+2];qe.children=ve}return{$$typeof:s,type:F.type,key:we,ref:ie,props:qe,_owner:xe}},Nt.createContext=function(F){return F={$$typeof:u,_currentValue:F,_currentValue2:F,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},F.Provider={$$typeof:l,_context:F},F.Consumer=F},Nt.createElement=T,Nt.createFactory=function(F){var Y=T.bind(null,F);return Y.type=F,Y},Nt.createRef=function(){return{current:null}},Nt.forwardRef=function(F){return{$$typeof:h,render:F}},Nt.isValidElement=z,Nt.lazy=function(F){return{$$typeof:g,_payload:{_status:-1,_result:F},_init:de}},Nt.memo=function(F,Y){return{$$typeof:f,type:F,compare:Y===void 0?null:Y}},Nt.startTransition=function(F){var Y=Z.transition;Z.transition={};try{F()}finally{Z.transition=Y}},Nt.unstable_act=ce,Nt.useCallback=function(F,Y){return oe.current.useCallback(F,Y)},Nt.useContext=function(F){return oe.current.useContext(F)},Nt.useDebugValue=function(){},Nt.useDeferredValue=function(F){return oe.current.useDeferredValue(F)},Nt.useEffect=function(F,Y){return oe.current.useEffect(F,Y)},Nt.useId=function(){return oe.current.useId()},Nt.useImperativeHandle=function(F,Y,Ce){return oe.current.useImperativeHandle(F,Y,Ce)},Nt.useInsertionEffect=function(F,Y){return oe.current.useInsertionEffect(F,Y)},Nt.useLayoutEffect=function(F,Y){return oe.current.useLayoutEffect(F,Y)},Nt.useMemo=function(F,Y){return oe.current.useMemo(F,Y)},Nt.useReducer=function(F,Y,Ce){return oe.current.useReducer(F,Y,Ce)},Nt.useRef=function(F){return oe.current.useRef(F)},Nt.useState=function(F){return oe.current.useState(F)},Nt.useSyncExternalStore=function(F,Y,Ce){return oe.current.useSyncExternalStore(F,Y,Ce)},Nt.useTransition=function(){return oe.current.useTransition()},Nt.version="18.3.1",Nt}var km;function Xh(){return km||(km=1,dd.exports=Ov()),dd.exports}/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Fm;function Bv(){if(Fm)return so;Fm=1;var s=Xh(),e=Symbol.for("react.element"),t=Symbol.for("react.fragment"),r=Object.prototype.hasOwnProperty,a=s.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,l={key:!0,ref:!0,__self:!0,__source:!0};function u(h,p,f){var g,b={},v=null,S=null;f!==void 0&&(v=""+f),p.key!==void 0&&(v=""+p.key),p.ref!==void 0&&(S=p.ref);for(g in p)r.call(p,g)&&!l.hasOwnProperty(g)&&(b[g]=p[g]);if(h&&h.defaultProps)for(g in p=h.defaultProps,p)b[g]===void 0&&(b[g]=p[g]);return{$$typeof:e,type:h,key:v,ref:S,props:b,_owner:a.current}}return so.Fragment=t,so.jsx=u,so.jsxs=u,so}var Um;function zv(){return Um||(Um=1,ud.exports=Bv()),ud.exports}var c=zv(),K=Xh();const jv=og(K);var Rl={},hd={exports:{}},ni={},fd={exports:{}},pd={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Om;function Hv(){return Om||(Om=1,(function(s){function e(Z,ee){var ce=Z.length;Z.push(ee);e:for(;0<ce;){var F=ce-1>>>1,Y=Z[F];if(0<a(Y,ee))Z[F]=ee,Z[ce]=Y,ce=F;else break e}}function t(Z){return Z.length===0?null:Z[0]}function r(Z){if(Z.length===0)return null;var ee=Z[0],ce=Z.pop();if(ce!==ee){Z[0]=ce;e:for(var F=0,Y=Z.length,Ce=Y>>>1;F<Ce;){var qe=2*(F+1)-1,we=Z[qe],ie=qe+1,xe=Z[ie];if(0>a(we,ce))ie<Y&&0>a(xe,we)?(Z[F]=xe,Z[ie]=ce,F=ie):(Z[F]=we,Z[qe]=ce,F=qe);else if(ie<Y&&0>a(xe,ce))Z[F]=xe,Z[ie]=ce,F=ie;else break e}}return ee}function a(Z,ee){var ce=Z.sortIndex-ee.sortIndex;return ce!==0?ce:Z.id-ee.id}if(typeof performance=="object"&&typeof performance.now=="function"){var l=performance;s.unstable_now=function(){return l.now()}}else{var u=Date,h=u.now();s.unstable_now=function(){return u.now()-h}}var p=[],f=[],g=1,b=null,v=3,S=!1,M=!1,E=!1,x=typeof setTimeout=="function"?setTimeout:null,_=typeof clearTimeout=="function"?clearTimeout:null,N=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function P(Z){for(var ee=t(f);ee!==null;){if(ee.callback===null)r(f);else if(ee.startTime<=Z)r(f),ee.sortIndex=ee.expirationTime,e(p,ee);else break;ee=t(f)}}function C(Z){if(E=!1,P(Z),!M)if(t(p)!==null)M=!0,de(k);else{var ee=t(f);ee!==null&&oe(C,ee.startTime-Z)}}function k(Z,ee){M=!1,E&&(E=!1,_(T),T=-1),S=!0;var ce=v;try{for(P(ee),b=t(p);b!==null&&(!(b.expirationTime>ee)||Z&&!O());){var F=b.callback;if(typeof F=="function"){b.callback=null,v=b.priorityLevel;var Y=F(b.expirationTime<=ee);ee=s.unstable_now(),typeof Y=="function"?b.callback=Y:b===t(p)&&r(p),P(ee)}else r(p);b=t(p)}if(b!==null)var Ce=!0;else{var qe=t(f);qe!==null&&oe(C,qe.startTime-ee),Ce=!1}return Ce}finally{b=null,v=ce,S=!1}}var D=!1,U=null,T=-1,I=5,z=-1;function O(){return!(s.unstable_now()-z<I)}function H(){if(U!==null){var Z=s.unstable_now();z=Z;var ee=!0;try{ee=U(!0,Z)}finally{ee?fe():(D=!1,U=null)}}else D=!1}var fe;if(typeof N=="function")fe=function(){N(H)};else if(typeof MessageChannel<"u"){var re=new MessageChannel,q=re.port2;re.port1.onmessage=H,fe=function(){q.postMessage(null)}}else fe=function(){x(H,0)};function de(Z){U=Z,D||(D=!0,fe())}function oe(Z,ee){T=x(function(){Z(s.unstable_now())},ee)}s.unstable_IdlePriority=5,s.unstable_ImmediatePriority=1,s.unstable_LowPriority=4,s.unstable_NormalPriority=3,s.unstable_Profiling=null,s.unstable_UserBlockingPriority=2,s.unstable_cancelCallback=function(Z){Z.callback=null},s.unstable_continueExecution=function(){M||S||(M=!0,de(k))},s.unstable_forceFrameRate=function(Z){0>Z||125<Z?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):I=0<Z?Math.floor(1e3/Z):5},s.unstable_getCurrentPriorityLevel=function(){return v},s.unstable_getFirstCallbackNode=function(){return t(p)},s.unstable_next=function(Z){switch(v){case 1:case 2:case 3:var ee=3;break;default:ee=v}var ce=v;v=ee;try{return Z()}finally{v=ce}},s.unstable_pauseExecution=function(){},s.unstable_requestPaint=function(){},s.unstable_runWithPriority=function(Z,ee){switch(Z){case 1:case 2:case 3:case 4:case 5:break;default:Z=3}var ce=v;v=Z;try{return ee()}finally{v=ce}},s.unstable_scheduleCallback=function(Z,ee,ce){var F=s.unstable_now();switch(typeof ce=="object"&&ce!==null?(ce=ce.delay,ce=typeof ce=="number"&&0<ce?F+ce:F):ce=F,Z){case 1:var Y=-1;break;case 2:Y=250;break;case 5:Y=1073741823;break;case 4:Y=1e4;break;default:Y=5e3}return Y=ce+Y,Z={id:g++,callback:ee,priorityLevel:Z,startTime:ce,expirationTime:Y,sortIndex:-1},ce>F?(Z.sortIndex=ce,e(f,Z),t(p)===null&&Z===t(f)&&(E?(_(T),T=-1):E=!0,oe(C,ce-F))):(Z.sortIndex=Y,e(p,Z),M||S||(M=!0,de(k))),Z},s.unstable_shouldYield=O,s.unstable_wrapCallback=function(Z){var ee=v;return function(){var ce=v;v=ee;try{return Z.apply(this,arguments)}finally{v=ce}}}})(pd)),pd}var Bm;function Vv(){return Bm||(Bm=1,fd.exports=Hv()),fd.exports}/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var zm;function Gv(){if(zm)return ni;zm=1;var s=Xh(),e=Vv();function t(n){for(var i="https://reactjs.org/docs/error-decoder.html?invariant="+n,o=1;o<arguments.length;o++)i+="&args[]="+encodeURIComponent(arguments[o]);return"Minified React error #"+n+"; visit "+i+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var r=new Set,a={};function l(n,i){u(n,i),u(n+"Capture",i)}function u(n,i){for(a[n]=i,n=0;n<i.length;n++)r.add(i[n])}var h=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),p=Object.prototype.hasOwnProperty,f=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,g={},b={};function v(n){return p.call(b,n)?!0:p.call(g,n)?!1:f.test(n)?b[n]=!0:(g[n]=!0,!1)}function S(n,i,o,d){if(o!==null&&o.type===0)return!1;switch(typeof i){case"function":case"symbol":return!0;case"boolean":return d?!1:o!==null?!o.acceptsBooleans:(n=n.toLowerCase().slice(0,5),n!=="data-"&&n!=="aria-");default:return!1}}function M(n,i,o,d){if(i===null||typeof i>"u"||S(n,i,o,d))return!0;if(d)return!1;if(o!==null)switch(o.type){case 3:return!i;case 4:return i===!1;case 5:return isNaN(i);case 6:return isNaN(i)||1>i}return!1}function E(n,i,o,d,m,y,A){this.acceptsBooleans=i===2||i===3||i===4,this.attributeName=d,this.attributeNamespace=m,this.mustUseProperty=o,this.propertyName=n,this.type=i,this.sanitizeURL=y,this.removeEmptyString=A}var x={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(n){x[n]=new E(n,0,!1,n,null,!1,!1)}),[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(n){var i=n[0];x[i]=new E(i,1,!1,n[1],null,!1,!1)}),["contentEditable","draggable","spellCheck","value"].forEach(function(n){x[n]=new E(n,2,!1,n.toLowerCase(),null,!1,!1)}),["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(n){x[n]=new E(n,2,!1,n,null,!1,!1)}),"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(n){x[n]=new E(n,3,!1,n.toLowerCase(),null,!1,!1)}),["checked","multiple","muted","selected"].forEach(function(n){x[n]=new E(n,3,!0,n,null,!1,!1)}),["capture","download"].forEach(function(n){x[n]=new E(n,4,!1,n,null,!1,!1)}),["cols","rows","size","span"].forEach(function(n){x[n]=new E(n,6,!1,n,null,!1,!1)}),["rowSpan","start"].forEach(function(n){x[n]=new E(n,5,!1,n.toLowerCase(),null,!1,!1)});var _=/[\-:]([a-z])/g;function N(n){return n[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(n){var i=n.replace(_,N);x[i]=new E(i,1,!1,n,null,!1,!1)}),"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(n){var i=n.replace(_,N);x[i]=new E(i,1,!1,n,"http://www.w3.org/1999/xlink",!1,!1)}),["xml:base","xml:lang","xml:space"].forEach(function(n){var i=n.replace(_,N);x[i]=new E(i,1,!1,n,"http://www.w3.org/XML/1998/namespace",!1,!1)}),["tabIndex","crossOrigin"].forEach(function(n){x[n]=new E(n,1,!1,n.toLowerCase(),null,!1,!1)}),x.xlinkHref=new E("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1),["src","href","action","formAction"].forEach(function(n){x[n]=new E(n,1,!1,n.toLowerCase(),null,!0,!0)});function P(n,i,o,d){var m=x.hasOwnProperty(i)?x[i]:null;(m!==null?m.type!==0:d||!(2<i.length)||i[0]!=="o"&&i[0]!=="O"||i[1]!=="n"&&i[1]!=="N")&&(M(i,o,m,d)&&(o=null),d||m===null?v(i)&&(o===null?n.removeAttribute(i):n.setAttribute(i,""+o)):m.mustUseProperty?n[m.propertyName]=o===null?m.type===3?!1:"":o:(i=m.attributeName,d=m.attributeNamespace,o===null?n.removeAttribute(i):(m=m.type,o=m===3||m===4&&o===!0?"":""+o,d?n.setAttributeNS(d,i,o):n.setAttribute(i,o))))}var C=s.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,k=Symbol.for("react.element"),D=Symbol.for("react.portal"),U=Symbol.for("react.fragment"),T=Symbol.for("react.strict_mode"),I=Symbol.for("react.profiler"),z=Symbol.for("react.provider"),O=Symbol.for("react.context"),H=Symbol.for("react.forward_ref"),fe=Symbol.for("react.suspense"),re=Symbol.for("react.suspense_list"),q=Symbol.for("react.memo"),de=Symbol.for("react.lazy"),oe=Symbol.for("react.offscreen"),Z=Symbol.iterator;function ee(n){return n===null||typeof n!="object"?null:(n=Z&&n[Z]||n["@@iterator"],typeof n=="function"?n:null)}var ce=Object.assign,F;function Y(n){if(F===void 0)try{throw Error()}catch(o){var i=o.stack.trim().match(/\n( *(at )?)/);F=i&&i[1]||""}return`
`+F+n}var Ce=!1;function qe(n,i){if(!n||Ce)return"";Ce=!0;var o=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(i)if(i=function(){throw Error()},Object.defineProperty(i.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(i,[])}catch(ge){var d=ge}Reflect.construct(n,[],i)}else{try{i.call()}catch(ge){d=ge}n.call(i.prototype)}else{try{throw Error()}catch(ge){d=ge}n()}}catch(ge){if(ge&&d&&typeof ge.stack=="string"){for(var m=ge.stack.split(`
`),y=d.stack.split(`
`),A=m.length-1,B=y.length-1;1<=A&&0<=B&&m[A]!==y[B];)B--;for(;1<=A&&0<=B;A--,B--)if(m[A]!==y[B]){if(A!==1||B!==1)do if(A--,B--,0>B||m[A]!==y[B]){var V=`
`+m[A].replace(" at new "," at ");return n.displayName&&V.includes("<anonymous>")&&(V=V.replace("<anonymous>",n.displayName)),V}while(1<=A&&0<=B);break}}}finally{Ce=!1,Error.prepareStackTrace=o}return(n=n?n.displayName||n.name:"")?Y(n):""}function we(n){switch(n.tag){case 5:return Y(n.type);case 16:return Y("Lazy");case 13:return Y("Suspense");case 19:return Y("SuspenseList");case 0:case 2:case 15:return n=qe(n.type,!1),n;case 11:return n=qe(n.type.render,!1),n;case 1:return n=qe(n.type,!0),n;default:return""}}function ie(n){if(n==null)return null;if(typeof n=="function")return n.displayName||n.name||null;if(typeof n=="string")return n;switch(n){case U:return"Fragment";case D:return"Portal";case I:return"Profiler";case T:return"StrictMode";case fe:return"Suspense";case re:return"SuspenseList"}if(typeof n=="object")switch(n.$$typeof){case O:return(n.displayName||"Context")+".Consumer";case z:return(n._context.displayName||"Context")+".Provider";case H:var i=n.render;return n=n.displayName,n||(n=i.displayName||i.name||"",n=n!==""?"ForwardRef("+n+")":"ForwardRef"),n;case q:return i=n.displayName||null,i!==null?i:ie(n.type)||"Memo";case de:i=n._payload,n=n._init;try{return ie(n(i))}catch{}}return null}function xe(n){var i=n.type;switch(n.tag){case 24:return"Cache";case 9:return(i.displayName||"Context")+".Consumer";case 10:return(i._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return n=i.render,n=n.displayName||n.name||"",i.displayName||(n!==""?"ForwardRef("+n+")":"ForwardRef");case 7:return"Fragment";case 5:return i;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return ie(i);case 8:return i===T?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof i=="function")return i.displayName||i.name||null;if(typeof i=="string")return i}return null}function ve(n){switch(typeof n){case"boolean":case"number":case"string":case"undefined":return n;case"object":return n;default:return""}}function te(n){var i=n.type;return(n=n.nodeName)&&n.toLowerCase()==="input"&&(i==="checkbox"||i==="radio")}function Se(n){var i=te(n)?"checked":"value",o=Object.getOwnPropertyDescriptor(n.constructor.prototype,i),d=""+n[i];if(!n.hasOwnProperty(i)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var m=o.get,y=o.set;return Object.defineProperty(n,i,{configurable:!0,get:function(){return m.call(this)},set:function(A){d=""+A,y.call(this,A)}}),Object.defineProperty(n,i,{enumerable:o.enumerable}),{getValue:function(){return d},setValue:function(A){d=""+A},stopTracking:function(){n._valueTracker=null,delete n[i]}}}}function Qe(n){n._valueTracker||(n._valueTracker=Se(n))}function Ft(n){if(!n)return!1;var i=n._valueTracker;if(!i)return!0;var o=i.getValue(),d="";return n&&(d=te(n)?n.checked?"true":"false":n.value),n=d,n!==o?(i.setValue(n),!0):!1}function ut(n){if(n=n||(typeof document<"u"?document:void 0),typeof n>"u")return null;try{return n.activeElement||n.body}catch{return n.body}}function Ct(n,i){var o=i.checked;return ce({},i,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:o??n._wrapperState.initialChecked})}function it(n,i){var o=i.defaultValue==null?"":i.defaultValue,d=i.checked!=null?i.checked:i.defaultChecked;o=ve(i.value!=null?i.value:o),n._wrapperState={initialChecked:d,initialValue:o,controlled:i.type==="checkbox"||i.type==="radio"?i.checked!=null:i.value!=null}}function Je(n,i){i=i.checked,i!=null&&P(n,"checked",i,!1)}function Lt(n,i){Je(n,i);var o=ve(i.value),d=i.type;if(o!=null)d==="number"?(o===0&&n.value===""||n.value!=o)&&(n.value=""+o):n.value!==""+o&&(n.value=""+o);else if(d==="submit"||d==="reset"){n.removeAttribute("value");return}i.hasOwnProperty("value")?St(n,i.type,o):i.hasOwnProperty("defaultValue")&&St(n,i.type,ve(i.defaultValue)),i.checked==null&&i.defaultChecked!=null&&(n.defaultChecked=!!i.defaultChecked)}function zt(n,i,o){if(i.hasOwnProperty("value")||i.hasOwnProperty("defaultValue")){var d=i.type;if(!(d!=="submit"&&d!=="reset"||i.value!==void 0&&i.value!==null))return;i=""+n._wrapperState.initialValue,o||i===n.value||(n.value=i),n.defaultValue=i}o=n.name,o!==""&&(n.name=""),n.defaultChecked=!!n._wrapperState.initialChecked,o!==""&&(n.name=o)}function St(n,i,o){(i!=="number"||ut(n.ownerDocument)!==n)&&(o==null?n.defaultValue=""+n._wrapperState.initialValue:n.defaultValue!==""+o&&(n.defaultValue=""+o))}var Dt=Array.isArray;function wt(n,i,o,d){if(n=n.options,i){i={};for(var m=0;m<o.length;m++)i["$"+o[m]]=!0;for(o=0;o<n.length;o++)m=i.hasOwnProperty("$"+n[o].value),n[o].selected!==m&&(n[o].selected=m),m&&d&&(n[o].defaultSelected=!0)}else{for(o=""+ve(o),i=null,m=0;m<n.length;m++){if(n[m].value===o){n[m].selected=!0,d&&(n[m].defaultSelected=!0);return}i!==null||n[m].disabled||(i=n[m])}i!==null&&(i.selected=!0)}}function ct(n,i){if(i.dangerouslySetInnerHTML!=null)throw Error(t(91));return ce({},i,{value:void 0,defaultValue:void 0,children:""+n._wrapperState.initialValue})}function Q(n,i){var o=i.value;if(o==null){if(o=i.children,i=i.defaultValue,o!=null){if(i!=null)throw Error(t(92));if(Dt(o)){if(1<o.length)throw Error(t(93));o=o[0]}i=o}i==null&&(i=""),o=i}n._wrapperState={initialValue:ve(o)}}function et(n,i){var o=ve(i.value),d=ve(i.defaultValue);o!=null&&(o=""+o,o!==n.value&&(n.value=o),i.defaultValue==null&&n.defaultValue!==o&&(n.defaultValue=o)),d!=null&&(n.defaultValue=""+d)}function ze(n){var i=n.textContent;i===n._wrapperState.initialValue&&i!==""&&i!==null&&(n.value=i)}function L(n){switch(n){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function w(n,i){return n==null||n==="http://www.w3.org/1999/xhtml"?L(i):n==="http://www.w3.org/2000/svg"&&i==="foreignObject"?"http://www.w3.org/1999/xhtml":n}var $,ae=(function(n){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(i,o,d,m){MSApp.execUnsafeLocalFunction(function(){return n(i,o,d,m)})}:n})(function(n,i){if(n.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in n)n.innerHTML=i;else{for($=$||document.createElement("div"),$.innerHTML="<svg>"+i.valueOf().toString()+"</svg>",i=$.firstChild;n.firstChild;)n.removeChild(n.firstChild);for(;i.firstChild;)n.appendChild(i.firstChild)}});function me(n,i){if(i){var o=n.firstChild;if(o&&o===n.lastChild&&o.nodeType===3){o.nodeValue=i;return}}n.textContent=i}var Me={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},Ne=["Webkit","ms","Moz","O"];Object.keys(Me).forEach(function(n){Ne.forEach(function(i){i=i+n.charAt(0).toUpperCase()+n.substring(1),Me[i]=Me[n]})});function ue(n,i,o){return i==null||typeof i=="boolean"||i===""?"":o||typeof i!="number"||i===0||Me.hasOwnProperty(n)&&Me[n]?(""+i).trim():i+"px"}function ye(n,i){n=n.style;for(var o in i)if(i.hasOwnProperty(o)){var d=o.indexOf("--")===0,m=ue(o,i[o],d);o==="float"&&(o="cssFloat"),d?n.setProperty(o,m):n[o]=m}}var Ee=ce({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function He(n,i){if(i){if(Ee[n]&&(i.children!=null||i.dangerouslySetInnerHTML!=null))throw Error(t(137,n));if(i.dangerouslySetInnerHTML!=null){if(i.children!=null)throw Error(t(60));if(typeof i.dangerouslySetInnerHTML!="object"||!("__html"in i.dangerouslySetInnerHTML))throw Error(t(61))}if(i.style!=null&&typeof i.style!="object")throw Error(t(62))}}function Ie(n,i){if(n.indexOf("-")===-1)return typeof i.is=="string";switch(n){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var ke=null;function We(n){return n=n.target||n.srcElement||window,n.correspondingUseElement&&(n=n.correspondingUseElement),n.nodeType===3?n.parentNode:n}var Ze=null,at=null,G=null;function Fe(n){if(n=Ga(n)){if(typeof Ze!="function")throw Error(t(280));var i=n.stateNode;i&&(i=Go(i),Ze(n.stateNode,n.type,i))}}function j(n){at?G?G.push(n):G=[n]:at=n}function be(){if(at){var n=at,i=G;if(G=at=null,Fe(n),i)for(n=0;n<i.length;n++)Fe(i[n])}}function Re(n,i){return n(i)}function _e(){}var Be=!1;function je(n,i,o){if(Be)return n(i,o);Be=!0;try{return Re(n,i,o)}finally{Be=!1,(at!==null||G!==null)&&(_e(),be())}}function ht(n,i){var o=n.stateNode;if(o===null)return null;var d=Go(o);if(d===null)return null;o=d[i];e:switch(i){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(d=!d.disabled)||(n=n.type,d=!(n==="button"||n==="input"||n==="select"||n==="textarea")),n=!d;break e;default:n=!1}if(n)return null;if(o&&typeof o!="function")throw Error(t(231,i,typeof o));return o}var Et=!1;if(h)try{var $t={};Object.defineProperty($t,"passive",{get:function(){Et=!0}}),window.addEventListener("test",$t,$t),window.removeEventListener("test",$t,$t)}catch{Et=!1}function It(n,i,o,d,m,y,A,B,V){var ge=Array.prototype.slice.call(arguments,3);try{i.apply(o,ge)}catch(Pe){this.onError(Pe)}}var tn=!1,Cn=null,Hn=!1,Rn=null,br={onError:function(n){tn=!0,Cn=n}};function zi(n,i,o,d,m,y,A,B,V){tn=!1,Cn=null,It.apply(br,arguments)}function Ts(n,i,o,d,m,y,A,B,V){if(zi.apply(this,arguments),tn){if(tn){var ge=Cn;tn=!1,Cn=null}else throw Error(t(198));Hn||(Hn=!0,Rn=ge)}}function Sn(n){var i=n,o=n;if(n.alternate)for(;i.return;)i=i.return;else{n=i;do i=n,(i.flags&4098)!==0&&(o=i.return),n=i.return;while(n)}return i.tag===3?o:null}function ji(n){if(n.tag===13){var i=n.memoizedState;if(i===null&&(n=n.alternate,n!==null&&(i=n.memoizedState)),i!==null)return i.dehydrated}return null}function tr(n){if(Sn(n)!==n)throw Error(t(188))}function ts(n){var i=n.alternate;if(!i){if(i=Sn(n),i===null)throw Error(t(188));return i!==n?null:n}for(var o=n,d=i;;){var m=o.return;if(m===null)break;var y=m.alternate;if(y===null){if(d=m.return,d!==null){o=d;continue}break}if(m.child===y.child){for(y=m.child;y;){if(y===o)return tr(m),n;if(y===d)return tr(m),i;y=y.sibling}throw Error(t(188))}if(o.return!==d.return)o=m,d=y;else{for(var A=!1,B=m.child;B;){if(B===o){A=!0,o=m,d=y;break}if(B===d){A=!0,d=m,o=y;break}B=B.sibling}if(!A){for(B=y.child;B;){if(B===o){A=!0,o=y,d=m;break}if(B===d){A=!0,d=y,o=m;break}B=B.sibling}if(!A)throw Error(t(189))}}if(o.alternate!==d)throw Error(t(190))}if(o.tag!==3)throw Error(t(188));return o.stateNode.current===o?n:i}function xt(n){return n=ts(n),n!==null?jt(n):null}function jt(n){if(n.tag===5||n.tag===6)return n;for(n=n.child;n!==null;){var i=jt(n);if(i!==null)return i;n=n.sibling}return null}var nn=e.unstable_scheduleCallback,rn=e.unstable_cancelCallback,hn=e.unstable_shouldYield,ln=e.unstable_requestPaint,bt=e.unstable_now,nr=e.unstable_getCurrentPriorityLevel,Hi=e.unstable_ImmediatePriority,R=e.unstable_UserBlockingPriority,W=e.unstable_NormalPriority,le=e.unstable_LowPriority,se=e.unstable_IdlePriority,ne=null,Te=null;function Oe(n){if(Te&&typeof Te.onCommitFiberRoot=="function")try{Te.onCommitFiberRoot(ne,n,void 0,(n.current.flags&128)===128)}catch{}}var Le=Math.clz32?Math.clz32:lt,Xe=Math.log,Ve=Math.LN2;function lt(n){return n>>>=0,n===0?32:31-(Xe(n)/Ve|0)|0}var mt=64,$e=4194304;function Rt(n){switch(n&-n){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return n&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return n}}function Xt(n,i){var o=n.pendingLanes;if(o===0)return 0;var d=0,m=n.suspendedLanes,y=n.pingedLanes,A=o&268435455;if(A!==0){var B=A&~m;B!==0?d=Rt(B):(y&=A,y!==0&&(d=Rt(y)))}else A=o&~m,A!==0?d=Rt(A):y!==0&&(d=Rt(y));if(d===0)return 0;if(i!==0&&i!==d&&(i&m)===0&&(m=d&-d,y=i&-i,m>=y||m===16&&(y&4194240)!==0))return i;if((d&4)!==0&&(d|=o&16),i=n.entangledLanes,i!==0)for(n=n.entanglements,i&=d;0<i;)o=31-Le(i),m=1<<o,d|=n[o],i&=~m;return d}function Yt(n,i){switch(n){case 1:case 2:case 4:return i+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return i+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Vt(n,i){for(var o=n.suspendedLanes,d=n.pingedLanes,m=n.expirationTimes,y=n.pendingLanes;0<y;){var A=31-Le(y),B=1<<A,V=m[A];V===-1?((B&o)===0||(B&d)!==0)&&(m[A]=Yt(B,i)):V<=i&&(n.expiredLanes|=B),y&=~B}}function fn(n){return n=n.pendingLanes&-1073741825,n!==0?n:n&1073741824?1073741824:0}function Ye(){var n=mt;return mt<<=1,(mt&4194240)===0&&(mt=64),n}function Pn(n){for(var i=[],o=0;31>o;o++)i.push(n);return i}function Tt(n,i,o){n.pendingLanes|=i,i!==536870912&&(n.suspendedLanes=0,n.pingedLanes=0),n=n.eventTimes,i=31-Le(i),n[i]=o}function Yn(n,i){var o=n.pendingLanes&~i;n.pendingLanes=i,n.suspendedLanes=0,n.pingedLanes=0,n.expiredLanes&=i,n.mutableReadLanes&=i,n.entangledLanes&=i,i=n.entanglements;var d=n.eventTimes;for(n=n.expirationTimes;0<o;){var m=31-Le(o),y=1<<m;i[m]=0,d[m]=-1,n[m]=-1,o&=~y}}function Kn(n,i){var o=n.entangledLanes|=i;for(n=n.entanglements;o;){var d=31-Le(o),m=1<<d;m&i|n[d]&i&&(n[d]|=i),o&=~m}}var Pt=0;function ir(n){return n&=-n,1<n?4<n?(n&268435455)!==0?16:536870912:4:1}var Ht,Zt,Ei,Gt,Ti,Vi=!1,ns=[],Sr=null,Mr=null,wr=null,Ca=new Map,Ra=new Map,Er=[],ax="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function xf(n,i){switch(n){case"focusin":case"focusout":Sr=null;break;case"dragenter":case"dragleave":Mr=null;break;case"mouseover":case"mouseout":wr=null;break;case"pointerover":case"pointerout":Ca.delete(i.pointerId);break;case"gotpointercapture":case"lostpointercapture":Ra.delete(i.pointerId)}}function Pa(n,i,o,d,m,y){return n===null||n.nativeEvent!==y?(n={blockedOn:i,domEventName:o,eventSystemFlags:d,nativeEvent:y,targetContainers:[m]},i!==null&&(i=Ga(i),i!==null&&Zt(i)),n):(n.eventSystemFlags|=d,i=n.targetContainers,m!==null&&i.indexOf(m)===-1&&i.push(m),n)}function ox(n,i,o,d,m){switch(i){case"focusin":return Sr=Pa(Sr,n,i,o,d,m),!0;case"dragenter":return Mr=Pa(Mr,n,i,o,d,m),!0;case"mouseover":return wr=Pa(wr,n,i,o,d,m),!0;case"pointerover":var y=m.pointerId;return Ca.set(y,Pa(Ca.get(y)||null,n,i,o,d,m)),!0;case"gotpointercapture":return y=m.pointerId,Ra.set(y,Pa(Ra.get(y)||null,n,i,o,d,m)),!0}return!1}function vf(n){var i=is(n.target);if(i!==null){var o=Sn(i);if(o!==null){if(i=o.tag,i===13){if(i=ji(o),i!==null){n.blockedOn=i,Ti(n.priority,function(){Ei(o)});return}}else if(i===3&&o.stateNode.current.memoizedState.isDehydrated){n.blockedOn=o.tag===3?o.stateNode.containerInfo:null;return}}}n.blockedOn=null}function Po(n){if(n.blockedOn!==null)return!1;for(var i=n.targetContainers;0<i.length;){var o=Uc(n.domEventName,n.eventSystemFlags,i[0],n.nativeEvent);if(o===null){o=n.nativeEvent;var d=new o.constructor(o.type,o);ke=d,o.target.dispatchEvent(d),ke=null}else return i=Ga(o),i!==null&&Zt(i),n.blockedOn=o,!1;i.shift()}return!0}function _f(n,i,o){Po(n)&&o.delete(i)}function lx(){Vi=!1,Sr!==null&&Po(Sr)&&(Sr=null),Mr!==null&&Po(Mr)&&(Mr=null),wr!==null&&Po(wr)&&(wr=null),Ca.forEach(_f),Ra.forEach(_f)}function Na(n,i){n.blockedOn===i&&(n.blockedOn=null,Vi||(Vi=!0,e.unstable_scheduleCallback(e.unstable_NormalPriority,lx)))}function La(n){function i(m){return Na(m,n)}if(0<ns.length){Na(ns[0],n);for(var o=1;o<ns.length;o++){var d=ns[o];d.blockedOn===n&&(d.blockedOn=null)}}for(Sr!==null&&Na(Sr,n),Mr!==null&&Na(Mr,n),wr!==null&&Na(wr,n),Ca.forEach(i),Ra.forEach(i),o=0;o<Er.length;o++)d=Er[o],d.blockedOn===n&&(d.blockedOn=null);for(;0<Er.length&&(o=Er[0],o.blockedOn===null);)vf(o),o.blockedOn===null&&Er.shift()}var As=C.ReactCurrentBatchConfig,No=!0;function cx(n,i,o,d){var m=Pt,y=As.transition;As.transition=null;try{Pt=1,Fc(n,i,o,d)}finally{Pt=m,As.transition=y}}function ux(n,i,o,d){var m=Pt,y=As.transition;As.transition=null;try{Pt=4,Fc(n,i,o,d)}finally{Pt=m,As.transition=y}}function Fc(n,i,o,d){if(No){var m=Uc(n,i,o,d);if(m===null)eu(n,i,d,Lo,o),xf(n,d);else if(ox(m,n,i,o,d))d.stopPropagation();else if(xf(n,d),i&4&&-1<ax.indexOf(n)){for(;m!==null;){var y=Ga(m);if(y!==null&&Ht(y),y=Uc(n,i,o,d),y===null&&eu(n,i,d,Lo,o),y===m)break;m=y}m!==null&&d.stopPropagation()}else eu(n,i,d,null,o)}}var Lo=null;function Uc(n,i,o,d){if(Lo=null,n=We(d),n=is(n),n!==null)if(i=Sn(n),i===null)n=null;else if(o=i.tag,o===13){if(n=ji(i),n!==null)return n;n=null}else if(o===3){if(i.stateNode.current.memoizedState.isDehydrated)return i.tag===3?i.stateNode.containerInfo:null;n=null}else i!==n&&(n=null);return Lo=n,null}function yf(n){switch(n){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(nr()){case Hi:return 1;case R:return 4;case W:case le:return 16;case se:return 536870912;default:return 16}default:return 16}}var Tr=null,Oc=null,Do=null;function bf(){if(Do)return Do;var n,i=Oc,o=i.length,d,m="value"in Tr?Tr.value:Tr.textContent,y=m.length;for(n=0;n<o&&i[n]===m[n];n++);var A=o-n;for(d=1;d<=A&&i[o-d]===m[y-d];d++);return Do=m.slice(n,1<d?1-d:void 0)}function Io(n){var i=n.keyCode;return"charCode"in n?(n=n.charCode,n===0&&i===13&&(n=13)):n=i,n===10&&(n=13),32<=n||n===13?n:0}function ko(){return!0}function Sf(){return!1}function oi(n){function i(o,d,m,y,A){this._reactName=o,this._targetInst=m,this.type=d,this.nativeEvent=y,this.target=A,this.currentTarget=null;for(var B in n)n.hasOwnProperty(B)&&(o=n[B],this[B]=o?o(y):y[B]);return this.isDefaultPrevented=(y.defaultPrevented!=null?y.defaultPrevented:y.returnValue===!1)?ko:Sf,this.isPropagationStopped=Sf,this}return ce(i.prototype,{preventDefault:function(){this.defaultPrevented=!0;var o=this.nativeEvent;o&&(o.preventDefault?o.preventDefault():typeof o.returnValue!="unknown"&&(o.returnValue=!1),this.isDefaultPrevented=ko)},stopPropagation:function(){var o=this.nativeEvent;o&&(o.stopPropagation?o.stopPropagation():typeof o.cancelBubble!="unknown"&&(o.cancelBubble=!0),this.isPropagationStopped=ko)},persist:function(){},isPersistent:ko}),i}var Cs={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(n){return n.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Bc=oi(Cs),Da=ce({},Cs,{view:0,detail:0}),dx=oi(Da),zc,jc,Ia,Fo=ce({},Da,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Vc,button:0,buttons:0,relatedTarget:function(n){return n.relatedTarget===void 0?n.fromElement===n.srcElement?n.toElement:n.fromElement:n.relatedTarget},movementX:function(n){return"movementX"in n?n.movementX:(n!==Ia&&(Ia&&n.type==="mousemove"?(zc=n.screenX-Ia.screenX,jc=n.screenY-Ia.screenY):jc=zc=0,Ia=n),zc)},movementY:function(n){return"movementY"in n?n.movementY:jc}}),Mf=oi(Fo),hx=ce({},Fo,{dataTransfer:0}),fx=oi(hx),px=ce({},Da,{relatedTarget:0}),Hc=oi(px),mx=ce({},Cs,{animationName:0,elapsedTime:0,pseudoElement:0}),gx=oi(mx),xx=ce({},Cs,{clipboardData:function(n){return"clipboardData"in n?n.clipboardData:window.clipboardData}}),vx=oi(xx),_x=ce({},Cs,{data:0}),wf=oi(_x),yx={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},bx={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Sx={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Mx(n){var i=this.nativeEvent;return i.getModifierState?i.getModifierState(n):(n=Sx[n])?!!i[n]:!1}function Vc(){return Mx}var wx=ce({},Da,{key:function(n){if(n.key){var i=yx[n.key]||n.key;if(i!=="Unidentified")return i}return n.type==="keypress"?(n=Io(n),n===13?"Enter":String.fromCharCode(n)):n.type==="keydown"||n.type==="keyup"?bx[n.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Vc,charCode:function(n){return n.type==="keypress"?Io(n):0},keyCode:function(n){return n.type==="keydown"||n.type==="keyup"?n.keyCode:0},which:function(n){return n.type==="keypress"?Io(n):n.type==="keydown"||n.type==="keyup"?n.keyCode:0}}),Ex=oi(wx),Tx=ce({},Fo,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Ef=oi(Tx),Ax=ce({},Da,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Vc}),Cx=oi(Ax),Rx=ce({},Cs,{propertyName:0,elapsedTime:0,pseudoElement:0}),Px=oi(Rx),Nx=ce({},Fo,{deltaX:function(n){return"deltaX"in n?n.deltaX:"wheelDeltaX"in n?-n.wheelDeltaX:0},deltaY:function(n){return"deltaY"in n?n.deltaY:"wheelDeltaY"in n?-n.wheelDeltaY:"wheelDelta"in n?-n.wheelDelta:0},deltaZ:0,deltaMode:0}),Lx=oi(Nx),Dx=[9,13,27,32],Gc=h&&"CompositionEvent"in window,ka=null;h&&"documentMode"in document&&(ka=document.documentMode);var Ix=h&&"TextEvent"in window&&!ka,Tf=h&&(!Gc||ka&&8<ka&&11>=ka),Af=" ",Cf=!1;function Rf(n,i){switch(n){case"keyup":return Dx.indexOf(i.keyCode)!==-1;case"keydown":return i.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Pf(n){return n=n.detail,typeof n=="object"&&"data"in n?n.data:null}var Rs=!1;function kx(n,i){switch(n){case"compositionend":return Pf(i);case"keypress":return i.which!==32?null:(Cf=!0,Af);case"textInput":return n=i.data,n===Af&&Cf?null:n;default:return null}}function Fx(n,i){if(Rs)return n==="compositionend"||!Gc&&Rf(n,i)?(n=bf(),Do=Oc=Tr=null,Rs=!1,n):null;switch(n){case"paste":return null;case"keypress":if(!(i.ctrlKey||i.altKey||i.metaKey)||i.ctrlKey&&i.altKey){if(i.char&&1<i.char.length)return i.char;if(i.which)return String.fromCharCode(i.which)}return null;case"compositionend":return Tf&&i.locale!=="ko"?null:i.data;default:return null}}var Ux={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Nf(n){var i=n&&n.nodeName&&n.nodeName.toLowerCase();return i==="input"?!!Ux[n.type]:i==="textarea"}function Lf(n,i,o,d){j(d),i=jo(i,"onChange"),0<i.length&&(o=new Bc("onChange","change",null,o,d),n.push({event:o,listeners:i}))}var Fa=null,Ua=null;function Ox(n){Kf(n,0)}function Uo(n){var i=Is(n);if(Ft(i))return n}function Bx(n,i){if(n==="change")return i}var Df=!1;if(h){var Wc;if(h){var Xc="oninput"in document;if(!Xc){var If=document.createElement("div");If.setAttribute("oninput","return;"),Xc=typeof If.oninput=="function"}Wc=Xc}else Wc=!1;Df=Wc&&(!document.documentMode||9<document.documentMode)}function kf(){Fa&&(Fa.detachEvent("onpropertychange",Ff),Ua=Fa=null)}function Ff(n){if(n.propertyName==="value"&&Uo(Ua)){var i=[];Lf(i,Ua,n,We(n)),je(Ox,i)}}function zx(n,i,o){n==="focusin"?(kf(),Fa=i,Ua=o,Fa.attachEvent("onpropertychange",Ff)):n==="focusout"&&kf()}function jx(n){if(n==="selectionchange"||n==="keyup"||n==="keydown")return Uo(Ua)}function Hx(n,i){if(n==="click")return Uo(i)}function Vx(n,i){if(n==="input"||n==="change")return Uo(i)}function Gx(n,i){return n===i&&(n!==0||1/n===1/i)||n!==n&&i!==i}var Ai=typeof Object.is=="function"?Object.is:Gx;function Oa(n,i){if(Ai(n,i))return!0;if(typeof n!="object"||n===null||typeof i!="object"||i===null)return!1;var o=Object.keys(n),d=Object.keys(i);if(o.length!==d.length)return!1;for(d=0;d<o.length;d++){var m=o[d];if(!p.call(i,m)||!Ai(n[m],i[m]))return!1}return!0}function Uf(n){for(;n&&n.firstChild;)n=n.firstChild;return n}function Of(n,i){var o=Uf(n);n=0;for(var d;o;){if(o.nodeType===3){if(d=n+o.textContent.length,n<=i&&d>=i)return{node:o,offset:i-n};n=d}e:{for(;o;){if(o.nextSibling){o=o.nextSibling;break e}o=o.parentNode}o=void 0}o=Uf(o)}}function Bf(n,i){return n&&i?n===i?!0:n&&n.nodeType===3?!1:i&&i.nodeType===3?Bf(n,i.parentNode):"contains"in n?n.contains(i):n.compareDocumentPosition?!!(n.compareDocumentPosition(i)&16):!1:!1}function zf(){for(var n=window,i=ut();i instanceof n.HTMLIFrameElement;){try{var o=typeof i.contentWindow.location.href=="string"}catch{o=!1}if(o)n=i.contentWindow;else break;i=ut(n.document)}return i}function qc(n){var i=n&&n.nodeName&&n.nodeName.toLowerCase();return i&&(i==="input"&&(n.type==="text"||n.type==="search"||n.type==="tel"||n.type==="url"||n.type==="password")||i==="textarea"||n.contentEditable==="true")}function Wx(n){var i=zf(),o=n.focusedElem,d=n.selectionRange;if(i!==o&&o&&o.ownerDocument&&Bf(o.ownerDocument.documentElement,o)){if(d!==null&&qc(o)){if(i=d.start,n=d.end,n===void 0&&(n=i),"selectionStart"in o)o.selectionStart=i,o.selectionEnd=Math.min(n,o.value.length);else if(n=(i=o.ownerDocument||document)&&i.defaultView||window,n.getSelection){n=n.getSelection();var m=o.textContent.length,y=Math.min(d.start,m);d=d.end===void 0?y:Math.min(d.end,m),!n.extend&&y>d&&(m=d,d=y,y=m),m=Of(o,y);var A=Of(o,d);m&&A&&(n.rangeCount!==1||n.anchorNode!==m.node||n.anchorOffset!==m.offset||n.focusNode!==A.node||n.focusOffset!==A.offset)&&(i=i.createRange(),i.setStart(m.node,m.offset),n.removeAllRanges(),y>d?(n.addRange(i),n.extend(A.node,A.offset)):(i.setEnd(A.node,A.offset),n.addRange(i)))}}for(i=[],n=o;n=n.parentNode;)n.nodeType===1&&i.push({element:n,left:n.scrollLeft,top:n.scrollTop});for(typeof o.focus=="function"&&o.focus(),o=0;o<i.length;o++)n=i[o],n.element.scrollLeft=n.left,n.element.scrollTop=n.top}}var Xx=h&&"documentMode"in document&&11>=document.documentMode,Ps=null,$c=null,Ba=null,Yc=!1;function jf(n,i,o){var d=o.window===o?o.document:o.nodeType===9?o:o.ownerDocument;Yc||Ps==null||Ps!==ut(d)||(d=Ps,"selectionStart"in d&&qc(d)?d={start:d.selectionStart,end:d.selectionEnd}:(d=(d.ownerDocument&&d.ownerDocument.defaultView||window).getSelection(),d={anchorNode:d.anchorNode,anchorOffset:d.anchorOffset,focusNode:d.focusNode,focusOffset:d.focusOffset}),Ba&&Oa(Ba,d)||(Ba=d,d=jo($c,"onSelect"),0<d.length&&(i=new Bc("onSelect","select",null,i,o),n.push({event:i,listeners:d}),i.target=Ps)))}function Oo(n,i){var o={};return o[n.toLowerCase()]=i.toLowerCase(),o["Webkit"+n]="webkit"+i,o["Moz"+n]="moz"+i,o}var Ns={animationend:Oo("Animation","AnimationEnd"),animationiteration:Oo("Animation","AnimationIteration"),animationstart:Oo("Animation","AnimationStart"),transitionend:Oo("Transition","TransitionEnd")},Kc={},Hf={};h&&(Hf=document.createElement("div").style,"AnimationEvent"in window||(delete Ns.animationend.animation,delete Ns.animationiteration.animation,delete Ns.animationstart.animation),"TransitionEvent"in window||delete Ns.transitionend.transition);function Bo(n){if(Kc[n])return Kc[n];if(!Ns[n])return n;var i=Ns[n],o;for(o in i)if(i.hasOwnProperty(o)&&o in Hf)return Kc[n]=i[o];return n}var Vf=Bo("animationend"),Gf=Bo("animationiteration"),Wf=Bo("animationstart"),Xf=Bo("transitionend"),qf=new Map,$f="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function Ar(n,i){qf.set(n,i),l(i,[n])}for(var Zc=0;Zc<$f.length;Zc++){var Qc=$f[Zc],qx=Qc.toLowerCase(),$x=Qc[0].toUpperCase()+Qc.slice(1);Ar(qx,"on"+$x)}Ar(Vf,"onAnimationEnd"),Ar(Gf,"onAnimationIteration"),Ar(Wf,"onAnimationStart"),Ar("dblclick","onDoubleClick"),Ar("focusin","onFocus"),Ar("focusout","onBlur"),Ar(Xf,"onTransitionEnd"),u("onMouseEnter",["mouseout","mouseover"]),u("onMouseLeave",["mouseout","mouseover"]),u("onPointerEnter",["pointerout","pointerover"]),u("onPointerLeave",["pointerout","pointerover"]),l("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),l("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),l("onBeforeInput",["compositionend","keypress","textInput","paste"]),l("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),l("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),l("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var za="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Yx=new Set("cancel close invalid load scroll toggle".split(" ").concat(za));function Yf(n,i,o){var d=n.type||"unknown-event";n.currentTarget=o,Ts(d,i,void 0,n),n.currentTarget=null}function Kf(n,i){i=(i&4)!==0;for(var o=0;o<n.length;o++){var d=n[o],m=d.event;d=d.listeners;e:{var y=void 0;if(i)for(var A=d.length-1;0<=A;A--){var B=d[A],V=B.instance,ge=B.currentTarget;if(B=B.listener,V!==y&&m.isPropagationStopped())break e;Yf(m,B,ge),y=V}else for(A=0;A<d.length;A++){if(B=d[A],V=B.instance,ge=B.currentTarget,B=B.listener,V!==y&&m.isPropagationStopped())break e;Yf(m,B,ge),y=V}}}if(Hn)throw n=Rn,Hn=!1,Rn=null,n}function Qt(n,i){var o=i[au];o===void 0&&(o=i[au]=new Set);var d=n+"__bubble";o.has(d)||(Zf(i,n,2,!1),o.add(d))}function Jc(n,i,o){var d=0;i&&(d|=4),Zf(o,n,d,i)}var zo="_reactListening"+Math.random().toString(36).slice(2);function ja(n){if(!n[zo]){n[zo]=!0,r.forEach(function(o){o!=="selectionchange"&&(Yx.has(o)||Jc(o,!1,n),Jc(o,!0,n))});var i=n.nodeType===9?n:n.ownerDocument;i===null||i[zo]||(i[zo]=!0,Jc("selectionchange",!1,i))}}function Zf(n,i,o,d){switch(yf(i)){case 1:var m=cx;break;case 4:m=ux;break;default:m=Fc}o=m.bind(null,i,o,n),m=void 0,!Et||i!=="touchstart"&&i!=="touchmove"&&i!=="wheel"||(m=!0),d?m!==void 0?n.addEventListener(i,o,{capture:!0,passive:m}):n.addEventListener(i,o,!0):m!==void 0?n.addEventListener(i,o,{passive:m}):n.addEventListener(i,o,!1)}function eu(n,i,o,d,m){var y=d;if((i&1)===0&&(i&2)===0&&d!==null)e:for(;;){if(d===null)return;var A=d.tag;if(A===3||A===4){var B=d.stateNode.containerInfo;if(B===m||B.nodeType===8&&B.parentNode===m)break;if(A===4)for(A=d.return;A!==null;){var V=A.tag;if((V===3||V===4)&&(V=A.stateNode.containerInfo,V===m||V.nodeType===8&&V.parentNode===m))return;A=A.return}for(;B!==null;){if(A=is(B),A===null)return;if(V=A.tag,V===5||V===6){d=y=A;continue e}B=B.parentNode}}d=d.return}je(function(){var ge=y,Pe=We(o),De=[];e:{var Ae=qf.get(n);if(Ae!==void 0){var Ke=Bc,nt=n;switch(n){case"keypress":if(Io(o)===0)break e;case"keydown":case"keyup":Ke=Ex;break;case"focusin":nt="focus",Ke=Hc;break;case"focusout":nt="blur",Ke=Hc;break;case"beforeblur":case"afterblur":Ke=Hc;break;case"click":if(o.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":Ke=Mf;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":Ke=fx;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":Ke=Cx;break;case Vf:case Gf:case Wf:Ke=gx;break;case Xf:Ke=Px;break;case"scroll":Ke=dx;break;case"wheel":Ke=Lx;break;case"copy":case"cut":case"paste":Ke=vx;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":Ke=Ef}var rt=(i&4)!==0,dn=!rt&&n==="scroll",he=rt?Ae!==null?Ae+"Capture":null:Ae;rt=[];for(var J=ge,pe;J!==null;){pe=J;var Ue=pe.stateNode;if(pe.tag===5&&Ue!==null&&(pe=Ue,he!==null&&(Ue=ht(J,he),Ue!=null&&rt.push(Ha(J,Ue,pe)))),dn)break;J=J.return}0<rt.length&&(Ae=new Ke(Ae,nt,null,o,Pe),De.push({event:Ae,listeners:rt}))}}if((i&7)===0){e:{if(Ae=n==="mouseover"||n==="pointerover",Ke=n==="mouseout"||n==="pointerout",Ae&&o!==ke&&(nt=o.relatedTarget||o.fromElement)&&(is(nt)||nt[rr]))break e;if((Ke||Ae)&&(Ae=Pe.window===Pe?Pe:(Ae=Pe.ownerDocument)?Ae.defaultView||Ae.parentWindow:window,Ke?(nt=o.relatedTarget||o.toElement,Ke=ge,nt=nt?is(nt):null,nt!==null&&(dn=Sn(nt),nt!==dn||nt.tag!==5&&nt.tag!==6)&&(nt=null)):(Ke=null,nt=ge),Ke!==nt)){if(rt=Mf,Ue="onMouseLeave",he="onMouseEnter",J="mouse",(n==="pointerout"||n==="pointerover")&&(rt=Ef,Ue="onPointerLeave",he="onPointerEnter",J="pointer"),dn=Ke==null?Ae:Is(Ke),pe=nt==null?Ae:Is(nt),Ae=new rt(Ue,J+"leave",Ke,o,Pe),Ae.target=dn,Ae.relatedTarget=pe,Ue=null,is(Pe)===ge&&(rt=new rt(he,J+"enter",nt,o,Pe),rt.target=pe,rt.relatedTarget=dn,Ue=rt),dn=Ue,Ke&&nt)t:{for(rt=Ke,he=nt,J=0,pe=rt;pe;pe=Ls(pe))J++;for(pe=0,Ue=he;Ue;Ue=Ls(Ue))pe++;for(;0<J-pe;)rt=Ls(rt),J--;for(;0<pe-J;)he=Ls(he),pe--;for(;J--;){if(rt===he||he!==null&&rt===he.alternate)break t;rt=Ls(rt),he=Ls(he)}rt=null}else rt=null;Ke!==null&&Qf(De,Ae,Ke,rt,!1),nt!==null&&dn!==null&&Qf(De,dn,nt,rt,!0)}}e:{if(Ae=ge?Is(ge):window,Ke=Ae.nodeName&&Ae.nodeName.toLowerCase(),Ke==="select"||Ke==="input"&&Ae.type==="file")var ot=Bx;else if(Nf(Ae))if(Df)ot=Vx;else{ot=jx;var ft=zx}else(Ke=Ae.nodeName)&&Ke.toLowerCase()==="input"&&(Ae.type==="checkbox"||Ae.type==="radio")&&(ot=Hx);if(ot&&(ot=ot(n,ge))){Lf(De,ot,o,Pe);break e}ft&&ft(n,Ae,ge),n==="focusout"&&(ft=Ae._wrapperState)&&ft.controlled&&Ae.type==="number"&&St(Ae,"number",Ae.value)}switch(ft=ge?Is(ge):window,n){case"focusin":(Nf(ft)||ft.contentEditable==="true")&&(Ps=ft,$c=ge,Ba=null);break;case"focusout":Ba=$c=Ps=null;break;case"mousedown":Yc=!0;break;case"contextmenu":case"mouseup":case"dragend":Yc=!1,jf(De,o,Pe);break;case"selectionchange":if(Xx)break;case"keydown":case"keyup":jf(De,o,Pe)}var pt;if(Gc)e:{switch(n){case"compositionstart":var vt="onCompositionStart";break e;case"compositionend":vt="onCompositionEnd";break e;case"compositionupdate":vt="onCompositionUpdate";break e}vt=void 0}else Rs?Rf(n,o)&&(vt="onCompositionEnd"):n==="keydown"&&o.keyCode===229&&(vt="onCompositionStart");vt&&(Tf&&o.locale!=="ko"&&(Rs||vt!=="onCompositionStart"?vt==="onCompositionEnd"&&Rs&&(pt=bf()):(Tr=Pe,Oc="value"in Tr?Tr.value:Tr.textContent,Rs=!0)),ft=jo(ge,vt),0<ft.length&&(vt=new wf(vt,n,null,o,Pe),De.push({event:vt,listeners:ft}),pt?vt.data=pt:(pt=Pf(o),pt!==null&&(vt.data=pt)))),(pt=Ix?kx(n,o):Fx(n,o))&&(ge=jo(ge,"onBeforeInput"),0<ge.length&&(Pe=new wf("onBeforeInput","beforeinput",null,o,Pe),De.push({event:Pe,listeners:ge}),Pe.data=pt))}Kf(De,i)})}function Ha(n,i,o){return{instance:n,listener:i,currentTarget:o}}function jo(n,i){for(var o=i+"Capture",d=[];n!==null;){var m=n,y=m.stateNode;m.tag===5&&y!==null&&(m=y,y=ht(n,o),y!=null&&d.unshift(Ha(n,y,m)),y=ht(n,i),y!=null&&d.push(Ha(n,y,m))),n=n.return}return d}function Ls(n){if(n===null)return null;do n=n.return;while(n&&n.tag!==5);return n||null}function Qf(n,i,o,d,m){for(var y=i._reactName,A=[];o!==null&&o!==d;){var B=o,V=B.alternate,ge=B.stateNode;if(V!==null&&V===d)break;B.tag===5&&ge!==null&&(B=ge,m?(V=ht(o,y),V!=null&&A.unshift(Ha(o,V,B))):m||(V=ht(o,y),V!=null&&A.push(Ha(o,V,B)))),o=o.return}A.length!==0&&n.push({event:i,listeners:A})}var Kx=/\r\n?/g,Zx=/\u0000|\uFFFD/g;function Jf(n){return(typeof n=="string"?n:""+n).replace(Kx,`
`).replace(Zx,"")}function Ho(n,i,o){if(i=Jf(i),Jf(n)!==i&&o)throw Error(t(425))}function Vo(){}var tu=null,nu=null;function iu(n,i){return n==="textarea"||n==="noscript"||typeof i.children=="string"||typeof i.children=="number"||typeof i.dangerouslySetInnerHTML=="object"&&i.dangerouslySetInnerHTML!==null&&i.dangerouslySetInnerHTML.__html!=null}var ru=typeof setTimeout=="function"?setTimeout:void 0,Qx=typeof clearTimeout=="function"?clearTimeout:void 0,ep=typeof Promise=="function"?Promise:void 0,Jx=typeof queueMicrotask=="function"?queueMicrotask:typeof ep<"u"?function(n){return ep.resolve(null).then(n).catch(ev)}:ru;function ev(n){setTimeout(function(){throw n})}function su(n,i){var o=i,d=0;do{var m=o.nextSibling;if(n.removeChild(o),m&&m.nodeType===8)if(o=m.data,o==="/$"){if(d===0){n.removeChild(m),La(i);return}d--}else o!=="$"&&o!=="$?"&&o!=="$!"||d++;o=m}while(o);La(i)}function Cr(n){for(;n!=null;n=n.nextSibling){var i=n.nodeType;if(i===1||i===3)break;if(i===8){if(i=n.data,i==="$"||i==="$!"||i==="$?")break;if(i==="/$")return null}}return n}function tp(n){n=n.previousSibling;for(var i=0;n;){if(n.nodeType===8){var o=n.data;if(o==="$"||o==="$!"||o==="$?"){if(i===0)return n;i--}else o==="/$"&&i++}n=n.previousSibling}return null}var Ds=Math.random().toString(36).slice(2),Gi="__reactFiber$"+Ds,Va="__reactProps$"+Ds,rr="__reactContainer$"+Ds,au="__reactEvents$"+Ds,tv="__reactListeners$"+Ds,nv="__reactHandles$"+Ds;function is(n){var i=n[Gi];if(i)return i;for(var o=n.parentNode;o;){if(i=o[rr]||o[Gi]){if(o=i.alternate,i.child!==null||o!==null&&o.child!==null)for(n=tp(n);n!==null;){if(o=n[Gi])return o;n=tp(n)}return i}n=o,o=n.parentNode}return null}function Ga(n){return n=n[Gi]||n[rr],!n||n.tag!==5&&n.tag!==6&&n.tag!==13&&n.tag!==3?null:n}function Is(n){if(n.tag===5||n.tag===6)return n.stateNode;throw Error(t(33))}function Go(n){return n[Va]||null}var ou=[],ks=-1;function Rr(n){return{current:n}}function Jt(n){0>ks||(n.current=ou[ks],ou[ks]=null,ks--)}function Kt(n,i){ks++,ou[ks]=n.current,n.current=i}var Pr={},In=Rr(Pr),Zn=Rr(!1),rs=Pr;function Fs(n,i){var o=n.type.contextTypes;if(!o)return Pr;var d=n.stateNode;if(d&&d.__reactInternalMemoizedUnmaskedChildContext===i)return d.__reactInternalMemoizedMaskedChildContext;var m={},y;for(y in o)m[y]=i[y];return d&&(n=n.stateNode,n.__reactInternalMemoizedUnmaskedChildContext=i,n.__reactInternalMemoizedMaskedChildContext=m),m}function Qn(n){return n=n.childContextTypes,n!=null}function Wo(){Jt(Zn),Jt(In)}function np(n,i,o){if(In.current!==Pr)throw Error(t(168));Kt(In,i),Kt(Zn,o)}function ip(n,i,o){var d=n.stateNode;if(i=i.childContextTypes,typeof d.getChildContext!="function")return o;d=d.getChildContext();for(var m in d)if(!(m in i))throw Error(t(108,xe(n)||"Unknown",m));return ce({},o,d)}function Xo(n){return n=(n=n.stateNode)&&n.__reactInternalMemoizedMergedChildContext||Pr,rs=In.current,Kt(In,n),Kt(Zn,Zn.current),!0}function rp(n,i,o){var d=n.stateNode;if(!d)throw Error(t(169));o?(n=ip(n,i,rs),d.__reactInternalMemoizedMergedChildContext=n,Jt(Zn),Jt(In),Kt(In,n)):Jt(Zn),Kt(Zn,o)}var sr=null,qo=!1,lu=!1;function sp(n){sr===null?sr=[n]:sr.push(n)}function iv(n){qo=!0,sp(n)}function Nr(){if(!lu&&sr!==null){lu=!0;var n=0,i=Pt;try{var o=sr;for(Pt=1;n<o.length;n++){var d=o[n];do d=d(!0);while(d!==null)}sr=null,qo=!1}catch(m){throw sr!==null&&(sr=sr.slice(n+1)),nn(Hi,Nr),m}finally{Pt=i,lu=!1}}return null}var Us=[],Os=0,$o=null,Yo=0,pi=[],mi=0,ss=null,ar=1,or="";function as(n,i){Us[Os++]=Yo,Us[Os++]=$o,$o=n,Yo=i}function ap(n,i,o){pi[mi++]=ar,pi[mi++]=or,pi[mi++]=ss,ss=n;var d=ar;n=or;var m=32-Le(d)-1;d&=~(1<<m),o+=1;var y=32-Le(i)+m;if(30<y){var A=m-m%5;y=(d&(1<<A)-1).toString(32),d>>=A,m-=A,ar=1<<32-Le(i)+m|o<<m|d,or=y+n}else ar=1<<y|o<<m|d,or=n}function cu(n){n.return!==null&&(as(n,1),ap(n,1,0))}function uu(n){for(;n===$o;)$o=Us[--Os],Us[Os]=null,Yo=Us[--Os],Us[Os]=null;for(;n===ss;)ss=pi[--mi],pi[mi]=null,or=pi[--mi],pi[mi]=null,ar=pi[--mi],pi[mi]=null}var li=null,ci=null,sn=!1,Ci=null;function op(n,i){var o=_i(5,null,null,0);o.elementType="DELETED",o.stateNode=i,o.return=n,i=n.deletions,i===null?(n.deletions=[o],n.flags|=16):i.push(o)}function lp(n,i){switch(n.tag){case 5:var o=n.type;return i=i.nodeType!==1||o.toLowerCase()!==i.nodeName.toLowerCase()?null:i,i!==null?(n.stateNode=i,li=n,ci=Cr(i.firstChild),!0):!1;case 6:return i=n.pendingProps===""||i.nodeType!==3?null:i,i!==null?(n.stateNode=i,li=n,ci=null,!0):!1;case 13:return i=i.nodeType!==8?null:i,i!==null?(o=ss!==null?{id:ar,overflow:or}:null,n.memoizedState={dehydrated:i,treeContext:o,retryLane:1073741824},o=_i(18,null,null,0),o.stateNode=i,o.return=n,n.child=o,li=n,ci=null,!0):!1;default:return!1}}function du(n){return(n.mode&1)!==0&&(n.flags&128)===0}function hu(n){if(sn){var i=ci;if(i){var o=i;if(!lp(n,i)){if(du(n))throw Error(t(418));i=Cr(o.nextSibling);var d=li;i&&lp(n,i)?op(d,o):(n.flags=n.flags&-4097|2,sn=!1,li=n)}}else{if(du(n))throw Error(t(418));n.flags=n.flags&-4097|2,sn=!1,li=n}}}function cp(n){for(n=n.return;n!==null&&n.tag!==5&&n.tag!==3&&n.tag!==13;)n=n.return;li=n}function Ko(n){if(n!==li)return!1;if(!sn)return cp(n),sn=!0,!1;var i;if((i=n.tag!==3)&&!(i=n.tag!==5)&&(i=n.type,i=i!=="head"&&i!=="body"&&!iu(n.type,n.memoizedProps)),i&&(i=ci)){if(du(n))throw up(),Error(t(418));for(;i;)op(n,i),i=Cr(i.nextSibling)}if(cp(n),n.tag===13){if(n=n.memoizedState,n=n!==null?n.dehydrated:null,!n)throw Error(t(317));e:{for(n=n.nextSibling,i=0;n;){if(n.nodeType===8){var o=n.data;if(o==="/$"){if(i===0){ci=Cr(n.nextSibling);break e}i--}else o!=="$"&&o!=="$!"&&o!=="$?"||i++}n=n.nextSibling}ci=null}}else ci=li?Cr(n.stateNode.nextSibling):null;return!0}function up(){for(var n=ci;n;)n=Cr(n.nextSibling)}function Bs(){ci=li=null,sn=!1}function fu(n){Ci===null?Ci=[n]:Ci.push(n)}var rv=C.ReactCurrentBatchConfig;function Wa(n,i,o){if(n=o.ref,n!==null&&typeof n!="function"&&typeof n!="object"){if(o._owner){if(o=o._owner,o){if(o.tag!==1)throw Error(t(309));var d=o.stateNode}if(!d)throw Error(t(147,n));var m=d,y=""+n;return i!==null&&i.ref!==null&&typeof i.ref=="function"&&i.ref._stringRef===y?i.ref:(i=function(A){var B=m.refs;A===null?delete B[y]:B[y]=A},i._stringRef=y,i)}if(typeof n!="string")throw Error(t(284));if(!o._owner)throw Error(t(290,n))}return n}function Zo(n,i){throw n=Object.prototype.toString.call(i),Error(t(31,n==="[object Object]"?"object with keys {"+Object.keys(i).join(", ")+"}":n))}function dp(n){var i=n._init;return i(n._payload)}function hp(n){function i(he,J){if(n){var pe=he.deletions;pe===null?(he.deletions=[J],he.flags|=16):pe.push(J)}}function o(he,J){if(!n)return null;for(;J!==null;)i(he,J),J=J.sibling;return null}function d(he,J){for(he=new Map;J!==null;)J.key!==null?he.set(J.key,J):he.set(J.index,J),J=J.sibling;return he}function m(he,J){return he=Br(he,J),he.index=0,he.sibling=null,he}function y(he,J,pe){return he.index=pe,n?(pe=he.alternate,pe!==null?(pe=pe.index,pe<J?(he.flags|=2,J):pe):(he.flags|=2,J)):(he.flags|=1048576,J)}function A(he){return n&&he.alternate===null&&(he.flags|=2),he}function B(he,J,pe,Ue){return J===null||J.tag!==6?(J=rd(pe,he.mode,Ue),J.return=he,J):(J=m(J,pe),J.return=he,J)}function V(he,J,pe,Ue){var ot=pe.type;return ot===U?Pe(he,J,pe.props.children,Ue,pe.key):J!==null&&(J.elementType===ot||typeof ot=="object"&&ot!==null&&ot.$$typeof===de&&dp(ot)===J.type)?(Ue=m(J,pe.props),Ue.ref=Wa(he,J,pe),Ue.return=he,Ue):(Ue=bl(pe.type,pe.key,pe.props,null,he.mode,Ue),Ue.ref=Wa(he,J,pe),Ue.return=he,Ue)}function ge(he,J,pe,Ue){return J===null||J.tag!==4||J.stateNode.containerInfo!==pe.containerInfo||J.stateNode.implementation!==pe.implementation?(J=sd(pe,he.mode,Ue),J.return=he,J):(J=m(J,pe.children||[]),J.return=he,J)}function Pe(he,J,pe,Ue,ot){return J===null||J.tag!==7?(J=ps(pe,he.mode,Ue,ot),J.return=he,J):(J=m(J,pe),J.return=he,J)}function De(he,J,pe){if(typeof J=="string"&&J!==""||typeof J=="number")return J=rd(""+J,he.mode,pe),J.return=he,J;if(typeof J=="object"&&J!==null){switch(J.$$typeof){case k:return pe=bl(J.type,J.key,J.props,null,he.mode,pe),pe.ref=Wa(he,null,J),pe.return=he,pe;case D:return J=sd(J,he.mode,pe),J.return=he,J;case de:var Ue=J._init;return De(he,Ue(J._payload),pe)}if(Dt(J)||ee(J))return J=ps(J,he.mode,pe,null),J.return=he,J;Zo(he,J)}return null}function Ae(he,J,pe,Ue){var ot=J!==null?J.key:null;if(typeof pe=="string"&&pe!==""||typeof pe=="number")return ot!==null?null:B(he,J,""+pe,Ue);if(typeof pe=="object"&&pe!==null){switch(pe.$$typeof){case k:return pe.key===ot?V(he,J,pe,Ue):null;case D:return pe.key===ot?ge(he,J,pe,Ue):null;case de:return ot=pe._init,Ae(he,J,ot(pe._payload),Ue)}if(Dt(pe)||ee(pe))return ot!==null?null:Pe(he,J,pe,Ue,null);Zo(he,pe)}return null}function Ke(he,J,pe,Ue,ot){if(typeof Ue=="string"&&Ue!==""||typeof Ue=="number")return he=he.get(pe)||null,B(J,he,""+Ue,ot);if(typeof Ue=="object"&&Ue!==null){switch(Ue.$$typeof){case k:return he=he.get(Ue.key===null?pe:Ue.key)||null,V(J,he,Ue,ot);case D:return he=he.get(Ue.key===null?pe:Ue.key)||null,ge(J,he,Ue,ot);case de:var ft=Ue._init;return Ke(he,J,pe,ft(Ue._payload),ot)}if(Dt(Ue)||ee(Ue))return he=he.get(pe)||null,Pe(J,he,Ue,ot,null);Zo(J,Ue)}return null}function nt(he,J,pe,Ue){for(var ot=null,ft=null,pt=J,vt=J=0,En=null;pt!==null&&vt<pe.length;vt++){pt.index>vt?(En=pt,pt=null):En=pt.sibling;var Bt=Ae(he,pt,pe[vt],Ue);if(Bt===null){pt===null&&(pt=En);break}n&&pt&&Bt.alternate===null&&i(he,pt),J=y(Bt,J,vt),ft===null?ot=Bt:ft.sibling=Bt,ft=Bt,pt=En}if(vt===pe.length)return o(he,pt),sn&&as(he,vt),ot;if(pt===null){for(;vt<pe.length;vt++)pt=De(he,pe[vt],Ue),pt!==null&&(J=y(pt,J,vt),ft===null?ot=pt:ft.sibling=pt,ft=pt);return sn&&as(he,vt),ot}for(pt=d(he,pt);vt<pe.length;vt++)En=Ke(pt,he,vt,pe[vt],Ue),En!==null&&(n&&En.alternate!==null&&pt.delete(En.key===null?vt:En.key),J=y(En,J,vt),ft===null?ot=En:ft.sibling=En,ft=En);return n&&pt.forEach(function(zr){return i(he,zr)}),sn&&as(he,vt),ot}function rt(he,J,pe,Ue){var ot=ee(pe);if(typeof ot!="function")throw Error(t(150));if(pe=ot.call(pe),pe==null)throw Error(t(151));for(var ft=ot=null,pt=J,vt=J=0,En=null,Bt=pe.next();pt!==null&&!Bt.done;vt++,Bt=pe.next()){pt.index>vt?(En=pt,pt=null):En=pt.sibling;var zr=Ae(he,pt,Bt.value,Ue);if(zr===null){pt===null&&(pt=En);break}n&&pt&&zr.alternate===null&&i(he,pt),J=y(zr,J,vt),ft===null?ot=zr:ft.sibling=zr,ft=zr,pt=En}if(Bt.done)return o(he,pt),sn&&as(he,vt),ot;if(pt===null){for(;!Bt.done;vt++,Bt=pe.next())Bt=De(he,Bt.value,Ue),Bt!==null&&(J=y(Bt,J,vt),ft===null?ot=Bt:ft.sibling=Bt,ft=Bt);return sn&&as(he,vt),ot}for(pt=d(he,pt);!Bt.done;vt++,Bt=pe.next())Bt=Ke(pt,he,vt,Bt.value,Ue),Bt!==null&&(n&&Bt.alternate!==null&&pt.delete(Bt.key===null?vt:Bt.key),J=y(Bt,J,vt),ft===null?ot=Bt:ft.sibling=Bt,ft=Bt);return n&&pt.forEach(function(Uv){return i(he,Uv)}),sn&&as(he,vt),ot}function dn(he,J,pe,Ue){if(typeof pe=="object"&&pe!==null&&pe.type===U&&pe.key===null&&(pe=pe.props.children),typeof pe=="object"&&pe!==null){switch(pe.$$typeof){case k:e:{for(var ot=pe.key,ft=J;ft!==null;){if(ft.key===ot){if(ot=pe.type,ot===U){if(ft.tag===7){o(he,ft.sibling),J=m(ft,pe.props.children),J.return=he,he=J;break e}}else if(ft.elementType===ot||typeof ot=="object"&&ot!==null&&ot.$$typeof===de&&dp(ot)===ft.type){o(he,ft.sibling),J=m(ft,pe.props),J.ref=Wa(he,ft,pe),J.return=he,he=J;break e}o(he,ft);break}else i(he,ft);ft=ft.sibling}pe.type===U?(J=ps(pe.props.children,he.mode,Ue,pe.key),J.return=he,he=J):(Ue=bl(pe.type,pe.key,pe.props,null,he.mode,Ue),Ue.ref=Wa(he,J,pe),Ue.return=he,he=Ue)}return A(he);case D:e:{for(ft=pe.key;J!==null;){if(J.key===ft)if(J.tag===4&&J.stateNode.containerInfo===pe.containerInfo&&J.stateNode.implementation===pe.implementation){o(he,J.sibling),J=m(J,pe.children||[]),J.return=he,he=J;break e}else{o(he,J);break}else i(he,J);J=J.sibling}J=sd(pe,he.mode,Ue),J.return=he,he=J}return A(he);case de:return ft=pe._init,dn(he,J,ft(pe._payload),Ue)}if(Dt(pe))return nt(he,J,pe,Ue);if(ee(pe))return rt(he,J,pe,Ue);Zo(he,pe)}return typeof pe=="string"&&pe!==""||typeof pe=="number"?(pe=""+pe,J!==null&&J.tag===6?(o(he,J.sibling),J=m(J,pe),J.return=he,he=J):(o(he,J),J=rd(pe,he.mode,Ue),J.return=he,he=J),A(he)):o(he,J)}return dn}var zs=hp(!0),fp=hp(!1),Qo=Rr(null),Jo=null,js=null,pu=null;function mu(){pu=js=Jo=null}function gu(n){var i=Qo.current;Jt(Qo),n._currentValue=i}function xu(n,i,o){for(;n!==null;){var d=n.alternate;if((n.childLanes&i)!==i?(n.childLanes|=i,d!==null&&(d.childLanes|=i)):d!==null&&(d.childLanes&i)!==i&&(d.childLanes|=i),n===o)break;n=n.return}}function Hs(n,i){Jo=n,pu=js=null,n=n.dependencies,n!==null&&n.firstContext!==null&&((n.lanes&i)!==0&&(Jn=!0),n.firstContext=null)}function gi(n){var i=n._currentValue;if(pu!==n)if(n={context:n,memoizedValue:i,next:null},js===null){if(Jo===null)throw Error(t(308));js=n,Jo.dependencies={lanes:0,firstContext:n}}else js=js.next=n;return i}var os=null;function vu(n){os===null?os=[n]:os.push(n)}function pp(n,i,o,d){var m=i.interleaved;return m===null?(o.next=o,vu(i)):(o.next=m.next,m.next=o),i.interleaved=o,lr(n,d)}function lr(n,i){n.lanes|=i;var o=n.alternate;for(o!==null&&(o.lanes|=i),o=n,n=n.return;n!==null;)n.childLanes|=i,o=n.alternate,o!==null&&(o.childLanes|=i),o=n,n=n.return;return o.tag===3?o.stateNode:null}var Lr=!1;function _u(n){n.updateQueue={baseState:n.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function mp(n,i){n=n.updateQueue,i.updateQueue===n&&(i.updateQueue={baseState:n.baseState,firstBaseUpdate:n.firstBaseUpdate,lastBaseUpdate:n.lastBaseUpdate,shared:n.shared,effects:n.effects})}function cr(n,i){return{eventTime:n,lane:i,tag:0,payload:null,callback:null,next:null}}function Dr(n,i,o){var d=n.updateQueue;if(d===null)return null;if(d=d.shared,(Ot&2)!==0){var m=d.pending;return m===null?i.next=i:(i.next=m.next,m.next=i),d.pending=i,lr(n,o)}return m=d.interleaved,m===null?(i.next=i,vu(d)):(i.next=m.next,m.next=i),d.interleaved=i,lr(n,o)}function el(n,i,o){if(i=i.updateQueue,i!==null&&(i=i.shared,(o&4194240)!==0)){var d=i.lanes;d&=n.pendingLanes,o|=d,i.lanes=o,Kn(n,o)}}function gp(n,i){var o=n.updateQueue,d=n.alternate;if(d!==null&&(d=d.updateQueue,o===d)){var m=null,y=null;if(o=o.firstBaseUpdate,o!==null){do{var A={eventTime:o.eventTime,lane:o.lane,tag:o.tag,payload:o.payload,callback:o.callback,next:null};y===null?m=y=A:y=y.next=A,o=o.next}while(o!==null);y===null?m=y=i:y=y.next=i}else m=y=i;o={baseState:d.baseState,firstBaseUpdate:m,lastBaseUpdate:y,shared:d.shared,effects:d.effects},n.updateQueue=o;return}n=o.lastBaseUpdate,n===null?o.firstBaseUpdate=i:n.next=i,o.lastBaseUpdate=i}function tl(n,i,o,d){var m=n.updateQueue;Lr=!1;var y=m.firstBaseUpdate,A=m.lastBaseUpdate,B=m.shared.pending;if(B!==null){m.shared.pending=null;var V=B,ge=V.next;V.next=null,A===null?y=ge:A.next=ge,A=V;var Pe=n.alternate;Pe!==null&&(Pe=Pe.updateQueue,B=Pe.lastBaseUpdate,B!==A&&(B===null?Pe.firstBaseUpdate=ge:B.next=ge,Pe.lastBaseUpdate=V))}if(y!==null){var De=m.baseState;A=0,Pe=ge=V=null,B=y;do{var Ae=B.lane,Ke=B.eventTime;if((d&Ae)===Ae){Pe!==null&&(Pe=Pe.next={eventTime:Ke,lane:0,tag:B.tag,payload:B.payload,callback:B.callback,next:null});e:{var nt=n,rt=B;switch(Ae=i,Ke=o,rt.tag){case 1:if(nt=rt.payload,typeof nt=="function"){De=nt.call(Ke,De,Ae);break e}De=nt;break e;case 3:nt.flags=nt.flags&-65537|128;case 0:if(nt=rt.payload,Ae=typeof nt=="function"?nt.call(Ke,De,Ae):nt,Ae==null)break e;De=ce({},De,Ae);break e;case 2:Lr=!0}}B.callback!==null&&B.lane!==0&&(n.flags|=64,Ae=m.effects,Ae===null?m.effects=[B]:Ae.push(B))}else Ke={eventTime:Ke,lane:Ae,tag:B.tag,payload:B.payload,callback:B.callback,next:null},Pe===null?(ge=Pe=Ke,V=De):Pe=Pe.next=Ke,A|=Ae;if(B=B.next,B===null){if(B=m.shared.pending,B===null)break;Ae=B,B=Ae.next,Ae.next=null,m.lastBaseUpdate=Ae,m.shared.pending=null}}while(!0);if(Pe===null&&(V=De),m.baseState=V,m.firstBaseUpdate=ge,m.lastBaseUpdate=Pe,i=m.shared.interleaved,i!==null){m=i;do A|=m.lane,m=m.next;while(m!==i)}else y===null&&(m.shared.lanes=0);us|=A,n.lanes=A,n.memoizedState=De}}function xp(n,i,o){if(n=i.effects,i.effects=null,n!==null)for(i=0;i<n.length;i++){var d=n[i],m=d.callback;if(m!==null){if(d.callback=null,d=o,typeof m!="function")throw Error(t(191,m));m.call(d)}}}var Xa={},Wi=Rr(Xa),qa=Rr(Xa),$a=Rr(Xa);function ls(n){if(n===Xa)throw Error(t(174));return n}function yu(n,i){switch(Kt($a,i),Kt(qa,n),Kt(Wi,Xa),n=i.nodeType,n){case 9:case 11:i=(i=i.documentElement)?i.namespaceURI:w(null,"");break;default:n=n===8?i.parentNode:i,i=n.namespaceURI||null,n=n.tagName,i=w(i,n)}Jt(Wi),Kt(Wi,i)}function Vs(){Jt(Wi),Jt(qa),Jt($a)}function vp(n){ls($a.current);var i=ls(Wi.current),o=w(i,n.type);i!==o&&(Kt(qa,n),Kt(Wi,o))}function bu(n){qa.current===n&&(Jt(Wi),Jt(qa))}var an=Rr(0);function nl(n){for(var i=n;i!==null;){if(i.tag===13){var o=i.memoizedState;if(o!==null&&(o=o.dehydrated,o===null||o.data==="$?"||o.data==="$!"))return i}else if(i.tag===19&&i.memoizedProps.revealOrder!==void 0){if((i.flags&128)!==0)return i}else if(i.child!==null){i.child.return=i,i=i.child;continue}if(i===n)break;for(;i.sibling===null;){if(i.return===null||i.return===n)return null;i=i.return}i.sibling.return=i.return,i=i.sibling}return null}var Su=[];function Mu(){for(var n=0;n<Su.length;n++)Su[n]._workInProgressVersionPrimary=null;Su.length=0}var il=C.ReactCurrentDispatcher,wu=C.ReactCurrentBatchConfig,cs=0,on=null,gn=null,Mn=null,rl=!1,Ya=!1,Ka=0,sv=0;function kn(){throw Error(t(321))}function Eu(n,i){if(i===null)return!1;for(var o=0;o<i.length&&o<n.length;o++)if(!Ai(n[o],i[o]))return!1;return!0}function Tu(n,i,o,d,m,y){if(cs=y,on=i,i.memoizedState=null,i.updateQueue=null,i.lanes=0,il.current=n===null||n.memoizedState===null?cv:uv,n=o(d,m),Ya){y=0;do{if(Ya=!1,Ka=0,25<=y)throw Error(t(301));y+=1,Mn=gn=null,i.updateQueue=null,il.current=dv,n=o(d,m)}while(Ya)}if(il.current=ol,i=gn!==null&&gn.next!==null,cs=0,Mn=gn=on=null,rl=!1,i)throw Error(t(300));return n}function Au(){var n=Ka!==0;return Ka=0,n}function Xi(){var n={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Mn===null?on.memoizedState=Mn=n:Mn=Mn.next=n,Mn}function xi(){if(gn===null){var n=on.alternate;n=n!==null?n.memoizedState:null}else n=gn.next;var i=Mn===null?on.memoizedState:Mn.next;if(i!==null)Mn=i,gn=n;else{if(n===null)throw Error(t(310));gn=n,n={memoizedState:gn.memoizedState,baseState:gn.baseState,baseQueue:gn.baseQueue,queue:gn.queue,next:null},Mn===null?on.memoizedState=Mn=n:Mn=Mn.next=n}return Mn}function Za(n,i){return typeof i=="function"?i(n):i}function Cu(n){var i=xi(),o=i.queue;if(o===null)throw Error(t(311));o.lastRenderedReducer=n;var d=gn,m=d.baseQueue,y=o.pending;if(y!==null){if(m!==null){var A=m.next;m.next=y.next,y.next=A}d.baseQueue=m=y,o.pending=null}if(m!==null){y=m.next,d=d.baseState;var B=A=null,V=null,ge=y;do{var Pe=ge.lane;if((cs&Pe)===Pe)V!==null&&(V=V.next={lane:0,action:ge.action,hasEagerState:ge.hasEagerState,eagerState:ge.eagerState,next:null}),d=ge.hasEagerState?ge.eagerState:n(d,ge.action);else{var De={lane:Pe,action:ge.action,hasEagerState:ge.hasEagerState,eagerState:ge.eagerState,next:null};V===null?(B=V=De,A=d):V=V.next=De,on.lanes|=Pe,us|=Pe}ge=ge.next}while(ge!==null&&ge!==y);V===null?A=d:V.next=B,Ai(d,i.memoizedState)||(Jn=!0),i.memoizedState=d,i.baseState=A,i.baseQueue=V,o.lastRenderedState=d}if(n=o.interleaved,n!==null){m=n;do y=m.lane,on.lanes|=y,us|=y,m=m.next;while(m!==n)}else m===null&&(o.lanes=0);return[i.memoizedState,o.dispatch]}function Ru(n){var i=xi(),o=i.queue;if(o===null)throw Error(t(311));o.lastRenderedReducer=n;var d=o.dispatch,m=o.pending,y=i.memoizedState;if(m!==null){o.pending=null;var A=m=m.next;do y=n(y,A.action),A=A.next;while(A!==m);Ai(y,i.memoizedState)||(Jn=!0),i.memoizedState=y,i.baseQueue===null&&(i.baseState=y),o.lastRenderedState=y}return[y,d]}function _p(){}function yp(n,i){var o=on,d=xi(),m=i(),y=!Ai(d.memoizedState,m);if(y&&(d.memoizedState=m,Jn=!0),d=d.queue,Pu(Mp.bind(null,o,d,n),[n]),d.getSnapshot!==i||y||Mn!==null&&Mn.memoizedState.tag&1){if(o.flags|=2048,Qa(9,Sp.bind(null,o,d,m,i),void 0,null),wn===null)throw Error(t(349));(cs&30)!==0||bp(o,i,m)}return m}function bp(n,i,o){n.flags|=16384,n={getSnapshot:i,value:o},i=on.updateQueue,i===null?(i={lastEffect:null,stores:null},on.updateQueue=i,i.stores=[n]):(o=i.stores,o===null?i.stores=[n]:o.push(n))}function Sp(n,i,o,d){i.value=o,i.getSnapshot=d,wp(i)&&Ep(n)}function Mp(n,i,o){return o(function(){wp(i)&&Ep(n)})}function wp(n){var i=n.getSnapshot;n=n.value;try{var o=i();return!Ai(n,o)}catch{return!0}}function Ep(n){var i=lr(n,1);i!==null&&Li(i,n,1,-1)}function Tp(n){var i=Xi();return typeof n=="function"&&(n=n()),i.memoizedState=i.baseState=n,n={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:Za,lastRenderedState:n},i.queue=n,n=n.dispatch=lv.bind(null,on,n),[i.memoizedState,n]}function Qa(n,i,o,d){return n={tag:n,create:i,destroy:o,deps:d,next:null},i=on.updateQueue,i===null?(i={lastEffect:null,stores:null},on.updateQueue=i,i.lastEffect=n.next=n):(o=i.lastEffect,o===null?i.lastEffect=n.next=n:(d=o.next,o.next=n,n.next=d,i.lastEffect=n)),n}function Ap(){return xi().memoizedState}function sl(n,i,o,d){var m=Xi();on.flags|=n,m.memoizedState=Qa(1|i,o,void 0,d===void 0?null:d)}function al(n,i,o,d){var m=xi();d=d===void 0?null:d;var y=void 0;if(gn!==null){var A=gn.memoizedState;if(y=A.destroy,d!==null&&Eu(d,A.deps)){m.memoizedState=Qa(i,o,y,d);return}}on.flags|=n,m.memoizedState=Qa(1|i,o,y,d)}function Cp(n,i){return sl(8390656,8,n,i)}function Pu(n,i){return al(2048,8,n,i)}function Rp(n,i){return al(4,2,n,i)}function Pp(n,i){return al(4,4,n,i)}function Np(n,i){if(typeof i=="function")return n=n(),i(n),function(){i(null)};if(i!=null)return n=n(),i.current=n,function(){i.current=null}}function Lp(n,i,o){return o=o!=null?o.concat([n]):null,al(4,4,Np.bind(null,i,n),o)}function Nu(){}function Dp(n,i){var o=xi();i=i===void 0?null:i;var d=o.memoizedState;return d!==null&&i!==null&&Eu(i,d[1])?d[0]:(o.memoizedState=[n,i],n)}function Ip(n,i){var o=xi();i=i===void 0?null:i;var d=o.memoizedState;return d!==null&&i!==null&&Eu(i,d[1])?d[0]:(n=n(),o.memoizedState=[n,i],n)}function kp(n,i,o){return(cs&21)===0?(n.baseState&&(n.baseState=!1,Jn=!0),n.memoizedState=o):(Ai(o,i)||(o=Ye(),on.lanes|=o,us|=o,n.baseState=!0),i)}function av(n,i){var o=Pt;Pt=o!==0&&4>o?o:4,n(!0);var d=wu.transition;wu.transition={};try{n(!1),i()}finally{Pt=o,wu.transition=d}}function Fp(){return xi().memoizedState}function ov(n,i,o){var d=Ur(n);if(o={lane:d,action:o,hasEagerState:!1,eagerState:null,next:null},Up(n))Op(i,o);else if(o=pp(n,i,o,d),o!==null){var m=Gn();Li(o,n,d,m),Bp(o,i,d)}}function lv(n,i,o){var d=Ur(n),m={lane:d,action:o,hasEagerState:!1,eagerState:null,next:null};if(Up(n))Op(i,m);else{var y=n.alternate;if(n.lanes===0&&(y===null||y.lanes===0)&&(y=i.lastRenderedReducer,y!==null))try{var A=i.lastRenderedState,B=y(A,o);if(m.hasEagerState=!0,m.eagerState=B,Ai(B,A)){var V=i.interleaved;V===null?(m.next=m,vu(i)):(m.next=V.next,V.next=m),i.interleaved=m;return}}catch{}finally{}o=pp(n,i,m,d),o!==null&&(m=Gn(),Li(o,n,d,m),Bp(o,i,d))}}function Up(n){var i=n.alternate;return n===on||i!==null&&i===on}function Op(n,i){Ya=rl=!0;var o=n.pending;o===null?i.next=i:(i.next=o.next,o.next=i),n.pending=i}function Bp(n,i,o){if((o&4194240)!==0){var d=i.lanes;d&=n.pendingLanes,o|=d,i.lanes=o,Kn(n,o)}}var ol={readContext:gi,useCallback:kn,useContext:kn,useEffect:kn,useImperativeHandle:kn,useInsertionEffect:kn,useLayoutEffect:kn,useMemo:kn,useReducer:kn,useRef:kn,useState:kn,useDebugValue:kn,useDeferredValue:kn,useTransition:kn,useMutableSource:kn,useSyncExternalStore:kn,useId:kn,unstable_isNewReconciler:!1},cv={readContext:gi,useCallback:function(n,i){return Xi().memoizedState=[n,i===void 0?null:i],n},useContext:gi,useEffect:Cp,useImperativeHandle:function(n,i,o){return o=o!=null?o.concat([n]):null,sl(4194308,4,Np.bind(null,i,n),o)},useLayoutEffect:function(n,i){return sl(4194308,4,n,i)},useInsertionEffect:function(n,i){return sl(4,2,n,i)},useMemo:function(n,i){var o=Xi();return i=i===void 0?null:i,n=n(),o.memoizedState=[n,i],n},useReducer:function(n,i,o){var d=Xi();return i=o!==void 0?o(i):i,d.memoizedState=d.baseState=i,n={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:n,lastRenderedState:i},d.queue=n,n=n.dispatch=ov.bind(null,on,n),[d.memoizedState,n]},useRef:function(n){var i=Xi();return n={current:n},i.memoizedState=n},useState:Tp,useDebugValue:Nu,useDeferredValue:function(n){return Xi().memoizedState=n},useTransition:function(){var n=Tp(!1),i=n[0];return n=av.bind(null,n[1]),Xi().memoizedState=n,[i,n]},useMutableSource:function(){},useSyncExternalStore:function(n,i,o){var d=on,m=Xi();if(sn){if(o===void 0)throw Error(t(407));o=o()}else{if(o=i(),wn===null)throw Error(t(349));(cs&30)!==0||bp(d,i,o)}m.memoizedState=o;var y={value:o,getSnapshot:i};return m.queue=y,Cp(Mp.bind(null,d,y,n),[n]),d.flags|=2048,Qa(9,Sp.bind(null,d,y,o,i),void 0,null),o},useId:function(){var n=Xi(),i=wn.identifierPrefix;if(sn){var o=or,d=ar;o=(d&~(1<<32-Le(d)-1)).toString(32)+o,i=":"+i+"R"+o,o=Ka++,0<o&&(i+="H"+o.toString(32)),i+=":"}else o=sv++,i=":"+i+"r"+o.toString(32)+":";return n.memoizedState=i},unstable_isNewReconciler:!1},uv={readContext:gi,useCallback:Dp,useContext:gi,useEffect:Pu,useImperativeHandle:Lp,useInsertionEffect:Rp,useLayoutEffect:Pp,useMemo:Ip,useReducer:Cu,useRef:Ap,useState:function(){return Cu(Za)},useDebugValue:Nu,useDeferredValue:function(n){var i=xi();return kp(i,gn.memoizedState,n)},useTransition:function(){var n=Cu(Za)[0],i=xi().memoizedState;return[n,i]},useMutableSource:_p,useSyncExternalStore:yp,useId:Fp,unstable_isNewReconciler:!1},dv={readContext:gi,useCallback:Dp,useContext:gi,useEffect:Pu,useImperativeHandle:Lp,useInsertionEffect:Rp,useLayoutEffect:Pp,useMemo:Ip,useReducer:Ru,useRef:Ap,useState:function(){return Ru(Za)},useDebugValue:Nu,useDeferredValue:function(n){var i=xi();return gn===null?i.memoizedState=n:kp(i,gn.memoizedState,n)},useTransition:function(){var n=Ru(Za)[0],i=xi().memoizedState;return[n,i]},useMutableSource:_p,useSyncExternalStore:yp,useId:Fp,unstable_isNewReconciler:!1};function Ri(n,i){if(n&&n.defaultProps){i=ce({},i),n=n.defaultProps;for(var o in n)i[o]===void 0&&(i[o]=n[o]);return i}return i}function Lu(n,i,o,d){i=n.memoizedState,o=o(d,i),o=o==null?i:ce({},i,o),n.memoizedState=o,n.lanes===0&&(n.updateQueue.baseState=o)}var ll={isMounted:function(n){return(n=n._reactInternals)?Sn(n)===n:!1},enqueueSetState:function(n,i,o){n=n._reactInternals;var d=Gn(),m=Ur(n),y=cr(d,m);y.payload=i,o!=null&&(y.callback=o),i=Dr(n,y,m),i!==null&&(Li(i,n,m,d),el(i,n,m))},enqueueReplaceState:function(n,i,o){n=n._reactInternals;var d=Gn(),m=Ur(n),y=cr(d,m);y.tag=1,y.payload=i,o!=null&&(y.callback=o),i=Dr(n,y,m),i!==null&&(Li(i,n,m,d),el(i,n,m))},enqueueForceUpdate:function(n,i){n=n._reactInternals;var o=Gn(),d=Ur(n),m=cr(o,d);m.tag=2,i!=null&&(m.callback=i),i=Dr(n,m,d),i!==null&&(Li(i,n,d,o),el(i,n,d))}};function zp(n,i,o,d,m,y,A){return n=n.stateNode,typeof n.shouldComponentUpdate=="function"?n.shouldComponentUpdate(d,y,A):i.prototype&&i.prototype.isPureReactComponent?!Oa(o,d)||!Oa(m,y):!0}function jp(n,i,o){var d=!1,m=Pr,y=i.contextType;return typeof y=="object"&&y!==null?y=gi(y):(m=Qn(i)?rs:In.current,d=i.contextTypes,y=(d=d!=null)?Fs(n,m):Pr),i=new i(o,y),n.memoizedState=i.state!==null&&i.state!==void 0?i.state:null,i.updater=ll,n.stateNode=i,i._reactInternals=n,d&&(n=n.stateNode,n.__reactInternalMemoizedUnmaskedChildContext=m,n.__reactInternalMemoizedMaskedChildContext=y),i}function Hp(n,i,o,d){n=i.state,typeof i.componentWillReceiveProps=="function"&&i.componentWillReceiveProps(o,d),typeof i.UNSAFE_componentWillReceiveProps=="function"&&i.UNSAFE_componentWillReceiveProps(o,d),i.state!==n&&ll.enqueueReplaceState(i,i.state,null)}function Du(n,i,o,d){var m=n.stateNode;m.props=o,m.state=n.memoizedState,m.refs={},_u(n);var y=i.contextType;typeof y=="object"&&y!==null?m.context=gi(y):(y=Qn(i)?rs:In.current,m.context=Fs(n,y)),m.state=n.memoizedState,y=i.getDerivedStateFromProps,typeof y=="function"&&(Lu(n,i,y,o),m.state=n.memoizedState),typeof i.getDerivedStateFromProps=="function"||typeof m.getSnapshotBeforeUpdate=="function"||typeof m.UNSAFE_componentWillMount!="function"&&typeof m.componentWillMount!="function"||(i=m.state,typeof m.componentWillMount=="function"&&m.componentWillMount(),typeof m.UNSAFE_componentWillMount=="function"&&m.UNSAFE_componentWillMount(),i!==m.state&&ll.enqueueReplaceState(m,m.state,null),tl(n,o,m,d),m.state=n.memoizedState),typeof m.componentDidMount=="function"&&(n.flags|=4194308)}function Gs(n,i){try{var o="",d=i;do o+=we(d),d=d.return;while(d);var m=o}catch(y){m=`
Error generating stack: `+y.message+`
`+y.stack}return{value:n,source:i,stack:m,digest:null}}function Iu(n,i,o){return{value:n,source:null,stack:o??null,digest:i??null}}function ku(n,i){try{console.error(i.value)}catch(o){setTimeout(function(){throw o})}}var hv=typeof WeakMap=="function"?WeakMap:Map;function Vp(n,i,o){o=cr(-1,o),o.tag=3,o.payload={element:null};var d=i.value;return o.callback=function(){ml||(ml=!0,Ku=d),ku(n,i)},o}function Gp(n,i,o){o=cr(-1,o),o.tag=3;var d=n.type.getDerivedStateFromError;if(typeof d=="function"){var m=i.value;o.payload=function(){return d(m)},o.callback=function(){ku(n,i)}}var y=n.stateNode;return y!==null&&typeof y.componentDidCatch=="function"&&(o.callback=function(){ku(n,i),typeof d!="function"&&(kr===null?kr=new Set([this]):kr.add(this));var A=i.stack;this.componentDidCatch(i.value,{componentStack:A!==null?A:""})}),o}function Wp(n,i,o){var d=n.pingCache;if(d===null){d=n.pingCache=new hv;var m=new Set;d.set(i,m)}else m=d.get(i),m===void 0&&(m=new Set,d.set(i,m));m.has(o)||(m.add(o),n=Tv.bind(null,n,i,o),i.then(n,n))}function Xp(n){do{var i;if((i=n.tag===13)&&(i=n.memoizedState,i=i!==null?i.dehydrated!==null:!0),i)return n;n=n.return}while(n!==null);return null}function qp(n,i,o,d,m){return(n.mode&1)===0?(n===i?n.flags|=65536:(n.flags|=128,o.flags|=131072,o.flags&=-52805,o.tag===1&&(o.alternate===null?o.tag=17:(i=cr(-1,1),i.tag=2,Dr(o,i,1))),o.lanes|=1),n):(n.flags|=65536,n.lanes=m,n)}var fv=C.ReactCurrentOwner,Jn=!1;function Vn(n,i,o,d){i.child=n===null?fp(i,null,o,d):zs(i,n.child,o,d)}function $p(n,i,o,d,m){o=o.render;var y=i.ref;return Hs(i,m),d=Tu(n,i,o,d,y,m),o=Au(),n!==null&&!Jn?(i.updateQueue=n.updateQueue,i.flags&=-2053,n.lanes&=~m,ur(n,i,m)):(sn&&o&&cu(i),i.flags|=1,Vn(n,i,d,m),i.child)}function Yp(n,i,o,d,m){if(n===null){var y=o.type;return typeof y=="function"&&!id(y)&&y.defaultProps===void 0&&o.compare===null&&o.defaultProps===void 0?(i.tag=15,i.type=y,Kp(n,i,y,d,m)):(n=bl(o.type,null,d,i,i.mode,m),n.ref=i.ref,n.return=i,i.child=n)}if(y=n.child,(n.lanes&m)===0){var A=y.memoizedProps;if(o=o.compare,o=o!==null?o:Oa,o(A,d)&&n.ref===i.ref)return ur(n,i,m)}return i.flags|=1,n=Br(y,d),n.ref=i.ref,n.return=i,i.child=n}function Kp(n,i,o,d,m){if(n!==null){var y=n.memoizedProps;if(Oa(y,d)&&n.ref===i.ref)if(Jn=!1,i.pendingProps=d=y,(n.lanes&m)!==0)(n.flags&131072)!==0&&(Jn=!0);else return i.lanes=n.lanes,ur(n,i,m)}return Fu(n,i,o,d,m)}function Zp(n,i,o){var d=i.pendingProps,m=d.children,y=n!==null?n.memoizedState:null;if(d.mode==="hidden")if((i.mode&1)===0)i.memoizedState={baseLanes:0,cachePool:null,transitions:null},Kt(Xs,ui),ui|=o;else{if((o&1073741824)===0)return n=y!==null?y.baseLanes|o:o,i.lanes=i.childLanes=1073741824,i.memoizedState={baseLanes:n,cachePool:null,transitions:null},i.updateQueue=null,Kt(Xs,ui),ui|=n,null;i.memoizedState={baseLanes:0,cachePool:null,transitions:null},d=y!==null?y.baseLanes:o,Kt(Xs,ui),ui|=d}else y!==null?(d=y.baseLanes|o,i.memoizedState=null):d=o,Kt(Xs,ui),ui|=d;return Vn(n,i,m,o),i.child}function Qp(n,i){var o=i.ref;(n===null&&o!==null||n!==null&&n.ref!==o)&&(i.flags|=512,i.flags|=2097152)}function Fu(n,i,o,d,m){var y=Qn(o)?rs:In.current;return y=Fs(i,y),Hs(i,m),o=Tu(n,i,o,d,y,m),d=Au(),n!==null&&!Jn?(i.updateQueue=n.updateQueue,i.flags&=-2053,n.lanes&=~m,ur(n,i,m)):(sn&&d&&cu(i),i.flags|=1,Vn(n,i,o,m),i.child)}function Jp(n,i,o,d,m){if(Qn(o)){var y=!0;Xo(i)}else y=!1;if(Hs(i,m),i.stateNode===null)ul(n,i),jp(i,o,d),Du(i,o,d,m),d=!0;else if(n===null){var A=i.stateNode,B=i.memoizedProps;A.props=B;var V=A.context,ge=o.contextType;typeof ge=="object"&&ge!==null?ge=gi(ge):(ge=Qn(o)?rs:In.current,ge=Fs(i,ge));var Pe=o.getDerivedStateFromProps,De=typeof Pe=="function"||typeof A.getSnapshotBeforeUpdate=="function";De||typeof A.UNSAFE_componentWillReceiveProps!="function"&&typeof A.componentWillReceiveProps!="function"||(B!==d||V!==ge)&&Hp(i,A,d,ge),Lr=!1;var Ae=i.memoizedState;A.state=Ae,tl(i,d,A,m),V=i.memoizedState,B!==d||Ae!==V||Zn.current||Lr?(typeof Pe=="function"&&(Lu(i,o,Pe,d),V=i.memoizedState),(B=Lr||zp(i,o,B,d,Ae,V,ge))?(De||typeof A.UNSAFE_componentWillMount!="function"&&typeof A.componentWillMount!="function"||(typeof A.componentWillMount=="function"&&A.componentWillMount(),typeof A.UNSAFE_componentWillMount=="function"&&A.UNSAFE_componentWillMount()),typeof A.componentDidMount=="function"&&(i.flags|=4194308)):(typeof A.componentDidMount=="function"&&(i.flags|=4194308),i.memoizedProps=d,i.memoizedState=V),A.props=d,A.state=V,A.context=ge,d=B):(typeof A.componentDidMount=="function"&&(i.flags|=4194308),d=!1)}else{A=i.stateNode,mp(n,i),B=i.memoizedProps,ge=i.type===i.elementType?B:Ri(i.type,B),A.props=ge,De=i.pendingProps,Ae=A.context,V=o.contextType,typeof V=="object"&&V!==null?V=gi(V):(V=Qn(o)?rs:In.current,V=Fs(i,V));var Ke=o.getDerivedStateFromProps;(Pe=typeof Ke=="function"||typeof A.getSnapshotBeforeUpdate=="function")||typeof A.UNSAFE_componentWillReceiveProps!="function"&&typeof A.componentWillReceiveProps!="function"||(B!==De||Ae!==V)&&Hp(i,A,d,V),Lr=!1,Ae=i.memoizedState,A.state=Ae,tl(i,d,A,m);var nt=i.memoizedState;B!==De||Ae!==nt||Zn.current||Lr?(typeof Ke=="function"&&(Lu(i,o,Ke,d),nt=i.memoizedState),(ge=Lr||zp(i,o,ge,d,Ae,nt,V)||!1)?(Pe||typeof A.UNSAFE_componentWillUpdate!="function"&&typeof A.componentWillUpdate!="function"||(typeof A.componentWillUpdate=="function"&&A.componentWillUpdate(d,nt,V),typeof A.UNSAFE_componentWillUpdate=="function"&&A.UNSAFE_componentWillUpdate(d,nt,V)),typeof A.componentDidUpdate=="function"&&(i.flags|=4),typeof A.getSnapshotBeforeUpdate=="function"&&(i.flags|=1024)):(typeof A.componentDidUpdate!="function"||B===n.memoizedProps&&Ae===n.memoizedState||(i.flags|=4),typeof A.getSnapshotBeforeUpdate!="function"||B===n.memoizedProps&&Ae===n.memoizedState||(i.flags|=1024),i.memoizedProps=d,i.memoizedState=nt),A.props=d,A.state=nt,A.context=V,d=ge):(typeof A.componentDidUpdate!="function"||B===n.memoizedProps&&Ae===n.memoizedState||(i.flags|=4),typeof A.getSnapshotBeforeUpdate!="function"||B===n.memoizedProps&&Ae===n.memoizedState||(i.flags|=1024),d=!1)}return Uu(n,i,o,d,y,m)}function Uu(n,i,o,d,m,y){Qp(n,i);var A=(i.flags&128)!==0;if(!d&&!A)return m&&rp(i,o,!1),ur(n,i,y);d=i.stateNode,fv.current=i;var B=A&&typeof o.getDerivedStateFromError!="function"?null:d.render();return i.flags|=1,n!==null&&A?(i.child=zs(i,n.child,null,y),i.child=zs(i,null,B,y)):Vn(n,i,B,y),i.memoizedState=d.state,m&&rp(i,o,!0),i.child}function em(n){var i=n.stateNode;i.pendingContext?np(n,i.pendingContext,i.pendingContext!==i.context):i.context&&np(n,i.context,!1),yu(n,i.containerInfo)}function tm(n,i,o,d,m){return Bs(),fu(m),i.flags|=256,Vn(n,i,o,d),i.child}var Ou={dehydrated:null,treeContext:null,retryLane:0};function Bu(n){return{baseLanes:n,cachePool:null,transitions:null}}function nm(n,i,o){var d=i.pendingProps,m=an.current,y=!1,A=(i.flags&128)!==0,B;if((B=A)||(B=n!==null&&n.memoizedState===null?!1:(m&2)!==0),B?(y=!0,i.flags&=-129):(n===null||n.memoizedState!==null)&&(m|=1),Kt(an,m&1),n===null)return hu(i),n=i.memoizedState,n!==null&&(n=n.dehydrated,n!==null)?((i.mode&1)===0?i.lanes=1:n.data==="$!"?i.lanes=8:i.lanes=1073741824,null):(A=d.children,n=d.fallback,y?(d=i.mode,y=i.child,A={mode:"hidden",children:A},(d&1)===0&&y!==null?(y.childLanes=0,y.pendingProps=A):y=Sl(A,d,0,null),n=ps(n,d,o,null),y.return=i,n.return=i,y.sibling=n,i.child=y,i.child.memoizedState=Bu(o),i.memoizedState=Ou,n):zu(i,A));if(m=n.memoizedState,m!==null&&(B=m.dehydrated,B!==null))return pv(n,i,A,d,B,m,o);if(y){y=d.fallback,A=i.mode,m=n.child,B=m.sibling;var V={mode:"hidden",children:d.children};return(A&1)===0&&i.child!==m?(d=i.child,d.childLanes=0,d.pendingProps=V,i.deletions=null):(d=Br(m,V),d.subtreeFlags=m.subtreeFlags&14680064),B!==null?y=Br(B,y):(y=ps(y,A,o,null),y.flags|=2),y.return=i,d.return=i,d.sibling=y,i.child=d,d=y,y=i.child,A=n.child.memoizedState,A=A===null?Bu(o):{baseLanes:A.baseLanes|o,cachePool:null,transitions:A.transitions},y.memoizedState=A,y.childLanes=n.childLanes&~o,i.memoizedState=Ou,d}return y=n.child,n=y.sibling,d=Br(y,{mode:"visible",children:d.children}),(i.mode&1)===0&&(d.lanes=o),d.return=i,d.sibling=null,n!==null&&(o=i.deletions,o===null?(i.deletions=[n],i.flags|=16):o.push(n)),i.child=d,i.memoizedState=null,d}function zu(n,i){return i=Sl({mode:"visible",children:i},n.mode,0,null),i.return=n,n.child=i}function cl(n,i,o,d){return d!==null&&fu(d),zs(i,n.child,null,o),n=zu(i,i.pendingProps.children),n.flags|=2,i.memoizedState=null,n}function pv(n,i,o,d,m,y,A){if(o)return i.flags&256?(i.flags&=-257,d=Iu(Error(t(422))),cl(n,i,A,d)):i.memoizedState!==null?(i.child=n.child,i.flags|=128,null):(y=d.fallback,m=i.mode,d=Sl({mode:"visible",children:d.children},m,0,null),y=ps(y,m,A,null),y.flags|=2,d.return=i,y.return=i,d.sibling=y,i.child=d,(i.mode&1)!==0&&zs(i,n.child,null,A),i.child.memoizedState=Bu(A),i.memoizedState=Ou,y);if((i.mode&1)===0)return cl(n,i,A,null);if(m.data==="$!"){if(d=m.nextSibling&&m.nextSibling.dataset,d)var B=d.dgst;return d=B,y=Error(t(419)),d=Iu(y,d,void 0),cl(n,i,A,d)}if(B=(A&n.childLanes)!==0,Jn||B){if(d=wn,d!==null){switch(A&-A){case 4:m=2;break;case 16:m=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:m=32;break;case 536870912:m=268435456;break;default:m=0}m=(m&(d.suspendedLanes|A))!==0?0:m,m!==0&&m!==y.retryLane&&(y.retryLane=m,lr(n,m),Li(d,n,m,-1))}return nd(),d=Iu(Error(t(421))),cl(n,i,A,d)}return m.data==="$?"?(i.flags|=128,i.child=n.child,i=Av.bind(null,n),m._reactRetry=i,null):(n=y.treeContext,ci=Cr(m.nextSibling),li=i,sn=!0,Ci=null,n!==null&&(pi[mi++]=ar,pi[mi++]=or,pi[mi++]=ss,ar=n.id,or=n.overflow,ss=i),i=zu(i,d.children),i.flags|=4096,i)}function im(n,i,o){n.lanes|=i;var d=n.alternate;d!==null&&(d.lanes|=i),xu(n.return,i,o)}function ju(n,i,o,d,m){var y=n.memoizedState;y===null?n.memoizedState={isBackwards:i,rendering:null,renderingStartTime:0,last:d,tail:o,tailMode:m}:(y.isBackwards=i,y.rendering=null,y.renderingStartTime=0,y.last=d,y.tail=o,y.tailMode=m)}function rm(n,i,o){var d=i.pendingProps,m=d.revealOrder,y=d.tail;if(Vn(n,i,d.children,o),d=an.current,(d&2)!==0)d=d&1|2,i.flags|=128;else{if(n!==null&&(n.flags&128)!==0)e:for(n=i.child;n!==null;){if(n.tag===13)n.memoizedState!==null&&im(n,o,i);else if(n.tag===19)im(n,o,i);else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===i)break e;for(;n.sibling===null;){if(n.return===null||n.return===i)break e;n=n.return}n.sibling.return=n.return,n=n.sibling}d&=1}if(Kt(an,d),(i.mode&1)===0)i.memoizedState=null;else switch(m){case"forwards":for(o=i.child,m=null;o!==null;)n=o.alternate,n!==null&&nl(n)===null&&(m=o),o=o.sibling;o=m,o===null?(m=i.child,i.child=null):(m=o.sibling,o.sibling=null),ju(i,!1,m,o,y);break;case"backwards":for(o=null,m=i.child,i.child=null;m!==null;){if(n=m.alternate,n!==null&&nl(n)===null){i.child=m;break}n=m.sibling,m.sibling=o,o=m,m=n}ju(i,!0,o,null,y);break;case"together":ju(i,!1,null,null,void 0);break;default:i.memoizedState=null}return i.child}function ul(n,i){(i.mode&1)===0&&n!==null&&(n.alternate=null,i.alternate=null,i.flags|=2)}function ur(n,i,o){if(n!==null&&(i.dependencies=n.dependencies),us|=i.lanes,(o&i.childLanes)===0)return null;if(n!==null&&i.child!==n.child)throw Error(t(153));if(i.child!==null){for(n=i.child,o=Br(n,n.pendingProps),i.child=o,o.return=i;n.sibling!==null;)n=n.sibling,o=o.sibling=Br(n,n.pendingProps),o.return=i;o.sibling=null}return i.child}function mv(n,i,o){switch(i.tag){case 3:em(i),Bs();break;case 5:vp(i);break;case 1:Qn(i.type)&&Xo(i);break;case 4:yu(i,i.stateNode.containerInfo);break;case 10:var d=i.type._context,m=i.memoizedProps.value;Kt(Qo,d._currentValue),d._currentValue=m;break;case 13:if(d=i.memoizedState,d!==null)return d.dehydrated!==null?(Kt(an,an.current&1),i.flags|=128,null):(o&i.child.childLanes)!==0?nm(n,i,o):(Kt(an,an.current&1),n=ur(n,i,o),n!==null?n.sibling:null);Kt(an,an.current&1);break;case 19:if(d=(o&i.childLanes)!==0,(n.flags&128)!==0){if(d)return rm(n,i,o);i.flags|=128}if(m=i.memoizedState,m!==null&&(m.rendering=null,m.tail=null,m.lastEffect=null),Kt(an,an.current),d)break;return null;case 22:case 23:return i.lanes=0,Zp(n,i,o)}return ur(n,i,o)}var sm,Hu,am,om;sm=function(n,i){for(var o=i.child;o!==null;){if(o.tag===5||o.tag===6)n.appendChild(o.stateNode);else if(o.tag!==4&&o.child!==null){o.child.return=o,o=o.child;continue}if(o===i)break;for(;o.sibling===null;){if(o.return===null||o.return===i)return;o=o.return}o.sibling.return=o.return,o=o.sibling}},Hu=function(){},am=function(n,i,o,d){var m=n.memoizedProps;if(m!==d){n=i.stateNode,ls(Wi.current);var y=null;switch(o){case"input":m=Ct(n,m),d=Ct(n,d),y=[];break;case"select":m=ce({},m,{value:void 0}),d=ce({},d,{value:void 0}),y=[];break;case"textarea":m=ct(n,m),d=ct(n,d),y=[];break;default:typeof m.onClick!="function"&&typeof d.onClick=="function"&&(n.onclick=Vo)}He(o,d);var A;o=null;for(ge in m)if(!d.hasOwnProperty(ge)&&m.hasOwnProperty(ge)&&m[ge]!=null)if(ge==="style"){var B=m[ge];for(A in B)B.hasOwnProperty(A)&&(o||(o={}),o[A]="")}else ge!=="dangerouslySetInnerHTML"&&ge!=="children"&&ge!=="suppressContentEditableWarning"&&ge!=="suppressHydrationWarning"&&ge!=="autoFocus"&&(a.hasOwnProperty(ge)?y||(y=[]):(y=y||[]).push(ge,null));for(ge in d){var V=d[ge];if(B=m?.[ge],d.hasOwnProperty(ge)&&V!==B&&(V!=null||B!=null))if(ge==="style")if(B){for(A in B)!B.hasOwnProperty(A)||V&&V.hasOwnProperty(A)||(o||(o={}),o[A]="");for(A in V)V.hasOwnProperty(A)&&B[A]!==V[A]&&(o||(o={}),o[A]=V[A])}else o||(y||(y=[]),y.push(ge,o)),o=V;else ge==="dangerouslySetInnerHTML"?(V=V?V.__html:void 0,B=B?B.__html:void 0,V!=null&&B!==V&&(y=y||[]).push(ge,V)):ge==="children"?typeof V!="string"&&typeof V!="number"||(y=y||[]).push(ge,""+V):ge!=="suppressContentEditableWarning"&&ge!=="suppressHydrationWarning"&&(a.hasOwnProperty(ge)?(V!=null&&ge==="onScroll"&&Qt("scroll",n),y||B===V||(y=[])):(y=y||[]).push(ge,V))}o&&(y=y||[]).push("style",o);var ge=y;(i.updateQueue=ge)&&(i.flags|=4)}},om=function(n,i,o,d){o!==d&&(i.flags|=4)};function Ja(n,i){if(!sn)switch(n.tailMode){case"hidden":i=n.tail;for(var o=null;i!==null;)i.alternate!==null&&(o=i),i=i.sibling;o===null?n.tail=null:o.sibling=null;break;case"collapsed":o=n.tail;for(var d=null;o!==null;)o.alternate!==null&&(d=o),o=o.sibling;d===null?i||n.tail===null?n.tail=null:n.tail.sibling=null:d.sibling=null}}function Fn(n){var i=n.alternate!==null&&n.alternate.child===n.child,o=0,d=0;if(i)for(var m=n.child;m!==null;)o|=m.lanes|m.childLanes,d|=m.subtreeFlags&14680064,d|=m.flags&14680064,m.return=n,m=m.sibling;else for(m=n.child;m!==null;)o|=m.lanes|m.childLanes,d|=m.subtreeFlags,d|=m.flags,m.return=n,m=m.sibling;return n.subtreeFlags|=d,n.childLanes=o,i}function gv(n,i,o){var d=i.pendingProps;switch(uu(i),i.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Fn(i),null;case 1:return Qn(i.type)&&Wo(),Fn(i),null;case 3:return d=i.stateNode,Vs(),Jt(Zn),Jt(In),Mu(),d.pendingContext&&(d.context=d.pendingContext,d.pendingContext=null),(n===null||n.child===null)&&(Ko(i)?i.flags|=4:n===null||n.memoizedState.isDehydrated&&(i.flags&256)===0||(i.flags|=1024,Ci!==null&&(Ju(Ci),Ci=null))),Hu(n,i),Fn(i),null;case 5:bu(i);var m=ls($a.current);if(o=i.type,n!==null&&i.stateNode!=null)am(n,i,o,d,m),n.ref!==i.ref&&(i.flags|=512,i.flags|=2097152);else{if(!d){if(i.stateNode===null)throw Error(t(166));return Fn(i),null}if(n=ls(Wi.current),Ko(i)){d=i.stateNode,o=i.type;var y=i.memoizedProps;switch(d[Gi]=i,d[Va]=y,n=(i.mode&1)!==0,o){case"dialog":Qt("cancel",d),Qt("close",d);break;case"iframe":case"object":case"embed":Qt("load",d);break;case"video":case"audio":for(m=0;m<za.length;m++)Qt(za[m],d);break;case"source":Qt("error",d);break;case"img":case"image":case"link":Qt("error",d),Qt("load",d);break;case"details":Qt("toggle",d);break;case"input":it(d,y),Qt("invalid",d);break;case"select":d._wrapperState={wasMultiple:!!y.multiple},Qt("invalid",d);break;case"textarea":Q(d,y),Qt("invalid",d)}He(o,y),m=null;for(var A in y)if(y.hasOwnProperty(A)){var B=y[A];A==="children"?typeof B=="string"?d.textContent!==B&&(y.suppressHydrationWarning!==!0&&Ho(d.textContent,B,n),m=["children",B]):typeof B=="number"&&d.textContent!==""+B&&(y.suppressHydrationWarning!==!0&&Ho(d.textContent,B,n),m=["children",""+B]):a.hasOwnProperty(A)&&B!=null&&A==="onScroll"&&Qt("scroll",d)}switch(o){case"input":Qe(d),zt(d,y,!0);break;case"textarea":Qe(d),ze(d);break;case"select":case"option":break;default:typeof y.onClick=="function"&&(d.onclick=Vo)}d=m,i.updateQueue=d,d!==null&&(i.flags|=4)}else{A=m.nodeType===9?m:m.ownerDocument,n==="http://www.w3.org/1999/xhtml"&&(n=L(o)),n==="http://www.w3.org/1999/xhtml"?o==="script"?(n=A.createElement("div"),n.innerHTML="<script><\/script>",n=n.removeChild(n.firstChild)):typeof d.is=="string"?n=A.createElement(o,{is:d.is}):(n=A.createElement(o),o==="select"&&(A=n,d.multiple?A.multiple=!0:d.size&&(A.size=d.size))):n=A.createElementNS(n,o),n[Gi]=i,n[Va]=d,sm(n,i,!1,!1),i.stateNode=n;e:{switch(A=Ie(o,d),o){case"dialog":Qt("cancel",n),Qt("close",n),m=d;break;case"iframe":case"object":case"embed":Qt("load",n),m=d;break;case"video":case"audio":for(m=0;m<za.length;m++)Qt(za[m],n);m=d;break;case"source":Qt("error",n),m=d;break;case"img":case"image":case"link":Qt("error",n),Qt("load",n),m=d;break;case"details":Qt("toggle",n),m=d;break;case"input":it(n,d),m=Ct(n,d),Qt("invalid",n);break;case"option":m=d;break;case"select":n._wrapperState={wasMultiple:!!d.multiple},m=ce({},d,{value:void 0}),Qt("invalid",n);break;case"textarea":Q(n,d),m=ct(n,d),Qt("invalid",n);break;default:m=d}He(o,m),B=m;for(y in B)if(B.hasOwnProperty(y)){var V=B[y];y==="style"?ye(n,V):y==="dangerouslySetInnerHTML"?(V=V?V.__html:void 0,V!=null&&ae(n,V)):y==="children"?typeof V=="string"?(o!=="textarea"||V!=="")&&me(n,V):typeof V=="number"&&me(n,""+V):y!=="suppressContentEditableWarning"&&y!=="suppressHydrationWarning"&&y!=="autoFocus"&&(a.hasOwnProperty(y)?V!=null&&y==="onScroll"&&Qt("scroll",n):V!=null&&P(n,y,V,A))}switch(o){case"input":Qe(n),zt(n,d,!1);break;case"textarea":Qe(n),ze(n);break;case"option":d.value!=null&&n.setAttribute("value",""+ve(d.value));break;case"select":n.multiple=!!d.multiple,y=d.value,y!=null?wt(n,!!d.multiple,y,!1):d.defaultValue!=null&&wt(n,!!d.multiple,d.defaultValue,!0);break;default:typeof m.onClick=="function"&&(n.onclick=Vo)}switch(o){case"button":case"input":case"select":case"textarea":d=!!d.autoFocus;break e;case"img":d=!0;break e;default:d=!1}}d&&(i.flags|=4)}i.ref!==null&&(i.flags|=512,i.flags|=2097152)}return Fn(i),null;case 6:if(n&&i.stateNode!=null)om(n,i,n.memoizedProps,d);else{if(typeof d!="string"&&i.stateNode===null)throw Error(t(166));if(o=ls($a.current),ls(Wi.current),Ko(i)){if(d=i.stateNode,o=i.memoizedProps,d[Gi]=i,(y=d.nodeValue!==o)&&(n=li,n!==null))switch(n.tag){case 3:Ho(d.nodeValue,o,(n.mode&1)!==0);break;case 5:n.memoizedProps.suppressHydrationWarning!==!0&&Ho(d.nodeValue,o,(n.mode&1)!==0)}y&&(i.flags|=4)}else d=(o.nodeType===9?o:o.ownerDocument).createTextNode(d),d[Gi]=i,i.stateNode=d}return Fn(i),null;case 13:if(Jt(an),d=i.memoizedState,n===null||n.memoizedState!==null&&n.memoizedState.dehydrated!==null){if(sn&&ci!==null&&(i.mode&1)!==0&&(i.flags&128)===0)up(),Bs(),i.flags|=98560,y=!1;else if(y=Ko(i),d!==null&&d.dehydrated!==null){if(n===null){if(!y)throw Error(t(318));if(y=i.memoizedState,y=y!==null?y.dehydrated:null,!y)throw Error(t(317));y[Gi]=i}else Bs(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;Fn(i),y=!1}else Ci!==null&&(Ju(Ci),Ci=null),y=!0;if(!y)return i.flags&65536?i:null}return(i.flags&128)!==0?(i.lanes=o,i):(d=d!==null,d!==(n!==null&&n.memoizedState!==null)&&d&&(i.child.flags|=8192,(i.mode&1)!==0&&(n===null||(an.current&1)!==0?xn===0&&(xn=3):nd())),i.updateQueue!==null&&(i.flags|=4),Fn(i),null);case 4:return Vs(),Hu(n,i),n===null&&ja(i.stateNode.containerInfo),Fn(i),null;case 10:return gu(i.type._context),Fn(i),null;case 17:return Qn(i.type)&&Wo(),Fn(i),null;case 19:if(Jt(an),y=i.memoizedState,y===null)return Fn(i),null;if(d=(i.flags&128)!==0,A=y.rendering,A===null)if(d)Ja(y,!1);else{if(xn!==0||n!==null&&(n.flags&128)!==0)for(n=i.child;n!==null;){if(A=nl(n),A!==null){for(i.flags|=128,Ja(y,!1),d=A.updateQueue,d!==null&&(i.updateQueue=d,i.flags|=4),i.subtreeFlags=0,d=o,o=i.child;o!==null;)y=o,n=d,y.flags&=14680066,A=y.alternate,A===null?(y.childLanes=0,y.lanes=n,y.child=null,y.subtreeFlags=0,y.memoizedProps=null,y.memoizedState=null,y.updateQueue=null,y.dependencies=null,y.stateNode=null):(y.childLanes=A.childLanes,y.lanes=A.lanes,y.child=A.child,y.subtreeFlags=0,y.deletions=null,y.memoizedProps=A.memoizedProps,y.memoizedState=A.memoizedState,y.updateQueue=A.updateQueue,y.type=A.type,n=A.dependencies,y.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext}),o=o.sibling;return Kt(an,an.current&1|2),i.child}n=n.sibling}y.tail!==null&&bt()>qs&&(i.flags|=128,d=!0,Ja(y,!1),i.lanes=4194304)}else{if(!d)if(n=nl(A),n!==null){if(i.flags|=128,d=!0,o=n.updateQueue,o!==null&&(i.updateQueue=o,i.flags|=4),Ja(y,!0),y.tail===null&&y.tailMode==="hidden"&&!A.alternate&&!sn)return Fn(i),null}else 2*bt()-y.renderingStartTime>qs&&o!==1073741824&&(i.flags|=128,d=!0,Ja(y,!1),i.lanes=4194304);y.isBackwards?(A.sibling=i.child,i.child=A):(o=y.last,o!==null?o.sibling=A:i.child=A,y.last=A)}return y.tail!==null?(i=y.tail,y.rendering=i,y.tail=i.sibling,y.renderingStartTime=bt(),i.sibling=null,o=an.current,Kt(an,d?o&1|2:o&1),i):(Fn(i),null);case 22:case 23:return td(),d=i.memoizedState!==null,n!==null&&n.memoizedState!==null!==d&&(i.flags|=8192),d&&(i.mode&1)!==0?(ui&1073741824)!==0&&(Fn(i),i.subtreeFlags&6&&(i.flags|=8192)):Fn(i),null;case 24:return null;case 25:return null}throw Error(t(156,i.tag))}function xv(n,i){switch(uu(i),i.tag){case 1:return Qn(i.type)&&Wo(),n=i.flags,n&65536?(i.flags=n&-65537|128,i):null;case 3:return Vs(),Jt(Zn),Jt(In),Mu(),n=i.flags,(n&65536)!==0&&(n&128)===0?(i.flags=n&-65537|128,i):null;case 5:return bu(i),null;case 13:if(Jt(an),n=i.memoizedState,n!==null&&n.dehydrated!==null){if(i.alternate===null)throw Error(t(340));Bs()}return n=i.flags,n&65536?(i.flags=n&-65537|128,i):null;case 19:return Jt(an),null;case 4:return Vs(),null;case 10:return gu(i.type._context),null;case 22:case 23:return td(),null;case 24:return null;default:return null}}var dl=!1,Un=!1,vv=typeof WeakSet=="function"?WeakSet:Set,tt=null;function Ws(n,i){var o=n.ref;if(o!==null)if(typeof o=="function")try{o(null)}catch(d){cn(n,i,d)}else o.current=null}function Vu(n,i,o){try{o()}catch(d){cn(n,i,d)}}var lm=!1;function _v(n,i){if(tu=No,n=zf(),qc(n)){if("selectionStart"in n)var o={start:n.selectionStart,end:n.selectionEnd};else e:{o=(o=n.ownerDocument)&&o.defaultView||window;var d=o.getSelection&&o.getSelection();if(d&&d.rangeCount!==0){o=d.anchorNode;var m=d.anchorOffset,y=d.focusNode;d=d.focusOffset;try{o.nodeType,y.nodeType}catch{o=null;break e}var A=0,B=-1,V=-1,ge=0,Pe=0,De=n,Ae=null;t:for(;;){for(var Ke;De!==o||m!==0&&De.nodeType!==3||(B=A+m),De!==y||d!==0&&De.nodeType!==3||(V=A+d),De.nodeType===3&&(A+=De.nodeValue.length),(Ke=De.firstChild)!==null;)Ae=De,De=Ke;for(;;){if(De===n)break t;if(Ae===o&&++ge===m&&(B=A),Ae===y&&++Pe===d&&(V=A),(Ke=De.nextSibling)!==null)break;De=Ae,Ae=De.parentNode}De=Ke}o=B===-1||V===-1?null:{start:B,end:V}}else o=null}o=o||{start:0,end:0}}else o=null;for(nu={focusedElem:n,selectionRange:o},No=!1,tt=i;tt!==null;)if(i=tt,n=i.child,(i.subtreeFlags&1028)!==0&&n!==null)n.return=i,tt=n;else for(;tt!==null;){i=tt;try{var nt=i.alternate;if((i.flags&1024)!==0)switch(i.tag){case 0:case 11:case 15:break;case 1:if(nt!==null){var rt=nt.memoizedProps,dn=nt.memoizedState,he=i.stateNode,J=he.getSnapshotBeforeUpdate(i.elementType===i.type?rt:Ri(i.type,rt),dn);he.__reactInternalSnapshotBeforeUpdate=J}break;case 3:var pe=i.stateNode.containerInfo;pe.nodeType===1?pe.textContent="":pe.nodeType===9&&pe.documentElement&&pe.removeChild(pe.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(t(163))}}catch(Ue){cn(i,i.return,Ue)}if(n=i.sibling,n!==null){n.return=i.return,tt=n;break}tt=i.return}return nt=lm,lm=!1,nt}function eo(n,i,o){var d=i.updateQueue;if(d=d!==null?d.lastEffect:null,d!==null){var m=d=d.next;do{if((m.tag&n)===n){var y=m.destroy;m.destroy=void 0,y!==void 0&&Vu(i,o,y)}m=m.next}while(m!==d)}}function hl(n,i){if(i=i.updateQueue,i=i!==null?i.lastEffect:null,i!==null){var o=i=i.next;do{if((o.tag&n)===n){var d=o.create;o.destroy=d()}o=o.next}while(o!==i)}}function Gu(n){var i=n.ref;if(i!==null){var o=n.stateNode;switch(n.tag){case 5:n=o;break;default:n=o}typeof i=="function"?i(n):i.current=n}}function cm(n){var i=n.alternate;i!==null&&(n.alternate=null,cm(i)),n.child=null,n.deletions=null,n.sibling=null,n.tag===5&&(i=n.stateNode,i!==null&&(delete i[Gi],delete i[Va],delete i[au],delete i[tv],delete i[nv])),n.stateNode=null,n.return=null,n.dependencies=null,n.memoizedProps=null,n.memoizedState=null,n.pendingProps=null,n.stateNode=null,n.updateQueue=null}function um(n){return n.tag===5||n.tag===3||n.tag===4}function dm(n){e:for(;;){for(;n.sibling===null;){if(n.return===null||um(n.return))return null;n=n.return}for(n.sibling.return=n.return,n=n.sibling;n.tag!==5&&n.tag!==6&&n.tag!==18;){if(n.flags&2||n.child===null||n.tag===4)continue e;n.child.return=n,n=n.child}if(!(n.flags&2))return n.stateNode}}function Wu(n,i,o){var d=n.tag;if(d===5||d===6)n=n.stateNode,i?o.nodeType===8?o.parentNode.insertBefore(n,i):o.insertBefore(n,i):(o.nodeType===8?(i=o.parentNode,i.insertBefore(n,o)):(i=o,i.appendChild(n)),o=o._reactRootContainer,o!=null||i.onclick!==null||(i.onclick=Vo));else if(d!==4&&(n=n.child,n!==null))for(Wu(n,i,o),n=n.sibling;n!==null;)Wu(n,i,o),n=n.sibling}function Xu(n,i,o){var d=n.tag;if(d===5||d===6)n=n.stateNode,i?o.insertBefore(n,i):o.appendChild(n);else if(d!==4&&(n=n.child,n!==null))for(Xu(n,i,o),n=n.sibling;n!==null;)Xu(n,i,o),n=n.sibling}var Nn=null,Pi=!1;function Ir(n,i,o){for(o=o.child;o!==null;)hm(n,i,o),o=o.sibling}function hm(n,i,o){if(Te&&typeof Te.onCommitFiberUnmount=="function")try{Te.onCommitFiberUnmount(ne,o)}catch{}switch(o.tag){case 5:Un||Ws(o,i);case 6:var d=Nn,m=Pi;Nn=null,Ir(n,i,o),Nn=d,Pi=m,Nn!==null&&(Pi?(n=Nn,o=o.stateNode,n.nodeType===8?n.parentNode.removeChild(o):n.removeChild(o)):Nn.removeChild(o.stateNode));break;case 18:Nn!==null&&(Pi?(n=Nn,o=o.stateNode,n.nodeType===8?su(n.parentNode,o):n.nodeType===1&&su(n,o),La(n)):su(Nn,o.stateNode));break;case 4:d=Nn,m=Pi,Nn=o.stateNode.containerInfo,Pi=!0,Ir(n,i,o),Nn=d,Pi=m;break;case 0:case 11:case 14:case 15:if(!Un&&(d=o.updateQueue,d!==null&&(d=d.lastEffect,d!==null))){m=d=d.next;do{var y=m,A=y.destroy;y=y.tag,A!==void 0&&((y&2)!==0||(y&4)!==0)&&Vu(o,i,A),m=m.next}while(m!==d)}Ir(n,i,o);break;case 1:if(!Un&&(Ws(o,i),d=o.stateNode,typeof d.componentWillUnmount=="function"))try{d.props=o.memoizedProps,d.state=o.memoizedState,d.componentWillUnmount()}catch(B){cn(o,i,B)}Ir(n,i,o);break;case 21:Ir(n,i,o);break;case 22:o.mode&1?(Un=(d=Un)||o.memoizedState!==null,Ir(n,i,o),Un=d):Ir(n,i,o);break;default:Ir(n,i,o)}}function fm(n){var i=n.updateQueue;if(i!==null){n.updateQueue=null;var o=n.stateNode;o===null&&(o=n.stateNode=new vv),i.forEach(function(d){var m=Cv.bind(null,n,d);o.has(d)||(o.add(d),d.then(m,m))})}}function Ni(n,i){var o=i.deletions;if(o!==null)for(var d=0;d<o.length;d++){var m=o[d];try{var y=n,A=i,B=A;e:for(;B!==null;){switch(B.tag){case 5:Nn=B.stateNode,Pi=!1;break e;case 3:Nn=B.stateNode.containerInfo,Pi=!0;break e;case 4:Nn=B.stateNode.containerInfo,Pi=!0;break e}B=B.return}if(Nn===null)throw Error(t(160));hm(y,A,m),Nn=null,Pi=!1;var V=m.alternate;V!==null&&(V.return=null),m.return=null}catch(ge){cn(m,i,ge)}}if(i.subtreeFlags&12854)for(i=i.child;i!==null;)pm(i,n),i=i.sibling}function pm(n,i){var o=n.alternate,d=n.flags;switch(n.tag){case 0:case 11:case 14:case 15:if(Ni(i,n),qi(n),d&4){try{eo(3,n,n.return),hl(3,n)}catch(rt){cn(n,n.return,rt)}try{eo(5,n,n.return)}catch(rt){cn(n,n.return,rt)}}break;case 1:Ni(i,n),qi(n),d&512&&o!==null&&Ws(o,o.return);break;case 5:if(Ni(i,n),qi(n),d&512&&o!==null&&Ws(o,o.return),n.flags&32){var m=n.stateNode;try{me(m,"")}catch(rt){cn(n,n.return,rt)}}if(d&4&&(m=n.stateNode,m!=null)){var y=n.memoizedProps,A=o!==null?o.memoizedProps:y,B=n.type,V=n.updateQueue;if(n.updateQueue=null,V!==null)try{B==="input"&&y.type==="radio"&&y.name!=null&&Je(m,y),Ie(B,A);var ge=Ie(B,y);for(A=0;A<V.length;A+=2){var Pe=V[A],De=V[A+1];Pe==="style"?ye(m,De):Pe==="dangerouslySetInnerHTML"?ae(m,De):Pe==="children"?me(m,De):P(m,Pe,De,ge)}switch(B){case"input":Lt(m,y);break;case"textarea":et(m,y);break;case"select":var Ae=m._wrapperState.wasMultiple;m._wrapperState.wasMultiple=!!y.multiple;var Ke=y.value;Ke!=null?wt(m,!!y.multiple,Ke,!1):Ae!==!!y.multiple&&(y.defaultValue!=null?wt(m,!!y.multiple,y.defaultValue,!0):wt(m,!!y.multiple,y.multiple?[]:"",!1))}m[Va]=y}catch(rt){cn(n,n.return,rt)}}break;case 6:if(Ni(i,n),qi(n),d&4){if(n.stateNode===null)throw Error(t(162));m=n.stateNode,y=n.memoizedProps;try{m.nodeValue=y}catch(rt){cn(n,n.return,rt)}}break;case 3:if(Ni(i,n),qi(n),d&4&&o!==null&&o.memoizedState.isDehydrated)try{La(i.containerInfo)}catch(rt){cn(n,n.return,rt)}break;case 4:Ni(i,n),qi(n);break;case 13:Ni(i,n),qi(n),m=n.child,m.flags&8192&&(y=m.memoizedState!==null,m.stateNode.isHidden=y,!y||m.alternate!==null&&m.alternate.memoizedState!==null||(Yu=bt())),d&4&&fm(n);break;case 22:if(Pe=o!==null&&o.memoizedState!==null,n.mode&1?(Un=(ge=Un)||Pe,Ni(i,n),Un=ge):Ni(i,n),qi(n),d&8192){if(ge=n.memoizedState!==null,(n.stateNode.isHidden=ge)&&!Pe&&(n.mode&1)!==0)for(tt=n,Pe=n.child;Pe!==null;){for(De=tt=Pe;tt!==null;){switch(Ae=tt,Ke=Ae.child,Ae.tag){case 0:case 11:case 14:case 15:eo(4,Ae,Ae.return);break;case 1:Ws(Ae,Ae.return);var nt=Ae.stateNode;if(typeof nt.componentWillUnmount=="function"){d=Ae,o=Ae.return;try{i=d,nt.props=i.memoizedProps,nt.state=i.memoizedState,nt.componentWillUnmount()}catch(rt){cn(d,o,rt)}}break;case 5:Ws(Ae,Ae.return);break;case 22:if(Ae.memoizedState!==null){xm(De);continue}}Ke!==null?(Ke.return=Ae,tt=Ke):xm(De)}Pe=Pe.sibling}e:for(Pe=null,De=n;;){if(De.tag===5){if(Pe===null){Pe=De;try{m=De.stateNode,ge?(y=m.style,typeof y.setProperty=="function"?y.setProperty("display","none","important"):y.display="none"):(B=De.stateNode,V=De.memoizedProps.style,A=V!=null&&V.hasOwnProperty("display")?V.display:null,B.style.display=ue("display",A))}catch(rt){cn(n,n.return,rt)}}}else if(De.tag===6){if(Pe===null)try{De.stateNode.nodeValue=ge?"":De.memoizedProps}catch(rt){cn(n,n.return,rt)}}else if((De.tag!==22&&De.tag!==23||De.memoizedState===null||De===n)&&De.child!==null){De.child.return=De,De=De.child;continue}if(De===n)break e;for(;De.sibling===null;){if(De.return===null||De.return===n)break e;Pe===De&&(Pe=null),De=De.return}Pe===De&&(Pe=null),De.sibling.return=De.return,De=De.sibling}}break;case 19:Ni(i,n),qi(n),d&4&&fm(n);break;case 21:break;default:Ni(i,n),qi(n)}}function qi(n){var i=n.flags;if(i&2){try{e:{for(var o=n.return;o!==null;){if(um(o)){var d=o;break e}o=o.return}throw Error(t(160))}switch(d.tag){case 5:var m=d.stateNode;d.flags&32&&(me(m,""),d.flags&=-33);var y=dm(n);Xu(n,y,m);break;case 3:case 4:var A=d.stateNode.containerInfo,B=dm(n);Wu(n,B,A);break;default:throw Error(t(161))}}catch(V){cn(n,n.return,V)}n.flags&=-3}i&4096&&(n.flags&=-4097)}function yv(n,i,o){tt=n,mm(n)}function mm(n,i,o){for(var d=(n.mode&1)!==0;tt!==null;){var m=tt,y=m.child;if(m.tag===22&&d){var A=m.memoizedState!==null||dl;if(!A){var B=m.alternate,V=B!==null&&B.memoizedState!==null||Un;B=dl;var ge=Un;if(dl=A,(Un=V)&&!ge)for(tt=m;tt!==null;)A=tt,V=A.child,A.tag===22&&A.memoizedState!==null?vm(m):V!==null?(V.return=A,tt=V):vm(m);for(;y!==null;)tt=y,mm(y),y=y.sibling;tt=m,dl=B,Un=ge}gm(n)}else(m.subtreeFlags&8772)!==0&&y!==null?(y.return=m,tt=y):gm(n)}}function gm(n){for(;tt!==null;){var i=tt;if((i.flags&8772)!==0){var o=i.alternate;try{if((i.flags&8772)!==0)switch(i.tag){case 0:case 11:case 15:Un||hl(5,i);break;case 1:var d=i.stateNode;if(i.flags&4&&!Un)if(o===null)d.componentDidMount();else{var m=i.elementType===i.type?o.memoizedProps:Ri(i.type,o.memoizedProps);d.componentDidUpdate(m,o.memoizedState,d.__reactInternalSnapshotBeforeUpdate)}var y=i.updateQueue;y!==null&&xp(i,y,d);break;case 3:var A=i.updateQueue;if(A!==null){if(o=null,i.child!==null)switch(i.child.tag){case 5:o=i.child.stateNode;break;case 1:o=i.child.stateNode}xp(i,A,o)}break;case 5:var B=i.stateNode;if(o===null&&i.flags&4){o=B;var V=i.memoizedProps;switch(i.type){case"button":case"input":case"select":case"textarea":V.autoFocus&&o.focus();break;case"img":V.src&&(o.src=V.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(i.memoizedState===null){var ge=i.alternate;if(ge!==null){var Pe=ge.memoizedState;if(Pe!==null){var De=Pe.dehydrated;De!==null&&La(De)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(t(163))}Un||i.flags&512&&Gu(i)}catch(Ae){cn(i,i.return,Ae)}}if(i===n){tt=null;break}if(o=i.sibling,o!==null){o.return=i.return,tt=o;break}tt=i.return}}function xm(n){for(;tt!==null;){var i=tt;if(i===n){tt=null;break}var o=i.sibling;if(o!==null){o.return=i.return,tt=o;break}tt=i.return}}function vm(n){for(;tt!==null;){var i=tt;try{switch(i.tag){case 0:case 11:case 15:var o=i.return;try{hl(4,i)}catch(V){cn(i,o,V)}break;case 1:var d=i.stateNode;if(typeof d.componentDidMount=="function"){var m=i.return;try{d.componentDidMount()}catch(V){cn(i,m,V)}}var y=i.return;try{Gu(i)}catch(V){cn(i,y,V)}break;case 5:var A=i.return;try{Gu(i)}catch(V){cn(i,A,V)}}}catch(V){cn(i,i.return,V)}if(i===n){tt=null;break}var B=i.sibling;if(B!==null){B.return=i.return,tt=B;break}tt=i.return}}var bv=Math.ceil,fl=C.ReactCurrentDispatcher,qu=C.ReactCurrentOwner,vi=C.ReactCurrentBatchConfig,Ot=0,wn=null,pn=null,Ln=0,ui=0,Xs=Rr(0),xn=0,to=null,us=0,pl=0,$u=0,no=null,ei=null,Yu=0,qs=1/0,dr=null,ml=!1,Ku=null,kr=null,gl=!1,Fr=null,xl=0,io=0,Zu=null,vl=-1,_l=0;function Gn(){return(Ot&6)!==0?bt():vl!==-1?vl:vl=bt()}function Ur(n){return(n.mode&1)===0?1:(Ot&2)!==0&&Ln!==0?Ln&-Ln:rv.transition!==null?(_l===0&&(_l=Ye()),_l):(n=Pt,n!==0||(n=window.event,n=n===void 0?16:yf(n.type)),n)}function Li(n,i,o,d){if(50<io)throw io=0,Zu=null,Error(t(185));Tt(n,o,d),((Ot&2)===0||n!==wn)&&(n===wn&&((Ot&2)===0&&(pl|=o),xn===4&&Or(n,Ln)),ti(n,d),o===1&&Ot===0&&(i.mode&1)===0&&(qs=bt()+500,qo&&Nr()))}function ti(n,i){var o=n.callbackNode;Vt(n,i);var d=Xt(n,n===wn?Ln:0);if(d===0)o!==null&&rn(o),n.callbackNode=null,n.callbackPriority=0;else if(i=d&-d,n.callbackPriority!==i){if(o!=null&&rn(o),i===1)n.tag===0?iv(ym.bind(null,n)):sp(ym.bind(null,n)),Jx(function(){(Ot&6)===0&&Nr()}),o=null;else{switch(ir(d)){case 1:o=Hi;break;case 4:o=R;break;case 16:o=W;break;case 536870912:o=se;break;default:o=W}o=Cm(o,_m.bind(null,n))}n.callbackPriority=i,n.callbackNode=o}}function _m(n,i){if(vl=-1,_l=0,(Ot&6)!==0)throw Error(t(327));var o=n.callbackNode;if($s()&&n.callbackNode!==o)return null;var d=Xt(n,n===wn?Ln:0);if(d===0)return null;if((d&30)!==0||(d&n.expiredLanes)!==0||i)i=yl(n,d);else{i=d;var m=Ot;Ot|=2;var y=Sm();(wn!==n||Ln!==i)&&(dr=null,qs=bt()+500,hs(n,i));do try{wv();break}catch(B){bm(n,B)}while(!0);mu(),fl.current=y,Ot=m,pn!==null?i=0:(wn=null,Ln=0,i=xn)}if(i!==0){if(i===2&&(m=fn(n),m!==0&&(d=m,i=Qu(n,m))),i===1)throw o=to,hs(n,0),Or(n,d),ti(n,bt()),o;if(i===6)Or(n,d);else{if(m=n.current.alternate,(d&30)===0&&!Sv(m)&&(i=yl(n,d),i===2&&(y=fn(n),y!==0&&(d=y,i=Qu(n,y))),i===1))throw o=to,hs(n,0),Or(n,d),ti(n,bt()),o;switch(n.finishedWork=m,n.finishedLanes=d,i){case 0:case 1:throw Error(t(345));case 2:fs(n,ei,dr);break;case 3:if(Or(n,d),(d&130023424)===d&&(i=Yu+500-bt(),10<i)){if(Xt(n,0)!==0)break;if(m=n.suspendedLanes,(m&d)!==d){Gn(),n.pingedLanes|=n.suspendedLanes&m;break}n.timeoutHandle=ru(fs.bind(null,n,ei,dr),i);break}fs(n,ei,dr);break;case 4:if(Or(n,d),(d&4194240)===d)break;for(i=n.eventTimes,m=-1;0<d;){var A=31-Le(d);y=1<<A,A=i[A],A>m&&(m=A),d&=~y}if(d=m,d=bt()-d,d=(120>d?120:480>d?480:1080>d?1080:1920>d?1920:3e3>d?3e3:4320>d?4320:1960*bv(d/1960))-d,10<d){n.timeoutHandle=ru(fs.bind(null,n,ei,dr),d);break}fs(n,ei,dr);break;case 5:fs(n,ei,dr);break;default:throw Error(t(329))}}}return ti(n,bt()),n.callbackNode===o?_m.bind(null,n):null}function Qu(n,i){var o=no;return n.current.memoizedState.isDehydrated&&(hs(n,i).flags|=256),n=yl(n,i),n!==2&&(i=ei,ei=o,i!==null&&Ju(i)),n}function Ju(n){ei===null?ei=n:ei.push.apply(ei,n)}function Sv(n){for(var i=n;;){if(i.flags&16384){var o=i.updateQueue;if(o!==null&&(o=o.stores,o!==null))for(var d=0;d<o.length;d++){var m=o[d],y=m.getSnapshot;m=m.value;try{if(!Ai(y(),m))return!1}catch{return!1}}}if(o=i.child,i.subtreeFlags&16384&&o!==null)o.return=i,i=o;else{if(i===n)break;for(;i.sibling===null;){if(i.return===null||i.return===n)return!0;i=i.return}i.sibling.return=i.return,i=i.sibling}}return!0}function Or(n,i){for(i&=~$u,i&=~pl,n.suspendedLanes|=i,n.pingedLanes&=~i,n=n.expirationTimes;0<i;){var o=31-Le(i),d=1<<o;n[o]=-1,i&=~d}}function ym(n){if((Ot&6)!==0)throw Error(t(327));$s();var i=Xt(n,0);if((i&1)===0)return ti(n,bt()),null;var o=yl(n,i);if(n.tag!==0&&o===2){var d=fn(n);d!==0&&(i=d,o=Qu(n,d))}if(o===1)throw o=to,hs(n,0),Or(n,i),ti(n,bt()),o;if(o===6)throw Error(t(345));return n.finishedWork=n.current.alternate,n.finishedLanes=i,fs(n,ei,dr),ti(n,bt()),null}function ed(n,i){var o=Ot;Ot|=1;try{return n(i)}finally{Ot=o,Ot===0&&(qs=bt()+500,qo&&Nr())}}function ds(n){Fr!==null&&Fr.tag===0&&(Ot&6)===0&&$s();var i=Ot;Ot|=1;var o=vi.transition,d=Pt;try{if(vi.transition=null,Pt=1,n)return n()}finally{Pt=d,vi.transition=o,Ot=i,(Ot&6)===0&&Nr()}}function td(){ui=Xs.current,Jt(Xs)}function hs(n,i){n.finishedWork=null,n.finishedLanes=0;var o=n.timeoutHandle;if(o!==-1&&(n.timeoutHandle=-1,Qx(o)),pn!==null)for(o=pn.return;o!==null;){var d=o;switch(uu(d),d.tag){case 1:d=d.type.childContextTypes,d!=null&&Wo();break;case 3:Vs(),Jt(Zn),Jt(In),Mu();break;case 5:bu(d);break;case 4:Vs();break;case 13:Jt(an);break;case 19:Jt(an);break;case 10:gu(d.type._context);break;case 22:case 23:td()}o=o.return}if(wn=n,pn=n=Br(n.current,null),Ln=ui=i,xn=0,to=null,$u=pl=us=0,ei=no=null,os!==null){for(i=0;i<os.length;i++)if(o=os[i],d=o.interleaved,d!==null){o.interleaved=null;var m=d.next,y=o.pending;if(y!==null){var A=y.next;y.next=m,d.next=A}o.pending=d}os=null}return n}function bm(n,i){do{var o=pn;try{if(mu(),il.current=ol,rl){for(var d=on.memoizedState;d!==null;){var m=d.queue;m!==null&&(m.pending=null),d=d.next}rl=!1}if(cs=0,Mn=gn=on=null,Ya=!1,Ka=0,qu.current=null,o===null||o.return===null){xn=1,to=i,pn=null;break}e:{var y=n,A=o.return,B=o,V=i;if(i=Ln,B.flags|=32768,V!==null&&typeof V=="object"&&typeof V.then=="function"){var ge=V,Pe=B,De=Pe.tag;if((Pe.mode&1)===0&&(De===0||De===11||De===15)){var Ae=Pe.alternate;Ae?(Pe.updateQueue=Ae.updateQueue,Pe.memoizedState=Ae.memoizedState,Pe.lanes=Ae.lanes):(Pe.updateQueue=null,Pe.memoizedState=null)}var Ke=Xp(A);if(Ke!==null){Ke.flags&=-257,qp(Ke,A,B,y,i),Ke.mode&1&&Wp(y,ge,i),i=Ke,V=ge;var nt=i.updateQueue;if(nt===null){var rt=new Set;rt.add(V),i.updateQueue=rt}else nt.add(V);break e}else{if((i&1)===0){Wp(y,ge,i),nd();break e}V=Error(t(426))}}else if(sn&&B.mode&1){var dn=Xp(A);if(dn!==null){(dn.flags&65536)===0&&(dn.flags|=256),qp(dn,A,B,y,i),fu(Gs(V,B));break e}}y=V=Gs(V,B),xn!==4&&(xn=2),no===null?no=[y]:no.push(y),y=A;do{switch(y.tag){case 3:y.flags|=65536,i&=-i,y.lanes|=i;var he=Vp(y,V,i);gp(y,he);break e;case 1:B=V;var J=y.type,pe=y.stateNode;if((y.flags&128)===0&&(typeof J.getDerivedStateFromError=="function"||pe!==null&&typeof pe.componentDidCatch=="function"&&(kr===null||!kr.has(pe)))){y.flags|=65536,i&=-i,y.lanes|=i;var Ue=Gp(y,B,i);gp(y,Ue);break e}}y=y.return}while(y!==null)}wm(o)}catch(ot){i=ot,pn===o&&o!==null&&(pn=o=o.return);continue}break}while(!0)}function Sm(){var n=fl.current;return fl.current=ol,n===null?ol:n}function nd(){(xn===0||xn===3||xn===2)&&(xn=4),wn===null||(us&268435455)===0&&(pl&268435455)===0||Or(wn,Ln)}function yl(n,i){var o=Ot;Ot|=2;var d=Sm();(wn!==n||Ln!==i)&&(dr=null,hs(n,i));do try{Mv();break}catch(m){bm(n,m)}while(!0);if(mu(),Ot=o,fl.current=d,pn!==null)throw Error(t(261));return wn=null,Ln=0,xn}function Mv(){for(;pn!==null;)Mm(pn)}function wv(){for(;pn!==null&&!hn();)Mm(pn)}function Mm(n){var i=Am(n.alternate,n,ui);n.memoizedProps=n.pendingProps,i===null?wm(n):pn=i,qu.current=null}function wm(n){var i=n;do{var o=i.alternate;if(n=i.return,(i.flags&32768)===0){if(o=gv(o,i,ui),o!==null){pn=o;return}}else{if(o=xv(o,i),o!==null){o.flags&=32767,pn=o;return}if(n!==null)n.flags|=32768,n.subtreeFlags=0,n.deletions=null;else{xn=6,pn=null;return}}if(i=i.sibling,i!==null){pn=i;return}pn=i=n}while(i!==null);xn===0&&(xn=5)}function fs(n,i,o){var d=Pt,m=vi.transition;try{vi.transition=null,Pt=1,Ev(n,i,o,d)}finally{vi.transition=m,Pt=d}return null}function Ev(n,i,o,d){do $s();while(Fr!==null);if((Ot&6)!==0)throw Error(t(327));o=n.finishedWork;var m=n.finishedLanes;if(o===null)return null;if(n.finishedWork=null,n.finishedLanes=0,o===n.current)throw Error(t(177));n.callbackNode=null,n.callbackPriority=0;var y=o.lanes|o.childLanes;if(Yn(n,y),n===wn&&(pn=wn=null,Ln=0),(o.subtreeFlags&2064)===0&&(o.flags&2064)===0||gl||(gl=!0,Cm(W,function(){return $s(),null})),y=(o.flags&15990)!==0,(o.subtreeFlags&15990)!==0||y){y=vi.transition,vi.transition=null;var A=Pt;Pt=1;var B=Ot;Ot|=4,qu.current=null,_v(n,o),pm(o,n),Wx(nu),No=!!tu,nu=tu=null,n.current=o,yv(o),ln(),Ot=B,Pt=A,vi.transition=y}else n.current=o;if(gl&&(gl=!1,Fr=n,xl=m),y=n.pendingLanes,y===0&&(kr=null),Oe(o.stateNode),ti(n,bt()),i!==null)for(d=n.onRecoverableError,o=0;o<i.length;o++)m=i[o],d(m.value,{componentStack:m.stack,digest:m.digest});if(ml)throw ml=!1,n=Ku,Ku=null,n;return(xl&1)!==0&&n.tag!==0&&$s(),y=n.pendingLanes,(y&1)!==0?n===Zu?io++:(io=0,Zu=n):io=0,Nr(),null}function $s(){if(Fr!==null){var n=ir(xl),i=vi.transition,o=Pt;try{if(vi.transition=null,Pt=16>n?16:n,Fr===null)var d=!1;else{if(n=Fr,Fr=null,xl=0,(Ot&6)!==0)throw Error(t(331));var m=Ot;for(Ot|=4,tt=n.current;tt!==null;){var y=tt,A=y.child;if((tt.flags&16)!==0){var B=y.deletions;if(B!==null){for(var V=0;V<B.length;V++){var ge=B[V];for(tt=ge;tt!==null;){var Pe=tt;switch(Pe.tag){case 0:case 11:case 15:eo(8,Pe,y)}var De=Pe.child;if(De!==null)De.return=Pe,tt=De;else for(;tt!==null;){Pe=tt;var Ae=Pe.sibling,Ke=Pe.return;if(cm(Pe),Pe===ge){tt=null;break}if(Ae!==null){Ae.return=Ke,tt=Ae;break}tt=Ke}}}var nt=y.alternate;if(nt!==null){var rt=nt.child;if(rt!==null){nt.child=null;do{var dn=rt.sibling;rt.sibling=null,rt=dn}while(rt!==null)}}tt=y}}if((y.subtreeFlags&2064)!==0&&A!==null)A.return=y,tt=A;else e:for(;tt!==null;){if(y=tt,(y.flags&2048)!==0)switch(y.tag){case 0:case 11:case 15:eo(9,y,y.return)}var he=y.sibling;if(he!==null){he.return=y.return,tt=he;break e}tt=y.return}}var J=n.current;for(tt=J;tt!==null;){A=tt;var pe=A.child;if((A.subtreeFlags&2064)!==0&&pe!==null)pe.return=A,tt=pe;else e:for(A=J;tt!==null;){if(B=tt,(B.flags&2048)!==0)try{switch(B.tag){case 0:case 11:case 15:hl(9,B)}}catch(ot){cn(B,B.return,ot)}if(B===A){tt=null;break e}var Ue=B.sibling;if(Ue!==null){Ue.return=B.return,tt=Ue;break e}tt=B.return}}if(Ot=m,Nr(),Te&&typeof Te.onPostCommitFiberRoot=="function")try{Te.onPostCommitFiberRoot(ne,n)}catch{}d=!0}return d}finally{Pt=o,vi.transition=i}}return!1}function Em(n,i,o){i=Gs(o,i),i=Vp(n,i,1),n=Dr(n,i,1),i=Gn(),n!==null&&(Tt(n,1,i),ti(n,i))}function cn(n,i,o){if(n.tag===3)Em(n,n,o);else for(;i!==null;){if(i.tag===3){Em(i,n,o);break}else if(i.tag===1){var d=i.stateNode;if(typeof i.type.getDerivedStateFromError=="function"||typeof d.componentDidCatch=="function"&&(kr===null||!kr.has(d))){n=Gs(o,n),n=Gp(i,n,1),i=Dr(i,n,1),n=Gn(),i!==null&&(Tt(i,1,n),ti(i,n));break}}i=i.return}}function Tv(n,i,o){var d=n.pingCache;d!==null&&d.delete(i),i=Gn(),n.pingedLanes|=n.suspendedLanes&o,wn===n&&(Ln&o)===o&&(xn===4||xn===3&&(Ln&130023424)===Ln&&500>bt()-Yu?hs(n,0):$u|=o),ti(n,i)}function Tm(n,i){i===0&&((n.mode&1)===0?i=1:(i=$e,$e<<=1,($e&130023424)===0&&($e=4194304)));var o=Gn();n=lr(n,i),n!==null&&(Tt(n,i,o),ti(n,o))}function Av(n){var i=n.memoizedState,o=0;i!==null&&(o=i.retryLane),Tm(n,o)}function Cv(n,i){var o=0;switch(n.tag){case 13:var d=n.stateNode,m=n.memoizedState;m!==null&&(o=m.retryLane);break;case 19:d=n.stateNode;break;default:throw Error(t(314))}d!==null&&d.delete(i),Tm(n,o)}var Am;Am=function(n,i,o){if(n!==null)if(n.memoizedProps!==i.pendingProps||Zn.current)Jn=!0;else{if((n.lanes&o)===0&&(i.flags&128)===0)return Jn=!1,mv(n,i,o);Jn=(n.flags&131072)!==0}else Jn=!1,sn&&(i.flags&1048576)!==0&&ap(i,Yo,i.index);switch(i.lanes=0,i.tag){case 2:var d=i.type;ul(n,i),n=i.pendingProps;var m=Fs(i,In.current);Hs(i,o),m=Tu(null,i,d,n,m,o);var y=Au();return i.flags|=1,typeof m=="object"&&m!==null&&typeof m.render=="function"&&m.$$typeof===void 0?(i.tag=1,i.memoizedState=null,i.updateQueue=null,Qn(d)?(y=!0,Xo(i)):y=!1,i.memoizedState=m.state!==null&&m.state!==void 0?m.state:null,_u(i),m.updater=ll,i.stateNode=m,m._reactInternals=i,Du(i,d,n,o),i=Uu(null,i,d,!0,y,o)):(i.tag=0,sn&&y&&cu(i),Vn(null,i,m,o),i=i.child),i;case 16:d=i.elementType;e:{switch(ul(n,i),n=i.pendingProps,m=d._init,d=m(d._payload),i.type=d,m=i.tag=Pv(d),n=Ri(d,n),m){case 0:i=Fu(null,i,d,n,o);break e;case 1:i=Jp(null,i,d,n,o);break e;case 11:i=$p(null,i,d,n,o);break e;case 14:i=Yp(null,i,d,Ri(d.type,n),o);break e}throw Error(t(306,d,""))}return i;case 0:return d=i.type,m=i.pendingProps,m=i.elementType===d?m:Ri(d,m),Fu(n,i,d,m,o);case 1:return d=i.type,m=i.pendingProps,m=i.elementType===d?m:Ri(d,m),Jp(n,i,d,m,o);case 3:e:{if(em(i),n===null)throw Error(t(387));d=i.pendingProps,y=i.memoizedState,m=y.element,mp(n,i),tl(i,d,null,o);var A=i.memoizedState;if(d=A.element,y.isDehydrated)if(y={element:d,isDehydrated:!1,cache:A.cache,pendingSuspenseBoundaries:A.pendingSuspenseBoundaries,transitions:A.transitions},i.updateQueue.baseState=y,i.memoizedState=y,i.flags&256){m=Gs(Error(t(423)),i),i=tm(n,i,d,o,m);break e}else if(d!==m){m=Gs(Error(t(424)),i),i=tm(n,i,d,o,m);break e}else for(ci=Cr(i.stateNode.containerInfo.firstChild),li=i,sn=!0,Ci=null,o=fp(i,null,d,o),i.child=o;o;)o.flags=o.flags&-3|4096,o=o.sibling;else{if(Bs(),d===m){i=ur(n,i,o);break e}Vn(n,i,d,o)}i=i.child}return i;case 5:return vp(i),n===null&&hu(i),d=i.type,m=i.pendingProps,y=n!==null?n.memoizedProps:null,A=m.children,iu(d,m)?A=null:y!==null&&iu(d,y)&&(i.flags|=32),Qp(n,i),Vn(n,i,A,o),i.child;case 6:return n===null&&hu(i),null;case 13:return nm(n,i,o);case 4:return yu(i,i.stateNode.containerInfo),d=i.pendingProps,n===null?i.child=zs(i,null,d,o):Vn(n,i,d,o),i.child;case 11:return d=i.type,m=i.pendingProps,m=i.elementType===d?m:Ri(d,m),$p(n,i,d,m,o);case 7:return Vn(n,i,i.pendingProps,o),i.child;case 8:return Vn(n,i,i.pendingProps.children,o),i.child;case 12:return Vn(n,i,i.pendingProps.children,o),i.child;case 10:e:{if(d=i.type._context,m=i.pendingProps,y=i.memoizedProps,A=m.value,Kt(Qo,d._currentValue),d._currentValue=A,y!==null)if(Ai(y.value,A)){if(y.children===m.children&&!Zn.current){i=ur(n,i,o);break e}}else for(y=i.child,y!==null&&(y.return=i);y!==null;){var B=y.dependencies;if(B!==null){A=y.child;for(var V=B.firstContext;V!==null;){if(V.context===d){if(y.tag===1){V=cr(-1,o&-o),V.tag=2;var ge=y.updateQueue;if(ge!==null){ge=ge.shared;var Pe=ge.pending;Pe===null?V.next=V:(V.next=Pe.next,Pe.next=V),ge.pending=V}}y.lanes|=o,V=y.alternate,V!==null&&(V.lanes|=o),xu(y.return,o,i),B.lanes|=o;break}V=V.next}}else if(y.tag===10)A=y.type===i.type?null:y.child;else if(y.tag===18){if(A=y.return,A===null)throw Error(t(341));A.lanes|=o,B=A.alternate,B!==null&&(B.lanes|=o),xu(A,o,i),A=y.sibling}else A=y.child;if(A!==null)A.return=y;else for(A=y;A!==null;){if(A===i){A=null;break}if(y=A.sibling,y!==null){y.return=A.return,A=y;break}A=A.return}y=A}Vn(n,i,m.children,o),i=i.child}return i;case 9:return m=i.type,d=i.pendingProps.children,Hs(i,o),m=gi(m),d=d(m),i.flags|=1,Vn(n,i,d,o),i.child;case 14:return d=i.type,m=Ri(d,i.pendingProps),m=Ri(d.type,m),Yp(n,i,d,m,o);case 15:return Kp(n,i,i.type,i.pendingProps,o);case 17:return d=i.type,m=i.pendingProps,m=i.elementType===d?m:Ri(d,m),ul(n,i),i.tag=1,Qn(d)?(n=!0,Xo(i)):n=!1,Hs(i,o),jp(i,d,m),Du(i,d,m,o),Uu(null,i,d,!0,n,o);case 19:return rm(n,i,o);case 22:return Zp(n,i,o)}throw Error(t(156,i.tag))};function Cm(n,i){return nn(n,i)}function Rv(n,i,o,d){this.tag=n,this.key=o,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=i,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=d,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function _i(n,i,o,d){return new Rv(n,i,o,d)}function id(n){return n=n.prototype,!(!n||!n.isReactComponent)}function Pv(n){if(typeof n=="function")return id(n)?1:0;if(n!=null){if(n=n.$$typeof,n===H)return 11;if(n===q)return 14}return 2}function Br(n,i){var o=n.alternate;return o===null?(o=_i(n.tag,i,n.key,n.mode),o.elementType=n.elementType,o.type=n.type,o.stateNode=n.stateNode,o.alternate=n,n.alternate=o):(o.pendingProps=i,o.type=n.type,o.flags=0,o.subtreeFlags=0,o.deletions=null),o.flags=n.flags&14680064,o.childLanes=n.childLanes,o.lanes=n.lanes,o.child=n.child,o.memoizedProps=n.memoizedProps,o.memoizedState=n.memoizedState,o.updateQueue=n.updateQueue,i=n.dependencies,o.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext},o.sibling=n.sibling,o.index=n.index,o.ref=n.ref,o}function bl(n,i,o,d,m,y){var A=2;if(d=n,typeof n=="function")id(n)&&(A=1);else if(typeof n=="string")A=5;else e:switch(n){case U:return ps(o.children,m,y,i);case T:A=8,m|=8;break;case I:return n=_i(12,o,i,m|2),n.elementType=I,n.lanes=y,n;case fe:return n=_i(13,o,i,m),n.elementType=fe,n.lanes=y,n;case re:return n=_i(19,o,i,m),n.elementType=re,n.lanes=y,n;case oe:return Sl(o,m,y,i);default:if(typeof n=="object"&&n!==null)switch(n.$$typeof){case z:A=10;break e;case O:A=9;break e;case H:A=11;break e;case q:A=14;break e;case de:A=16,d=null;break e}throw Error(t(130,n==null?n:typeof n,""))}return i=_i(A,o,i,m),i.elementType=n,i.type=d,i.lanes=y,i}function ps(n,i,o,d){return n=_i(7,n,d,i),n.lanes=o,n}function Sl(n,i,o,d){return n=_i(22,n,d,i),n.elementType=oe,n.lanes=o,n.stateNode={isHidden:!1},n}function rd(n,i,o){return n=_i(6,n,null,i),n.lanes=o,n}function sd(n,i,o){return i=_i(4,n.children!==null?n.children:[],n.key,i),i.lanes=o,i.stateNode={containerInfo:n.containerInfo,pendingChildren:null,implementation:n.implementation},i}function Nv(n,i,o,d,m){this.tag=i,this.containerInfo=n,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=Pn(0),this.expirationTimes=Pn(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Pn(0),this.identifierPrefix=d,this.onRecoverableError=m,this.mutableSourceEagerHydrationData=null}function ad(n,i,o,d,m,y,A,B,V){return n=new Nv(n,i,o,B,V),i===1?(i=1,y===!0&&(i|=8)):i=0,y=_i(3,null,null,i),n.current=y,y.stateNode=n,y.memoizedState={element:d,isDehydrated:o,cache:null,transitions:null,pendingSuspenseBoundaries:null},_u(y),n}function Lv(n,i,o){var d=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:D,key:d==null?null:""+d,children:n,containerInfo:i,implementation:o}}function Rm(n){if(!n)return Pr;n=n._reactInternals;e:{if(Sn(n)!==n||n.tag!==1)throw Error(t(170));var i=n;do{switch(i.tag){case 3:i=i.stateNode.context;break e;case 1:if(Qn(i.type)){i=i.stateNode.__reactInternalMemoizedMergedChildContext;break e}}i=i.return}while(i!==null);throw Error(t(171))}if(n.tag===1){var o=n.type;if(Qn(o))return ip(n,o,i)}return i}function Pm(n,i,o,d,m,y,A,B,V){return n=ad(o,d,!0,n,m,y,A,B,V),n.context=Rm(null),o=n.current,d=Gn(),m=Ur(o),y=cr(d,m),y.callback=i??null,Dr(o,y,m),n.current.lanes=m,Tt(n,m,d),ti(n,d),n}function Ml(n,i,o,d){var m=i.current,y=Gn(),A=Ur(m);return o=Rm(o),i.context===null?i.context=o:i.pendingContext=o,i=cr(y,A),i.payload={element:n},d=d===void 0?null:d,d!==null&&(i.callback=d),n=Dr(m,i,A),n!==null&&(Li(n,m,A,y),el(n,m,A)),A}function wl(n){if(n=n.current,!n.child)return null;switch(n.child.tag){case 5:return n.child.stateNode;default:return n.child.stateNode}}function Nm(n,i){if(n=n.memoizedState,n!==null&&n.dehydrated!==null){var o=n.retryLane;n.retryLane=o!==0&&o<i?o:i}}function od(n,i){Nm(n,i),(n=n.alternate)&&Nm(n,i)}function Dv(){return null}var Lm=typeof reportError=="function"?reportError:function(n){console.error(n)};function ld(n){this._internalRoot=n}El.prototype.render=ld.prototype.render=function(n){var i=this._internalRoot;if(i===null)throw Error(t(409));Ml(n,i,null,null)},El.prototype.unmount=ld.prototype.unmount=function(){var n=this._internalRoot;if(n!==null){this._internalRoot=null;var i=n.containerInfo;ds(function(){Ml(null,n,null,null)}),i[rr]=null}};function El(n){this._internalRoot=n}El.prototype.unstable_scheduleHydration=function(n){if(n){var i=Gt();n={blockedOn:null,target:n,priority:i};for(var o=0;o<Er.length&&i!==0&&i<Er[o].priority;o++);Er.splice(o,0,n),o===0&&vf(n)}};function cd(n){return!(!n||n.nodeType!==1&&n.nodeType!==9&&n.nodeType!==11)}function Tl(n){return!(!n||n.nodeType!==1&&n.nodeType!==9&&n.nodeType!==11&&(n.nodeType!==8||n.nodeValue!==" react-mount-point-unstable "))}function Dm(){}function Iv(n,i,o,d,m){if(m){if(typeof d=="function"){var y=d;d=function(){var ge=wl(A);y.call(ge)}}var A=Pm(i,d,n,0,null,!1,!1,"",Dm);return n._reactRootContainer=A,n[rr]=A.current,ja(n.nodeType===8?n.parentNode:n),ds(),A}for(;m=n.lastChild;)n.removeChild(m);if(typeof d=="function"){var B=d;d=function(){var ge=wl(V);B.call(ge)}}var V=ad(n,0,!1,null,null,!1,!1,"",Dm);return n._reactRootContainer=V,n[rr]=V.current,ja(n.nodeType===8?n.parentNode:n),ds(function(){Ml(i,V,o,d)}),V}function Al(n,i,o,d,m){var y=o._reactRootContainer;if(y){var A=y;if(typeof m=="function"){var B=m;m=function(){var V=wl(A);B.call(V)}}Ml(i,A,n,m)}else A=Iv(o,i,n,m,d);return wl(A)}Ht=function(n){switch(n.tag){case 3:var i=n.stateNode;if(i.current.memoizedState.isDehydrated){var o=Rt(i.pendingLanes);o!==0&&(Kn(i,o|1),ti(i,bt()),(Ot&6)===0&&(qs=bt()+500,Nr()))}break;case 13:ds(function(){var d=lr(n,1);if(d!==null){var m=Gn();Li(d,n,1,m)}}),od(n,1)}},Zt=function(n){if(n.tag===13){var i=lr(n,134217728);if(i!==null){var o=Gn();Li(i,n,134217728,o)}od(n,134217728)}},Ei=function(n){if(n.tag===13){var i=Ur(n),o=lr(n,i);if(o!==null){var d=Gn();Li(o,n,i,d)}od(n,i)}},Gt=function(){return Pt},Ti=function(n,i){var o=Pt;try{return Pt=n,i()}finally{Pt=o}},Ze=function(n,i,o){switch(i){case"input":if(Lt(n,o),i=o.name,o.type==="radio"&&i!=null){for(o=n;o.parentNode;)o=o.parentNode;for(o=o.querySelectorAll("input[name="+JSON.stringify(""+i)+'][type="radio"]'),i=0;i<o.length;i++){var d=o[i];if(d!==n&&d.form===n.form){var m=Go(d);if(!m)throw Error(t(90));Ft(d),Lt(d,m)}}}break;case"textarea":et(n,o);break;case"select":i=o.value,i!=null&&wt(n,!!o.multiple,i,!1)}},Re=ed,_e=ds;var kv={usingClientEntryPoint:!1,Events:[Ga,Is,Go,j,be,ed]},ro={findFiberByHostInstance:is,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},Fv={bundleType:ro.bundleType,version:ro.version,rendererPackageName:ro.rendererPackageName,rendererConfig:ro.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:C.ReactCurrentDispatcher,findHostInstanceByFiber:function(n){return n=xt(n),n===null?null:n.stateNode},findFiberByHostInstance:ro.findFiberByHostInstance||Dv,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Cl=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Cl.isDisabled&&Cl.supportsFiber)try{ne=Cl.inject(Fv),Te=Cl}catch{}}return ni.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=kv,ni.createPortal=function(n,i){var o=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!cd(i))throw Error(t(200));return Lv(n,i,null,o)},ni.createRoot=function(n,i){if(!cd(n))throw Error(t(299));var o=!1,d="",m=Lm;return i!=null&&(i.unstable_strictMode===!0&&(o=!0),i.identifierPrefix!==void 0&&(d=i.identifierPrefix),i.onRecoverableError!==void 0&&(m=i.onRecoverableError)),i=ad(n,1,!1,null,null,o,!1,d,m),n[rr]=i.current,ja(n.nodeType===8?n.parentNode:n),new ld(i)},ni.findDOMNode=function(n){if(n==null)return null;if(n.nodeType===1)return n;var i=n._reactInternals;if(i===void 0)throw typeof n.render=="function"?Error(t(188)):(n=Object.keys(n).join(","),Error(t(268,n)));return n=xt(i),n=n===null?null:n.stateNode,n},ni.flushSync=function(n){return ds(n)},ni.hydrate=function(n,i,o){if(!Tl(i))throw Error(t(200));return Al(null,n,i,!0,o)},ni.hydrateRoot=function(n,i,o){if(!cd(n))throw Error(t(405));var d=o!=null&&o.hydratedSources||null,m=!1,y="",A=Lm;if(o!=null&&(o.unstable_strictMode===!0&&(m=!0),o.identifierPrefix!==void 0&&(y=o.identifierPrefix),o.onRecoverableError!==void 0&&(A=o.onRecoverableError)),i=Pm(i,null,n,1,o??null,m,!1,y,A),n[rr]=i.current,ja(n),d)for(n=0;n<d.length;n++)o=d[n],m=o._getVersion,m=m(o._source),i.mutableSourceEagerHydrationData==null?i.mutableSourceEagerHydrationData=[o,m]:i.mutableSourceEagerHydrationData.push(o,m);return new El(i)},ni.render=function(n,i,o){if(!Tl(i))throw Error(t(200));return Al(null,n,i,!1,o)},ni.unmountComponentAtNode=function(n){if(!Tl(n))throw Error(t(40));return n._reactRootContainer?(ds(function(){Al(null,null,n,!1,function(){n._reactRootContainer=null,n[rr]=null})}),!0):!1},ni.unstable_batchedUpdates=ed,ni.unstable_renderSubtreeIntoContainer=function(n,i,o,d){if(!Tl(o))throw Error(t(200));if(n==null||n._reactInternals===void 0)throw Error(t(38));return Al(n,i,o,!1,d)},ni.version="18.3.1-next-f1338f8080-20240426",ni}var jm;function Wv(){if(jm)return hd.exports;jm=1;function s(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(s)}catch(e){console.error(e)}}return s(),hd.exports=Gv(),hd.exports}var Hm;function Xv(){if(Hm)return Rl;Hm=1;var s=Wv();return Rl.createRoot=s.createRoot,Rl.hydrateRoot=s.hydrateRoot,Rl}var qv=Xv();const $v=og(qv);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Yv=s=>s.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),lg=(...s)=>s.filter((e,t,r)=>!!e&&e.trim()!==""&&r.indexOf(e)===t).join(" ").trim();/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var Kv={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Zv=K.forwardRef(({color:s="currentColor",size:e=24,strokeWidth:t=2,absoluteStrokeWidth:r,className:a="",children:l,iconNode:u,...h},p)=>K.createElement("svg",{ref:p,...Kv,width:e,height:e,stroke:s,strokeWidth:r?Number(t)*24/Number(e):t,className:lg("lucide",a),...h},[...u.map(([f,g])=>K.createElement(f,g)),...Array.isArray(l)?l:[l]]));/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const st=(s,e)=>{const t=K.forwardRef(({className:r,...a},l)=>K.createElement(Zv,{ref:l,iconNode:e,className:lg(`lucide-${Yv(s)}`,r),...a}));return t.displayName=`${s}`,t};/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const cg=st("Activity",[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const gc=st("Anchor",[["path",{d:"M12 22V8",key:"qkxhtm"}],["path",{d:"M5 12H2a10 10 0 0 0 20 0h-3",key:"1hv3nh"}],["circle",{cx:"12",cy:"5",r:"3",key:"rqqgnr"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qv=st("AudioWaveform",[["path",{d:"M2 13a2 2 0 0 0 2-2V7a2 2 0 0 1 4 0v13a2 2 0 0 0 4 0V4a2 2 0 0 1 4 0v13a2 2 0 0 0 4 0v-4a2 2 0 0 1 2-2",key:"57tc96"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Jv=st("Ban",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m4.9 4.9 14.2 14.2",key:"1m5liu"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ug=st("BookOpen",[["path",{d:"M12 7v14",key:"1akyts"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",key:"ruj8y"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e_=st("Bot",[["path",{d:"M12 8V4H8",key:"hb8ula"}],["rect",{width:"16",height:"12",x:"4",y:"8",rx:"2",key:"enze0r"}],["path",{d:"M2 14h2",key:"vft8re"}],["path",{d:"M20 14h2",key:"4cs60a"}],["path",{d:"M15 13v2",key:"1xurst"}],["path",{d:"M9 13v2",key:"rq6x2g"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qh=st("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const fa=st("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t_=st("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n_=st("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pa=st("ChevronUp",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i_=st("CircleAlert",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r_=st("CircleCheck",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ac=st("CircleDot",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"1",key:"41hilf"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s_=st("Clipboard",[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",key:"116196"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $h=st("CodeXml",[["path",{d:"m18 16 4-4-4-4",key:"1inbqp"}],["path",{d:"m6 8-4 4 4 4",key:"15zrgr"}],["path",{d:"m14.5 4-5 16",key:"e7oirm"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a_=st("Code",[["polyline",{points:"16 18 22 12 16 6",key:"z7tu5w"}],["polyline",{points:"8 6 2 12 8 18",key:"1eg1df"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xc=st("Compass",[["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z",key:"9ktpf1"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o_=st("Copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const dg=st("Cpu",[["rect",{width:"16",height:"16",x:"4",y:"4",rx:"2",key:"14l7u7"}],["rect",{width:"6",height:"6",x:"9",y:"9",rx:"1",key:"5aljv4"}],["path",{d:"M15 2v2",key:"13l42r"}],["path",{d:"M15 20v2",key:"15mkzm"}],["path",{d:"M2 15h2",key:"1gxd5l"}],["path",{d:"M2 9h2",key:"1bbxkp"}],["path",{d:"M20 15h2",key:"19e6y8"}],["path",{d:"M20 9h2",key:"19tzq7"}],["path",{d:"M9 2v2",key:"165o2o"}],["path",{d:"M9 20v2",key:"i2bqo8"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l_=st("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c_=st("FileCode",[["path",{d:"M10 12.5 8 15l2 2.5",key:"1tg20x"}],["path",{d:"m14 12.5 2 2.5-2 2.5",key:"yinavb"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z",key:"1mlx9k"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Vm=st("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u_=st("FileWarning",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Kr=st("Flame",[["path",{d:"M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z",key:"96xj49"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d_=st("Gauge",[["path",{d:"m12 14 4-4",key:"9kzdfg"}],["path",{d:"M3.34 19a10 10 0 1 1 17.32 0",key:"19p75a"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h_=st("Github",[["path",{d:"M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4",key:"tonef"}],["path",{d:"M9 18c-4.51 2-5-2-7-2",key:"9comsn"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f_=st("GraduationCap",[["path",{d:"M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",key:"j76jl0"}],["path",{d:"M22 10v6",key:"1lu8f3"}],["path",{d:"M6 12.5V16a6 3 0 0 0 12 0v-3.5",key:"1r8lef"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Yh=st("Info",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p_=st("Key",[["path",{d:"m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4",key:"g0fldk"}],["path",{d:"m21 2-9.6 9.6",key:"1j0ho8"}],["circle",{cx:"7.5",cy:"15.5",r:"5.5",key:"yqb3hr"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m_=st("Layers",[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const vc=st("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const g_=st("Magnet",[["path",{d:"m6 15-4-4 6.75-6.77a7.79 7.79 0 0 1 11 11L13 22l-4-4 6.39-6.36a2.14 2.14 0 0 0-3-3L6 15",key:"1i3lhw"}],["path",{d:"m5 8 4 4",key:"j6kj7e"}],["path",{d:"m12 15 4 4",key:"lnac28"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x_=st("Maximize2",[["polyline",{points:"15 3 21 3 21 9",key:"mznyad"}],["polyline",{points:"9 21 3 21 3 15",key:"1avn1i"}],["line",{x1:"21",x2:"14",y1:"3",y2:"10",key:"ota7mn"}],["line",{x1:"3",x2:"10",y1:"21",y2:"14",key:"1atl0r"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v_=st("MessageSquare",[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",key:"1lielz"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const hg=st("Minimize2",[["polyline",{points:"4 14 10 14 10 20",key:"11kfnr"}],["polyline",{points:"20 10 14 10 14 4",key:"rlmsce"}],["line",{x1:"14",x2:"21",y1:"10",y2:"3",key:"o5lafz"}],["line",{x1:"3",x2:"10",y1:"21",y2:"14",key:"1atl0r"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Gm=st("Move",[["path",{d:"M12 2v20",key:"t6zp3m"}],["path",{d:"m15 19-3 3-3-3",key:"11eu04"}],["path",{d:"m19 9 3 3-3 3",key:"1mg7y2"}],["path",{d:"M2 12h20",key:"9i4pu4"}],["path",{d:"m5 9-3 3 3 3",key:"j64kie"}],["path",{d:"m9 5 3-3 3 3",key:"l8vdw6"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const __=st("Orbit",[["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}],["circle",{cx:"19",cy:"5",r:"2",key:"mhkx31"}],["circle",{cx:"5",cy:"19",r:"2",key:"v8kfzx"}],["path",{d:"M10.4 21.9a10 10 0 0 0 9.941-15.416",key:"eohfx2"}],["path",{d:"M13.5 2.1a10 10 0 0 0-9.841 15.416",key:"19pvbm"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y_=st("Pause",[["rect",{x:"14",y:"4",width:"4",height:"16",rx:"1",key:"zuxfzm"}],["rect",{x:"6",y:"4",width:"4",height:"16",rx:"1",key:"1okwgv"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Kh=st("Play",[["polygon",{points:"6 3 20 12 6 21 6 3",key:"1oa8hb"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Wm=st("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b_=st("RotateCcw",[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Zh=st("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const S_=st("Send",[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M_=st("Server",[["rect",{width:"20",height:"8",x:"2",y:"2",rx:"2",ry:"2",key:"ngkwjq"}],["rect",{width:"20",height:"8",x:"2",y:"14",rx:"2",ry:"2",key:"iecqi9"}],["line",{x1:"6",x2:"6.01",y1:"6",y2:"6",key:"16zg32"}],["line",{x1:"6",x2:"6.01",y1:"18",y2:"18",key:"nzw8ys"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const fg=st("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w_=st("Share2",[["circle",{cx:"18",cy:"5",r:"3",key:"gq8acd"}],["circle",{cx:"6",cy:"12",r:"3",key:"w7nqdw"}],["circle",{cx:"18",cy:"19",r:"3",key:"1xt0gg"}],["line",{x1:"8.59",x2:"15.42",y1:"13.51",y2:"17.49",key:"47mynk"}],["line",{x1:"15.41",x2:"8.59",y1:"6.51",y2:"10.49",key:"1n3mei"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E_=st("ShieldAlert",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M12 8v4",key:"1got3b"}],["path",{d:"M12 16h.01",key:"1drbdi"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qh=st("ShieldCheck",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const da=st("Shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const T_=st("SlidersHorizontal",[["line",{x1:"21",x2:"14",y1:"4",y2:"4",key:"obuewd"}],["line",{x1:"10",x2:"3",y1:"4",y2:"4",key:"1q6298"}],["line",{x1:"21",x2:"12",y1:"12",y2:"12",key:"1iu8h1"}],["line",{x1:"8",x2:"3",y1:"12",y2:"12",key:"ntss68"}],["line",{x1:"21",x2:"16",y1:"20",y2:"20",key:"14d8ph"}],["line",{x1:"12",x2:"3",y1:"20",y2:"20",key:"m0wm8r"}],["line",{x1:"14",x2:"14",y1:"2",y2:"6",key:"14e1ph"}],["line",{x1:"8",x2:"8",y1:"10",y2:"14",key:"1i6ji0"}],["line",{x1:"16",x2:"16",y1:"18",y2:"22",key:"1lctlv"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ga=st("SlidersVertical",[["line",{x1:"4",x2:"4",y1:"21",y2:"14",key:"1p332r"}],["line",{x1:"4",x2:"4",y1:"10",y2:"3",key:"gb41h5"}],["line",{x1:"12",x2:"12",y1:"21",y2:"12",key:"hf2csr"}],["line",{x1:"12",x2:"12",y1:"8",y2:"3",key:"1kfi7u"}],["line",{x1:"20",x2:"20",y1:"21",y2:"16",key:"1lhrwl"}],["line",{x1:"20",x2:"20",y1:"12",y2:"3",key:"16vvfq"}],["line",{x1:"2",x2:"6",y1:"14",y2:"14",key:"1uebub"}],["line",{x1:"10",x2:"14",y1:"8",y2:"8",key:"1yglbp"}],["line",{x1:"18",x2:"22",y1:"16",y2:"16",key:"1jxqpz"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const yo=st("Sparkles",[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}],["path",{d:"M20 3v4",key:"1olli1"}],["path",{d:"M22 5h-4",key:"1gvqau"}],["path",{d:"M4 17v2",key:"vumght"}],["path",{d:"M5 18H3",key:"zchphs"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pg=st("Swords",[["polyline",{points:"14.5 17.5 3 6 3 3 6 3 17.5 14.5",key:"1hfsw2"}],["line",{x1:"13",x2:"19",y1:"19",y2:"13",key:"1vrmhu"}],["line",{x1:"16",x2:"20",y1:"16",y2:"20",key:"1bron3"}],["line",{x1:"19",x2:"21",y1:"21",y2:"19",key:"13pww6"}],["polyline",{points:"14.5 6.5 18 3 21 3 21 6 17.5 9.5",key:"hbey2j"}],["line",{x1:"5",x2:"9",y1:"14",y2:"18",key:"1hf58s"}],["line",{x1:"7",x2:"4",y1:"17",y2:"20",key:"pidxm4"}],["line",{x1:"3",x2:"5",y1:"19",y2:"21",key:"1pehsh"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const A_=st("Terminal",[["polyline",{points:"4 17 10 11 4 5",key:"akl6gq"}],["line",{x1:"12",x2:"20",y1:"19",y2:"19",key:"q2wloq"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Jd=st("TriangleAlert",[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C_=st("UserCheck",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["polyline",{points:"16 11 18 13 22 9",key:"1pwet4"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const R_=st("Volume2",[["path",{d:"M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",key:"uqj9uw"}],["path",{d:"M16 9a5 5 0 0 1 0 6",key:"1q6k2b"}],["path",{d:"M19.364 18.364a9 9 0 0 0 0-12.728",key:"ijwkga"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const P_=st("VolumeX",[["path",{d:"M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",key:"uqj9uw"}],["line",{x1:"22",x2:"16",y1:"9",y2:"15",key:"1ewh16"}],["line",{x1:"16",x2:"22",y1:"9",y2:"15",key:"5ykzw1"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _c=st("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const mg=st("Zap",[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]]),N_=({activeTab:s,setActiveTab:e,splitView:t,setSplitView:r,onOpenSettings:a,onCopySetupLink:l,onOpenCodeExport:u,showNavigator:h,setShowNavigator:p})=>{const[f,g]=K.useState(!1),b=()=>{l(),g(!0),setTimeout(()=>g(!1),2e3)};return c.jsx("header",{className:"sticky top-0 z-40 w-full bg-[#1c1c21]/95 border-b border-white/5 backdrop-blur-md",children:c.jsxs("div",{className:"mx-auto flex max-w-7xl flex-wrap items-center gap-x-3 gap-y-2 px-4 py-2.5 sm:flex-nowrap sm:px-6 sm:py-3",children:[c.jsxs("div",{className:"flex min-w-0 flex-1 items-center space-x-3 sm:flex-none",children:[c.jsx("div",{className:"flex h-9 w-9 items-center justify-center rounded-lg bg-blue-500/10 border border-blue-500/30",children:c.jsx(__,{className:"h-4 w-4 text-blue-400"})}),c.jsxs("div",{children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx("h1",{className:"whitespace-nowrap text-base font-bold text-white sm:text-xl",children:"The Token Cosmos"}),c.jsx("span",{className:"hidden rounded-full border border-cyan-500/30 bg-cyan-500/20 px-2.5 py-0.5 font-mono text-[10px] text-cyan-300 sm:inline",children:"v5.0"})]}),c.jsx("p",{className:"text-xs text-gray-400 hidden sm:block",children:"Enterprise X-Ray & Spatial Telemetry for LLM Sampling"})]})]}),c.jsxs("div",{className:"flex w-full items-center justify-between gap-1 overflow-x-auto sm:ml-auto sm:w-auto sm:justify-end sm:gap-2",children:[c.jsxs("button",{onClick:b,"aria-label":"Copy current parameter setup link to clipboard",className:"btn-secondary-matte flex shrink-0 items-center space-x-1.5 rounded-full p-2 text-xs sm:px-3.5 sm:py-1.5",title:"Copy Setup Link to Clipboard",children:[f?c.jsx(qh,{className:"h-3.5 w-3.5 text-emerald-400"}):c.jsx(w_,{className:"h-3.5 w-3.5"}),c.jsx("span",{className:"hidden sm:inline",children:f?"Link Copied!":"Share Setup"})]}),c.jsx("button",{onClick:a,"aria-label":"Open Bring Your Own Engine configuration settings modal",className:"btn-secondary-matte shrink-0 rounded-full p-2 text-xs",title:"Bring Your Own Engine (BYOE) Settings",children:c.jsx(fg,{className:"h-4 w-4"})}),p&&c.jsxs("button",{onClick:()=>p(!h),"aria-label":h?"Hide AI Navigator Guide":"Open AI Navigator Guide",className:`flex shrink-0 items-center space-x-1.5 rounded-full p-2 text-xs font-medium transition-all sm:px-3 sm:py-1.5 ${h?"bg-purple-600/30 text-purple-200 border border-purple-500/50 shadow-sm":"btn-secondary-matte"}`,title:"Toggle AI Tourist Guide",children:[c.jsx(yo,{className:"h-3.5 w-3.5 text-purple-400"}),c.jsx("span",{className:"hidden lg:inline",children:h?"Guide Active":"AI Guide"})]}),s==="experiment"&&c.jsxs("button",{onClick:()=>r(!t),"aria-label":t?"Disable A/B Duel Mode":"Enable side-by-side A/B Duel Mode",className:`flex shrink-0 items-center space-x-2 rounded-full p-2 text-xs font-medium transition-all sm:px-3.5 sm:py-1.5 ${t?"bg-blue-600 text-white border border-blue-500 shadow-sm":"btn-secondary-matte"}`,title:"Compare Model / Parameter Configurations side-by-side",children:[c.jsx(pg,{className:"h-3.5 w-3.5"}),c.jsx("span",{className:"hidden md:inline",children:t?"A/B Duel Active":"A/B Duel Mode"})]}),c.jsxs("div",{className:"flex shrink-0 rounded-full border border-white/10 bg-[#232329] p-1",role:"tablist",children:[c.jsxs("button",{onClick:()=>e("learn"),role:"tab","aria-selected":s==="learn","aria-label":"Switch to LEARN mode",className:`flex items-center space-x-1.5 rounded-full p-2 text-xs font-medium transition-all sm:px-3.5 sm:py-1 ${s==="learn"?"bg-blue-600 text-white font-semibold shadow-sm":"text-gray-400 hover:text-white"}`,children:[c.jsx(ug,{className:"h-3.5 w-3.5"}),c.jsx("span",{className:"hidden sm:inline",children:"LEARN"})]}),c.jsxs("button",{onClick:()=>e("labs"),role:"tab","aria-selected":s==="labs","aria-label":"Switch to LABS mode",className:`flex items-center space-x-1.5 rounded-full p-2 text-xs font-medium transition-all sm:px-3.5 sm:py-1 ${s==="labs"?"bg-cyan-600 text-white font-semibold shadow-sm":"text-gray-400 hover:text-white"}`,children:[c.jsx(f_,{className:"h-3.5 w-3.5"}),c.jsx("span",{className:"hidden sm:inline",children:"LABS"})]}),c.jsxs("button",{onClick:()=>e("experiment"),role:"tab","aria-selected":s==="experiment","aria-label":"Switch to EXPERIMENT mode",className:`flex items-center space-x-1.5 rounded-full p-2 text-xs font-medium transition-all sm:px-3.5 sm:py-1 ${s==="experiment"?"bg-blue-600 text-white font-semibold shadow-sm":"text-gray-400 hover:text-white"}`,children:[c.jsx(yo,{className:"h-3.5 w-3.5"}),c.jsx("span",{className:"hidden sm:inline",children:"EXPERIMENT"})]}),c.jsxs("button",{onClick:()=>e("export"),role:"tab","aria-selected":s==="export","aria-label":"Switch to EXPORT mode",className:`flex items-center space-x-1.5 rounded-full p-2 text-xs font-medium transition-all sm:px-3.5 sm:py-1 ${s==="export"?"bg-blue-600 text-white font-semibold shadow-sm":"text-gray-400 hover:text-white"}`,children:[c.jsx($h,{className:"h-3.5 w-3.5"}),c.jsx("span",{className:"hidden sm:inline",children:"EXPORT"})]})]}),c.jsx("a",{href:"https://github.com/thokchomlolet03-cpu/the-token-cosmos",target:"_blank",rel:"noopener noreferrer","aria-label":"Open The Token Cosmos GitHub repository",className:"btn-secondary-matte shrink-0 rounded-full p-2 text-xs",title:"GitHub Repository",children:c.jsx(h_,{className:"h-4 w-4"})})]})]})})},oc=[{id:"factual-roboticist",name:"Legal & Contract Extraction",subtitle:"Temp: 0.05 • Min-P: 0.05 • RAG: ON",description:"Ultra-deterministic factual extraction with strict context anchoring. Eliminates creative guesswork for legal clauses.",icon:"FileText",params:{temperature:.05,topK:5,topP:1,minP:.05,frequencyPenalty:0,presencePenalty:0,stopSequences:[],logitBiases:{}},ragEnabled:!0,prompt:"What is the governing law and liability limit specified in the agreement?",ragContext:"This Agreement shall be governed by the laws of Delaware. Aggregate liability under Section 8 shall not exceed $1,000,000."},{id:"strict-guardrail",name:"Code & SQL Generator",subtitle:"Temp: 0.01 • Schema: ON • Stop: \\n\\n",description:"Zero-temperature greedy mode with stop sequences for structured JSON, SQL queries, and code syntax generation.",icon:"Code",params:{temperature:.01,topK:50,topP:1,minP:.1,frequencyPenalty:.2,presencePenalty:0,stopSequences:[`

`,"```"],logitBiases:{Delve:-100,delve:-100}},ragEnabled:!1,prompt:"Write an optimized PostgreSQL query to count active users by region.",ragContext:""},{id:"balanced-navigator",name:"Medical Record Summarizer",subtitle:"Temp: 0.10 • Top-K: 10 • RAG: ON",description:"High precision medical QA mode. Tethered strictly to clinical notes to prevent hallucinated medical advice.",icon:"Clipboard",params:{temperature:.1,topK:10,topP:.9,minP:.02,frequencyPenalty:.1,presencePenalty:.1,stopSequences:[],logitBiases:{}},ragEnabled:!0,prompt:"What was the patient's blood pressure and prescribed dosage?",ragContext:"Patient presents with blood pressure 120/80 mmHg. Prescribed Amoxicillin 500mg orally twice daily for 7 days."},{id:"wild-storyteller",name:"Creative & Game Dialogue",subtitle:"Temp: 1.30 • Top-P: 0.95 • Freq Pen: 0.8",description:"High entropy nucleus sampling for NPC dialogue, creative world-building, and unconstrained brainstorming.",icon:"MessageSquare",params:{temperature:1.3,topK:50,topP:.95,minP:.01,frequencyPenalty:.8,presencePenalty:.5,stopSequences:[],logitBiases:{}},ragEnabled:!1,prompt:"Deep in the glowing cybernetic forest, the ancient automaton discovered...",ragContext:""}],Ys={"capital-france":{baseline:[{token_id:101,token_str:" Paris",raw_logit:12.5,is_rag_grounded:!1},{token_id:102,token_str:" France",raw_logit:8.2,is_rag_grounded:!1},{token_id:103,token_str:" London",raw_logit:6.4,is_rag_grounded:!1},{token_id:104,token_str:" Lyon",raw_logit:5.8,is_rag_grounded:!1},{token_id:105,token_str:" Marseille",raw_logit:5.1,is_rag_grounded:!1},{token_id:106,token_str:" Berlin",raw_logit:4.2,is_rag_grounded:!1},{token_id:107,token_str:" Rome",raw_logit:3.9,is_rag_grounded:!1},{token_id:108,token_str:" Madrid",raw_logit:3.5,is_rag_grounded:!1},{token_id:109,token_str:" Tokyo",raw_logit:2.8,is_rag_grounded:!1},{token_id:110,token_str:" Washington",raw_logit:2.1,is_rag_grounded:!1},{token_id:111,token_str:" beautiful",raw_logit:1.8,is_rag_grounded:!1},{token_id:112,token_str:" known",raw_logit:1.5,is_rag_grounded:!1},{token_id:113,token_str:" famous",raw_logit:1.2,is_rag_grounded:!1},{token_id:114,token_str:" located",raw_logit:.9,is_rag_grounded:!1},{token_id:115,token_str:" home",raw_logit:.7,is_rag_grounded:!1},{token_id:116,token_str:" the",raw_logit:.5,is_rag_grounded:!1},{token_id:117,token_str:" a",raw_logit:.3,is_rag_grounded:!1},{token_id:118,token_str:" historic",raw_logit:.1,is_rag_grounded:!1},{token_id:119,token_str:" vibrant",raw_logit:-.2,is_rag_grounded:!1},{token_id:120,token_str:" bustling",raw_logit:-.5,is_rag_grounded:!1},...Array.from({length:30},(s,e)=>({token_id:200+e,token_str:` candidate_${e+1}`,raw_logit:-1-e*.3,is_rag_grounded:!1}))],rag:[{token_id:101,token_str:" Paris",raw_logit:18.9,is_rag_grounded:!0},{token_id:121,token_str:" Eiffel",raw_logit:14.2,is_rag_grounded:!0},{token_id:122,token_str:" Tower",raw_logit:12.8,is_rag_grounded:!0},{token_id:102,token_str:" France",raw_logit:7.1,is_rag_grounded:!0},{token_id:123,token_str:" 1889",raw_logit:6.5,is_rag_grounded:!0},{token_id:103,token_str:" London",raw_logit:1.2,is_rag_grounded:!1},{token_id:104,token_str:" Lyon",raw_logit:1,is_rag_grounded:!1},{token_id:105,token_str:" Marseille",raw_logit:.8,is_rag_grounded:!1},{token_id:106,token_str:" Berlin",raw_logit:.4,is_rag_grounded:!1},{token_id:107,token_str:" Rome",raw_logit:.2,is_rag_grounded:!1},...Array.from({length:40},(s,e)=>({token_id:300+e,token_str:` fringe_${e+1}`,raw_logit:-1.5-e*.2,is_rag_grounded:!1}))]},"cybernetic-forest":{baseline:[{token_id:501,token_str:" a",raw_logit:9.8,is_rag_grounded:!1},{token_id:502,token_str:" an",raw_logit:9.2,is_rag_grounded:!1},{token_id:503,token_str:" crystalline",raw_logit:8.7,is_rag_grounded:!1},{token_id:504,token_str:" forgotten",raw_logit:8.1,is_rag_grounded:!1},{token_id:505,token_str:" relic",raw_logit:7.5,is_rag_grounded:!1},{token_id:506,token_str:" pulse",raw_logit:7.2,is_rag_grounded:!1},{token_id:507,token_str:" glowing",raw_logit:6.8,is_rag_grounded:!1},{token_id:508,token_str:" hidden",raw_logit:6.4,is_rag_grounded:!1},{token_id:509,token_str:" secret",raw_logit:5.9,is_rag_grounded:!1},{token_id:510,token_str:" sanctuary",raw_logit:5.4,is_rag_grounded:!1},{token_id:511,token_str:" signal",raw_logit:5,is_rag_grounded:!1},{token_id:512,token_str:" memory",raw_logit:4.6,is_rag_grounded:!1},{token_id:513,token_str:" core",raw_logit:4.2,is_rag_grounded:!1},...Array.from({length:37},(s,e)=>({token_id:600+e,token_str:` Echo_${e+1}`,raw_logit:3.5-e*.2,is_rag_grounded:!1}))]}},L_=({params:s,activeParam:e})=>{const r=(()=>{switch(e){case"temperature":{const a=s.temperature;return a<=.4?{title:"Cold & Focused",icon:c.jsx(Kr,{className:"h-4 w-4 text-blue-400"}),badgeColor:"bg-blue-950/40 text-blue-300 border-blue-800/35",text:"The AI acts like a strict roboticist. It ignores creative risks and laser-focuses on the safest, most obvious words. Perfect for data tasks."}:a<=1.2?{title:"Balanced Atmosphere",icon:c.jsx(Kr,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800/50 text-slate-300 border-slate-700",text:"The AI mixes expected words with occasional surprising choices, mimicking natural human storytelling."}:{title:"Supernova Chaos",icon:c.jsx(Kr,{className:"h-4 w-4 text-rose-400"}),badgeColor:"bg-rose-950/40 text-rose-300 border-rose-800/35",text:"The AI begins guessing wildly. It will hallucinate facts and string together bizarre sentences. Use for brainstorming only."}}case"topK":{const a=s.topK;return a<=10?{title:"Strict Cutoff",icon:c.jsx(ga,{className:"h-4 w-4 text-blue-400"}),badgeColor:"bg-blue-950/40 text-blue-300 border-blue-800/35",text:"The AI is only allowed to look at the top few smartest choices. All background noise is completely blocked out."}:a<50?{title:"Broadening Horizons",icon:c.jsx(ga,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800/50 text-slate-300 border-slate-700",text:"The AI considers a wider pool of decent options, allowing for more variety in its vocabulary."}:{title:"Open Sky",icon:c.jsx(ga,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800/50 text-slate-300 border-slate-700",text:"The AI is looking at the maximum number of candidates. It relies entirely on Temperature to decide what to pick."}}case"topP":{const a=s.topP;return a<=.5?{title:"Tight Nucleus",icon:c.jsx(ac,{className:"h-4 w-4 text-blue-400"}),badgeColor:"bg-blue-950/40 text-blue-300 border-blue-800/35",text:"The shield only captures the absolute most confident words. If the AI isn't sure, it won't say it."}:a<=.9?{title:"Flexible Shield",icon:c.jsx(ac,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800/50 text-slate-300 border-slate-700",text:"The AI grabs a healthy mix of words until it reaches a solid confidence threshold."}:{title:"Weak Shield",icon:c.jsx(ac,{className:"h-4 w-4 text-rose-400"}),badgeColor:"bg-rose-950/40 text-rose-300 border-rose-800/35",text:"The AI lets almost everything through, capturing a massive pool of words regardless of how confident it is."}}case"minP":return s.minP<=.05?{title:"Broad Base",icon:c.jsx(xc,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800/50 text-slate-300 border-slate-700",text:"Allows low probability tail candidates as long as they meet a minimal baseline cutoff."}:{title:"Strict Gravity Well",icon:c.jsx(xc,{className:"h-4 w-4 text-blue-400"}),badgeColor:"bg-blue-950/40 text-blue-300 border-blue-800/35",text:"Filters out any candidate whose chance drops below relative fraction of top star."};case"frequencyPenalty":{const a=s.frequencyPenalty;return a===0?{title:"Repetitive Orbit",icon:c.jsx(da,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800 text-slate-300 border-slate-700",text:"Previously used words retain full probability weight, allowing infinite repetitive loops."}:a<1?{title:"Synonym Searcher",icon:c.jsx(da,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800/50 text-slate-300 border-slate-700",text:"Gradually penalizes repetitive words, encouraging vocabulary variety."}:{title:"Exhaustion Mode",icon:c.jsx(da,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800/50 text-slate-300 border-slate-700",text:"Previously used words physically dim in opacity, forcing the AI away from familiar paths."}}case"presencePenalty":return s.presencePenalty===0?{title:"No Topic Shift",icon:c.jsx(da,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800 text-slate-300 border-slate-700",text:"Does not penalize topic presence; AI stays focused on existing subject context."}:{title:"Horizon Booster",icon:c.jsx(da,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800/50 text-slate-300 border-slate-700",text:"Applies a one-time penalty on any word already seen, encouraging topic exploration."};default:return{title:"Interactive Math Engine",icon:c.jsx(Yh,{className:"h-4 w-4 text-blue-400"}),badgeColor:"bg-blue-950/40 text-blue-300 border-blue-800/35",text:"Drag any sampling slider to see real-time English explanations of LLM mathematical shifts."}}})();return c.jsxs("div",{"aria-live":"polite","aria-atomic":"true",className:"rounded-xl border border-slate-700 bg-slate-900/90 p-3.5 shadow-md backdrop-blur-md transition-all duration-200",children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-slate-800 pb-2 mb-2",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx(yo,{className:"h-4 w-4 text-blue-400"}),c.jsx("span",{className:"text-xs font-bold text-slate-100 uppercase tracking-wider",children:"Cosmic Guide Explanation"})]}),c.jsxs("div",{className:`flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold border ${r.badgeColor}`,children:[r.icon,c.jsx("span",{children:r.title})]})]}),c.jsx("p",{className:"text-xs text-slate-200 leading-relaxed font-sans font-normal",children:r.text})]})};function ao(s,e,t=[]){if(!s||s.length===0)return[];const r={};t.forEach(x=>{const _=x.trim();r[x]=(r[x]||0)+1,_!==x&&(r[_]=(r[_]||0)+1)});const a=s.map(x=>{let _=0;const N=x.token_str.trim();e.logitBiases&&(e.logitBiases[x.token_str]!==void 0?_+=e.logitBiases[x.token_str]:e.logitBiases[N]!==void 0&&(_+=e.logitBiases[N]));const P=Math.max(r[x.token_str]||0,r[N]||0),C=P>0?1:0,k=e.presencePenalty*C+e.frequencyPenalty*P,D=x.raw_logit+_-k;return{...x,adjusted_logit:D,isHistorical:P>0,historicalCount:P}});a.sort((x,_)=>_.adjusted_logit-x.adjusted_logit);const l=Math.max(.001,e.temperature);let u=new Array(a.length).fill(0);if(l<=.01)u[0]=1;else{const x=a[0].adjusted_logit,_=a.map(P=>Math.exp((P.adjusted_logit-x)/l)),N=_.reduce((P,C)=>P+C,0);u=_.map(P=>N>0?P/N:0)}let h=a.map((x,_)=>({...x,probability:u[_],rank:_+1,isFiltered:!1,orbitRadius:0,orbitAngle:0,size:0,color:""}));const p=Math.min(Math.max(1,Math.round(e.topK)),h.length);h.forEach((x,_)=>{_>=p&&!x.isFiltered&&(x.isFiltered=!0,x.filterReason="Top-K")});let f=0;const g=Math.min(1,Math.max(.05,e.topP));for(let x=0;x<h.length;x++){const _=h[x];_.isFiltered||(f>=g?(_.isFiltered=!0,_.filterReason="Top-P"):f+=_.probability)}const b=h.length>0?h[0].probability:0,v=e.minP*b;h.forEach(x=>{!x.isFiltered&&x.probability<v&&(x.isFiltered=!0,x.filterReason="Min-P")}),h.forEach(x=>{x.adjusted_logit<=-50&&(x.isFiltered=!0,x.filterReason="Banned")});const M=h.filter(x=>!x.isFiltered).reduce((x,_)=>x+_.probability,0);h.forEach(x=>{x.isFiltered?x.probability=0:x.probability=M>0?x.probability/M:0});const E=h.length;return h.forEach((x,_)=>{const N=_/Math.max(1,E-1),P=_===0?0:35+N*180;x.orbitRadius=P,x.orbitAngle=_*137.5*Math.PI/180,_===0?x.size=18+x.probability*25:x.isFiltered?x.size=3:x.size=6+x.probability*20,x.filterReason==="Banned"?x.color="#1e293b":x.is_rag_grounded?x.color="#06b6d4":_===0?x.color="#f59e0b":x.isFiltered?x.color="#475569":x.probability>.15?x.color="#38bdf8":x.probability>.05?x.color="#a855f7":x.color="#ec4899"}),h}function D_(s){const e=s.filter(r=>!r.isFiltered&&r.probability>0);if(e.length===0)return 0;let t=0;for(const r of e)r.probability>1e-10&&(t-=r.probability*Math.log2(r.probability));return Math.max(0,t)}function Xm(s,e){const t=s.probability,r=s.rank,a=Math.min(1,t*2),l=Math.max(0,1-(r-1)/10),u=Math.min(1,e/5),h=Math.max(0,Math.min(1,a*.5+l*.3+(1-u)*.2));let p,f;return r<=3&&t>.7?(p="high",f="#475569"):t>=.1?(p="moderate",f="#334155"):(p="low",f="#1e293b"),{entropy:e,confidence:p,confidenceScore:h,perplexityColor:f}}function I_(s){return s.split(/(?<=[.!?;])\s+|\n+/).map(e=>e.trim()).filter(e=>e.length>0)}function k_(s,e,t){if(!e||e.length===0)return-5;const r=s.split(/\s+/).filter(u=>u.length>1);if(r.length===0)return-5;let a=0,l=0;for(const u of r){const h=u.replace(/[^a-zA-Z0-9]/g,"").toLowerCase();if(h.length<2)continue;const p=e.find(f=>{const g=f.token_str.trim().toLowerCase();return g===h||g.includes(h)||h.includes(g)});if(p){const f=e[0]?.raw_logit||16,g=(p.raw_logit-f)/Math.max(.1,t.temperature);a+=g,l++}else a-=3.5,l++}return l>0?a/l:-5}function F_(s,e,t){const r=s.toLowerCase(),a=e.toLowerCase(),l=new Set(r.split(/\s+/).filter(f=>f.length>3)),u=new Set(a.split(/\s+/).filter(f=>f.length>3));let h=0;return l.forEach(f=>{u.has(f)&&h++}),(l.size>0?h/l.size:0)<.1&&t>3?"Abrupt topic shift — minimal lexical continuity with previous context":r.includes("however")||r.includes("but")||r.includes("despite")||r.includes("although")?"Contradictory conjunction introduces logical tension with preceding statement":r.length>200?"Overly complex sentence structure — high cognitive load for model parsing":t>4?"Severe probability collapse — language pattern deviates sharply from training distribution":t>2?"Moderate coherence gap — phrasing may be ambiguous or structurally unusual":"Minor fluency variation — acceptable in most contexts"}function U_(s,e=.5){if(s.length<2)return[];const t=[];for(let f=1;f<s.length;f++)t.push(s[f-1].logProb-s[f].logProb);const r=t.reduce((f,g)=>f+g,0)/t.length,a=t.reduce((f,g)=>f+(g-r)**2,0)/t.length,l=Math.sqrt(a)||.5,u=1+e*2,h=[];for(let f=1;f<s.length;f++){const g=s[f-1].logProb-s[f].logProb;if(g>r+u*l*.5){const b=l>.01?(g-r)/l:0;let v;b>3?v="critical":b>2?v="warning":v="info",h.push({phraseIndex:f,phrase:s[f].text,logProbDrop:Math.round(g*100)/100,previousLogProb:Math.round(s[f-1].logProb*100)/100,currentLogProb:Math.round(s[f].logProb*100)/100,severity:v,reason:F_(s[f].text,s[f-1].text,g)})}}const p={critical:0,warning:1,info:2};return h.sort((f,g)=>{const b=p[f.severity]-p[g.severity];return b!==0?b:g.logProbDrop-f.logProbDrop}),h}async function O_(s,e,t,r=.5){const a=performance.now(),l=I_(s),u=[],h=10;for(let v=0;v<l.length;v+=h){const S=l.slice(v,v+h);v>0&&await new Promise(M=>{typeof requestIdleCallback<"u"?requestIdleCallback(()=>M()):setTimeout(M,0)});for(const M of S){const E=k_(M,e,t);u.push({text:M,logProb:E,normalizedScore:0})}}if(u.length>0){const v=Math.min(...u.map(E=>E.logProb)),M=Math.max(...u.map(E=>E.logProb))-v||1;u.forEach(E=>{E.normalizedScore=(E.logProb-v)/M})}const p=u.reduce((v,S)=>v+S.logProb,0),f=u.length>0?p/u.length:0,g=U_(u,r),b=Math.round((performance.now()-a)*100)/100;return{inputText:s,totalJointLogProb:Math.round(p*100)/100,averageLogProb:Math.round(f*100)/100,phrases:u,frictionPoints:g,analysisTimeMs:b}}function B_(s,e){if(!s)return[];const t=[],r=e?e.split(/\s+/).filter(l=>l.length>3):[];let a=[];try{if(s?.choices?.[0]?.logprobs?.content?.[0]?.top_logprobs)a=s.choices[0].logprobs.content[0].top_logprobs.map(u=>({token:u.token||u.text||"",logprob:typeof u.logprob=="number"?u.logprob:-5}));else if(s?.choices?.[0]?.logprobs?.top_logprobs?.[0]){const l=s.choices[0].logprobs.top_logprobs[0];Array.isArray(l)?a=l.map(u=>({token:u.token||"",logprob:typeof u.logprob=="number"?u.logprob:-5})):typeof l=="object"&&(a=Object.entries(l).map(([u,h])=>({token:u,logprob:typeof h=="number"?h:-5})))}else if(Array.isArray(s?.candidates))return s.candidates}catch(l){console.warn("Failed to parse external logprobs response, using fallback candidates:",l)}return a.forEach((l,u)=>{const h=Math.round((l.logprob+16)*100)/100,p=l.token||`token_${u+1}`;let f=!1;if(r.length>0){const g=p.trim().toLowerCase();g.length>2&&(f=r.some(b=>b.toLowerCase().includes(g)||g.includes(b.toLowerCase())))}t.push({token_id:5e3+u,token_str:p,raw_logit:h,is_rag_grounded:f})}),t.sort((l,u)=>u.raw_logit-l.raw_logit),t}const qm={critical:{icon:Jd,label:"Critical",bgClass:"bg-red-500/10",textClass:"text-red-300",borderClass:"border-red-500/30",dotColor:"#ef4444"},warning:{icon:i_,label:"Warning",bgClass:"bg-amber-500/10",textClass:"text-amber-300",borderClass:"border-amber-500/30",dotColor:"#f59e0b"},info:{icon:Yh,label:"Info",bgClass:"bg-sky-500/10",textClass:"text-sky-300",borderClass:"border-sky-500/30",dotColor:"#38bdf8"}},z_=`Our onboarding process begins with a comprehensive background check taking 3-5 business days. Once completed, new hires receive their equipment and access credentials.

However, the IT provisioning system requires manual approval from three separate department heads, each operating on different schedules.

After equipment setup, employees must complete a mandatory 40-hour training program. But the training materials haven't been updated since 2019 and reference deprecated internal tools.

Despite these challenges, we expect full productivity within the first two weeks of employment.`,j_=({params:s,rawLogits:e})=>{const[t,r]=K.useState(""),[a,l]=K.useState(!1),[u,h]=K.useState(null),[p,f]=K.useState(.5),[g,b]=K.useState(new Set),[v,S]=K.useState(!1),M=async()=>{if(t.trim()){l(!0),h(null);try{const P=await O_(t,e,s,p);h(P),b(new Set)}catch(P){console.error("Friction analysis failed:",P)}finally{l(!1)}}},E=()=>{r(z_),h(null)},x=P=>{b(C=>{const k=new Set(C);return k.has(P)?k.delete(P):k.add(P),k})},_=P=>P>.7?"#10b981":P>.4?"#f59e0b":"#ef4444",N=K.useMemo(()=>u?{critical:u.frictionPoints.filter(P=>P.severity==="critical").length,warning:u.frictionPoints.filter(P=>P.severity==="warning").length,info:u.frictionPoints.filter(P=>P.severity==="info").length}:{critical:0,warning:0,info:0},[u]);return c.jsxs("div",{className:"flex flex-col space-y-4 h-full",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx("div",{className:"flex h-7 w-7 items-center justify-center rounded-lg bg-white/10 border border-white/20",children:c.jsx(Zh,{className:"h-3.5 w-3.5 text-white"})}),c.jsxs("div",{children:[c.jsx("h3",{className:"text-sm font-bold text-white tracking-tight",children:"Friction Analysis"}),c.jsx("p",{className:"text-[10px] text-gray-400 font-mono",children:"Joint log-probability • Drop-off detection"})]})]}),c.jsxs("div",{className:"relative",children:[c.jsx("textarea",{value:t,onChange:P=>{r(P.target.value),h(null)},placeholder:"Paste a business process, code block, job description, or any complex text to analyze for logical friction points...",rows:6,className:"w-full rounded-lg bg-[#111111] border border-white/10 px-3 py-2 text-xs text-gray-100 placeholder:text-gray-600 focus:border-gray-500 focus:outline-none focus:ring-0 resize-none font-mono leading-relaxed"}),c.jsxs("div",{className:"absolute bottom-2 right-2 flex items-center space-x-1.5",children:[c.jsx("button",{onClick:E,className:"btn-secondary-matte px-2.5 py-1 text-[11px]",children:"Load Contract Sample"}),c.jsx("button",{onClick:M,disabled:a||!t.trim(),className:"btn-primary-matte px-3 py-1 text-xs flex items-center space-x-1.5 disabled:opacity-50 disabled:cursor-not-allowed",children:a?c.jsxs(c.Fragment,{children:[c.jsx(vc,{className:"h-3.5 w-3.5 animate-spin"}),c.jsx("span",{children:"Scanning..."})]}):c.jsxs(c.Fragment,{children:[c.jsx(Kh,{className:"h-3.5 w-3.5 fill-current"}),c.jsx("span",{children:"Analyze Friction"})]})})]})]}),c.jsxs("div",{className:"flex items-center space-x-3",children:[c.jsxs("div",{className:"flex items-center space-x-1.5",children:[c.jsx(d_,{className:"h-3.5 w-3.5 text-orange-400"}),c.jsx("span",{className:"text-[11px] font-bold text-slate-300",children:"Sensitivity"})]}),c.jsx("input",{type:"range",min:"0",max:"1",step:"0.05",value:p,onChange:P=>f(parseFloat(P.target.value)),className:"flex-1 h-1.5 rounded-full appearance-none bg-slate-800 accent-orange-500"}),c.jsx("span",{className:"text-[10px] font-mono text-orange-300 w-12 text-right",children:p<.33?"Loose":p<.66?"Balanced":"Strict"})]}),c.jsx("button",{onClick:M,disabled:a||!t.trim(),className:"flex items-center justify-center space-x-2 rounded-xl bg-gradient-to-r from-orange-500 to-red-600 px-4 py-2 text-xs font-bold text-white shadow-lg hover:opacity-90 transition-opacity disabled:opacity-40 disabled:cursor-not-allowed",children:a?c.jsxs(c.Fragment,{children:[c.jsx(vc,{className:"h-3.5 w-3.5 animate-spin"}),c.jsx("span",{children:"Analyzing Friction..."})]}):c.jsxs(c.Fragment,{children:[c.jsx(mg,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:"Analyze Friction Points"})]})}),u&&c.jsxs("div",{className:"flex flex-col space-y-3 overflow-y-auto flex-1 min-h-0",children:[c.jsxs("div",{className:"grid grid-cols-3 gap-2",children:[c.jsxs("div",{className:"rounded-lg bg-slate-950/80 border border-slate-800 p-2 text-center",children:[c.jsx("div",{className:"text-[10px] text-slate-400 font-mono uppercase",children:"Joint Log-Prob"}),c.jsx("div",{className:"text-sm font-bold text-blue-300 font-mono",children:u.totalJointLogProb.toFixed(1)})]}),c.jsxs("div",{className:"rounded-lg bg-slate-950/80 border border-slate-800 p-2 text-center",children:[c.jsx("div",{className:"text-[10px] text-slate-400 font-mono uppercase",children:"Avg Score"}),c.jsx("div",{className:"text-sm font-bold text-blue-300 font-mono",children:u.averageLogProb.toFixed(2)})]}),c.jsxs("div",{className:"rounded-lg bg-slate-950/80 border border-slate-800 p-2 text-center",children:[c.jsx("div",{className:"text-[10px] text-slate-400 font-mono uppercase",children:"Analysis"}),c.jsxs("div",{className:"text-sm font-bold text-blue-300 font-mono",children:[u.analysisTimeMs,"ms"]})]})]}),c.jsx("div",{className:"flex items-center space-x-2",children:["critical","warning","info"].map(P=>{const C=qm[P],k=N[P],D=C.icon;return c.jsxs("div",{className:`flex items-center space-x-1 rounded-lg px-2 py-1 text-[10px] font-mono font-bold border ${C.bgClass} ${C.textClass} ${C.borderClass}`,children:[c.jsx(D,{className:"h-3 w-3"}),c.jsxs("span",{children:[k," ",C.label]})]},P)})}),c.jsxs("button",{onClick:()=>S(!v),className:"flex items-center space-x-1.5 text-[11px] text-slate-300 hover:text-orange-300 transition-colors",children:[c.jsx(cg,{className:"h-3.5 w-3.5 text-orange-400"}),c.jsx("span",{className:"font-bold",children:"Phrase-Level Heatmap"}),v?c.jsx(pa,{className:"h-3 w-3"}):c.jsx(fa,{className:"h-3 w-3"})]}),v&&c.jsx("div",{className:"space-y-1 max-h-[200px] overflow-y-auto rounded-lg bg-slate-950/60 p-2 border border-slate-800",children:u.phrases.map((P,C)=>c.jsxs("div",{className:"flex items-start space-x-2 rounded-md px-2 py-1 text-[10px] font-mono",children:[c.jsx("span",{className:"shrink-0 mt-1 h-2 w-2 rounded-full",style:{backgroundColor:_(P.normalizedScore)}}),c.jsx("span",{className:"text-slate-300 leading-relaxed flex-1",children:P.text}),c.jsx("span",{className:"shrink-0 font-bold",style:{color:_(P.normalizedScore)},children:P.logProb.toFixed(2)})]},C))}),u.frictionPoints.length>0?c.jsxs("div",{className:"space-y-2",children:[c.jsxs("div",{className:"flex items-center space-x-1.5",children:[c.jsx(u_,{className:"h-3.5 w-3.5 text-red-400"}),c.jsxs("span",{className:"text-[11px] font-bold text-slate-200",children:["Operational Friction Report (",u.frictionPoints.length," points)"]})]}),u.frictionPoints.map((P,C)=>{const k=qm[P.severity],D=k.icon,U=g.has(C);return c.jsxs("div",{className:`rounded-xl border ${k.borderClass} ${k.bgClass} overflow-hidden`,children:[c.jsxs("button",{onClick:()=>x(C),className:"w-full flex items-center justify-between px-3 py-2 text-left",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx(D,{className:`h-3.5 w-3.5 ${k.textClass}`}),c.jsxs("span",{className:`text-[11px] font-bold ${k.textClass}`,children:[k.label," — Phrase #",P.phraseIndex+1]}),c.jsxs("span",{className:"text-[10px] font-mono text-slate-400",children:["Drop: ",P.logProbDrop.toFixed(2)]})]}),U?c.jsx(pa,{className:"h-3 w-3 text-slate-400"}):c.jsx(fa,{className:"h-3 w-3 text-slate-400"})]}),U&&c.jsxs("div",{className:"px-3 pb-2.5 space-y-1.5 border-t border-slate-800/50",children:[c.jsxs("div",{className:"mt-2 rounded-md bg-slate-950/60 px-2.5 py-1.5 text-[10px] font-mono text-slate-300 leading-relaxed",children:['"',P.phrase,'"']}),c.jsxs("div",{className:"grid grid-cols-2 gap-2 text-[10px] font-mono",children:[c.jsxs("div",{children:[c.jsx("span",{className:"text-slate-500",children:"Previous Log-Prob:"})," ",c.jsx("span",{className:"text-emerald-300",children:P.previousLogProb})]}),c.jsxs("div",{children:[c.jsx("span",{className:"text-slate-500",children:"Current Log-Prob:"})," ",c.jsx("span",{className:"text-red-300",children:P.currentLogProb})]})]}),c.jsxs("div",{className:"text-[10px] text-slate-300 leading-relaxed italic flex items-start space-x-1.5",children:[c.jsx(Yh,{className:"h-3.5 w-3.5 text-slate-500 shrink-0 mt-0.5"}),c.jsx("span",{children:P.reason})]})]})]},C)})]}):c.jsxs("div",{className:"rounded-xl bg-emerald-500/10 border border-emerald-500/20 px-4 py-3 text-center flex items-center justify-center space-x-2",children:[c.jsx(qh,{className:"h-4 w-4 text-emerald-400"}),c.jsx("span",{className:"text-xs text-emerald-300 font-medium",children:"No significant friction points detected at current sensitivity level"})]})]})]})},$m=({params:s,setParams:e,prompt:t,setPrompt:r,systemPrompt:a,setSystemPrompt:l,jsonSchema:u,setJsonSchema:h,jsonSchemaEnabled:p,setJsonSchemaEnabled:f,ragContext:g,setRagContext:b,ragEnabled:v,setRagEnabled:S,onApplyPreset:M,onLaunchPrompt:E,onInteractFeature:x,isFetchingLogits:_=!1,rawLogits:N=[],isReasoningModel:P=!1})=>{const[C,k]=K.useState("sampling"),[D,U]=K.useState(!!a.trim()),[T,I]=K.useState(p),[z,O]=K.useState(v),[H,fe]=K.useState(!1),[re,q]=K.useState(""),[de,oe]=K.useState(-100),[Z,ee]=K.useState(""),[ce,F]=K.useState("temperature"),Y=te=>{x&&x({...te,timestamp:Date.now()})},Ce=(te,Se)=>{e(Qe=>({...Qe,[te]:Se}))},qe=()=>{if(!re.trim())return;const te=re.trim();e(Se=>({...Se,logitBiases:{...Se.logitBiases,[te]:de}})),Y({feature:`Logit Bias ('${te}': ${de})`,whatItIs:`Direct numerical modifier applied to token '${te}' before Softmax normalization.`,whyItIs:"Allows strict black-listing (-100) or heavy boosting (+10.0) of target vocabulary terms.",impact:de<=-50?`Implodes token '${te}' into a red Black Hole icon on the outer fringe (0% chance).`:`Pulls token '${te}' toward the center supergiant star.`,guidance:'Use -100 to ban unwanted buzzwords ("delve", "testament").'}),q("")},we=te=>{e(Se=>{const Qe={...Se.logitBiases};return delete Qe[te],{...Se,logitBiases:Qe}})},ie=()=>{if(!Z.trim())return;const te=Z.trim();s.stopSequences.includes(te)||Ce("stopSequences",[...s.stopSequences,te]),Y({feature:`Emergency Stop Sequence ("${te}")`,whatItIs:"Text pattern string that instantly halts generation when encountered.",whyItIs:"Prevents endless runaway text generation loops.",impact:`Truncates response output immediately when candidate matches "${te}".`,guidance:"Add \\n\\n or END to stop multi-paragraph answers cleanly."}),ee("")},xe=te=>{Ce("stopSequences",s.stopSequences.filter(Se=>Se!==te))},ve=te=>{const Se="h-4 w-4 text-slate-400 group-hover:text-blue-500 transition-colors duration-200";switch(te){case"FileText":return c.jsx(Vm,{className:Se});case"Code":return c.jsx(a_,{className:Se});case"Clipboard":return c.jsx(s_,{className:Se});case"MessageSquare":return c.jsx(v_,{className:Se});default:return c.jsx(ga,{className:Se})}};return c.jsxs("div",{className:"glass-panel-matte flex flex-col h-full rounded-xl overflow-hidden",children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-white/10 bg-[#1c1c21] px-5 py-3",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx(T_,{className:"h-4 w-4 text-slate-400"}),c.jsx("h2",{className:"text-sm font-bold text-white tracking-tight hidden sm:block",children:"Mission Control"})]}),c.jsxs("div",{className:"flex rounded-full bg-[#18181b] p-1 border border-white/10",children:[c.jsxs("button",{onClick:()=>k("sampling"),className:`flex items-center space-x-1.5 rounded-full px-3 py-1 text-xs font-medium transition-all ${C==="sampling"?"bg-blue-600 text-white font-semibold shadow-sm":"text-gray-400 hover:text-white"}`,children:[c.jsx(ga,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:"Sampling"})]}),c.jsxs("button",{onClick:()=>k("friction"),className:`flex items-center space-x-1.5 rounded-full px-3 py-1 text-xs font-medium transition-all ${C==="friction"?"bg-blue-600 text-white font-semibold shadow-sm":"text-gray-400 hover:text-white"}`,children:[c.jsx(Zh,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:"Friction Analysis"})]})]})]}),c.jsx("div",{className:"flex-1 overflow-y-auto p-5 space-y-6",children:C==="friction"?c.jsx(j_,{params:s,rawLogits:N}):c.jsxs("div",{className:"space-y-6",children:[c.jsxs("div",{children:[c.jsxs("label",{className:"text-[11px] font-mono uppercase tracking-wider text-gray-400 flex items-center space-x-1.5 mb-1",children:[c.jsx(yo,{className:"h-3.5 w-3.5 text-slate-400"}),c.jsx("span",{children:"Example Tasks"})]}),c.jsx("p",{className:"text-[10px] text-gray-500 mb-2.5",children:"Click one to see how the AI handles different jobs."}),c.jsx("div",{className:"grid grid-cols-2 gap-2",children:oc.map(te=>c.jsxs("button",{onClick:()=>{M(te),Y({feature:`Preset: ${te.name}`,whatItIs:`Pre-configured hyperparameter setup calibrated for ${te.name}.`,whyItIs:"Demonstrates ideal settings for specific AI tasks (e.g. strict coding vs creative writing).",impact:`Re-allocates Temperature to ${te.params.temperature}, Top-K to ${te.params.topK}, and toggles RAG.`,guidance:"Click presets to instantly jump between robotic factual accuracy and wild storytelling!"})},"aria-label":`Apply ${te.name} preset: ${te.subtitle}`,className:"glass-panel-interactive-matte flex flex-col items-start p-3 rounded-lg text-left border border-white/10 hover:border-white/20 transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] group",children:[c.jsxs("div",{className:"flex items-center space-x-2 w-full mb-1",children:[ve(te.icon),c.jsx("span",{className:"text-xs font-semibold text-gray-200 group-hover:text-white transition-colors duration-200 truncate",children:te.name})]}),c.jsx("span",{className:"text-[10px] text-gray-400 font-mono",children:te.subtitle})]},te.id))})]}),c.jsxs("div",{className:"rounded-xl border border-white/10 bg-[#111111] overflow-hidden",children:[c.jsxs("button",{type:"button",onClick:()=>U(!D),"aria-label":"Toggle AI Personality and Role instructions","aria-expanded":D,className:"w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-medium text-gray-200 hover:bg-white/5 transition-colors",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx(C_,{className:`h-4 w-4 transition-colors duration-200 ${a.trim()?"text-blue-500":"text-slate-400"}`}),c.jsx("span",{className:"font-semibold text-white tracking-tight",children:"AI Personality & Role"}),c.jsx("span",{className:`rounded-md px-2 py-0.5 text-[10px] font-mono font-medium ${a.trim()?"bg-white/10 text-white border border-white/15":"bg-black text-gray-400 border border-white/10"}`,children:a.trim()?"ACTIVE":"DEFAULT"})]}),D?c.jsx(pa,{className:"h-4 w-4 text-gray-400"}):c.jsx(fa,{className:"h-4 w-4 text-gray-400"})]}),D&&c.jsxs("div",{className:"p-3 border-t border-white/10 space-y-2 bg-[#0A0A0A]",children:[c.jsxs("p",{className:"text-[11px] text-gray-400 leading-relaxed font-mono",children:["Tell the AI who it should act like (e.g., ",c.jsx("em",{children:'"You are a helpful tutor"'}),"). Shifts the baseline word probabilities."]}),c.jsx("textarea",{"aria-label":"System prompt persona instructions",value:a,onChange:te=>{l(te.target.value),Y({feature:"System Persona Override",whatItIs:"Top-level behavioral directive injected into model chat template.",whyItIs:"Establishes domain persona expertise before processing user prompts.",impact:"Shifts baseline raw logit distribution across entire vocabulary.",guidance:"Use for domain task specialization (e.g. SQL DBA, Legal clause parser)."})},rows:2,className:"w-full rounded-lg bg-[#111111] border border-white/10 px-2.5 py-1.5 text-xs text-gray-100 placeholder:text-gray-600 focus:border-gray-500 focus:ring-0 focus:outline-none font-mono",placeholder:"You are a senior PostgreSQL DBA. Reply only with valid SQL queries..."})]})]}),c.jsxs("div",{className:"space-y-3",children:[c.jsxs("div",{children:[c.jsxs("div",{className:"flex items-center justify-between mb-1.5",children:[c.jsxs("label",{htmlFor:"prompt-input",className:"text-xs font-semibold text-gray-300 flex items-center space-x-1.5",children:[c.jsx(Vm,{className:"h-3.5 w-3.5 text-gray-400"}),c.jsx("span",{className:"text-white tracking-tight",children:"Your Message (The Prompt)"})]}),c.jsx("span",{className:"text-[10px] text-gray-400 font-mono",children:"Custom Prompt"})]}),c.jsx("textarea",{id:"prompt-input","aria-label":"Enter custom prompt for LLM sampling",value:t,onChange:te=>r(te.target.value),rows:2,className:"w-full rounded-lg bg-[#111111] border border-white/10 px-3 py-2 text-xs text-gray-100 placeholder:text-gray-600 focus:border-gray-500 focus:outline-none focus:ring-0 resize-none font-mono leading-relaxed",placeholder:"Type your question or starting sentence here..."})]}),c.jsxs("div",{className:"rounded-xl border border-white/10 bg-[#111111] overflow-hidden",children:[c.jsxs("button",{onClick:()=>{const te=!v;S(te),O(te),Y({feature:`RAG Grounding (${te?"ON":"OFF"})`,whatItIs:"Retrieval-Augmented Generation context tethering.",whyItIs:"Forces the LLM to base its predictions on user-provided factual documents.",impact:te?"Pulls grounded document terms to the center supergiant star via cyan laser beams.":"Un-tethers predictions, allowing parametric memory generation.",guidance:"Turn ON when accuracy is non-negotiable."})},"aria-label":v?"Turn RAG Fact Anchor OFF":"Turn RAG Fact Anchor ON","aria-expanded":z,className:"w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-medium text-gray-200 hover:bg-white/5 transition-colors",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx(gc,{className:`h-4 w-4 transition-colors duration-200 ${v?"text-blue-500":"text-slate-400"}`}),c.jsx("span",{className:"font-semibold text-white tracking-tight",children:"Provide Reference Facts"}),c.jsx("span",{className:`rounded-md px-2 py-0.5 text-[10px] font-mono font-medium ${v?"bg-white/10 text-white border border-white/15":"bg-black text-gray-400 border border-white/10"}`,children:v?"Grounded":"OFF"})]}),z?c.jsx(pa,{className:"h-4 w-4 text-gray-400"}):c.jsx(fa,{className:"h-4 w-4 text-gray-400"})]}),z&&c.jsxs("div",{className:"p-3 border-t border-white/10 space-y-2 bg-[#0A0A0A]",children:[c.jsxs("div",{className:"flex items-center space-x-1.5 text-[11px] text-gray-300 font-mono",children:[c.jsx(gc,{className:"h-3.5 w-3.5 text-gray-400"}),c.jsx("span",{children:"Paste reference facts here. The AI will read this instead of guessing."})]}),c.jsx("textarea",{"aria-label":"Retrieved factual context for RAG grounding",value:g,onChange:te=>b(te.target.value),rows:2,className:"w-full rounded-lg bg-slate-900 border border-slate-800 px-2.5 py-1.5 text-xs text-slate-100 placeholder-slate-600 focus:border-blue-500 focus:outline-none font-mono",placeholder:"Example: Employees must be in the office Tuesday through Thursday. Monday and Friday are remote."})]})]}),c.jsxs("div",{className:"rounded-xl border border-white/10 bg-[#111111] overflow-hidden",children:[c.jsxs("button",{onClick:()=>{const te=!p;f(te),I(te),Y({feature:`Structured Output JSON Schema (${te?"ACTIVE":"OFF"})`,whatItIs:"Rigid JSON grammar rule enforcer.",whyItIs:"Guarantees the AI returns valid JSON data structures instead of plain conversational prose.",impact:te?"Non-conforming tokens drop to 0% probability and turn red, proving format compliance.":"Restores normal dictionary token vocabulary.",guidance:"Activate when building automated API data extraction pipelines."})},"aria-label":p?"Turn Structured Output JSON Schema OFF":"Turn Structured Output JSON Schema ON","aria-expanded":T,className:"w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-medium text-slate-200 hover:bg-white/5 transition-colors",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx($h,{className:`h-4 w-4 transition-colors duration-200 ${p?"text-blue-500":"text-slate-400"}`}),c.jsx("span",{className:"font-semibold text-slate-100",children:"Force Strict Formatting"}),c.jsx("span",{className:`rounded-full px-2 py-0.5 text-[10px] font-bold ${p?"bg-blue-500/20 text-blue-300 border border-blue-400/30":"bg-slate-800 text-slate-400"}`,children:p?"ACTIVE":"OFF"})]}),T?c.jsx(pa,{className:"h-4 w-4 text-slate-400"}):c.jsx(fa,{className:"h-4 w-4 text-slate-400"})]}),T&&c.jsxs("div",{className:"p-3 border-t border-white/10 space-y-2 bg-[#0A0A0A]",children:[c.jsx("p",{className:"text-[11px] text-slate-300 leading-relaxed",children:"Forces the AI to answer in a rigid data format instead of a paragraph."}),c.jsx("textarea",{"aria-label":"JSON Schema for structured output enforcement",value:u,onChange:te=>h(te.target.value),rows:2,className:"w-full rounded-lg bg-slate-900 border border-slate-800 px-2.5 py-1.5 text-xs text-slate-100 placeholder-slate-600 focus:border-blue-500 focus:outline-none font-mono",placeholder:'{ "type": "object", "properties": { "result": { "type": "string" } } }'})]})]}),c.jsx("button",{onClick:E,disabled:_||!t.trim(),"aria-label":"Launch prompt evaluation and fetch token candidates",className:"w-full flex items-center justify-center space-x-2 rounded-xl bg-blue-600 hover:bg-blue-700 py-2.5 text-xs font-bold text-white shadow-md disabled:opacity-50 disabled:cursor-not-allowed transition-all",children:_?c.jsxs(c.Fragment,{children:[c.jsx(vc,{className:"h-4 w-4 animate-spin text-white"}),c.jsx("span",{children:"Mapping AI Thoughts..."})]}):c.jsxs(c.Fragment,{children:[c.jsx(Kh,{className:"h-4 w-4 text-white"}),c.jsx("span",{children:"Map the AI's Thoughts"})]})})]}),c.jsx(L_,{params:s,activeParam:ce}),c.jsxs("div",{className:"space-y-4 pt-2 border-t border-slate-800",children:[c.jsxs("h3",{className:"text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5",children:[c.jsx(Kr,{className:"h-3.5 w-3.5 text-slate-400"}),c.jsx("span",{children:"Brain Controls (How it Picks Words)"})]}),P?c.jsx("div",{className:"space-y-4",children:c.jsxs("div",{className:"rounded-xl border border-purple-500/30 bg-purple-950/20 p-4 shadow-lg shadow-purple-500/10",children:[c.jsxs("div",{className:"flex items-center space-x-2 mb-2",children:[c.jsx(e_,{className:"h-4 w-4 text-purple-400 animate-pulse"}),c.jsx("span",{className:"text-xs font-bold text-purple-300 uppercase tracking-widest",children:"Reasoning Active"})]}),c.jsx("p",{className:"text-[10px] text-purple-200/70 mb-4 leading-relaxed",children:"Standard decoding parameters (Temperature, Top-P) are disabled during reasoning. Adjust the Thinking Budget to control latent space exploration depth."}),c.jsxs("div",{className:"space-y-1.5",children:[c.jsxs("div",{className:"flex justify-between text-xs",children:[c.jsxs("label",{htmlFor:"thinking-budget",className:"font-medium text-slate-200 flex items-center space-x-1",children:[c.jsx("span",{children:"Thinking Budget"}),c.jsx("span",{className:"text-slate-400 font-mono text-[11px]",children:"(Max Tokens)"})]}),c.jsx("span",{className:"font-mono font-bold text-purple-400",children:s.maxThinkingTokens||2048})]}),c.jsx("input",{id:"thinking-budget",type:"range",min:"50",max:"4096",step:"50",value:s.maxThinkingTokens||2048,onChange:te=>e(Se=>({...Se,maxThinkingTokens:parseInt(te.target.value)})),className:"w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 hover:accent-blue-400 transition-all"}),c.jsxs("div",{className:"flex justify-between text-[9px] font-mono text-slate-500 px-1 pt-1",children:[c.jsx("span",{children:"50 (Fractured)"}),c.jsx("span",{children:"4096 (Deep Thought)"})]})]})]})}):c.jsxs(c.Fragment,{children:[c.jsxs("div",{className:"space-y-1.5",children:[c.jsxs("div",{className:"flex justify-between text-xs",children:[c.jsx("label",{htmlFor:"temp-slider",className:"font-medium text-slate-200 flex items-center space-x-1",children:c.jsx("span",{children:"Creativity vs. Focus (Temperature)"})}),c.jsx("span",{className:"font-mono font-bold text-amber-400",children:s.temperature.toFixed(2)})]}),c.jsx("input",{id:"temp-slider","aria-label":"Adjust Temperature T slider from 0.01 to 2.0",type:"range",min:"0.01",max:"2.0",step:"0.01",value:s.temperature,onFocus:()=>{F("temperature"),Y({feature:`Cosmic Heat (Temperature T = ${s.temperature.toFixed(2)})`,whatItIs:"Softmax exponent scaling divisor for candidate logits.",whyItIs:"Controls the balance between deterministic focus and creative randomness.",impact:s.temperature>1.2?"Outer asteroid stars glow brighter and flatten probability distribution.":"Sharpens top supergiant star probability toward 100%.",guidance:"Keep <0.3 for factual QA/code; set >1.0 for creative writing."})},onChange:te=>{const Se=parseFloat(te.target.value);F("temperature"),Ce("temperature",Se),Y({feature:`Temperature T (${Se.toFixed(2)})`,whatItIs:"Softmax exponent scaling divisor.",whyItIs:"Controls output entropy and candidate randomness.",impact:Se>1.2?"Causes low-probability outer tokens to glow brighter.":"Focuses probability heavily on the top star.",guidance:Se>1.2?"High entropy mode active.":"Factual focus mode active."})},className:"w-full"}),c.jsx("p",{className:"text-[11px] text-slate-400",children:"Low = Predictable and strict. High = Creative, random, and chaotic."}),c.jsx("div",{className:"flex items-center space-x-1.5 mt-1",children:s.temperature<=.2?c.jsxs("span",{className:"rounded-full bg-blue-500/10 text-blue-300 border border-blue-500/20 px-2 py-0.5 text-[10px] font-mono font-bold flex items-center space-x-1",children:[c.jsx(Qh,{className:"h-3 w-3 text-blue-400"}),c.jsx("span",{children:"Factual Precision (Legal / Medical / Code)"})]}):s.temperature>=1.2?c.jsxs("span",{className:"rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 px-2 py-0.5 text-[10px] font-mono font-bold flex items-center space-x-1",children:[c.jsx(Kr,{className:"h-3 w-3 text-rose-400"}),c.jsx("span",{children:"High Entropy (Creative Fiction / Dialogue)"})]}):c.jsx("span",{className:"rounded-full bg-blue-500/10 text-blue-300 border border-blue-500/20 px-2 py-0.5 text-[10px] font-mono font-medium",children:"Balanced Assistant Mode (General Q&A)"})})]}),c.jsxs("div",{className:"space-y-1.5",children:[c.jsxs("div",{className:"flex justify-between text-xs",children:[c.jsx("label",{htmlFor:"topk-slider",className:"font-medium text-slate-200 flex items-center space-x-1",children:c.jsx("span",{children:"Word Limit (Top-K)"})}),c.jsx("span",{className:"font-mono font-bold text-blue-400",children:s.topK})]}),c.jsx("input",{id:"topk-slider","aria-label":"Adjust Top-K slider from 1 to 100",type:"range",min:"1",max:"100",step:"1",value:s.topK,onFocus:()=>{F("topK"),Y({feature:`Orbital Ring (Top-K = ${s.topK})`,whatItIs:"Strict top K rank vocabulary candidate filter.",whyItIs:"Eliminates absurd long-tail tokens regardless of temperature.",impact:`Keeps top ${s.topK} candidate stars active; grays out outer tokens.`,guidance:"Set Top-K to 40 for standard conversational LLM sampling."})},onChange:te=>{const Se=parseInt(te.target.value,10);F("topK"),Ce("topK",Se),Y({feature:`Top-K Filter (${Se})`,whatItIs:"Rank cutoff threshold.",whyItIs:"Hard-clips tokens beyond rank K.",impact:`Only top ${Se} candidates remain eligible for sampling.`,guidance:`Top ${Se} candidates active.`})},className:"w-full"}),c.jsx("p",{className:"text-[11px] text-slate-400",children:"Only allow the AI to choose from the top K most likely words. Ignores the rest."})]}),c.jsxs("div",{className:"space-y-1.5",children:[c.jsxs("div",{className:"flex justify-between text-xs",children:[c.jsx("label",{htmlFor:"topp-slider",className:"font-medium text-slate-200 flex items-center space-x-1",children:c.jsx("span",{children:"Confidence Cutoff (Top-P)"})}),c.jsxs("span",{className:"font-mono font-bold text-blue-400",children:[(s.topP*100).toFixed(0),"%"]})]}),c.jsx("input",{id:"topp-slider","aria-label":"Adjust Top-P slider from 1% to 100%",type:"range",min:"0.01",max:"1.0",step:"0.01",value:s.topP,onFocus:()=>F("topP"),onChange:te=>{const Se=parseFloat(te.target.value);F("topP"),Ce("topP",Se),Y({feature:`Energy Shield (Top-P = ${(Se*100).toFixed(0)}%)`,whatItIs:"Cumulative probability nucleus cutoff threshold.",whyItIs:"Dynamically resizes candidate pool based on confidence distribution.",impact:`Drapes dynamic purple energy shield ring at cumulative ${(Se*100).toFixed(0)}%.`,guidance:"Set Top-P to 0.90 for balanced natural responses."})},className:"w-full"}),c.jsx("p",{className:"text-[11px] text-slate-400",children:"Only use words that make up the top P% of total probability."})]}),c.jsxs("div",{className:"space-y-1.5",children:[c.jsxs("div",{className:"flex justify-between text-xs",children:[c.jsx("label",{htmlFor:"minp-slider",className:"font-medium text-slate-200 flex items-center space-x-1",children:c.jsx("span",{children:"Ignore Wild Guesses (Min-P)"})}),c.jsxs("span",{className:"font-mono font-bold text-blue-400",children:[(s.minP*100).toFixed(1),"%"]})]}),c.jsx("input",{id:"minp-slider","aria-label":"Adjust Min-P slider from 0% to 100%",type:"range",min:"0.0",max:"1.0",step:"0.01",value:s.minP,onFocus:()=>F("minP"),onChange:te=>{const Se=parseFloat(te.target.value);F("minP"),Ce("minP",Se),Y({feature:`Gravity Well (Min-P = ${(Se*100).toFixed(1)}%)`,whatItIs:"Relative probability cutoff scaled to top star chance.",whyItIs:"Superior to Top-P at high temperatures because it scales dynamically.",impact:`Filters candidates below ${(Se*100).toFixed(1)}% of top star probability.`,guidance:"Set Min-P to 0.05 (5%) for clean sampling at T>1.0."})},className:"w-full"}),c.jsx("p",{className:"text-[11px] text-slate-400",children:"Hide words that have a near-zero chance of making sense."})]})]}),c.jsxs("div",{className:"rounded-xl border border-white/10 bg-[#111111] overflow-hidden",children:[c.jsxs("button",{type:"button",onClick:()=>fe(!H),"aria-label":"Toggle Penalties and Guardrails sampling options","aria-expanded":H,className:"w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-medium text-gray-200 hover:bg-white/5 transition-colors",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx(da,{className:`h-4 w-4 transition-colors duration-200 ${s.frequencyPenalty>0||s.presencePenalty>0||Object.keys(s.logitBiases).length>0||s.stopSequences.length>0?"text-blue-500":"text-slate-400"}`}),c.jsx("span",{className:"font-semibold text-white tracking-tight",children:"Repetition Blockers (Penalties)"}),c.jsx("span",{className:`rounded-full px-2 py-0.5 text-[10px] font-bold ${s.frequencyPenalty>0||s.presencePenalty>0||Object.keys(s.logitBiases).length>0||s.stopSequences.length>0?"bg-blue-500/10 text-blue-300 border border-blue-500/20":"bg-slate-800 text-slate-400"}`,children:s.frequencyPenalty>0||s.presencePenalty>0||Object.keys(s.logitBiases).length>0||s.stopSequences.length>0?"ACTIVE":"DEFAULT"})]}),H?c.jsx(pa,{className:"h-4 w-4 text-gray-400"}):c.jsx(fa,{className:"h-4 w-4 text-gray-400"})]}),H&&c.jsxs("div",{className:"p-4 border-t border-white/10 space-y-4 bg-[#0A0A0A]",children:[c.jsxs("div",{className:"space-y-1.5",children:[c.jsxs("div",{className:"flex justify-between text-xs",children:[c.jsx("label",{htmlFor:"freq-penalty-slider",className:"font-medium text-slate-200",children:"Exhaustion Meter (Frequency Penalty)"}),c.jsx("span",{className:"font-mono font-bold text-blue-400",children:s.frequencyPenalty.toFixed(2)})]}),c.jsx("input",{id:"freq-penalty-slider","aria-label":"Adjust Frequency Penalty (Exhaustion Meter) slider from -2 to 2",type:"range",min:"-2.0",max:"2.0",step:"0.01",value:s.frequencyPenalty,onFocus:()=>F("frequencyPenalty"),onChange:te=>{const Se=parseFloat(te.target.value);F("frequencyPenalty"),Ce("frequencyPenalty",Se),Y({feature:`Exhaustion Meter (Frequency Penalty = ${Se.toFixed(2)})`,whatItIs:"Repetition penalty proportional to exact token frequency count.",whyItIs:"Breaks stubborn repetitive phrases and word loops.",impact:"Words used repeatedly in context history dim in opacity.",guidance:"Increase >0.5 to stop the model from repeating words."})},className:"w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 hover:accent-blue-400 transition-all"})]}),c.jsxs("div",{className:"space-y-1.5",children:[c.jsxs("div",{className:"flex justify-between text-xs",children:[c.jsx("label",{htmlFor:"presence-penalty-slider",className:"font-medium text-slate-200",children:"Horizon Booster (Presence Penalty)"}),c.jsx("span",{className:"font-mono font-bold text-blue-400",children:s.presencePenalty.toFixed(2)})]}),c.jsx("input",{id:"presence-penalty-slider","aria-label":"Adjust Presence Penalty (Horizon Booster) slider from -2 to 2",type:"range",min:"-2.0",max:"2.0",step:"0.01",value:s.presencePenalty,onFocus:()=>F("presencePenalty"),onChange:te=>{const Se=parseFloat(te.target.value);F("presencePenalty"),Ce("presencePenalty",Se),Y({feature:`Horizon Booster (Presence Penalty = ${Se.toFixed(2)})`,whatItIs:"Flat penalty applied once to any token present in context.",whyItIs:"Encourages the model to introduce fresh new topics.",impact:"Broadens vocabulary scope across outer orbital rings.",guidance:"Increase >0.5 to encourage diverse topic exploration."})},className:"w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 hover:accent-blue-400 transition-all"})]}),c.jsxs("div",{className:"space-y-2",children:[c.jsx("label",{htmlFor:"bias-word-input",className:"text-xs font-medium text-slate-200 flex items-center justify-between",children:c.jsxs("span",{className:"flex items-center space-x-1",children:[c.jsx(g_,{className:"h-3.5 w-3.5 text-slate-400"}),c.jsx("span",{children:"Magnet / Black Hole (Logit Bias)"})]})}),c.jsx("div",{className:"flex flex-wrap gap-1.5 mb-2",children:Object.entries(s.logitBiases).map(([te,Se])=>c.jsxs("span",{className:`inline-flex items-center space-x-1 px-2 py-0.5 rounded-md text-xs font-mono border ${Se<0?"bg-slate-900 text-slate-300 border border-slate-700":"bg-blue-950/60 text-blue-300 border border-blue-800/50"}`,children:[c.jsxs("span",{children:["'",te,"':"]}),c.jsx("span",{className:"font-bold",children:Se>0?`+${Se}`:Se}),c.jsx("button",{type:"button",onClick:()=>we(te),"aria-label":`Remove logit bias for ${te}`,className:"hover:text-white ml-1",children:c.jsx(_c,{className:"h-3 w-3"})})]},te))}),c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx("input",{id:"bias-word-input",type:"text",placeholder:"Target word (e.g. delve)","aria-label":"Word to apply logit bias to",value:re,onChange:te=>q(te.target.value),className:"flex-1 rounded-lg bg-slate-900 border border-slate-800 px-2.5 py-1 text-xs text-slate-200 placeholder-slate-600 focus:border-cyan-400 focus:outline-none font-mono"}),c.jsxs("select",{"aria-label":"Select logit bias value",value:de,onChange:te=>oe(parseFloat(te.target.value)),className:"rounded-lg bg-slate-900 border border-slate-800 px-2 py-1 text-xs text-slate-200 font-mono focus:outline-none",children:[c.jsx("option",{value:-100,children:"-100 (Black Hole / Ban)"}),c.jsx("option",{value:-5,children:"-5.0 (Discourage)"}),c.jsx("option",{value:5,children:"+5.0 (Boost)"}),c.jsx("option",{value:10,children:"+10.0 (Magnet)"})]}),c.jsx("button",{type:"button",onClick:qe,"aria-label":"Add logit bias word",className:"rounded-lg bg-blue-600 hover:bg-blue-700 text-white p-1.5 shadow-md transition-colors",children:c.jsx(Wm,{className:"h-3.5 w-3.5"})})]})]}),c.jsxs("div",{className:"space-y-2",children:[c.jsxs("label",{htmlFor:"stop-seq-input",className:"text-xs font-medium text-slate-200 flex items-center space-x-1",children:[c.jsx(ac,{className:"h-3.5 w-3.5 text-slate-400"}),c.jsx("span",{children:"Emergency Brake (Stop Sequences)"})]}),c.jsx("div",{className:"flex flex-wrap gap-1.5",children:s.stopSequences.map(te=>c.jsxs("span",{className:"inline-flex items-center space-x-1 px-2 py-0.5 rounded-md text-xs font-mono bg-slate-800 text-amber-300 border border-slate-700",children:[c.jsxs("span",{children:['"',te,'"']}),c.jsx("button",{type:"button",onClick:()=>xe(te),"aria-label":`Remove stop sequence ${te}`,className:"hover:text-white ml-1",children:c.jsx(_c,{className:"h-3 w-3"})})]},te))}),c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx("input",{id:"stop-seq-input",type:"text",placeholder:"e.g. \\n or END","aria-label":"Stop sequence string to add",value:Z,onChange:te=>ee(te.target.value),className:"flex-1 rounded-lg bg-slate-900 border border-slate-800 px-2.5 py-1 text-xs text-slate-200 placeholder-slate-600 focus:border-cyan-400 focus:outline-none font-mono"}),c.jsx("button",{type:"button",onClick:ie,"aria-label":"Add stop sequence",className:"rounded-lg bg-amber-500/20 p-1.5 text-amber-300 border border-amber-400/40 hover:bg-amber-500/30",children:c.jsx(Wm,{className:"h-3.5 w-3.5"})})]})]})]})]}),"      "]})]})})]})};/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Jh="185",xa={ROTATE:0,DOLLY:1,PAN:2},ma={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},H_=0,Ym=1,V_=2,lc=1,G_=2,vo=3,Zr=0,si=1,Fi=2,Qi=0,Ms=1,yc=2,Km=3,Zm=4,W_=5,_s=100,X_=101,q_=102,$_=103,Y_=104,K_=200,Z_=201,Q_=202,J_=203,eh=204,th=205,ey=206,ty=207,ny=208,iy=209,ry=210,sy=211,ay=212,oy=213,ly=214,nh=0,ih=1,rh=2,ya=3,sh=4,ah=5,oh=6,lh=7,gg=0,cy=1,uy=2,Ji=0,xg=1,vg=2,_g=3,yg=4,bg=5,Sg=6,Mg=7,wg=300,ws=301,ba=302,md=303,gd=304,Dc=306,ch=1e3,xr=1001,uh=1002,Dn=1003,dy=1004,Pl=1005,zn=1006,xd=1007,bs=1008,Mi=1009,Eg=1010,Tg=1011,bo=1012,ef=1013,er=1014,Oi=1015,fi=1016,tf=1017,nf=1018,So=1020,Ag=35902,Cg=35899,Rg=1021,Pg=1022,Bi=1023,yr=1026,Ss=1027,Ng=1028,rf=1029,Qr=1030,sf=1031,af=1033,cc=33776,uc=33777,dc=33778,hc=33779,dh=35840,hh=35841,fh=35842,ph=35843,mh=36196,gh=37492,xh=37496,vh=37488,_h=37489,bc=37490,yh=37491,bh=37808,Sh=37809,Mh=37810,wh=37811,Eh=37812,Th=37813,Ah=37814,Ch=37815,Rh=37816,Ph=37817,Nh=37818,Lh=37819,Dh=37820,Ih=37821,kh=36492,Fh=36494,Uh=36495,Oh=36283,Bh=36284,Sc=36285,zh=36286,hy=3200,Qm=0,fy=1,$r="",bi="srgb",Mc="srgb-linear",wc="linear",Wt="srgb",Ks=7680,Jm=519,py=512,my=513,gy=514,of=515,xy=516,vy=517,lf=518,_y=519,e0=35044,t0="300 es",Zi=2e3,Ec=2001;function yy(s){for(let e=s.length-1;e>=0;--e)if(s[e]>=65535)return!0;return!1}function Tc(s){return document.createElementNS("http://www.w3.org/1999/xhtml",s)}function by(){const s=Tc("canvas");return s.style.display="block",s}const n0={};function i0(...s){const e="THREE."+s.shift();console.log(e,...s)}function Lg(s){const e=s[0];if(typeof e=="string"&&e.startsWith("TSL:")){const t=s[1];t&&t.isStackTrace?s[0]+=" "+t.getLocation():s[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return s}function gt(...s){s=Lg(s);const e="THREE."+s.shift();{const t=s[0];t&&t.isStackTrace?console.warn(t.getError(e)):console.warn(e,...s)}}function Ut(...s){s=Lg(s);const e="THREE."+s.shift();{const t=s[0];t&&t.isStackTrace?console.error(t.getError(e)):console.error(e,...s)}}function va(...s){const e=s.join(" ");e in n0||(n0[e]=!0,gt(...s))}function Sy(s,e,t){return new Promise(function(r,a){function l(){switch(s.clientWaitSync(e,s.SYNC_FLUSH_COMMANDS_BIT,0)){case s.WAIT_FAILED:a();break;case s.TIMEOUT_EXPIRED:setTimeout(l,t);break;default:r()}}setTimeout(l,t)})}const My={[nh]:ih,[rh]:oh,[sh]:lh,[ya]:ah,[ih]:nh,[oh]:rh,[lh]:sh,[ah]:ya};class es{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const r=this._listeners;r[e]===void 0&&(r[e]=[]),r[e].indexOf(t)===-1&&r[e].push(t)}hasEventListener(e,t){const r=this._listeners;return r===void 0?!1:r[e]!==void 0&&r[e].indexOf(t)!==-1}removeEventListener(e,t){const r=this._listeners;if(r===void 0)return;const a=r[e];if(a!==void 0){const l=a.indexOf(t);l!==-1&&a.splice(l,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const r=t[e.type];if(r!==void 0){e.target=this;const a=r.slice(0);for(let l=0,u=a.length;l<u;l++)a[l].call(this,e);e.target=null}}}const On=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],fc=Math.PI/180,jh=180/Math.PI;function Mo(){const s=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,r=Math.random()*4294967295|0;return(On[s&255]+On[s>>8&255]+On[s>>16&255]+On[s>>24&255]+"-"+On[e&255]+On[e>>8&255]+"-"+On[e>>16&15|64]+On[e>>24&255]+"-"+On[t&63|128]+On[t>>8&255]+"-"+On[t>>16&255]+On[t>>24&255]+On[r&255]+On[r>>8&255]+On[r>>16&255]+On[r>>24&255]).toLowerCase()}function At(s,e,t){return Math.max(e,Math.min(t,s))}function wy(s,e){return(s%e+e)%e}function vd(s,e,t){return(1-t)*s+t*e}function oo(s,e){switch(e.constructor){case Float32Array:return s;case Uint32Array:return s/4294967295;case Uint16Array:return s/65535;case Uint8Array:return s/255;case Int32Array:return Math.max(s/2147483647,-1);case Int16Array:return Math.max(s/32767,-1);case Int8Array:return Math.max(s/127,-1);default:throw new Error("THREE.MathUtils: Invalid component type.")}}function ii(s,e){switch(e.constructor){case Float32Array:return s;case Uint32Array:return Math.round(s*4294967295);case Uint16Array:return Math.round(s*65535);case Uint8Array:return Math.round(s*255);case Int32Array:return Math.round(s*2147483647);case Int16Array:return Math.round(s*32767);case Int8Array:return Math.round(s*127);default:throw new Error("THREE.MathUtils: Invalid component type.")}}const Ey={DEG2RAD:fc};class dt{static{dt.prototype.isVector2=!0}constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,r=this.y,a=e.elements;return this.x=a[0]*t+a[3]*r+a[6],this.y=a[1]*t+a[4]*r+a[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=At(this.x,e.x,t.x),this.y=At(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=At(this.x,e,t),this.y=At(this.y,e,t),this}clampLength(e,t){const r=this.length();return this.divideScalar(r||1).multiplyScalar(At(r,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const r=this.dot(e)/t;return Math.acos(At(r,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,r=this.y-e.y;return t*t+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,r){return this.x=e.x+(t.x-e.x)*r,this.y=e.y+(t.y-e.y)*r,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const r=Math.cos(t),a=Math.sin(t),l=this.x-e.x,u=this.y-e.y;return this.x=l*r-u*a+e.x,this.y=l*a+u*r+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Jr{constructor(e=0,t=0,r=0,a=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=r,this._w=a}static slerpFlat(e,t,r,a,l,u,h){let p=r[a+0],f=r[a+1],g=r[a+2],b=r[a+3],v=l[u+0],S=l[u+1],M=l[u+2],E=l[u+3];if(b!==E||p!==v||f!==S||g!==M){let x=p*v+f*S+g*M+b*E;x<0&&(v=-v,S=-S,M=-M,E=-E,x=-x);let _=1-h;if(x<.9995){const N=Math.acos(x),P=Math.sin(N);_=Math.sin(_*N)/P,h=Math.sin(h*N)/P,p=p*_+v*h,f=f*_+S*h,g=g*_+M*h,b=b*_+E*h}else{p=p*_+v*h,f=f*_+S*h,g=g*_+M*h,b=b*_+E*h;const N=1/Math.sqrt(p*p+f*f+g*g+b*b);p*=N,f*=N,g*=N,b*=N}}e[t]=p,e[t+1]=f,e[t+2]=g,e[t+3]=b}static multiplyQuaternionsFlat(e,t,r,a,l,u){const h=r[a],p=r[a+1],f=r[a+2],g=r[a+3],b=l[u],v=l[u+1],S=l[u+2],M=l[u+3];return e[t]=h*M+g*b+p*S-f*v,e[t+1]=p*M+g*v+f*b-h*S,e[t+2]=f*M+g*S+h*v-p*b,e[t+3]=g*M-h*b-p*v-f*S,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,r,a){return this._x=e,this._y=t,this._z=r,this._w=a,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const r=e._x,a=e._y,l=e._z,u=e._order,h=Math.cos,p=Math.sin,f=h(r/2),g=h(a/2),b=h(l/2),v=p(r/2),S=p(a/2),M=p(l/2);switch(u){case"XYZ":this._x=v*g*b+f*S*M,this._y=f*S*b-v*g*M,this._z=f*g*M+v*S*b,this._w=f*g*b-v*S*M;break;case"YXZ":this._x=v*g*b+f*S*M,this._y=f*S*b-v*g*M,this._z=f*g*M-v*S*b,this._w=f*g*b+v*S*M;break;case"ZXY":this._x=v*g*b-f*S*M,this._y=f*S*b+v*g*M,this._z=f*g*M+v*S*b,this._w=f*g*b-v*S*M;break;case"ZYX":this._x=v*g*b-f*S*M,this._y=f*S*b+v*g*M,this._z=f*g*M-v*S*b,this._w=f*g*b+v*S*M;break;case"YZX":this._x=v*g*b+f*S*M,this._y=f*S*b+v*g*M,this._z=f*g*M-v*S*b,this._w=f*g*b-v*S*M;break;case"XZY":this._x=v*g*b-f*S*M,this._y=f*S*b-v*g*M,this._z=f*g*M+v*S*b,this._w=f*g*b+v*S*M;break;default:gt("Quaternion: .setFromEuler() encountered an unknown order: "+u)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const r=t/2,a=Math.sin(r);return this._x=e.x*a,this._y=e.y*a,this._z=e.z*a,this._w=Math.cos(r),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,r=t[0],a=t[4],l=t[8],u=t[1],h=t[5],p=t[9],f=t[2],g=t[6],b=t[10],v=r+h+b;if(v>0){const S=.5/Math.sqrt(v+1);this._w=.25/S,this._x=(g-p)*S,this._y=(l-f)*S,this._z=(u-a)*S}else if(r>h&&r>b){const S=2*Math.sqrt(1+r-h-b);this._w=(g-p)/S,this._x=.25*S,this._y=(a+u)/S,this._z=(l+f)/S}else if(h>b){const S=2*Math.sqrt(1+h-r-b);this._w=(l-f)/S,this._x=(a+u)/S,this._y=.25*S,this._z=(p+g)/S}else{const S=2*Math.sqrt(1+b-r-h);this._w=(u-a)/S,this._x=(l+f)/S,this._y=(p+g)/S,this._z=.25*S}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let r=e.dot(t)+1;return r<1e-8?(r=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=r):(this._x=0,this._y=-e.z,this._z=e.y,this._w=r)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=r),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(At(this.dot(e),-1,1)))}rotateTowards(e,t){const r=this.angleTo(e);if(r===0)return this;const a=Math.min(1,t/r);return this.slerp(e,a),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const r=e._x,a=e._y,l=e._z,u=e._w,h=t._x,p=t._y,f=t._z,g=t._w;return this._x=r*g+u*h+a*f-l*p,this._y=a*g+u*p+l*h-r*f,this._z=l*g+u*f+r*p-a*h,this._w=u*g-r*h-a*p-l*f,this._onChangeCallback(),this}slerp(e,t){let r=e._x,a=e._y,l=e._z,u=e._w,h=this.dot(e);h<0&&(r=-r,a=-a,l=-l,u=-u,h=-h);let p=1-t;if(h<.9995){const f=Math.acos(h),g=Math.sin(f);p=Math.sin(p*f)/g,t=Math.sin(t*f)/g,this._x=this._x*p+r*t,this._y=this._y*p+a*t,this._z=this._z*p+l*t,this._w=this._w*p+u*t,this._onChangeCallback()}else this._x=this._x*p+r*t,this._y=this._y*p+a*t,this._z=this._z*p+l*t,this._w=this._w*p+u*t,this.normalize();return this}slerpQuaternions(e,t,r){return this.copy(e).slerp(t,r)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),r=Math.random(),a=Math.sqrt(1-r),l=Math.sqrt(r);return this.set(a*Math.sin(e),a*Math.cos(e),l*Math.sin(t),l*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class X{static{X.prototype.isVector3=!0}constructor(e=0,t=0,r=0){this.x=e,this.y=t,this.z=r}set(e,t,r){return r===void 0&&(r=this.z),this.x=e,this.y=t,this.z=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(r0.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(r0.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,r=this.y,a=this.z,l=e.elements;return this.x=l[0]*t+l[3]*r+l[6]*a,this.y=l[1]*t+l[4]*r+l[7]*a,this.z=l[2]*t+l[5]*r+l[8]*a,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,r=this.y,a=this.z,l=e.elements,u=1/(l[3]*t+l[7]*r+l[11]*a+l[15]);return this.x=(l[0]*t+l[4]*r+l[8]*a+l[12])*u,this.y=(l[1]*t+l[5]*r+l[9]*a+l[13])*u,this.z=(l[2]*t+l[6]*r+l[10]*a+l[14])*u,this}applyQuaternion(e){const t=this.x,r=this.y,a=this.z,l=e.x,u=e.y,h=e.z,p=e.w,f=2*(u*a-h*r),g=2*(h*t-l*a),b=2*(l*r-u*t);return this.x=t+p*f+u*b-h*g,this.y=r+p*g+h*f-l*b,this.z=a+p*b+l*g-u*f,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,r=this.y,a=this.z,l=e.elements;return this.x=l[0]*t+l[4]*r+l[8]*a,this.y=l[1]*t+l[5]*r+l[9]*a,this.z=l[2]*t+l[6]*r+l[10]*a,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=At(this.x,e.x,t.x),this.y=At(this.y,e.y,t.y),this.z=At(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=At(this.x,e,t),this.y=At(this.y,e,t),this.z=At(this.z,e,t),this}clampLength(e,t){const r=this.length();return this.divideScalar(r||1).multiplyScalar(At(r,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,r){return this.x=e.x+(t.x-e.x)*r,this.y=e.y+(t.y-e.y)*r,this.z=e.z+(t.z-e.z)*r,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const r=e.x,a=e.y,l=e.z,u=t.x,h=t.y,p=t.z;return this.x=a*p-l*h,this.y=l*u-r*p,this.z=r*h-a*u,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const r=e.dot(this)/t;return this.copy(e).multiplyScalar(r)}projectOnPlane(e){return _d.copy(this).projectOnVector(e),this.sub(_d)}reflect(e){return this.sub(_d.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const r=this.dot(e)/t;return Math.acos(At(r,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,r=this.y-e.y,a=this.z-e.z;return t*t+r*r+a*a}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,r){const a=Math.sin(t)*e;return this.x=a*Math.sin(r),this.y=Math.cos(t)*e,this.z=a*Math.cos(r),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,r){return this.x=e*Math.sin(t),this.y=r,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),r=this.setFromMatrixColumn(e,1).length(),a=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=r,this.z=a,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,r=Math.sqrt(1-t*t);return this.x=r*Math.cos(e),this.y=t,this.z=r*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const _d=new X,r0=new Jr;class yt{static{yt.prototype.isMatrix3=!0}constructor(e,t,r,a,l,u,h,p,f){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,r,a,l,u,h,p,f)}set(e,t,r,a,l,u,h,p,f){const g=this.elements;return g[0]=e,g[1]=a,g[2]=h,g[3]=t,g[4]=l,g[5]=p,g[6]=r,g[7]=u,g[8]=f,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,r=e.elements;return t[0]=r[0],t[1]=r[1],t[2]=r[2],t[3]=r[3],t[4]=r[4],t[5]=r[5],t[6]=r[6],t[7]=r[7],t[8]=r[8],this}extractBasis(e,t,r){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),r.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const r=e.elements,a=t.elements,l=this.elements,u=r[0],h=r[3],p=r[6],f=r[1],g=r[4],b=r[7],v=r[2],S=r[5],M=r[8],E=a[0],x=a[3],_=a[6],N=a[1],P=a[4],C=a[7],k=a[2],D=a[5],U=a[8];return l[0]=u*E+h*N+p*k,l[3]=u*x+h*P+p*D,l[6]=u*_+h*C+p*U,l[1]=f*E+g*N+b*k,l[4]=f*x+g*P+b*D,l[7]=f*_+g*C+b*U,l[2]=v*E+S*N+M*k,l[5]=v*x+S*P+M*D,l[8]=v*_+S*C+M*U,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],r=e[1],a=e[2],l=e[3],u=e[4],h=e[5],p=e[6],f=e[7],g=e[8];return t*u*g-t*h*f-r*l*g+r*h*p+a*l*f-a*u*p}invert(){const e=this.elements,t=e[0],r=e[1],a=e[2],l=e[3],u=e[4],h=e[5],p=e[6],f=e[7],g=e[8],b=g*u-h*f,v=h*p-g*l,S=f*l-u*p,M=t*b+r*v+a*S;if(M===0)return this.set(0,0,0,0,0,0,0,0,0);const E=1/M;return e[0]=b*E,e[1]=(a*f-g*r)*E,e[2]=(h*r-a*u)*E,e[3]=v*E,e[4]=(g*t-a*p)*E,e[5]=(a*l-h*t)*E,e[6]=S*E,e[7]=(r*p-f*t)*E,e[8]=(u*t-r*l)*E,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,r,a,l,u,h){const p=Math.cos(l),f=Math.sin(l);return this.set(r*p,r*f,-r*(p*u+f*h)+u+e,-a*f,a*p,-a*(-f*u+p*h)+h+t,0,0,1),this}scale(e,t){return va("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(yd.makeScale(e,t)),this}rotate(e){return va("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(yd.makeRotation(-e)),this}translate(e,t){return va("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(yd.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),r=Math.sin(e);return this.set(t,-r,0,r,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,r=e.elements;for(let a=0;a<9;a++)if(t[a]!==r[a])return!1;return!0}fromArray(e,t=0){for(let r=0;r<9;r++)this.elements[r]=e[r+t];return this}toArray(e=[],t=0){const r=this.elements;return e[t]=r[0],e[t+1]=r[1],e[t+2]=r[2],e[t+3]=r[3],e[t+4]=r[4],e[t+5]=r[5],e[t+6]=r[6],e[t+7]=r[7],e[t+8]=r[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const yd=new yt,s0=new yt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),a0=new yt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Ty(){const s={enabled:!0,workingColorSpace:Mc,spaces:{},convert:function(a,l,u){return this.enabled===!1||l===u||!l||!u||(this.spaces[l].transfer===Wt&&(a.r=vr(a.r),a.g=vr(a.g),a.b=vr(a.b)),this.spaces[l].primaries!==this.spaces[u].primaries&&(a.applyMatrix3(this.spaces[l].toXYZ),a.applyMatrix3(this.spaces[u].fromXYZ)),this.spaces[u].transfer===Wt&&(a.r=_a(a.r),a.g=_a(a.g),a.b=_a(a.b))),a},workingToColorSpace:function(a,l){return this.convert(a,this.workingColorSpace,l)},colorSpaceToWorking:function(a,l){return this.convert(a,l,this.workingColorSpace)},getPrimaries:function(a){return this.spaces[a].primaries},getTransfer:function(a){return a===$r?wc:this.spaces[a].transfer},getToneMappingMode:function(a){return this.spaces[a].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(a,l=this.workingColorSpace){return a.fromArray(this.spaces[l].luminanceCoefficients)},define:function(a){Object.assign(this.spaces,a)},_getMatrix:function(a,l,u){return a.copy(this.spaces[l].toXYZ).multiply(this.spaces[u].fromXYZ)},_getDrawingBufferColorSpace:function(a){return this.spaces[a].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(a=this.workingColorSpace){return this.spaces[a].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(a,l){return va("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),s.workingToColorSpace(a,l)},toWorkingColorSpace:function(a,l){return va("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),s.colorSpaceToWorking(a,l)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],r=[.3127,.329];return s.define({[Mc]:{primaries:e,whitePoint:r,transfer:wc,toXYZ:s0,fromXYZ:a0,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:bi},outputColorSpaceConfig:{drawingBufferColorSpace:bi}},[bi]:{primaries:e,whitePoint:r,transfer:Wt,toXYZ:s0,fromXYZ:a0,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:bi}}}),s}const kt=Ty();function vr(s){return s<.04045?s*.0773993808:Math.pow(s*.9478672986+.0521327014,2.4)}function _a(s){return s<.0031308?s*12.92:1.055*Math.pow(s,.41666)-.055}let Zs;class Ay{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let r;if(e instanceof HTMLCanvasElement)r=e;else{Zs===void 0&&(Zs=Tc("canvas")),Zs.width=e.width,Zs.height=e.height;const a=Zs.getContext("2d");e instanceof ImageData?a.putImageData(e,0,0):a.drawImage(e,0,0,e.width,e.height),r=Zs}return r.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=Tc("canvas");t.width=e.width,t.height=e.height;const r=t.getContext("2d");r.drawImage(e,0,0,e.width,e.height);const a=r.getImageData(0,0,e.width,e.height),l=a.data;for(let u=0;u<l.length;u++)l[u]=vr(l[u]/255)*255;return r.putImageData(a,0,0),t}else if(e.data){const t=e.data.slice(0);for(let r=0;r<t.length;r++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[r]=Math.floor(vr(t[r]/255)*255):t[r]=vr(t[r]);return{data:t,width:e.width,height:e.height}}else return gt("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let Cy=0;class cf{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Cy++}),this.uuid=Mo(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<"u"&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const r={uuid:this.uuid,url:""},a=this.data;if(a!==null){let l;if(Array.isArray(a)){l=[];for(let u=0,h=a.length;u<h;u++)a[u].isDataTexture?l.push(bd(a[u].image)):l.push(bd(a[u]))}else l=bd(a);r.url=l}return t||(e.images[this.uuid]=r),r}}function bd(s){return typeof HTMLImageElement<"u"&&s instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&s instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&s instanceof ImageBitmap?Ay.getDataURL(s):s.data?{data:Array.from(s.data),width:s.width,height:s.height,type:s.data.constructor.name}:(gt("Texture: Unable to serialize Texture."),{})}let Ry=0;const Sd=new X;class Xn extends es{constructor(e=Xn.DEFAULT_IMAGE,t=Xn.DEFAULT_MAPPING,r=xr,a=xr,l=zn,u=bs,h=Bi,p=Mi,f=Xn.DEFAULT_ANISOTROPY,g=$r){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Ry++}),this.uuid=Mo(),this.name="",this.source=new cf(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=r,this.wrapT=a,this.magFilter=l,this.minFilter=u,this.anisotropy=f,this.format=h,this.internalFormat=null,this.type=p,this.offset=new dt(0,0),this.repeat=new dt(1,1),this.center=new dt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new yt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=g,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(Sd).x}get height(){return this.source.getSize(Sd).y}get depth(){return this.source.getSize(Sd).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const r=e[t];if(r===void 0){gt(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const a=this[t];if(a===void 0){gt(`Texture.setValues(): property '${t}' does not exist.`);continue}a&&r&&a.isVector2&&r.isVector2||a&&r&&a.isVector3&&r.isVector3||a&&r&&a.isMatrix3&&r.isMatrix3?a.copy(r):this[t]=r}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const r={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(r.userData=this.userData),t||(e.textures[this.uuid]=r),r}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==wg)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case ch:e.x=e.x-Math.floor(e.x);break;case xr:e.x=e.x<0?0:1;break;case uh:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case ch:e.y=e.y-Math.floor(e.y);break;case xr:e.y=e.y<0?0:1;break;case uh:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Xn.DEFAULT_IMAGE=null;Xn.DEFAULT_MAPPING=wg;Xn.DEFAULT_ANISOTROPY=1;class un{static{un.prototype.isVector4=!0}constructor(e=0,t=0,r=0,a=1){this.x=e,this.y=t,this.z=r,this.w=a}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,r,a){return this.x=e,this.y=t,this.z=r,this.w=a,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,r=this.y,a=this.z,l=this.w,u=e.elements;return this.x=u[0]*t+u[4]*r+u[8]*a+u[12]*l,this.y=u[1]*t+u[5]*r+u[9]*a+u[13]*l,this.z=u[2]*t+u[6]*r+u[10]*a+u[14]*l,this.w=u[3]*t+u[7]*r+u[11]*a+u[15]*l,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,r,a,l;const p=e.elements,f=p[0],g=p[4],b=p[8],v=p[1],S=p[5],M=p[9],E=p[2],x=p[6],_=p[10];if(Math.abs(g-v)<.01&&Math.abs(b-E)<.01&&Math.abs(M-x)<.01){if(Math.abs(g+v)<.1&&Math.abs(b+E)<.1&&Math.abs(M+x)<.1&&Math.abs(f+S+_-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const P=(f+1)/2,C=(S+1)/2,k=(_+1)/2,D=(g+v)/4,U=(b+E)/4,T=(M+x)/4;return P>C&&P>k?P<.01?(r=0,a=.707106781,l=.707106781):(r=Math.sqrt(P),a=D/r,l=U/r):C>k?C<.01?(r=.707106781,a=0,l=.707106781):(a=Math.sqrt(C),r=D/a,l=T/a):k<.01?(r=.707106781,a=.707106781,l=0):(l=Math.sqrt(k),r=U/l,a=T/l),this.set(r,a,l,t),this}let N=Math.sqrt((x-M)*(x-M)+(b-E)*(b-E)+(v-g)*(v-g));return Math.abs(N)<.001&&(N=1),this.x=(x-M)/N,this.y=(b-E)/N,this.z=(v-g)/N,this.w=Math.acos((f+S+_-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=At(this.x,e.x,t.x),this.y=At(this.y,e.y,t.y),this.z=At(this.z,e.z,t.z),this.w=At(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=At(this.x,e,t),this.y=At(this.y,e,t),this.z=At(this.z,e,t),this.w=At(this.w,e,t),this}clampLength(e,t){const r=this.length();return this.divideScalar(r||1).multiplyScalar(At(r,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,r){return this.x=e.x+(t.x-e.x)*r,this.y=e.y+(t.y-e.y)*r,this.z=e.z+(t.z-e.z)*r,this.w=e.w+(t.w-e.w)*r,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Py extends es{constructor(e=1,t=1,r={}){super(),r=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:zn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},r),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=r.depth,this.scissor=new un(0,0,e,t),this.scissorTest=!1,this.viewport=new un(0,0,e,t),this.textures=[];const a={width:e,height:t,depth:r.depth},l=new Xn(a),u=r.count;for(let h=0;h<u;h++)this.textures[h]=l.clone(),this.textures[h].isRenderTargetTexture=!0,this.textures[h].renderTarget=this;this._setTextureOptions(r),this.depthBuffer=r.depthBuffer,this.stencilBuffer=r.stencilBuffer,this.resolveDepthBuffer=r.resolveDepthBuffer,this.resolveStencilBuffer=r.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=r.depthTexture,this.samples=r.samples,this.multiview=r.multiview,this.useArrayDepthTexture=r.useArrayDepthTexture}_setTextureOptions(e={}){const t={minFilter:zn,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let r=0;r<this.textures.length;r++)this.textures[r].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,r=1){if(this.width!==e||this.height!==t||this.depth!==r){this.width=e,this.height=t,this.depth=r;for(let a=0,l=this.textures.length;a<l;a++)this.textures[a].image.width=e,this.textures[a].image.height=t,this.textures[a].image.depth=r,this.textures[a].isData3DTexture!==!0&&(this.textures[a].isArrayTexture=this.textures[a].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,r=e.textures.length;t<r;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const a=Object.assign({},e.textures[t].image);this.textures[t].source=new cf(a)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class ai extends Py{constructor(e=1,t=1,r={}){super(e,t,r),this.isWebGLRenderTarget=!0}}class Dg extends Xn{constructor(e=null,t=1,r=1,a=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:r,depth:a},this.magFilter=Dn,this.minFilter=Dn,this.wrapR=xr,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class Ny extends Xn{constructor(e=null,t=1,r=1,a=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:r,depth:a},this.magFilter=Dn,this.minFilter=Dn,this.wrapR=xr,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class en{static{en.prototype.isMatrix4=!0}constructor(e,t,r,a,l,u,h,p,f,g,b,v,S,M,E,x){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,r,a,l,u,h,p,f,g,b,v,S,M,E,x)}set(e,t,r,a,l,u,h,p,f,g,b,v,S,M,E,x){const _=this.elements;return _[0]=e,_[4]=t,_[8]=r,_[12]=a,_[1]=l,_[5]=u,_[9]=h,_[13]=p,_[2]=f,_[6]=g,_[10]=b,_[14]=v,_[3]=S,_[7]=M,_[11]=E,_[15]=x,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new en().fromArray(this.elements)}copy(e){const t=this.elements,r=e.elements;return t[0]=r[0],t[1]=r[1],t[2]=r[2],t[3]=r[3],t[4]=r[4],t[5]=r[5],t[6]=r[6],t[7]=r[7],t[8]=r[8],t[9]=r[9],t[10]=r[10],t[11]=r[11],t[12]=r[12],t[13]=r[13],t[14]=r[14],t[15]=r[15],this}copyPosition(e){const t=this.elements,r=e.elements;return t[12]=r[12],t[13]=r[13],t[14]=r[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,r){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),r.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),r.setFromMatrixColumn(this,2),this)}makeBasis(e,t,r){return this.set(e.x,t.x,r.x,0,e.y,t.y,r.y,0,e.z,t.z,r.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();const t=this.elements,r=e.elements,a=1/Qs.setFromMatrixColumn(e,0).length(),l=1/Qs.setFromMatrixColumn(e,1).length(),u=1/Qs.setFromMatrixColumn(e,2).length();return t[0]=r[0]*a,t[1]=r[1]*a,t[2]=r[2]*a,t[3]=0,t[4]=r[4]*l,t[5]=r[5]*l,t[6]=r[6]*l,t[7]=0,t[8]=r[8]*u,t[9]=r[9]*u,t[10]=r[10]*u,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,r=e.x,a=e.y,l=e.z,u=Math.cos(r),h=Math.sin(r),p=Math.cos(a),f=Math.sin(a),g=Math.cos(l),b=Math.sin(l);if(e.order==="XYZ"){const v=u*g,S=u*b,M=h*g,E=h*b;t[0]=p*g,t[4]=-p*b,t[8]=f,t[1]=S+M*f,t[5]=v-E*f,t[9]=-h*p,t[2]=E-v*f,t[6]=M+S*f,t[10]=u*p}else if(e.order==="YXZ"){const v=p*g,S=p*b,M=f*g,E=f*b;t[0]=v+E*h,t[4]=M*h-S,t[8]=u*f,t[1]=u*b,t[5]=u*g,t[9]=-h,t[2]=S*h-M,t[6]=E+v*h,t[10]=u*p}else if(e.order==="ZXY"){const v=p*g,S=p*b,M=f*g,E=f*b;t[0]=v-E*h,t[4]=-u*b,t[8]=M+S*h,t[1]=S+M*h,t[5]=u*g,t[9]=E-v*h,t[2]=-u*f,t[6]=h,t[10]=u*p}else if(e.order==="ZYX"){const v=u*g,S=u*b,M=h*g,E=h*b;t[0]=p*g,t[4]=M*f-S,t[8]=v*f+E,t[1]=p*b,t[5]=E*f+v,t[9]=S*f-M,t[2]=-f,t[6]=h*p,t[10]=u*p}else if(e.order==="YZX"){const v=u*p,S=u*f,M=h*p,E=h*f;t[0]=p*g,t[4]=E-v*b,t[8]=M*b+S,t[1]=b,t[5]=u*g,t[9]=-h*g,t[2]=-f*g,t[6]=S*b+M,t[10]=v-E*b}else if(e.order==="XZY"){const v=u*p,S=u*f,M=h*p,E=h*f;t[0]=p*g,t[4]=-b,t[8]=f*g,t[1]=v*b+E,t[5]=u*g,t[9]=S*b-M,t[2]=M*b-S,t[6]=h*g,t[10]=E*b+v}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Ly,e,Dy)}lookAt(e,t,r){const a=this.elements;return di.subVectors(e,t),di.lengthSq()===0&&(di.z=1),di.normalize(),jr.crossVectors(r,di),jr.lengthSq()===0&&(Math.abs(r.z)===1?di.x+=1e-4:di.z+=1e-4,di.normalize(),jr.crossVectors(r,di)),jr.normalize(),Nl.crossVectors(di,jr),a[0]=jr.x,a[4]=Nl.x,a[8]=di.x,a[1]=jr.y,a[5]=Nl.y,a[9]=di.y,a[2]=jr.z,a[6]=Nl.z,a[10]=di.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const r=e.elements,a=t.elements,l=this.elements,u=r[0],h=r[4],p=r[8],f=r[12],g=r[1],b=r[5],v=r[9],S=r[13],M=r[2],E=r[6],x=r[10],_=r[14],N=r[3],P=r[7],C=r[11],k=r[15],D=a[0],U=a[4],T=a[8],I=a[12],z=a[1],O=a[5],H=a[9],fe=a[13],re=a[2],q=a[6],de=a[10],oe=a[14],Z=a[3],ee=a[7],ce=a[11],F=a[15];return l[0]=u*D+h*z+p*re+f*Z,l[4]=u*U+h*O+p*q+f*ee,l[8]=u*T+h*H+p*de+f*ce,l[12]=u*I+h*fe+p*oe+f*F,l[1]=g*D+b*z+v*re+S*Z,l[5]=g*U+b*O+v*q+S*ee,l[9]=g*T+b*H+v*de+S*ce,l[13]=g*I+b*fe+v*oe+S*F,l[2]=M*D+E*z+x*re+_*Z,l[6]=M*U+E*O+x*q+_*ee,l[10]=M*T+E*H+x*de+_*ce,l[14]=M*I+E*fe+x*oe+_*F,l[3]=N*D+P*z+C*re+k*Z,l[7]=N*U+P*O+C*q+k*ee,l[11]=N*T+P*H+C*de+k*ce,l[15]=N*I+P*fe+C*oe+k*F,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],r=e[4],a=e[8],l=e[12],u=e[1],h=e[5],p=e[9],f=e[13],g=e[2],b=e[6],v=e[10],S=e[14],M=e[3],E=e[7],x=e[11],_=e[15],N=p*S-f*v,P=h*S-f*b,C=h*v-p*b,k=u*S-f*g,D=u*v-p*g,U=u*b-h*g;return t*(E*N-x*P+_*C)-r*(M*N-x*k+_*D)+a*(M*P-E*k+_*U)-l*(M*C-E*D+x*U)}determinantAffine(){const e=this.elements,t=e[0],r=e[4],a=e[8],l=e[1],u=e[5],h=e[9],p=e[2],f=e[6],g=e[10];return t*(u*g-h*f)-r*(l*g-h*p)+a*(l*f-u*p)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,r){const a=this.elements;return e.isVector3?(a[12]=e.x,a[13]=e.y,a[14]=e.z):(a[12]=e,a[13]=t,a[14]=r),this}invert(){const e=this.elements,t=e[0],r=e[1],a=e[2],l=e[3],u=e[4],h=e[5],p=e[6],f=e[7],g=e[8],b=e[9],v=e[10],S=e[11],M=e[12],E=e[13],x=e[14],_=e[15],N=t*h-r*u,P=t*p-a*u,C=t*f-l*u,k=r*p-a*h,D=r*f-l*h,U=a*f-l*p,T=g*E-b*M,I=g*x-v*M,z=g*_-S*M,O=b*x-v*E,H=b*_-S*E,fe=v*_-S*x,re=N*fe-P*H+C*O+k*z-D*I+U*T;if(re===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const q=1/re;return e[0]=(h*fe-p*H+f*O)*q,e[1]=(a*H-r*fe-l*O)*q,e[2]=(E*U-x*D+_*k)*q,e[3]=(v*D-b*U-S*k)*q,e[4]=(p*z-u*fe-f*I)*q,e[5]=(t*fe-a*z+l*I)*q,e[6]=(x*C-M*U-_*P)*q,e[7]=(g*U-v*C+S*P)*q,e[8]=(u*H-h*z+f*T)*q,e[9]=(r*z-t*H-l*T)*q,e[10]=(M*D-E*C+_*N)*q,e[11]=(b*C-g*D-S*N)*q,e[12]=(h*I-u*O-p*T)*q,e[13]=(t*O-r*I+a*T)*q,e[14]=(E*P-M*k-x*N)*q,e[15]=(g*k-b*P+v*N)*q,this}scale(e){const t=this.elements,r=e.x,a=e.y,l=e.z;return t[0]*=r,t[4]*=a,t[8]*=l,t[1]*=r,t[5]*=a,t[9]*=l,t[2]*=r,t[6]*=a,t[10]*=l,t[3]*=r,t[7]*=a,t[11]*=l,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],r=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],a=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,r,a))}makeTranslation(e,t,r){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,r,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),r=Math.sin(e);return this.set(1,0,0,0,0,t,-r,0,0,r,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),r=Math.sin(e);return this.set(t,0,r,0,0,1,0,0,-r,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),r=Math.sin(e);return this.set(t,-r,0,0,r,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const r=Math.cos(t),a=Math.sin(t),l=1-r,u=e.x,h=e.y,p=e.z,f=l*u,g=l*h;return this.set(f*u+r,f*h-a*p,f*p+a*h,0,f*h+a*p,g*h+r,g*p-a*u,0,f*p-a*h,g*p+a*u,l*p*p+r,0,0,0,0,1),this}makeScale(e,t,r){return this.set(e,0,0,0,0,t,0,0,0,0,r,0,0,0,0,1),this}makeShear(e,t,r,a,l,u){return this.set(1,r,l,0,e,1,u,0,t,a,1,0,0,0,0,1),this}compose(e,t,r){const a=this.elements,l=t._x,u=t._y,h=t._z,p=t._w,f=l+l,g=u+u,b=h+h,v=l*f,S=l*g,M=l*b,E=u*g,x=u*b,_=h*b,N=p*f,P=p*g,C=p*b,k=r.x,D=r.y,U=r.z;return a[0]=(1-(E+_))*k,a[1]=(S+C)*k,a[2]=(M-P)*k,a[3]=0,a[4]=(S-C)*D,a[5]=(1-(v+_))*D,a[6]=(x+N)*D,a[7]=0,a[8]=(M+P)*U,a[9]=(x-N)*U,a[10]=(1-(v+E))*U,a[11]=0,a[12]=e.x,a[13]=e.y,a[14]=e.z,a[15]=1,this}decompose(e,t,r){const a=this.elements;e.x=a[12],e.y=a[13],e.z=a[14];const l=this.determinantAffine();if(l===0)return r.set(1,1,1),t.identity(),this;let u=Qs.set(a[0],a[1],a[2]).length();const h=Qs.set(a[4],a[5],a[6]).length(),p=Qs.set(a[8],a[9],a[10]).length();l<0&&(u=-u),Di.copy(this);const f=1/u,g=1/h,b=1/p;return Di.elements[0]*=f,Di.elements[1]*=f,Di.elements[2]*=f,Di.elements[4]*=g,Di.elements[5]*=g,Di.elements[6]*=g,Di.elements[8]*=b,Di.elements[9]*=b,Di.elements[10]*=b,t.setFromRotationMatrix(Di),r.x=u,r.y=h,r.z=p,this}makePerspective(e,t,r,a,l,u,h=Zi,p=!1){const f=this.elements,g=2*l/(t-e),b=2*l/(r-a),v=(t+e)/(t-e),S=(r+a)/(r-a);let M,E;if(p)M=l/(u-l),E=u*l/(u-l);else if(h===Zi)M=-(u+l)/(u-l),E=-2*u*l/(u-l);else if(h===Ec)M=-u/(u-l),E=-u*l/(u-l);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+h);return f[0]=g,f[4]=0,f[8]=v,f[12]=0,f[1]=0,f[5]=b,f[9]=S,f[13]=0,f[2]=0,f[6]=0,f[10]=M,f[14]=E,f[3]=0,f[7]=0,f[11]=-1,f[15]=0,this}makeOrthographic(e,t,r,a,l,u,h=Zi,p=!1){const f=this.elements,g=2/(t-e),b=2/(r-a),v=-(t+e)/(t-e),S=-(r+a)/(r-a);let M,E;if(p)M=1/(u-l),E=u/(u-l);else if(h===Zi)M=-2/(u-l),E=-(u+l)/(u-l);else if(h===Ec)M=-1/(u-l),E=-l/(u-l);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+h);return f[0]=g,f[4]=0,f[8]=0,f[12]=v,f[1]=0,f[5]=b,f[9]=0,f[13]=S,f[2]=0,f[6]=0,f[10]=M,f[14]=E,f[3]=0,f[7]=0,f[11]=0,f[15]=1,this}equals(e){const t=this.elements,r=e.elements;for(let a=0;a<16;a++)if(t[a]!==r[a])return!1;return!0}fromArray(e,t=0){for(let r=0;r<16;r++)this.elements[r]=e[r+t];return this}toArray(e=[],t=0){const r=this.elements;return e[t]=r[0],e[t+1]=r[1],e[t+2]=r[2],e[t+3]=r[3],e[t+4]=r[4],e[t+5]=r[5],e[t+6]=r[6],e[t+7]=r[7],e[t+8]=r[8],e[t+9]=r[9],e[t+10]=r[10],e[t+11]=r[11],e[t+12]=r[12],e[t+13]=r[13],e[t+14]=r[14],e[t+15]=r[15],e}}const Qs=new X,Di=new en,Ly=new X(0,0,0),Dy=new X(1,1,1),jr=new X,Nl=new X,di=new X,o0=new en,l0=new Jr;class Es{constructor(e=0,t=0,r=0,a=Es.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=r,this._order=a}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,r,a=this._order){return this._x=e,this._y=t,this._z=r,this._order=a,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,r=!0){const a=e.elements,l=a[0],u=a[4],h=a[8],p=a[1],f=a[5],g=a[9],b=a[2],v=a[6],S=a[10];switch(t){case"XYZ":this._y=Math.asin(At(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(-g,S),this._z=Math.atan2(-u,l)):(this._x=Math.atan2(v,f),this._z=0);break;case"YXZ":this._x=Math.asin(-At(g,-1,1)),Math.abs(g)<.9999999?(this._y=Math.atan2(h,S),this._z=Math.atan2(p,f)):(this._y=Math.atan2(-b,l),this._z=0);break;case"ZXY":this._x=Math.asin(At(v,-1,1)),Math.abs(v)<.9999999?(this._y=Math.atan2(-b,S),this._z=Math.atan2(-u,f)):(this._y=0,this._z=Math.atan2(p,l));break;case"ZYX":this._y=Math.asin(-At(b,-1,1)),Math.abs(b)<.9999999?(this._x=Math.atan2(v,S),this._z=Math.atan2(p,l)):(this._x=0,this._z=Math.atan2(-u,f));break;case"YZX":this._z=Math.asin(At(p,-1,1)),Math.abs(p)<.9999999?(this._x=Math.atan2(-g,f),this._y=Math.atan2(-b,l)):(this._x=0,this._y=Math.atan2(h,S));break;case"XZY":this._z=Math.asin(-At(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(v,f),this._y=Math.atan2(h,l)):(this._x=Math.atan2(-g,S),this._y=0);break;default:gt("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,r===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,r){return o0.makeRotationFromQuaternion(e),this.setFromRotationMatrix(o0,t,r)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return l0.setFromEuler(this),this.setFromQuaternion(l0,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Es.DEFAULT_ORDER="XYZ";class uf{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let Iy=0;const c0=new X,Js=new Jr,hr=new en,Ll=new X,lo=new X,ky=new X,Fy=new Jr,u0=new X(1,0,0),d0=new X(0,1,0),h0=new X(0,0,1),f0={type:"added"},Uy={type:"removed"},ea={type:"childadded",child:null},Md={type:"childremoved",child:null};class qn extends es{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Iy++}),this.uuid=Mo(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=qn.DEFAULT_UP.clone();const e=new X,t=new Es,r=new Jr,a=new X(1,1,1);function l(){r.setFromEuler(t,!1)}function u(){t.setFromQuaternion(r,void 0,!1)}t._onChange(l),r._onChange(u),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:r},scale:{configurable:!0,enumerable:!0,value:a},modelViewMatrix:{value:new en},normalMatrix:{value:new yt}}),this.matrix=new en,this.matrixWorld=new en,this.matrixAutoUpdate=qn.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=qn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new uf,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Js.setFromAxisAngle(e,t),this.quaternion.multiply(Js),this}rotateOnWorldAxis(e,t){return Js.setFromAxisAngle(e,t),this.quaternion.premultiply(Js),this}rotateX(e){return this.rotateOnAxis(u0,e)}rotateY(e){return this.rotateOnAxis(d0,e)}rotateZ(e){return this.rotateOnAxis(h0,e)}translateOnAxis(e,t){return c0.copy(e).applyQuaternion(this.quaternion),this.position.add(c0.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(u0,e)}translateY(e){return this.translateOnAxis(d0,e)}translateZ(e){return this.translateOnAxis(h0,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(hr.copy(this.matrixWorld).invert())}lookAt(e,t,r){e.isVector3?Ll.copy(e):Ll.set(e,t,r);const a=this.parent;this.updateWorldMatrix(!0,!1),lo.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?hr.lookAt(lo,Ll,this.up):hr.lookAt(Ll,lo,this.up),this.quaternion.setFromRotationMatrix(hr),a&&(hr.extractRotation(a.matrixWorld),Js.setFromRotationMatrix(hr),this.quaternion.premultiply(Js.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(Ut("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(f0),ea.child=e,this.dispatchEvent(ea),ea.child=null):Ut("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let r=0;r<arguments.length;r++)this.remove(arguments[r]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Uy),Md.child=e,this.dispatchEvent(Md),Md.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),hr.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),hr.multiply(e.parent.matrixWorld)),e.applyMatrix4(hr),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(f0),ea.child=e,this.dispatchEvent(ea),ea.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let r=0,a=this.children.length;r<a;r++){const u=this.children[r].getObjectByProperty(e,t);if(u!==void 0)return u}}getObjectsByProperty(e,t,r=[]){this[e]===t&&r.push(this);const a=this.children;for(let l=0,u=a.length;l<u;l++)a[l].getObjectsByProperty(e,t,r);return r}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(lo,e,ky),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(lo,Fy,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let r=0,a=t.length;r<a;r++)t[r].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let r=0,a=t.length;r<a;r++)t[r].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const t=e.x,r=e.y,a=e.z,l=this.matrix.elements;l[12]+=t-l[0]*t-l[4]*r-l[8]*a,l[13]+=r-l[1]*t-l[5]*r-l[9]*a,l[14]+=a-l[2]*t-l[6]*r-l[10]*a}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let r=0,a=t.length;r<a;r++)t[r].updateMatrixWorld(e)}updateWorldMatrix(e,t,r=!1){const a=this.parent;if(e===!0&&a!==null&&a.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||r)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,r=!0),t===!0){const l=this.children;for(let u=0,h=l.length;u<h;u++)l[u].updateWorldMatrix(!1,!0,r)}}toJSON(e){const t=e===void 0||typeof e=="string",r={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},r.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const a={};a.uuid=this.uuid,a.type=this.type,this.name!==""&&(a.name=this.name),this.castShadow===!0&&(a.castShadow=!0),this.receiveShadow===!0&&(a.receiveShadow=!0),this.visible===!1&&(a.visible=!1),this.frustumCulled===!1&&(a.frustumCulled=!1),this.renderOrder!==0&&(a.renderOrder=this.renderOrder),this.static!==!1&&(a.static=this.static),Object.keys(this.userData).length>0&&(a.userData=this.userData),a.layers=this.layers.mask,a.matrix=this.matrix.toArray(),a.up=this.up.toArray(),this.pivot!==null&&(a.pivot=this.pivot.toArray()),this.matrixAutoUpdate===!1&&(a.matrixAutoUpdate=!1),this.morphTargetDictionary!==void 0&&(a.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(a.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(a.type="InstancedMesh",a.count=this.count,a.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(a.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(a.type="BatchedMesh",a.perObjectFrustumCulled=this.perObjectFrustumCulled,a.sortObjects=this.sortObjects,a.drawRanges=this._drawRanges,a.reservedRanges=this._reservedRanges,a.geometryInfo=this._geometryInfo.map(h=>({...h,boundingBox:h.boundingBox?h.boundingBox.toJSON():void 0,boundingSphere:h.boundingSphere?h.boundingSphere.toJSON():void 0})),a.instanceInfo=this._instanceInfo.map(h=>({...h})),a.availableInstanceIds=this._availableInstanceIds.slice(),a.availableGeometryIds=this._availableGeometryIds.slice(),a.nextIndexStart=this._nextIndexStart,a.nextVertexStart=this._nextVertexStart,a.geometryCount=this._geometryCount,a.maxInstanceCount=this._maxInstanceCount,a.maxVertexCount=this._maxVertexCount,a.maxIndexCount=this._maxIndexCount,a.geometryInitialized=this._geometryInitialized,a.matricesTexture=this._matricesTexture.toJSON(e),a.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(a.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(a.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(a.boundingBox=this.boundingBox.toJSON()));function l(h,p){return h[p.uuid]===void 0&&(h[p.uuid]=p.toJSON(e)),p.uuid}if(this.isScene)this.background&&(this.background.isColor?a.background=this.background.toJSON():this.background.isTexture&&(a.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(a.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){a.geometry=l(e.geometries,this.geometry);const h=this.geometry.parameters;if(h!==void 0&&h.shapes!==void 0){const p=h.shapes;if(Array.isArray(p))for(let f=0,g=p.length;f<g;f++){const b=p[f];l(e.shapes,b)}else l(e.shapes,p)}}if(this.isSkinnedMesh&&(a.bindMode=this.bindMode,a.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(l(e.skeletons,this.skeleton),a.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const h=[];for(let p=0,f=this.material.length;p<f;p++)h.push(l(e.materials,this.material[p]));a.material=h}else a.material=l(e.materials,this.material);if(this.children.length>0){a.children=[];for(let h=0;h<this.children.length;h++)a.children.push(this.children[h].toJSON(e).object)}if(this.animations.length>0){a.animations=[];for(let h=0;h<this.animations.length;h++){const p=this.animations[h];a.animations.push(l(e.animations,p))}}if(t){const h=u(e.geometries),p=u(e.materials),f=u(e.textures),g=u(e.images),b=u(e.shapes),v=u(e.skeletons),S=u(e.animations),M=u(e.nodes);h.length>0&&(r.geometries=h),p.length>0&&(r.materials=p),f.length>0&&(r.textures=f),g.length>0&&(r.images=g),b.length>0&&(r.shapes=b),v.length>0&&(r.skeletons=v),S.length>0&&(r.animations=S),M.length>0&&(r.nodes=M)}return r.object=a,r;function u(h){const p=[];for(const f in h){const g=h[f];delete g.metadata,p.push(g)}return p}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let r=0;r<e.children.length;r++){const a=e.children[r];this.add(a.clone())}return this}}qn.DEFAULT_UP=new X(0,1,0);qn.DEFAULT_MATRIX_AUTO_UPDATE=!0;qn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class Dl extends qn{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Oy={type:"move"};class wd{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Dl,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Dl,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new X,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new X),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Dl,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new X,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new X,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const r of e.hand.values())this._getHandJoint(t,r)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,r){let a=null,l=null,u=null;const h=this._targetRay,p=this._grip,f=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(f&&e.hand){u=!0;for(const E of e.hand.values()){const x=t.getJointPose(E,r),_=this._getHandJoint(f,E);x!==null&&(_.matrix.fromArray(x.transform.matrix),_.matrix.decompose(_.position,_.rotation,_.scale),_.matrixWorldNeedsUpdate=!0,_.jointRadius=x.radius),_.visible=x!==null}const g=f.joints["index-finger-tip"],b=f.joints["thumb-tip"],v=g.position.distanceTo(b.position),S=.02,M=.005;f.inputState.pinching&&v>S+M?(f.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!f.inputState.pinching&&v<=S-M&&(f.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else p!==null&&e.gripSpace&&(l=t.getPose(e.gripSpace,r),l!==null&&(p.matrix.fromArray(l.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,l.linearVelocity?(p.hasLinearVelocity=!0,p.linearVelocity.copy(l.linearVelocity)):p.hasLinearVelocity=!1,l.angularVelocity?(p.hasAngularVelocity=!0,p.angularVelocity.copy(l.angularVelocity)):p.hasAngularVelocity=!1,p.eventsEnabled&&p.dispatchEvent({type:"gripUpdated",data:e,target:this})));h!==null&&(a=t.getPose(e.targetRaySpace,r),a===null&&l!==null&&(a=l),a!==null&&(h.matrix.fromArray(a.transform.matrix),h.matrix.decompose(h.position,h.rotation,h.scale),h.matrixWorldNeedsUpdate=!0,a.linearVelocity?(h.hasLinearVelocity=!0,h.linearVelocity.copy(a.linearVelocity)):h.hasLinearVelocity=!1,a.angularVelocity?(h.hasAngularVelocity=!0,h.angularVelocity.copy(a.angularVelocity)):h.hasAngularVelocity=!1,this.dispatchEvent(Oy)))}return h!==null&&(h.visible=a!==null),p!==null&&(p.visible=l!==null),f!==null&&(f.visible=u!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const r=new Dl;r.matrixAutoUpdate=!1,r.visible=!1,e.joints[t.jointName]=r,e.add(r)}return e.joints[t.jointName]}}const Ig={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Hr={h:0,s:0,l:0},Il={h:0,s:0,l:0};function Ed(s,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?s+(e-s)*6*t:t<1/2?e:t<2/3?s+(e-s)*6*(2/3-t):s}class _t{constructor(e,t,r){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,r)}set(e,t,r){if(t===void 0&&r===void 0){const a=e;a&&a.isColor?this.copy(a):typeof a=="number"?this.setHex(a):typeof a=="string"&&this.setStyle(a)}else this.setRGB(e,t,r);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=bi){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,kt.colorSpaceToWorking(this,t),this}setRGB(e,t,r,a=kt.workingColorSpace){return this.r=e,this.g=t,this.b=r,kt.colorSpaceToWorking(this,a),this}setHSL(e,t,r,a=kt.workingColorSpace){if(e=wy(e,1),t=At(t,0,1),r=At(r,0,1),t===0)this.r=this.g=this.b=r;else{const l=r<=.5?r*(1+t):r+t-r*t,u=2*r-l;this.r=Ed(u,l,e+1/3),this.g=Ed(u,l,e),this.b=Ed(u,l,e-1/3)}return kt.colorSpaceToWorking(this,a),this}setStyle(e,t=bi){function r(l){l!==void 0&&parseFloat(l)<1&&gt("Color: Alpha component of "+e+" will be ignored.")}let a;if(a=/^(\w+)\(([^\)]*)\)/.exec(e)){let l;const u=a[1],h=a[2];switch(u){case"rgb":case"rgba":if(l=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(h))return r(l[4]),this.setRGB(Math.min(255,parseInt(l[1],10))/255,Math.min(255,parseInt(l[2],10))/255,Math.min(255,parseInt(l[3],10))/255,t);if(l=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(h))return r(l[4]),this.setRGB(Math.min(100,parseInt(l[1],10))/100,Math.min(100,parseInt(l[2],10))/100,Math.min(100,parseInt(l[3],10))/100,t);break;case"hsl":case"hsla":if(l=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(h))return r(l[4]),this.setHSL(parseFloat(l[1])/360,parseFloat(l[2])/100,parseFloat(l[3])/100,t);break;default:gt("Color: Unknown color model "+e)}}else if(a=/^\#([A-Fa-f\d]+)$/.exec(e)){const l=a[1],u=l.length;if(u===3)return this.setRGB(parseInt(l.charAt(0),16)/15,parseInt(l.charAt(1),16)/15,parseInt(l.charAt(2),16)/15,t);if(u===6)return this.setHex(parseInt(l,16),t);gt("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=bi){const r=Ig[e.toLowerCase()];return r!==void 0?this.setHex(r,t):gt("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=vr(e.r),this.g=vr(e.g),this.b=vr(e.b),this}copyLinearToSRGB(e){return this.r=_a(e.r),this.g=_a(e.g),this.b=_a(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=bi){return kt.workingToColorSpace(Bn.copy(this),e),Math.round(At(Bn.r*255,0,255))*65536+Math.round(At(Bn.g*255,0,255))*256+Math.round(At(Bn.b*255,0,255))}getHexString(e=bi){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=kt.workingColorSpace){kt.workingToColorSpace(Bn.copy(this),t);const r=Bn.r,a=Bn.g,l=Bn.b,u=Math.max(r,a,l),h=Math.min(r,a,l);let p,f;const g=(h+u)/2;if(h===u)p=0,f=0;else{const b=u-h;switch(f=g<=.5?b/(u+h):b/(2-u-h),u){case r:p=(a-l)/b+(a<l?6:0);break;case a:p=(l-r)/b+2;break;case l:p=(r-a)/b+4;break}p/=6}return e.h=p,e.s=f,e.l=g,e}getRGB(e,t=kt.workingColorSpace){return kt.workingToColorSpace(Bn.copy(this),t),e.r=Bn.r,e.g=Bn.g,e.b=Bn.b,e}getStyle(e=bi){kt.workingToColorSpace(Bn.copy(this),e);const t=Bn.r,r=Bn.g,a=Bn.b;return e!==bi?`color(${e} ${t.toFixed(3)} ${r.toFixed(3)} ${a.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(r*255)},${Math.round(a*255)})`}offsetHSL(e,t,r){return this.getHSL(Hr),this.setHSL(Hr.h+e,Hr.s+t,Hr.l+r)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,r){return this.r=e.r+(t.r-e.r)*r,this.g=e.g+(t.g-e.g)*r,this.b=e.b+(t.b-e.b)*r,this}lerpHSL(e,t){this.getHSL(Hr),e.getHSL(Il);const r=vd(Hr.h,Il.h,t),a=vd(Hr.s,Il.s,t),l=vd(Hr.l,Il.l,t);return this.setHSL(r,a,l),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,r=this.g,a=this.b,l=e.elements;return this.r=l[0]*t+l[3]*r+l[6]*a,this.g=l[1]*t+l[4]*r+l[7]*a,this.b=l[2]*t+l[5]*r+l[8]*a,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Bn=new _t;_t.NAMES=Ig;class df{constructor(e,t=25e-5){this.isFogExp2=!0,this.name="",this.color=new _t(e),this.density=t}clone(){return new df(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class By extends qn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Es,this.environmentIntensity=1,this.environmentRotation=new Es,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}const Ii=new X,fr=new X,Td=new X,pr=new X,ta=new X,na=new X,p0=new X,Ad=new X,Cd=new X,Rd=new X,Pd=new un,Nd=new un,Ld=new un;class Ui{constructor(e=new X,t=new X,r=new X){this.a=e,this.b=t,this.c=r}static getNormal(e,t,r,a){a.subVectors(r,t),Ii.subVectors(e,t),a.cross(Ii);const l=a.lengthSq();return l>0?a.multiplyScalar(1/Math.sqrt(l)):a.set(0,0,0)}static getBarycoord(e,t,r,a,l){Ii.subVectors(a,t),fr.subVectors(r,t),Td.subVectors(e,t);const u=Ii.dot(Ii),h=Ii.dot(fr),p=Ii.dot(Td),f=fr.dot(fr),g=fr.dot(Td),b=u*f-h*h;if(b===0)return l.set(0,0,0),null;const v=1/b,S=(f*p-h*g)*v,M=(u*g-h*p)*v;return l.set(1-S-M,M,S)}static containsPoint(e,t,r,a){return this.getBarycoord(e,t,r,a,pr)===null?!1:pr.x>=0&&pr.y>=0&&pr.x+pr.y<=1}static getInterpolation(e,t,r,a,l,u,h,p){return this.getBarycoord(e,t,r,a,pr)===null?(p.x=0,p.y=0,"z"in p&&(p.z=0),"w"in p&&(p.w=0),null):(p.setScalar(0),p.addScaledVector(l,pr.x),p.addScaledVector(u,pr.y),p.addScaledVector(h,pr.z),p)}static getInterpolatedAttribute(e,t,r,a,l,u){return Pd.setScalar(0),Nd.setScalar(0),Ld.setScalar(0),Pd.fromBufferAttribute(e,t),Nd.fromBufferAttribute(e,r),Ld.fromBufferAttribute(e,a),u.setScalar(0),u.addScaledVector(Pd,l.x),u.addScaledVector(Nd,l.y),u.addScaledVector(Ld,l.z),u}static isFrontFacing(e,t,r,a){return Ii.subVectors(r,t),fr.subVectors(e,t),Ii.cross(fr).dot(a)<0}set(e,t,r){return this.a.copy(e),this.b.copy(t),this.c.copy(r),this}setFromPointsAndIndices(e,t,r,a){return this.a.copy(e[t]),this.b.copy(e[r]),this.c.copy(e[a]),this}setFromAttributeAndIndices(e,t,r,a){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,r),this.c.fromBufferAttribute(e,a),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Ii.subVectors(this.c,this.b),fr.subVectors(this.a,this.b),Ii.cross(fr).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return Ui.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return Ui.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,r,a,l){return Ui.getInterpolation(e,this.a,this.b,this.c,t,r,a,l)}containsPoint(e){return Ui.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return Ui.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const r=this.a,a=this.b,l=this.c;let u,h;ta.subVectors(a,r),na.subVectors(l,r),Ad.subVectors(e,r);const p=ta.dot(Ad),f=na.dot(Ad);if(p<=0&&f<=0)return t.copy(r);Cd.subVectors(e,a);const g=ta.dot(Cd),b=na.dot(Cd);if(g>=0&&b<=g)return t.copy(a);const v=p*b-g*f;if(v<=0&&p>=0&&g<=0)return u=p/(p-g),t.copy(r).addScaledVector(ta,u);Rd.subVectors(e,l);const S=ta.dot(Rd),M=na.dot(Rd);if(M>=0&&S<=M)return t.copy(l);const E=S*f-p*M;if(E<=0&&f>=0&&M<=0)return h=f/(f-M),t.copy(r).addScaledVector(na,h);const x=g*M-S*b;if(x<=0&&b-g>=0&&S-M>=0)return p0.subVectors(l,a),h=(b-g)/(b-g+(S-M)),t.copy(a).addScaledVector(p0,h);const _=1/(x+E+v);return u=E*_,h=v*_,t.copy(r).addScaledVector(ta,u).addScaledVector(na,h)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class wo{constructor(e=new X(1/0,1/0,1/0),t=new X(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,r=e.length;t<r;t+=3)this.expandByPoint(ki.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,r=e.count;t<r;t++)this.expandByPoint(ki.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,r=e.length;t<r;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const r=ki.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(r),this.max.copy(e).add(r),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const r=e.geometry;if(r!==void 0){const l=r.getAttribute("position");if(t===!0&&l!==void 0&&e.isInstancedMesh!==!0)for(let u=0,h=l.count;u<h;u++)e.isMesh===!0?e.getVertexPosition(u,ki):ki.fromBufferAttribute(l,u),ki.applyMatrix4(e.matrixWorld),this.expandByPoint(ki);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),kl.copy(e.boundingBox)):(r.boundingBox===null&&r.computeBoundingBox(),kl.copy(r.boundingBox)),kl.applyMatrix4(e.matrixWorld),this.union(kl)}const a=e.children;for(let l=0,u=a.length;l<u;l++)this.expandByObject(a[l],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,ki),ki.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,r;return e.normal.x>0?(t=e.normal.x*this.min.x,r=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,r=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,r+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,r+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,r+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,r+=e.normal.z*this.min.z),t<=-e.constant&&r>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(co),Fl.subVectors(this.max,co),ia.subVectors(e.a,co),ra.subVectors(e.b,co),sa.subVectors(e.c,co),Vr.subVectors(ra,ia),Gr.subVectors(sa,ra),ms.subVectors(ia,sa);let t=[0,-Vr.z,Vr.y,0,-Gr.z,Gr.y,0,-ms.z,ms.y,Vr.z,0,-Vr.x,Gr.z,0,-Gr.x,ms.z,0,-ms.x,-Vr.y,Vr.x,0,-Gr.y,Gr.x,0,-ms.y,ms.x,0];return!Dd(t,ia,ra,sa,Fl)||(t=[1,0,0,0,1,0,0,0,1],!Dd(t,ia,ra,sa,Fl))?!1:(Ul.crossVectors(Vr,Gr),t=[Ul.x,Ul.y,Ul.z],Dd(t,ia,ra,sa,Fl))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,ki).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(ki).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(mr[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),mr[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),mr[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),mr[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),mr[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),mr[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),mr[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),mr[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(mr),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const mr=[new X,new X,new X,new X,new X,new X,new X,new X],ki=new X,kl=new wo,ia=new X,ra=new X,sa=new X,Vr=new X,Gr=new X,ms=new X,co=new X,Fl=new X,Ul=new X,gs=new X;function Dd(s,e,t,r,a){for(let l=0,u=s.length-3;l<=u;l+=3){gs.fromArray(s,l);const h=a.x*Math.abs(gs.x)+a.y*Math.abs(gs.y)+a.z*Math.abs(gs.z),p=e.dot(gs),f=t.dot(gs),g=r.dot(gs);if(Math.max(-Math.max(p,f,g),Math.min(p,f,g))>h)return!1}return!0}const mn=new X,Ol=new dt;let zy=0;class An extends es{constructor(e,t,r=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:zy++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=r,this.usage=e0,this.updateRanges=[],this.gpuType=Oi,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,r){e*=this.itemSize,r*=t.itemSize;for(let a=0,l=this.itemSize;a<l;a++)this.array[e+a]=t.array[r+a];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,r=this.count;t<r;t++)Ol.fromBufferAttribute(this,t),Ol.applyMatrix3(e),this.setXY(t,Ol.x,Ol.y);else if(this.itemSize===3)for(let t=0,r=this.count;t<r;t++)mn.fromBufferAttribute(this,t),mn.applyMatrix3(e),this.setXYZ(t,mn.x,mn.y,mn.z);return this}applyMatrix4(e){for(let t=0,r=this.count;t<r;t++)mn.fromBufferAttribute(this,t),mn.applyMatrix4(e),this.setXYZ(t,mn.x,mn.y,mn.z);return this}applyNormalMatrix(e){for(let t=0,r=this.count;t<r;t++)mn.fromBufferAttribute(this,t),mn.applyNormalMatrix(e),this.setXYZ(t,mn.x,mn.y,mn.z);return this}transformDirection(e){for(let t=0,r=this.count;t<r;t++)mn.fromBufferAttribute(this,t),mn.transformDirection(e),this.setXYZ(t,mn.x,mn.y,mn.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let r=this.array[e*this.itemSize+t];return this.normalized&&(r=oo(r,this.array)),r}setComponent(e,t,r){return this.normalized&&(r=ii(r,this.array)),this.array[e*this.itemSize+t]=r,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=oo(t,this.array)),t}setX(e,t){return this.normalized&&(t=ii(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=oo(t,this.array)),t}setY(e,t){return this.normalized&&(t=ii(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=oo(t,this.array)),t}setZ(e,t){return this.normalized&&(t=ii(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=oo(t,this.array)),t}setW(e,t){return this.normalized&&(t=ii(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,r){return e*=this.itemSize,this.normalized&&(t=ii(t,this.array),r=ii(r,this.array)),this.array[e+0]=t,this.array[e+1]=r,this}setXYZ(e,t,r,a){return e*=this.itemSize,this.normalized&&(t=ii(t,this.array),r=ii(r,this.array),a=ii(a,this.array)),this.array[e+0]=t,this.array[e+1]=r,this.array[e+2]=a,this}setXYZW(e,t,r,a,l){return e*=this.itemSize,this.normalized&&(t=ii(t,this.array),r=ii(r,this.array),a=ii(a,this.array),l=ii(l,this.array)),this.array[e+0]=t,this.array[e+1]=r,this.array[e+2]=a,this.array[e+3]=l,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==e0&&(e.usage=this.usage),e}dispose(){this.dispatchEvent({type:"dispose"})}}class kg extends An{constructor(e,t,r){super(new Uint16Array(e),t,r)}}class Fg extends An{constructor(e,t,r){super(new Uint32Array(e),t,r)}}class $n extends An{constructor(e,t,r){super(new Float32Array(e),t,r)}}const jy=new wo,uo=new X,Id=new X;class Eo{constructor(e=new X,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const r=this.center;t!==void 0?r.copy(t):jy.setFromPoints(e).getCenter(r);let a=0;for(let l=0,u=e.length;l<u;l++)a=Math.max(a,r.distanceToSquared(e[l]));return this.radius=Math.sqrt(a),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const r=this.center.distanceToSquared(e);return t.copy(e),r>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;uo.subVectors(e,this.center);const t=uo.lengthSq();if(t>this.radius*this.radius){const r=Math.sqrt(t),a=(r-this.radius)*.5;this.center.addScaledVector(uo,a/r),this.radius+=a}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Id.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(uo.copy(e.center).add(Id)),this.expandByPoint(uo.copy(e.center).sub(Id))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let Hy=0;const yi=new en,kd=new qn,aa=new X,hi=new wo,ho=new wo,Tn=new X;class jn extends es{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Hy++}),this.uuid=Mo(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(yy(e)?Fg:kg)(e,1):this.index=e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,r=0){this.groups.push({start:e,count:t,materialIndex:r})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const r=this.attributes.normal;if(r!==void 0){const l=new yt().getNormalMatrix(e);r.applyNormalMatrix(l),r.needsUpdate=!0}const a=this.attributes.tangent;return a!==void 0&&(a.transformDirection(e),a.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return yi.makeRotationFromQuaternion(e),this.applyMatrix4(yi),this}rotateX(e){return yi.makeRotationX(e),this.applyMatrix4(yi),this}rotateY(e){return yi.makeRotationY(e),this.applyMatrix4(yi),this}rotateZ(e){return yi.makeRotationZ(e),this.applyMatrix4(yi),this}translate(e,t,r){return yi.makeTranslation(e,t,r),this.applyMatrix4(yi),this}scale(e,t,r){return yi.makeScale(e,t,r),this.applyMatrix4(yi),this}lookAt(e){return kd.lookAt(e),kd.updateMatrix(),this.applyMatrix4(kd.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(aa).negate(),this.translate(aa.x,aa.y,aa.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const r=[];for(let a=0,l=e.length;a<l;a++){const u=e[a];r.push(u.x,u.y,u.z||0)}this.setAttribute("position",new $n(r,3))}else{const r=Math.min(e.length,t.count);for(let a=0;a<r;a++){const l=e[a];t.setXYZ(a,l.x,l.y,l.z||0)}e.length>t.count&&gt("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new wo);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Ut("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new X(-1/0,-1/0,-1/0),new X(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let r=0,a=t.length;r<a;r++){const l=t[r];hi.setFromBufferAttribute(l),this.morphTargetsRelative?(Tn.addVectors(this.boundingBox.min,hi.min),this.boundingBox.expandByPoint(Tn),Tn.addVectors(this.boundingBox.max,hi.max),this.boundingBox.expandByPoint(Tn)):(this.boundingBox.expandByPoint(hi.min),this.boundingBox.expandByPoint(hi.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&Ut('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Eo);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Ut("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new X,1/0);return}if(e){const r=this.boundingSphere.center;if(hi.setFromBufferAttribute(e),t)for(let l=0,u=t.length;l<u;l++){const h=t[l];ho.setFromBufferAttribute(h),this.morphTargetsRelative?(Tn.addVectors(hi.min,ho.min),hi.expandByPoint(Tn),Tn.addVectors(hi.max,ho.max),hi.expandByPoint(Tn)):(hi.expandByPoint(ho.min),hi.expandByPoint(ho.max))}hi.getCenter(r);let a=0;for(let l=0,u=e.count;l<u;l++)Tn.fromBufferAttribute(e,l),a=Math.max(a,r.distanceToSquared(Tn));if(t)for(let l=0,u=t.length;l<u;l++){const h=t[l],p=this.morphTargetsRelative;for(let f=0,g=h.count;f<g;f++)Tn.fromBufferAttribute(h,f),p&&(aa.fromBufferAttribute(e,f),Tn.add(aa)),a=Math.max(a,r.distanceToSquared(Tn))}this.boundingSphere.radius=Math.sqrt(a),isNaN(this.boundingSphere.radius)&&Ut('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){Ut("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const r=t.position,a=t.normal,l=t.uv;let u=this.getAttribute("tangent");(u===void 0||u.count!==r.count)&&(u=new An(new Float32Array(4*r.count),4),this.setAttribute("tangent",u));const h=[],p=[];for(let T=0;T<r.count;T++)h[T]=new X,p[T]=new X;const f=new X,g=new X,b=new X,v=new dt,S=new dt,M=new dt,E=new X,x=new X;function _(T,I,z){f.fromBufferAttribute(r,T),g.fromBufferAttribute(r,I),b.fromBufferAttribute(r,z),v.fromBufferAttribute(l,T),S.fromBufferAttribute(l,I),M.fromBufferAttribute(l,z),g.sub(f),b.sub(f),S.sub(v),M.sub(v);const O=1/(S.x*M.y-M.x*S.y);isFinite(O)&&(E.copy(g).multiplyScalar(M.y).addScaledVector(b,-S.y).multiplyScalar(O),x.copy(b).multiplyScalar(S.x).addScaledVector(g,-M.x).multiplyScalar(O),h[T].add(E),h[I].add(E),h[z].add(E),p[T].add(x),p[I].add(x),p[z].add(x))}let N=this.groups;N.length===0&&(N=[{start:0,count:e.count}]);for(let T=0,I=N.length;T<I;++T){const z=N[T],O=z.start,H=z.count;for(let fe=O,re=O+H;fe<re;fe+=3)_(e.getX(fe+0),e.getX(fe+1),e.getX(fe+2))}const P=new X,C=new X,k=new X,D=new X;function U(T){k.fromBufferAttribute(a,T),D.copy(k);const I=h[T];P.copy(I),P.sub(k.multiplyScalar(k.dot(I))).normalize(),C.crossVectors(D,I);const O=C.dot(p[T])<0?-1:1;u.setXYZW(T,P.x,P.y,P.z,O)}for(let T=0,I=N.length;T<I;++T){const z=N[T],O=z.start,H=z.count;for(let fe=O,re=O+H;fe<re;fe+=3)U(e.getX(fe+0)),U(e.getX(fe+1)),U(e.getX(fe+2))}this._transformed=!0}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let r=this.getAttribute("normal");if(r===void 0||r.count!==t.count)r=new An(new Float32Array(t.count*3),3),this.setAttribute("normal",r);else for(let v=0,S=r.count;v<S;v++)r.setXYZ(v,0,0,0);const a=new X,l=new X,u=new X,h=new X,p=new X,f=new X,g=new X,b=new X;if(e)for(let v=0,S=e.count;v<S;v+=3){const M=e.getX(v+0),E=e.getX(v+1),x=e.getX(v+2);a.fromBufferAttribute(t,M),l.fromBufferAttribute(t,E),u.fromBufferAttribute(t,x),g.subVectors(u,l),b.subVectors(a,l),g.cross(b),h.fromBufferAttribute(r,M),p.fromBufferAttribute(r,E),f.fromBufferAttribute(r,x),h.add(g),p.add(g),f.add(g),r.setXYZ(M,h.x,h.y,h.z),r.setXYZ(E,p.x,p.y,p.z),r.setXYZ(x,f.x,f.y,f.z)}else for(let v=0,S=t.count;v<S;v+=3)a.fromBufferAttribute(t,v+0),l.fromBufferAttribute(t,v+1),u.fromBufferAttribute(t,v+2),g.subVectors(u,l),b.subVectors(a,l),g.cross(b),r.setXYZ(v+0,g.x,g.y,g.z),r.setXYZ(v+1,g.x,g.y,g.z),r.setXYZ(v+2,g.x,g.y,g.z);this.normalizeNormals(),r.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,r=e.count;t<r;t++)Tn.fromBufferAttribute(e,t),Tn.normalize(),e.setXYZ(t,Tn.x,Tn.y,Tn.z)}toNonIndexed(){function e(h,p){const f=h.array,g=h.itemSize,b=h.normalized,v=new f.constructor(p.length*g);let S=0,M=0;for(let E=0,x=p.length;E<x;E++){h.isInterleavedBufferAttribute?S=p[E]*h.data.stride+h.offset:S=p[E]*g;for(let _=0;_<g;_++)v[M++]=f[S++]}return new An(v,g,b)}if(this.index===null)return gt("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new jn,r=this.index.array,a=this.attributes;for(const h in a){const p=a[h],f=e(p,r);t.setAttribute(h,f)}const l=this.morphAttributes;for(const h in l){const p=[],f=l[h];for(let g=0,b=f.length;g<b;g++){const v=f[g],S=e(v,r);p.push(S)}t.morphAttributes[h]=p}t.morphTargetsRelative=this.morphTargetsRelative;const u=this.groups;for(let h=0,p=u.length;h<p;h++){const f=u[h];t.addGroup(f.start,f.count,f.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const p=this.parameters;for(const f in p)p[f]!==void 0&&(e[f]=p[f]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const r=this.attributes;for(const p in r){const f=r[p];e.data.attributes[p]=f.toJSON(e.data)}const a={};let l=!1;for(const p in this.morphAttributes){const f=this.morphAttributes[p],g=[];for(let b=0,v=f.length;b<v;b++){const S=f[b];g.push(S.toJSON(e.data))}g.length>0&&(a[p]=g,l=!0)}l&&(e.data.morphAttributes=a,e.data.morphTargetsRelative=this.morphTargetsRelative);const u=this.groups;u.length>0&&(e.data.groups=JSON.parse(JSON.stringify(u)));const h=this.boundingSphere;return h!==null&&(e.data.boundingSphere=h.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const r=e.index;r!==null&&this.setIndex(r.clone());const a=e.attributes;for(const f in a){const g=a[f];this.setAttribute(f,g.clone(t))}const l=e.morphAttributes;for(const f in l){const g=[],b=l[f];for(let v=0,S=b.length;v<S;v++)g.push(b[v].clone(t));this.morphAttributes[f]=g}this.morphTargetsRelative=e.morphTargetsRelative;const u=e.groups;for(let f=0,g=u.length;f<g;f++){const b=u[f];this.addGroup(b.start,b.count,b.materialIndex)}const h=e.boundingBox;h!==null&&(this.boundingBox=h.clone());const p=e.boundingSphere;return p!==null&&(this.boundingSphere=p.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}let Vy=0;class Ta extends es{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Vy++}),this.uuid=Mo(),this.name="",this.type="Material",this.blending=Ms,this.side=Zr,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=eh,this.blendDst=th,this.blendEquation=_s,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new _t(0,0,0),this.blendAlpha=0,this.depthFunc=ya,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Jm,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Ks,this.stencilZFail=Ks,this.stencilZPass=Ks,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const r=e[t];if(r===void 0){gt(`Material: parameter '${t}' has value of undefined.`);continue}const a=this[t];if(a===void 0){gt(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}a&&a.isColor?a.set(r):a&&a.isVector2&&r&&r.isVector2||a&&a.isEuler&&r&&r.isEuler||a&&a.isVector3&&r&&r.isVector3?a.copy(r):this[t]=r}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const r={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.color&&this.color.isColor&&(r.color=this.color.getHex()),this.roughness!==void 0&&(r.roughness=this.roughness),this.metalness!==void 0&&(r.metalness=this.metalness),this.sheen!==void 0&&(r.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(r.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(r.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(r.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(r.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(r.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(r.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(r.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(r.shininess=this.shininess),this.clearcoat!==void 0&&(r.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(r.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(r.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(r.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(r.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,r.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(r.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(r.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(r.dispersion=this.dispersion),this.iridescence!==void 0&&(r.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(r.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(r.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(r.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(r.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(r.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(r.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(r.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(r.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(r.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(r.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(r.lightMap=this.lightMap.toJSON(e).uuid,r.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(r.aoMap=this.aoMap.toJSON(e).uuid,r.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(r.bumpMap=this.bumpMap.toJSON(e).uuid,r.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(r.normalMap=this.normalMap.toJSON(e).uuid,r.normalMapType=this.normalMapType,r.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(r.displacementMap=this.displacementMap.toJSON(e).uuid,r.displacementScale=this.displacementScale,r.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(r.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(r.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(r.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(r.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(r.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(r.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(r.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(r.combine=this.combine)),this.envMapRotation!==void 0&&(r.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(r.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(r.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(r.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(r.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(r.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(r.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(r.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(r.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(r.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(r.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(r.size=this.size),this.shadowSide!==null&&(r.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(r.sizeAttenuation=this.sizeAttenuation),this.blending!==Ms&&(r.blending=this.blending),this.side!==Zr&&(r.side=this.side),this.vertexColors===!0&&(r.vertexColors=!0),this.opacity<1&&(r.opacity=this.opacity),this.transparent===!0&&(r.transparent=!0),this.blendSrc!==eh&&(r.blendSrc=this.blendSrc),this.blendDst!==th&&(r.blendDst=this.blendDst),this.blendEquation!==_s&&(r.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(r.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(r.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(r.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(r.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(r.blendAlpha=this.blendAlpha),this.depthFunc!==ya&&(r.depthFunc=this.depthFunc),this.depthTest===!1&&(r.depthTest=this.depthTest),this.depthWrite===!1&&(r.depthWrite=this.depthWrite),this.colorWrite===!1&&(r.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(r.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Jm&&(r.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(r.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(r.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Ks&&(r.stencilFail=this.stencilFail),this.stencilZFail!==Ks&&(r.stencilZFail=this.stencilZFail),this.stencilZPass!==Ks&&(r.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(r.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(r.rotation=this.rotation),this.polygonOffset===!0&&(r.polygonOffset=!0),this.polygonOffsetFactor!==0&&(r.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(r.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(r.linewidth=this.linewidth),this.dashSize!==void 0&&(r.dashSize=this.dashSize),this.gapSize!==void 0&&(r.gapSize=this.gapSize),this.scale!==void 0&&(r.scale=this.scale),this.dithering===!0&&(r.dithering=!0),this.alphaTest>0&&(r.alphaTest=this.alphaTest),this.alphaHash===!0&&(r.alphaHash=!0),this.alphaToCoverage===!0&&(r.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(r.premultipliedAlpha=!0),this.forceSinglePass===!0&&(r.forceSinglePass=!0),this.allowOverride===!1&&(r.allowOverride=!1),this.wireframe===!0&&(r.wireframe=!0),this.wireframeLinewidth>1&&(r.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(r.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(r.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(r.flatShading=!0),this.visible===!1&&(r.visible=!1),this.toneMapped===!1&&(r.toneMapped=!1),this.fog===!1&&(r.fog=!1),Object.keys(this.userData).length>0&&(r.userData=this.userData);function a(l){const u=[];for(const h in l){const p=l[h];delete p.metadata,u.push(p)}return u}if(t){const l=a(e.textures),u=a(e.images);l.length>0&&(r.textures=l),u.length>0&&(r.images=u)}return r}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new _t().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=e.iridescenceThicknessRange),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors=="number"?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let r=e.normalScale;Array.isArray(r)===!1&&(r=[r,r]),this.normalScale=new dt().fromArray(r)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new dt().fromArray(e.clearcoatNormalScale)),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let r=null;if(t!==null){const a=t.length;r=new Array(a);for(let l=0;l!==a;++l)r[l]=t[l].clone()}return this.clippingPlanes=r,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}const gr=new X,Fd=new X,Bl=new X,Wr=new X,Ud=new X,zl=new X,Od=new X;class To{constructor(e=new X,t=new X(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,gr)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const r=t.dot(this.direction);return r<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,r)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=gr.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(gr.copy(this.origin).addScaledVector(this.direction,t),gr.distanceToSquared(e))}distanceSqToSegment(e,t,r,a){Fd.copy(e).add(t).multiplyScalar(.5),Bl.copy(t).sub(e).normalize(),Wr.copy(this.origin).sub(Fd);const l=e.distanceTo(t)*.5,u=-this.direction.dot(Bl),h=Wr.dot(this.direction),p=-Wr.dot(Bl),f=Wr.lengthSq(),g=Math.abs(1-u*u);let b,v,S,M;if(g>0)if(b=u*p-h,v=u*h-p,M=l*g,b>=0)if(v>=-M)if(v<=M){const E=1/g;b*=E,v*=E,S=b*(b+u*v+2*h)+v*(u*b+v+2*p)+f}else v=l,b=Math.max(0,-(u*v+h)),S=-b*b+v*(v+2*p)+f;else v=-l,b=Math.max(0,-(u*v+h)),S=-b*b+v*(v+2*p)+f;else v<=-M?(b=Math.max(0,-(-u*l+h)),v=b>0?-l:Math.min(Math.max(-l,-p),l),S=-b*b+v*(v+2*p)+f):v<=M?(b=0,v=Math.min(Math.max(-l,-p),l),S=v*(v+2*p)+f):(b=Math.max(0,-(u*l+h)),v=b>0?l:Math.min(Math.max(-l,-p),l),S=-b*b+v*(v+2*p)+f);else v=u>0?-l:l,b=Math.max(0,-(u*v+h)),S=-b*b+v*(v+2*p)+f;return r&&r.copy(this.origin).addScaledVector(this.direction,b),a&&a.copy(Fd).addScaledVector(Bl,v),S}intersectSphere(e,t){gr.subVectors(e.center,this.origin);const r=gr.dot(this.direction),a=gr.dot(gr)-r*r,l=e.radius*e.radius;if(a>l)return null;const u=Math.sqrt(l-a),h=r-u,p=r+u;return p<0?null:h<0?this.at(p,t):this.at(h,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const r=-(this.origin.dot(e.normal)+e.constant)/t;return r>=0?r:null}intersectPlane(e,t){const r=this.distanceToPlane(e);return r===null?null:this.at(r,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let r,a,l,u,h,p;const f=1/this.direction.x,g=1/this.direction.y,b=1/this.direction.z,v=this.origin;return f>=0?(r=(e.min.x-v.x)*f,a=(e.max.x-v.x)*f):(r=(e.max.x-v.x)*f,a=(e.min.x-v.x)*f),g>=0?(l=(e.min.y-v.y)*g,u=(e.max.y-v.y)*g):(l=(e.max.y-v.y)*g,u=(e.min.y-v.y)*g),r>u||l>a||((l>r||isNaN(r))&&(r=l),(u<a||isNaN(a))&&(a=u),b>=0?(h=(e.min.z-v.z)*b,p=(e.max.z-v.z)*b):(h=(e.max.z-v.z)*b,p=(e.min.z-v.z)*b),r>p||h>a)||((h>r||r!==r)&&(r=h),(p<a||a!==a)&&(a=p),a<0)?null:this.at(r>=0?r:a,t)}intersectsBox(e){return this.intersectBox(e,gr)!==null}intersectTriangle(e,t,r,a,l){Ud.subVectors(t,e),zl.subVectors(r,e),Od.crossVectors(Ud,zl);let u=this.direction.dot(Od),h;if(u>0){if(a)return null;h=1}else if(u<0)h=-1,u=-u;else return null;Wr.subVectors(this.origin,e);const p=h*this.direction.dot(zl.crossVectors(Wr,zl));if(p<0)return null;const f=h*this.direction.dot(Ud.cross(Wr));if(f<0||p+f>u)return null;const g=-h*Wr.dot(Od);return g<0?null:this.at(g/u,l)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class hf extends Ta{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new _t(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Es,this.combine=gg,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const m0=new en,xs=new To,jl=new Eo,g0=new X,Hl=new X,Vl=new X,Gl=new X,Bd=new X,Wl=new X,x0=new X,Xl=new X;class wi extends qn{constructor(e=new jn,t=new hf){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,r=Object.keys(t);if(r.length>0){const a=t[r[0]];if(a!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let l=0,u=a.length;l<u;l++){const h=a[l].name||String(l);this.morphTargetInfluences.push(0),this.morphTargetDictionary[h]=l}}}}getVertexPosition(e,t){const r=this.geometry,a=r.attributes.position,l=r.morphAttributes.position,u=r.morphTargetsRelative;t.fromBufferAttribute(a,e);const h=this.morphTargetInfluences;if(l&&h){Wl.set(0,0,0);for(let p=0,f=l.length;p<f;p++){const g=h[p],b=l[p];g!==0&&(Bd.fromBufferAttribute(b,e),u?Wl.addScaledVector(Bd,g):Wl.addScaledVector(Bd.sub(t),g))}t.add(Wl)}return t}raycast(e,t){const r=this.geometry,a=this.material,l=this.matrixWorld;a!==void 0&&(r.boundingSphere===null&&r.computeBoundingSphere(),jl.copy(r.boundingSphere),jl.applyMatrix4(l),xs.copy(e.ray).recast(e.near),!(jl.containsPoint(xs.origin)===!1&&(xs.intersectSphere(jl,g0)===null||xs.origin.distanceToSquared(g0)>(e.far-e.near)**2))&&(m0.copy(l).invert(),xs.copy(e.ray).applyMatrix4(m0),!(r.boundingBox!==null&&xs.intersectsBox(r.boundingBox)===!1)&&this._computeIntersections(e,t,xs)))}_computeIntersections(e,t,r){let a;const l=this.geometry,u=this.material,h=l.index,p=l.attributes.position,f=l.attributes.uv,g=l.attributes.uv1,b=l.attributes.normal,v=l.groups,S=l.drawRange;if(h!==null)if(Array.isArray(u))for(let M=0,E=v.length;M<E;M++){const x=v[M],_=u[x.materialIndex],N=Math.max(x.start,S.start),P=Math.min(h.count,Math.min(x.start+x.count,S.start+S.count));for(let C=N,k=P;C<k;C+=3){const D=h.getX(C),U=h.getX(C+1),T=h.getX(C+2);a=ql(this,_,e,r,f,g,b,D,U,T),a&&(a.faceIndex=Math.floor(C/3),a.face.materialIndex=x.materialIndex,t.push(a))}}else{const M=Math.max(0,S.start),E=Math.min(h.count,S.start+S.count);for(let x=M,_=E;x<_;x+=3){const N=h.getX(x),P=h.getX(x+1),C=h.getX(x+2);a=ql(this,u,e,r,f,g,b,N,P,C),a&&(a.faceIndex=Math.floor(x/3),t.push(a))}}else if(p!==void 0)if(Array.isArray(u))for(let M=0,E=v.length;M<E;M++){const x=v[M],_=u[x.materialIndex],N=Math.max(x.start,S.start),P=Math.min(p.count,Math.min(x.start+x.count,S.start+S.count));for(let C=N,k=P;C<k;C+=3){const D=C,U=C+1,T=C+2;a=ql(this,_,e,r,f,g,b,D,U,T),a&&(a.faceIndex=Math.floor(C/3),a.face.materialIndex=x.materialIndex,t.push(a))}}else{const M=Math.max(0,S.start),E=Math.min(p.count,S.start+S.count);for(let x=M,_=E;x<_;x+=3){const N=x,P=x+1,C=x+2;a=ql(this,u,e,r,f,g,b,N,P,C),a&&(a.faceIndex=Math.floor(x/3),t.push(a))}}}}function Gy(s,e,t,r,a,l,u,h){let p;if(e.side===si?p=r.intersectTriangle(u,l,a,!0,h):p=r.intersectTriangle(a,l,u,e.side===Zr,h),p===null)return null;Xl.copy(h),Xl.applyMatrix4(s.matrixWorld);const f=t.ray.origin.distanceTo(Xl);return f<t.near||f>t.far?null:{distance:f,point:Xl.clone(),object:s}}function ql(s,e,t,r,a,l,u,h,p,f){s.getVertexPosition(h,Hl),s.getVertexPosition(p,Vl),s.getVertexPosition(f,Gl);const g=Gy(s,e,t,r,Hl,Vl,Gl,x0);if(g){const b=new X;Ui.getBarycoord(x0,Hl,Vl,Gl,b),a&&(g.uv=Ui.getInterpolatedAttribute(a,h,p,f,b,new dt)),l&&(g.uv1=Ui.getInterpolatedAttribute(l,h,p,f,b,new dt)),u&&(g.normal=Ui.getInterpolatedAttribute(u,h,p,f,b,new X),g.normal.dot(r.direction)>0&&g.normal.multiplyScalar(-1));const v={a:h,b:p,c:f,normal:new X,materialIndex:0};Ui.getNormal(Hl,Vl,Gl,v.normal),g.face=v,g.barycoord=b}return g}class Ug extends Xn{constructor(e=null,t=1,r=1,a,l,u,h,p,f=Dn,g=Dn,b,v){super(null,u,h,p,f,g,a,l,b,v),this.isDataTexture=!0,this.image={data:e,width:t,height:r},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const zd=new X,Wy=new X,Xy=new yt;class qr{constructor(e=new X(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,r,a){return this.normal.set(e,t,r),this.constant=a,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,r){const a=zd.subVectors(r,t).cross(Wy.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(a,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,r=!0){const a=e.delta(zd),l=this.normal.dot(a);if(l===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const u=-(e.start.dot(this.normal)+this.constant)/l;return r===!0&&(u<0||u>1)?null:t.copy(e.start).addScaledVector(a,u)}intersectsLine(e){const t=this.distanceToPoint(e.start),r=this.distanceToPoint(e.end);return t<0&&r>0||r<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const r=t||Xy.getNormalMatrix(e),a=this.coplanarPoint(zd).applyMatrix4(e),l=this.normal.applyMatrix3(r).normalize();return this.constant=-a.dot(l),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const vs=new Eo,qy=new dt(.5,.5),$l=new X;class Og{constructor(e=new qr,t=new qr,r=new qr,a=new qr,l=new qr,u=new qr){this.planes=[e,t,r,a,l,u]}set(e,t,r,a,l,u){const h=this.planes;return h[0].copy(e),h[1].copy(t),h[2].copy(r),h[3].copy(a),h[4].copy(l),h[5].copy(u),this}copy(e){const t=this.planes;for(let r=0;r<6;r++)t[r].copy(e.planes[r]);return this}setFromProjectionMatrix(e,t=Zi,r=!1){const a=this.planes,l=e.elements,u=l[0],h=l[1],p=l[2],f=l[3],g=l[4],b=l[5],v=l[6],S=l[7],M=l[8],E=l[9],x=l[10],_=l[11],N=l[12],P=l[13],C=l[14],k=l[15];if(a[0].setComponents(f-u,S-g,_-M,k-N).normalize(),a[1].setComponents(f+u,S+g,_+M,k+N).normalize(),a[2].setComponents(f+h,S+b,_+E,k+P).normalize(),a[3].setComponents(f-h,S-b,_-E,k-P).normalize(),r)a[4].setComponents(p,v,x,C).normalize(),a[5].setComponents(f-p,S-v,_-x,k-C).normalize();else if(a[4].setComponents(f-p,S-v,_-x,k-C).normalize(),t===Zi)a[5].setComponents(f+p,S+v,_+x,k+C).normalize();else if(t===Ec)a[5].setComponents(p,v,x,C).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),vs.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),vs.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(vs)}intersectsSprite(e){vs.center.set(0,0,0);const t=qy.distanceTo(e.center);return vs.radius=.7071067811865476+t,vs.applyMatrix4(e.matrixWorld),this.intersectsSphere(vs)}intersectsSphere(e){const t=this.planes,r=e.center,a=-e.radius;for(let l=0;l<6;l++)if(t[l].distanceToPoint(r)<a)return!1;return!0}intersectsBox(e){const t=this.planes;for(let r=0;r<6;r++){const a=t[r];if($l.x=a.normal.x>0?e.max.x:e.min.x,$l.y=a.normal.y>0?e.max.y:e.min.y,$l.z=a.normal.z>0?e.max.z:e.min.z,a.distanceToPoint($l)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let r=0;r<6;r++)if(t[r].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class ff extends Ta{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new _t(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const Ac=new X,Cc=new X,v0=new en,fo=new To,Yl=new Eo,jd=new X,_0=new X;class Bg extends qn{constructor(e=new jn,t=new ff){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,r=[0];for(let a=1,l=t.count;a<l;a++)Ac.fromBufferAttribute(t,a-1),Cc.fromBufferAttribute(t,a),r[a]=r[a-1],r[a]+=Ac.distanceTo(Cc);e.setAttribute("lineDistance",new $n(r,1))}else gt("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){const r=this.geometry,a=this.matrixWorld,l=e.params.Line.threshold,u=r.drawRange;if(r.boundingSphere===null&&r.computeBoundingSphere(),Yl.copy(r.boundingSphere),Yl.applyMatrix4(a),Yl.radius+=l,e.ray.intersectsSphere(Yl)===!1)return;v0.copy(a).invert(),fo.copy(e.ray).applyMatrix4(v0);const h=l/((this.scale.x+this.scale.y+this.scale.z)/3),p=h*h,f=this.isLineSegments?2:1,g=r.index,v=r.attributes.position;if(g!==null){const S=Math.max(0,u.start),M=Math.min(g.count,u.start+u.count);for(let E=S,x=M-1;E<x;E+=f){const _=g.getX(E),N=g.getX(E+1),P=Kl(this,e,fo,p,_,N,E);P&&t.push(P)}if(this.isLineLoop){const E=g.getX(M-1),x=g.getX(S),_=Kl(this,e,fo,p,E,x,M-1);_&&t.push(_)}}else{const S=Math.max(0,u.start),M=Math.min(v.count,u.start+u.count);for(let E=S,x=M-1;E<x;E+=f){const _=Kl(this,e,fo,p,E,E+1,E);_&&t.push(_)}if(this.isLineLoop){const E=Kl(this,e,fo,p,M-1,S,M-1);E&&t.push(E)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,r=Object.keys(t);if(r.length>0){const a=t[r[0]];if(a!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let l=0,u=a.length;l<u;l++){const h=a[l].name||String(l);this.morphTargetInfluences.push(0),this.morphTargetDictionary[h]=l}}}}}function Kl(s,e,t,r,a,l,u){const h=s.geometry.attributes.position;if(Ac.fromBufferAttribute(h,a),Cc.fromBufferAttribute(h,l),t.distanceSqToSegment(Ac,Cc,jd,_0)>r)return;jd.applyMatrix4(s.matrixWorld);const f=e.ray.origin.distanceTo(jd);if(!(f<e.near||f>e.far))return{distance:f,point:_0.clone().applyMatrix4(s.matrixWorld),index:u,face:null,faceIndex:null,barycoord:null,object:s}}const y0=new X,b0=new X;class $y extends Bg{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,r=[];for(let a=0,l=t.count;a<l;a+=2)y0.fromBufferAttribute(t,a),b0.fromBufferAttribute(t,a+1),r[a]=a===0?0:r[a-1],r[a+1]=r[a]+y0.distanceTo(b0);e.setAttribute("lineDistance",new $n(r,1))}else gt("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class Yy extends Ta{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new _t(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const S0=new en,Hh=new To,Zl=new Eo,Ql=new X;class Ky extends qn{constructor(e=new jn,t=new Yy){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){const r=this.geometry,a=this.matrixWorld,l=e.params.Points.threshold,u=r.drawRange;if(r.boundingSphere===null&&r.computeBoundingSphere(),Zl.copy(r.boundingSphere),Zl.applyMatrix4(a),Zl.radius+=l,e.ray.intersectsSphere(Zl)===!1)return;S0.copy(a).invert(),Hh.copy(e.ray).applyMatrix4(S0);const h=l/((this.scale.x+this.scale.y+this.scale.z)/3),p=h*h,f=r.index,b=r.attributes.position;if(f!==null){const v=Math.max(0,u.start),S=Math.min(f.count,u.start+u.count);for(let M=v,E=S;M<E;M++){const x=f.getX(M);Ql.fromBufferAttribute(b,x),M0(Ql,x,p,a,e,t,this)}}else{const v=Math.max(0,u.start),S=Math.min(b.count,u.start+u.count);for(let M=v,E=S;M<E;M++)Ql.fromBufferAttribute(b,M),M0(Ql,M,p,a,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,r=Object.keys(t);if(r.length>0){const a=t[r[0]];if(a!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let l=0,u=a.length;l<u;l++){const h=a[l].name||String(l);this.morphTargetInfluences.push(0),this.morphTargetDictionary[h]=l}}}}}function M0(s,e,t,r,a,l,u){const h=Hh.distanceSqToPoint(s);if(h<t){const p=new X;Hh.closestPointToPoint(s,p),p.applyMatrix4(r);const f=a.ray.origin.distanceTo(p);if(f<a.near||f>a.far)return;l.push({distance:f,distanceToRay:Math.sqrt(h),point:p,index:e,face:null,faceIndex:null,barycoord:null,object:u})}}class zg extends Xn{constructor(e=[],t=ws,r,a,l,u,h,p,f,g){super(e,t,r,a,l,u,h,p,f,g),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Sa extends Xn{constructor(e,t,r=er,a,l,u,h=Dn,p=Dn,f,g=yr,b=1){if(g!==yr&&g!==Ss)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const v={width:e,height:t,depth:b};super(v,a,l,u,h,p,g,r,f),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new cf(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}class Zy extends Sa{constructor(e,t=er,r=ws,a,l,u=Dn,h=Dn,p,f=yr){const g={width:e,height:e,depth:1},b=[g,g,g,g,g,g];super(e,e,t,r,a,l,u,h,p,f),this.image=b,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class jg extends Xn{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class Ao extends jn{constructor(e=1,t=1,r=1,a=1,l=1,u=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:r,widthSegments:a,heightSegments:l,depthSegments:u};const h=this;a=Math.floor(a),l=Math.floor(l),u=Math.floor(u);const p=[],f=[],g=[],b=[];let v=0,S=0;M("z","y","x",-1,-1,r,t,e,u,l,0),M("z","y","x",1,-1,r,t,-e,u,l,1),M("x","z","y",1,1,e,r,t,a,u,2),M("x","z","y",1,-1,e,r,-t,a,u,3),M("x","y","z",1,-1,e,t,r,a,l,4),M("x","y","z",-1,-1,e,t,-r,a,l,5),this.setIndex(p),this.setAttribute("position",new $n(f,3)),this.setAttribute("normal",new $n(g,3)),this.setAttribute("uv",new $n(b,2));function M(E,x,_,N,P,C,k,D,U,T,I){const z=C/U,O=k/T,H=C/2,fe=k/2,re=D/2,q=U+1,de=T+1;let oe=0,Z=0;const ee=new X;for(let ce=0;ce<de;ce++){const F=ce*O-fe;for(let Y=0;Y<q;Y++){const Ce=Y*z-H;ee[E]=Ce*N,ee[x]=F*P,ee[_]=re,f.push(ee.x,ee.y,ee.z),ee[E]=0,ee[x]=0,ee[_]=D>0?1:-1,g.push(ee.x,ee.y,ee.z),b.push(Y/U),b.push(1-ce/T),oe+=1}}for(let ce=0;ce<T;ce++)for(let F=0;F<U;F++){const Y=v+F+q*ce,Ce=v+F+q*(ce+1),qe=v+(F+1)+q*(ce+1),we=v+(F+1)+q*ce;p.push(Y,Ce,we),p.push(Ce,qe,we),Z+=6}h.addGroup(S,Z,I),S+=Z,v+=oe}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ao(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class Qy{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){gt("Curve: .getPoint() not implemented.")}getPointAt(e,t){const r=this.getUtoTmapping(e);return this.getPoint(r,t)}getPoints(e=5){const t=[];for(let r=0;r<=e;r++)t.push(this.getPoint(r/e));return t}getSpacedPoints(e=5){const t=[];for(let r=0;r<=e;r++)t.push(this.getPointAt(r/e));return t}getLength(){const e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const t=[];let r,a=this.getPoint(0),l=0;t.push(0);for(let u=1;u<=e;u++)r=this.getPoint(u/e),l+=r.distanceTo(a),t.push(l),a=r;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){const r=this.getLengths();let a=0;const l=r.length;let u;t?u=t:u=e*r[l-1];let h=0,p=l-1,f;for(;h<=p;)if(a=Math.floor(h+(p-h)/2),f=r[a]-u,f<0)h=a+1;else if(f>0)p=a-1;else{p=a;break}if(a=p,r[a]===u)return a/(l-1);const g=r[a],v=r[a+1]-g,S=(u-g)/v;return(a+S)/(l-1)}getTangent(e,t){let a=e-1e-4,l=e+1e-4;a<0&&(a=0),l>1&&(l=1);const u=this.getPoint(a),h=this.getPoint(l),p=t||(u.isVector2?new dt:new X);return p.copy(h).sub(u).normalize(),p}getTangentAt(e,t){const r=this.getUtoTmapping(e);return this.getTangent(r,t)}computeFrenetFrames(e,t=!1){const r=new X,a=[],l=[],u=[],h=new X,p=new en;for(let S=0;S<=e;S++){const M=S/e;a[S]=this.getTangentAt(M,new X)}l[0]=new X,u[0]=new X;let f=Number.MAX_VALUE;const g=Math.abs(a[0].x),b=Math.abs(a[0].y),v=Math.abs(a[0].z);g<=f&&(f=g,r.set(1,0,0)),b<=f&&(f=b,r.set(0,1,0)),v<=f&&r.set(0,0,1),h.crossVectors(a[0],r).normalize(),l[0].crossVectors(a[0],h),u[0].crossVectors(a[0],l[0]);for(let S=1;S<=e;S++){if(l[S]=l[S-1].clone(),u[S]=u[S-1].clone(),h.crossVectors(a[S-1],a[S]),h.length()>Number.EPSILON){h.normalize();const M=Math.acos(At(a[S-1].dot(a[S]),-1,1));l[S].applyMatrix4(p.makeRotationAxis(h,M))}u[S].crossVectors(a[S],l[S])}if(t===!0){let S=Math.acos(At(l[0].dot(l[e]),-1,1));S/=e,a[0].dot(h.crossVectors(l[0],l[e]))>0&&(S=-S);for(let M=1;M<=e;M++)l[M].applyMatrix4(p.makeRotationAxis(a[M],S*M)),u[M].crossVectors(a[M],l[M])}return{tangents:a,normals:l,binormals:u}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){const e={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}}function pf(){let s=0,e=0,t=0,r=0;function a(l,u,h,p){s=l,e=h,t=-3*l+3*u-2*h-p,r=2*l-2*u+h+p}return{initCatmullRom:function(l,u,h,p,f){a(u,h,f*(h-l),f*(p-u))},initNonuniformCatmullRom:function(l,u,h,p,f,g,b){let v=(u-l)/f-(h-l)/(f+g)+(h-u)/g,S=(h-u)/g-(p-u)/(g+b)+(p-h)/b;v*=g,S*=g,a(u,h,v,S)},calc:function(l){const u=l*l,h=u*l;return s+e*l+t*u+r*h}}}const w0=new X,E0=new X,Hd=new pf,Vd=new pf,Gd=new pf;class Jy extends Qy{constructor(e=[],t=!1,r="centripetal",a=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=r,this.tension=a}getPoint(e,t=new X){const r=t,a=this.points,l=a.length,u=(l-(this.closed?0:1))*e;let h=Math.floor(u),p=u-h;this.closed?h+=h>0?0:(Math.floor(Math.abs(h)/l)+1)*l:p===0&&h===l-1&&(h=l-2,p=1);let f,g;this.closed||h>0?f=a[(h-1)%l]:(E0.subVectors(a[0],a[1]).add(a[0]),f=E0);const b=a[h%l],v=a[(h+1)%l];if(this.closed||h+2<l?g=a[(h+2)%l]:(w0.subVectors(a[l-1],a[l-2]).add(a[l-1]),g=w0),this.curveType==="centripetal"||this.curveType==="chordal"){const S=this.curveType==="chordal"?.5:.25;let M=Math.pow(f.distanceToSquared(b),S),E=Math.pow(b.distanceToSquared(v),S),x=Math.pow(v.distanceToSquared(g),S);E<1e-4&&(E=1),M<1e-4&&(M=E),x<1e-4&&(x=E),Hd.initNonuniformCatmullRom(f.x,b.x,v.x,g.x,M,E,x),Vd.initNonuniformCatmullRom(f.y,b.y,v.y,g.y,M,E,x),Gd.initNonuniformCatmullRom(f.z,b.z,v.z,g.z,M,E,x)}else this.curveType==="catmullrom"&&(Hd.initCatmullRom(f.x,b.x,v.x,g.x,this.tension),Vd.initCatmullRom(f.y,b.y,v.y,g.y,this.tension),Gd.initCatmullRom(f.z,b.z,v.z,g.z,this.tension));return r.set(Hd.calc(p),Vd.calc(p),Gd.calc(p)),r}copy(e){super.copy(e),this.points=[];for(let t=0,r=e.points.length;t<r;t++){const a=e.points[t];this.points.push(a.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,r=this.points.length;t<r;t++){const a=this.points[t];e.points.push(a.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,r=e.points.length;t<r;t++){const a=e.points[t];this.points.push(new X().fromArray(a))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}}class Co extends jn{constructor(e=1,t=1,r=1,a=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:r,heightSegments:a};const l=e/2,u=t/2,h=Math.floor(r),p=Math.floor(a),f=h+1,g=p+1,b=e/h,v=t/p,S=[],M=[],E=[],x=[];for(let _=0;_<g;_++){const N=_*v-u;for(let P=0;P<f;P++){const C=P*b-l;M.push(C,-N,0),E.push(0,0,1),x.push(P/h),x.push(1-_/p)}}for(let _=0;_<p;_++)for(let N=0;N<h;N++){const P=N+f*_,C=N+f*(_+1),k=N+1+f*(_+1),D=N+1+f*_;S.push(P,C,D),S.push(C,k,D)}this.setIndex(S),this.setAttribute("position",new $n(M,3)),this.setAttribute("normal",new $n(E,3)),this.setAttribute("uv",new $n(x,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Co(e.width,e.height,e.widthSegments,e.heightSegments)}}function Ma(s){const e={};for(const t in s){e[t]={};for(const r in s[t]){const a=s[t][r];if(T0(a))a.isRenderTargetTexture?(gt("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][r]=null):e[t][r]=a.clone();else if(Array.isArray(a))if(T0(a[0])){const l=[];for(let u=0,h=a.length;u<h;u++)l[u]=a[u].clone();e[t][r]=l}else e[t][r]=a.slice();else e[t][r]=a}}return e}function Wn(s){const e={};for(let t=0;t<s.length;t++){const r=Ma(s[t]);for(const a in r)e[a]=r[a]}return e}function T0(s){return s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)}function e1(s){const e=[];for(let t=0;t<s.length;t++)e.push(s[t].clone());return e}function Hg(s){const e=s.getRenderTarget();return e===null?s.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:kt.workingColorSpace}const Rc={clone:Ma,merge:Wn};var t1=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,n1=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class _n extends Ta{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=t1,this.fragmentShader=n1,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Ma(e.uniforms),this.uniformsGroups=e1(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const a in this.uniforms){const u=this.uniforms[a].value;u&&u.isTexture?t.uniforms[a]={type:"t",value:u.toJSON(e).uuid}:u&&u.isColor?t.uniforms[a]={type:"c",value:u.getHex()}:u&&u.isVector2?t.uniforms[a]={type:"v2",value:u.toArray()}:u&&u.isVector3?t.uniforms[a]={type:"v3",value:u.toArray()}:u&&u.isVector4?t.uniforms[a]={type:"v4",value:u.toArray()}:u&&u.isMatrix3?t.uniforms[a]={type:"m3",value:u.toArray()}:u&&u.isMatrix4?t.uniforms[a]={type:"m4",value:u.toArray()}:t.uniforms[a]={value:u}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const r={};for(const a in this.extensions)this.extensions[a]===!0&&(r[a]=!0);return Object.keys(r).length>0&&(t.extensions=r),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(const r in e.uniforms){const a=e.uniforms[r];switch(this.uniforms[r]={},a.type){case"t":this.uniforms[r].value=t[a.value]||null;break;case"c":this.uniforms[r].value=new _t().setHex(a.value);break;case"v2":this.uniforms[r].value=new dt().fromArray(a.value);break;case"v3":this.uniforms[r].value=new X().fromArray(a.value);break;case"v4":this.uniforms[r].value=new un().fromArray(a.value);break;case"m3":this.uniforms[r].value=new yt().fromArray(a.value);break;case"m4":this.uniforms[r].value=new en().fromArray(a.value);break;default:this.uniforms[r].value=a.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(const r in e.extensions)this.extensions[r]=e.extensions[r];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}}class i1 extends _n{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class r1 extends Ta{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=hy,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class s1 extends Ta{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const Jl=new X,ec=new Jr,$i=new X;class Vg extends qn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new en,this.projectionMatrix=new en,this.projectionMatrixInverse=new en,this.coordinateSystem=Zi,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Jl,ec,$i),$i.x===1&&$i.y===1&&$i.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Jl,ec,$i.set(1,1,1)).invert()}updateWorldMatrix(e,t,r=!1){super.updateWorldMatrix(e,t,r),this.matrixWorld.decompose(Jl,ec,$i),$i.x===1&&$i.y===1&&$i.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Jl,ec,$i.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const Xr=new X,A0=new dt,C0=new dt;class Si extends Vg{constructor(e=50,t=1,r=.1,a=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=r,this.far=a,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=jh*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(fc*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return jh*2*Math.atan(Math.tan(fc*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,r){Xr.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Xr.x,Xr.y).multiplyScalar(-e/Xr.z),Xr.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),r.set(Xr.x,Xr.y).multiplyScalar(-e/Xr.z)}getViewSize(e,t){return this.getViewBounds(e,A0,C0),t.subVectors(C0,A0)}setViewOffset(e,t,r,a,l,u){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=r,this.view.offsetY=a,this.view.width=l,this.view.height=u,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(fc*.5*this.fov)/this.zoom,r=2*t,a=this.aspect*r,l=-.5*a;const u=this.view;if(this.view!==null&&this.view.enabled){const p=u.fullWidth,f=u.fullHeight;l+=u.offsetX*a/p,t-=u.offsetY*r/f,a*=u.width/p,r*=u.height/f}const h=this.filmOffset;h!==0&&(l+=e*h/this.getFilmWidth()),this.projectionMatrix.makePerspective(l,l+a,t,t-r,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}class mf extends Vg{constructor(e=-1,t=1,r=1,a=-1,l=.1,u=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=r,this.bottom=a,this.near=l,this.far=u,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,r,a,l,u){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=r,this.view.offsetY=a,this.view.width=l,this.view.height=u,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),r=(this.right+this.left)/2,a=(this.top+this.bottom)/2;let l=r-e,u=r+e,h=a+t,p=a-t;if(this.view!==null&&this.view.enabled){const f=(this.right-this.left)/this.view.fullWidth/this.zoom,g=(this.top-this.bottom)/this.view.fullHeight/this.zoom;l+=f*this.view.offsetX,u=l+f*this.view.width,h-=g*this.view.offsetY,p=h-g*this.view.height}this.projectionMatrix.makeOrthographic(l,u,h,p,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}const oa=-90,la=1;class a1 extends qn{constructor(e,t,r){super(),this.type="CubeCamera",this.renderTarget=r,this.coordinateSystem=null,this.activeMipmapLevel=0;const a=new Si(oa,la,e,t);a.layers=this.layers,this.add(a);const l=new Si(oa,la,e,t);l.layers=this.layers,this.add(l);const u=new Si(oa,la,e,t);u.layers=this.layers,this.add(u);const h=new Si(oa,la,e,t);h.layers=this.layers,this.add(h);const p=new Si(oa,la,e,t);p.layers=this.layers,this.add(p);const f=new Si(oa,la,e,t);f.layers=this.layers,this.add(f)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[r,a,l,u,h,p]=t;for(const f of t)this.remove(f);if(e===Zi)r.up.set(0,1,0),r.lookAt(1,0,0),a.up.set(0,1,0),a.lookAt(-1,0,0),l.up.set(0,0,-1),l.lookAt(0,1,0),u.up.set(0,0,1),u.lookAt(0,-1,0),h.up.set(0,1,0),h.lookAt(0,0,1),p.up.set(0,1,0),p.lookAt(0,0,-1);else if(e===Ec)r.up.set(0,-1,0),r.lookAt(-1,0,0),a.up.set(0,-1,0),a.lookAt(1,0,0),l.up.set(0,0,1),l.lookAt(0,1,0),u.up.set(0,0,-1),u.lookAt(0,-1,0),h.up.set(0,-1,0),h.lookAt(0,0,1),p.up.set(0,-1,0),p.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const f of t)this.add(f),f.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:r,activeMipmapLevel:a}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[l,u,h,p,f,g]=this.children,b=e.getRenderTarget(),v=e.getActiveCubeFace(),S=e.getActiveMipmapLevel(),M=e.xr.enabled;e.xr.enabled=!1;const E=r.texture.generateMipmaps;r.texture.generateMipmaps=!1;let x=!1;e.isWebGLRenderer===!0?x=e.state.buffers.depth.getReversed():x=e.reversedDepthBuffer,e.setRenderTarget(r,0,a),x&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),e.setRenderTarget(r,1,a),x&&e.autoClear===!1&&e.clearDepth(),e.render(t,u),e.setRenderTarget(r,2,a),x&&e.autoClear===!1&&e.clearDepth(),e.render(t,h),e.setRenderTarget(r,3,a),x&&e.autoClear===!1&&e.clearDepth(),e.render(t,p),e.setRenderTarget(r,4,a),x&&e.autoClear===!1&&e.clearDepth(),e.render(t,f),r.texture.generateMipmaps=E,e.setRenderTarget(r,5,a),x&&e.autoClear===!1&&e.clearDepth(),e.render(t,g),e.setRenderTarget(b,v,S),e.xr.enabled=M,r.texture.needsPMREMUpdate=!0}}class o1 extends Si{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}class l1{constructor(){this._previousTime=0,this._currentTime=0,this._startTime=performance.now(),this._delta=0,this._elapsed=0,this._timescale=1,this._document=null,this._pageVisibilityHandler=null}connect(e){this._document=e,e.hidden!==void 0&&(this._pageVisibilityHandler=c1.bind(this),e.addEventListener("visibilitychange",this._pageVisibilityHandler,!1))}disconnect(){this._pageVisibilityHandler!==null&&(this._document.removeEventListener("visibilitychange",this._pageVisibilityHandler),this._pageVisibilityHandler=null),this._document=null}getDelta(){return this._delta/1e3}getElapsed(){return this._elapsed/1e3}getTimescale(){return this._timescale}setTimescale(e){return this._timescale=e,this}reset(){return this._currentTime=performance.now()-this._startTime,this}dispose(){this.disconnect()}update(e){return this._pageVisibilityHandler!==null&&this._document.hidden===!0?this._delta=0:(this._previousTime=this._currentTime,this._currentTime=(e!==void 0?e:performance.now())-this._startTime,this._delta=(this._currentTime-this._previousTime)*this._timescale,this._elapsed+=this._delta),this}}function c1(){this._document.hidden===!1&&this.reset()}const R0=new en;class u1{constructor(e,t,r=0,a=1/0){this.ray=new To(e,t),this.near=r,this.far=a,this.camera=null,this.layers=new uf,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,t.projectionMatrix.elements[14]).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):Ut("Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return R0.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(R0),this}intersectObject(e,t=!0,r=[]){return Vh(e,this,r,t),r.sort(P0),r}intersectObjects(e,t=!0,r=[]){for(let a=0,l=e.length;a<l;a++)Vh(e[a],this,r,t);return r.sort(P0),r}}function P0(s,e){return s.distance-e.distance}function Vh(s,e,t,r){let a=!0;if(s.layers.test(e.layers)&&s.raycast(e,t)===!1&&(a=!1),a===!0&&r===!0){const l=s.children;for(let u=0,h=l.length;u<h;u++)Vh(l[u],e,t,!0)}}class N0{constructor(e=1,t=0,r=0){this.radius=e,this.phi=t,this.theta=r}set(e,t,r){return this.radius=e,this.phi=t,this.theta=r,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=At(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,r){return this.radius=Math.sqrt(e*e+t*t+r*r),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,r),this.phi=Math.acos(At(t/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}}class Gg{static{Gg.prototype.isMatrix2=!0}constructor(e,t,r,a){this.elements=[1,0,0,1],e!==void 0&&this.set(e,t,r,a)}identity(){return this.set(1,0,0,1),this}fromArray(e,t=0){for(let r=0;r<4;r++)this.elements[r]=e[r+t];return this}set(e,t,r,a){const l=this.elements;return l[0]=e,l[2]=t,l[1]=r,l[3]=a,this}}class d1 extends $y{constructor(e=10,t=10,r=4473924,a=8947848){r=new _t(r),a=new _t(a);const l=t/2,u=e/t,h=e/2,p=[],f=[];for(let v=0,S=0,M=-h;v<=t;v++,M+=u){p.push(-h,0,M,h,0,M),p.push(M,0,-h,M,0,h);const E=v===l?r:a;E.toArray(f,S),S+=3,E.toArray(f,S),S+=3,E.toArray(f,S),S+=3,E.toArray(f,S),S+=3}const g=new jn;g.setAttribute("position",new $n(p,3)),g.setAttribute("color",new $n(f,3));const b=new ff({vertexColors:!0,toneMapped:!1});super(g,b),this.type="GridHelper"}dispose(){this.geometry.dispose(),this.material.dispose()}}class h1 extends es{constructor(e,t=null){super(),this.object=e,this.domElement=t,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(e){if(e===void 0){gt("Controls: connect() now requires an element.");return}this.domElement!==null&&this.disconnect(),this.domElement=e}disconnect(){}dispose(){}update(){}}function L0(s,e,t,r){const a=f1(r);switch(t){case Rg:return s*e;case Ng:return s*e/a.components*a.byteLength;case rf:return s*e/a.components*a.byteLength;case Qr:return s*e*2/a.components*a.byteLength;case sf:return s*e*2/a.components*a.byteLength;case Pg:return s*e*3/a.components*a.byteLength;case Bi:return s*e*4/a.components*a.byteLength;case af:return s*e*4/a.components*a.byteLength;case cc:case uc:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*8;case dc:case hc:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*16;case hh:case ph:return Math.max(s,16)*Math.max(e,8)/4;case dh:case fh:return Math.max(s,8)*Math.max(e,8)/2;case mh:case gh:case vh:case _h:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*8;case xh:case bc:case yh:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*16;case bh:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*16;case Sh:return Math.floor((s+4)/5)*Math.floor((e+3)/4)*16;case Mh:return Math.floor((s+4)/5)*Math.floor((e+4)/5)*16;case wh:return Math.floor((s+5)/6)*Math.floor((e+4)/5)*16;case Eh:return Math.floor((s+5)/6)*Math.floor((e+5)/6)*16;case Th:return Math.floor((s+7)/8)*Math.floor((e+4)/5)*16;case Ah:return Math.floor((s+7)/8)*Math.floor((e+5)/6)*16;case Ch:return Math.floor((s+7)/8)*Math.floor((e+7)/8)*16;case Rh:return Math.floor((s+9)/10)*Math.floor((e+4)/5)*16;case Ph:return Math.floor((s+9)/10)*Math.floor((e+5)/6)*16;case Nh:return Math.floor((s+9)/10)*Math.floor((e+7)/8)*16;case Lh:return Math.floor((s+9)/10)*Math.floor((e+9)/10)*16;case Dh:return Math.floor((s+11)/12)*Math.floor((e+9)/10)*16;case Ih:return Math.floor((s+11)/12)*Math.floor((e+11)/12)*16;case kh:case Fh:case Uh:return Math.ceil(s/4)*Math.ceil(e/4)*16;case Oh:case Bh:return Math.ceil(s/4)*Math.ceil(e/4)*8;case Sc:case zh:return Math.ceil(s/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function f1(s){switch(s){case Mi:case Eg:return{byteLength:1,components:1};case bo:case Tg:case fi:return{byteLength:2,components:1};case tf:case nf:return{byteLength:2,components:4};case er:case ef:case Oi:return{byteLength:4,components:1};case Ag:case Cg:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${s}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Jh}}));typeof window<"u"&&(window.__THREE__?gt("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Jh);/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function Wg(){let s=null,e=!1,t=null,r=null;function a(l,u){t(l,u),r=s.requestAnimationFrame(a)}return{start:function(){e!==!0&&t!==null&&s!==null&&(r=s.requestAnimationFrame(a),e=!0)},stop:function(){s!==null&&s.cancelAnimationFrame(r),e=!1},setAnimationLoop:function(l){t=l},setContext:function(l){s=l}}}function p1(s){const e=new WeakMap;function t(h,p){const f=h.array,g=h.usage,b=f.byteLength,v=s.createBuffer();s.bindBuffer(p,v),s.bufferData(p,f,g),h.onUploadCallback();let S;if(f instanceof Float32Array)S=s.FLOAT;else if(typeof Float16Array<"u"&&f instanceof Float16Array)S=s.HALF_FLOAT;else if(f instanceof Uint16Array)h.isFloat16BufferAttribute?S=s.HALF_FLOAT:S=s.UNSIGNED_SHORT;else if(f instanceof Int16Array)S=s.SHORT;else if(f instanceof Uint32Array)S=s.UNSIGNED_INT;else if(f instanceof Int32Array)S=s.INT;else if(f instanceof Int8Array)S=s.BYTE;else if(f instanceof Uint8Array)S=s.UNSIGNED_BYTE;else if(f instanceof Uint8ClampedArray)S=s.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+f);return{buffer:v,type:S,bytesPerElement:f.BYTES_PER_ELEMENT,version:h.version,size:b}}function r(h,p,f){const g=p.array,b=p.updateRanges;if(s.bindBuffer(f,h),b.length===0)s.bufferSubData(f,0,g);else{b.sort((S,M)=>S.start-M.start);let v=0;for(let S=1;S<b.length;S++){const M=b[v],E=b[S];E.start<=M.start+M.count+1?M.count=Math.max(M.count,E.start+E.count-M.start):(++v,b[v]=E)}b.length=v+1;for(let S=0,M=b.length;S<M;S++){const E=b[S];s.bufferSubData(f,E.start*g.BYTES_PER_ELEMENT,g,E.start,E.count)}p.clearUpdateRanges()}p.onUploadCallback()}function a(h){return h.isInterleavedBufferAttribute&&(h=h.data),e.get(h)}function l(h){h.isInterleavedBufferAttribute&&(h=h.data);const p=e.get(h);p&&(s.deleteBuffer(p.buffer),e.delete(h))}function u(h,p){if(h.isInterleavedBufferAttribute&&(h=h.data),h.isGLBufferAttribute){const g=e.get(h);(!g||g.version<h.version)&&e.set(h,{buffer:h.buffer,type:h.type,bytesPerElement:h.elementSize,version:h.version});return}const f=e.get(h);if(f===void 0)e.set(h,t(h,p));else if(f.version<h.version){if(f.size!==h.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(f.buffer,h,p),f.version=h.version}}return{get:a,remove:l,update:u}}var m1=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,g1=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,x1=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,v1=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,_1=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,y1=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,b1=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,S1=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,M1=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,w1=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,E1=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,T1=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,A1=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,C1=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,R1=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,P1=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,N1=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,L1=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,D1=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,I1=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,k1=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,F1=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,U1=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,O1=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,B1=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,z1=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,j1=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,H1=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,V1=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,G1=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,W1="gl_FragColor = linearToOutputTexel( gl_FragColor );",X1=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,q1=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,$1=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,Y1=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,K1=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Z1=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Q1=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,J1=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,eb=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,tb=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,nb=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,ib=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,rb=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,sb=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,ab=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,ob=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,lb=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,cb=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,ub=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,db=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,hb=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,fb=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,pb=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,mb=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,gb=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,xb=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,vb=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,_b=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,yb=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,bb=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Sb=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Mb=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,wb=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Eb=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Tb=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Ab=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Cb=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Rb=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Pb=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Nb=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Lb=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Db=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Ib=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,kb=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Fb=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Ub=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,Ob=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Bb=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,zb=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,jb=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Hb=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Vb=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Gb=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,Wb=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Xb=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,qb=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,$b=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Yb=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Kb=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Zb=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,Qb=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Jb=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,eS=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,tS=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,nS=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,iS=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,rS=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,sS=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,aS=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,oS=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,lS=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,cS=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,uS=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,dS=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,hS=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,fS=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,pS=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const mS=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,gS=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,xS=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,vS=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,_S=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,yS=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,bS=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,SS=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,MS=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,wS=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,ES=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,TS=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,AS=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,CS=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,RS=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,PS=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,NS=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,LS=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,DS=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,IS=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,kS=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,FS=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,US=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,OS=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,BS=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,zS=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,jS=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,HS=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,VS=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,GS=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,WS=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,XS=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,qS=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,$S=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Mt={alphahash_fragment:m1,alphahash_pars_fragment:g1,alphamap_fragment:x1,alphamap_pars_fragment:v1,alphatest_fragment:_1,alphatest_pars_fragment:y1,aomap_fragment:b1,aomap_pars_fragment:S1,batching_pars_vertex:M1,batching_vertex:w1,begin_vertex:E1,beginnormal_vertex:T1,bsdfs:A1,iridescence_fragment:C1,bumpmap_pars_fragment:R1,clipping_planes_fragment:P1,clipping_planes_pars_fragment:N1,clipping_planes_pars_vertex:L1,clipping_planes_vertex:D1,color_fragment:I1,color_pars_fragment:k1,color_pars_vertex:F1,color_vertex:U1,common:O1,cube_uv_reflection_fragment:B1,defaultnormal_vertex:z1,displacementmap_pars_vertex:j1,displacementmap_vertex:H1,emissivemap_fragment:V1,emissivemap_pars_fragment:G1,colorspace_fragment:W1,colorspace_pars_fragment:X1,envmap_fragment:q1,envmap_common_pars_fragment:$1,envmap_pars_fragment:Y1,envmap_pars_vertex:K1,envmap_physical_pars_fragment:ob,envmap_vertex:Z1,fog_vertex:Q1,fog_pars_vertex:J1,fog_fragment:eb,fog_pars_fragment:tb,gradientmap_pars_fragment:nb,lightmap_pars_fragment:ib,lights_lambert_fragment:rb,lights_lambert_pars_fragment:sb,lights_pars_begin:ab,lights_toon_fragment:lb,lights_toon_pars_fragment:cb,lights_phong_fragment:ub,lights_phong_pars_fragment:db,lights_physical_fragment:hb,lights_physical_pars_fragment:fb,lights_fragment_begin:pb,lights_fragment_maps:mb,lights_fragment_end:gb,lightprobes_pars_fragment:xb,logdepthbuf_fragment:vb,logdepthbuf_pars_fragment:_b,logdepthbuf_pars_vertex:yb,logdepthbuf_vertex:bb,map_fragment:Sb,map_pars_fragment:Mb,map_particle_fragment:wb,map_particle_pars_fragment:Eb,metalnessmap_fragment:Tb,metalnessmap_pars_fragment:Ab,morphinstance_vertex:Cb,morphcolor_vertex:Rb,morphnormal_vertex:Pb,morphtarget_pars_vertex:Nb,morphtarget_vertex:Lb,normal_fragment_begin:Db,normal_fragment_maps:Ib,normal_pars_fragment:kb,normal_pars_vertex:Fb,normal_vertex:Ub,normalmap_pars_fragment:Ob,clearcoat_normal_fragment_begin:Bb,clearcoat_normal_fragment_maps:zb,clearcoat_pars_fragment:jb,iridescence_pars_fragment:Hb,opaque_fragment:Vb,packing:Gb,premultiplied_alpha_fragment:Wb,project_vertex:Xb,dithering_fragment:qb,dithering_pars_fragment:$b,roughnessmap_fragment:Yb,roughnessmap_pars_fragment:Kb,shadowmap_pars_fragment:Zb,shadowmap_pars_vertex:Qb,shadowmap_vertex:Jb,shadowmask_pars_fragment:eS,skinbase_vertex:tS,skinning_pars_vertex:nS,skinning_vertex:iS,skinnormal_vertex:rS,specularmap_fragment:sS,specularmap_pars_fragment:aS,tonemapping_fragment:oS,tonemapping_pars_fragment:lS,transmission_fragment:cS,transmission_pars_fragment:uS,uv_pars_fragment:dS,uv_pars_vertex:hS,uv_vertex:fS,worldpos_vertex:pS,background_vert:mS,background_frag:gS,backgroundCube_vert:xS,backgroundCube_frag:vS,cube_vert:_S,cube_frag:yS,depth_vert:bS,depth_frag:SS,distance_vert:MS,distance_frag:wS,equirect_vert:ES,equirect_frag:TS,linedashed_vert:AS,linedashed_frag:CS,meshbasic_vert:RS,meshbasic_frag:PS,meshlambert_vert:NS,meshlambert_frag:LS,meshmatcap_vert:DS,meshmatcap_frag:IS,meshnormal_vert:kS,meshnormal_frag:FS,meshphong_vert:US,meshphong_frag:OS,meshphysical_vert:BS,meshphysical_frag:zS,meshtoon_vert:jS,meshtoon_frag:HS,points_vert:VS,points_frag:GS,shadow_vert:WS,shadow_frag:XS,sprite_vert:qS,sprite_frag:$S},Ge={common:{diffuse:{value:new _t(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new yt},alphaMap:{value:null},alphaMapTransform:{value:new yt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new yt}},envmap:{envMap:{value:null},envMapRotation:{value:new yt},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new yt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new yt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new yt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new yt},normalScale:{value:new dt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new yt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new yt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new yt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new yt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new _t(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new X},probesMax:{value:new X},probesResolution:{value:new X}},points:{diffuse:{value:new _t(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new yt},alphaTest:{value:0},uvTransform:{value:new yt}},sprite:{diffuse:{value:new _t(16777215)},opacity:{value:1},center:{value:new dt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new yt},alphaMap:{value:null},alphaMapTransform:{value:new yt},alphaTest:{value:0}}},Ki={basic:{uniforms:Wn([Ge.common,Ge.specularmap,Ge.envmap,Ge.aomap,Ge.lightmap,Ge.fog]),vertexShader:Mt.meshbasic_vert,fragmentShader:Mt.meshbasic_frag},lambert:{uniforms:Wn([Ge.common,Ge.specularmap,Ge.envmap,Ge.aomap,Ge.lightmap,Ge.emissivemap,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,Ge.fog,Ge.lights,{emissive:{value:new _t(0)},envMapIntensity:{value:1}}]),vertexShader:Mt.meshlambert_vert,fragmentShader:Mt.meshlambert_frag},phong:{uniforms:Wn([Ge.common,Ge.specularmap,Ge.envmap,Ge.aomap,Ge.lightmap,Ge.emissivemap,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,Ge.fog,Ge.lights,{emissive:{value:new _t(0)},specular:{value:new _t(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Mt.meshphong_vert,fragmentShader:Mt.meshphong_frag},standard:{uniforms:Wn([Ge.common,Ge.envmap,Ge.aomap,Ge.lightmap,Ge.emissivemap,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,Ge.roughnessmap,Ge.metalnessmap,Ge.fog,Ge.lights,{emissive:{value:new _t(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Mt.meshphysical_vert,fragmentShader:Mt.meshphysical_frag},toon:{uniforms:Wn([Ge.common,Ge.aomap,Ge.lightmap,Ge.emissivemap,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,Ge.gradientmap,Ge.fog,Ge.lights,{emissive:{value:new _t(0)}}]),vertexShader:Mt.meshtoon_vert,fragmentShader:Mt.meshtoon_frag},matcap:{uniforms:Wn([Ge.common,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,Ge.fog,{matcap:{value:null}}]),vertexShader:Mt.meshmatcap_vert,fragmentShader:Mt.meshmatcap_frag},points:{uniforms:Wn([Ge.points,Ge.fog]),vertexShader:Mt.points_vert,fragmentShader:Mt.points_frag},dashed:{uniforms:Wn([Ge.common,Ge.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Mt.linedashed_vert,fragmentShader:Mt.linedashed_frag},depth:{uniforms:Wn([Ge.common,Ge.displacementmap]),vertexShader:Mt.depth_vert,fragmentShader:Mt.depth_frag},normal:{uniforms:Wn([Ge.common,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,{opacity:{value:1}}]),vertexShader:Mt.meshnormal_vert,fragmentShader:Mt.meshnormal_frag},sprite:{uniforms:Wn([Ge.sprite,Ge.fog]),vertexShader:Mt.sprite_vert,fragmentShader:Mt.sprite_frag},background:{uniforms:{uvTransform:{value:new yt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Mt.background_vert,fragmentShader:Mt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new yt}},vertexShader:Mt.backgroundCube_vert,fragmentShader:Mt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Mt.cube_vert,fragmentShader:Mt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Mt.equirect_vert,fragmentShader:Mt.equirect_frag},distance:{uniforms:Wn([Ge.common,Ge.displacementmap,{referencePosition:{value:new X},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Mt.distance_vert,fragmentShader:Mt.distance_frag},shadow:{uniforms:Wn([Ge.lights,Ge.fog,{color:{value:new _t(0)},opacity:{value:1}}]),vertexShader:Mt.shadow_vert,fragmentShader:Mt.shadow_frag}};Ki.physical={uniforms:Wn([Ki.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new yt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new yt},clearcoatNormalScale:{value:new dt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new yt},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new yt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new yt},sheen:{value:0},sheenColor:{value:new _t(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new yt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new yt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new yt},transmissionSamplerSize:{value:new dt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new yt},attenuationDistance:{value:0},attenuationColor:{value:new _t(0)},specularColor:{value:new _t(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new yt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new yt},anisotropyVector:{value:new dt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new yt}}]),vertexShader:Mt.meshphysical_vert,fragmentShader:Mt.meshphysical_frag};const tc={r:0,b:0,g:0},YS=new en,Xg=new yt;Xg.set(-1,0,0,0,1,0,0,0,1);function KS(s,e,t,r,a,l){const u=new _t(0);let h=a===!0?0:1,p,f,g=null,b=0,v=null;function S(N){let P=N.isScene===!0?N.background:null;if(P&&P.isTexture){const C=N.backgroundBlurriness>0;P=e.get(P,C)}return P}function M(N){let P=!1;const C=S(N);C===null?x(u,h):C&&C.isColor&&(x(C,1),P=!0);const k=s.xr.getEnvironmentBlendMode();k==="additive"?t.buffers.color.setClear(0,0,0,1,l):k==="alpha-blend"&&t.buffers.color.setClear(0,0,0,0,l),(s.autoClear||P)&&(t.buffers.depth.setTest(!0),t.buffers.depth.setMask(!0),t.buffers.color.setMask(!0),s.clear(s.autoClearColor,s.autoClearDepth,s.autoClearStencil))}function E(N,P){const C=S(P);C&&(C.isCubeTexture||C.mapping===Dc)?(f===void 0&&(f=new wi(new Ao(1,1,1),new _n({name:"BackgroundCubeMaterial",uniforms:Ma(Ki.backgroundCube.uniforms),vertexShader:Ki.backgroundCube.vertexShader,fragmentShader:Ki.backgroundCube.fragmentShader,side:si,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),f.geometry.deleteAttribute("normal"),f.geometry.deleteAttribute("uv"),f.onBeforeRender=function(k,D,U){this.matrixWorld.copyPosition(U.matrixWorld)},Object.defineProperty(f.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(f)),f.material.uniforms.envMap.value=C,f.material.uniforms.backgroundBlurriness.value=P.backgroundBlurriness,f.material.uniforms.backgroundIntensity.value=P.backgroundIntensity,f.material.uniforms.backgroundRotation.value.setFromMatrix4(YS.makeRotationFromEuler(P.backgroundRotation)).transpose(),C.isCubeTexture&&C.isRenderTargetTexture===!1&&f.material.uniforms.backgroundRotation.value.premultiply(Xg),f.material.toneMapped=kt.getTransfer(C.colorSpace)!==Wt,(g!==C||b!==C.version||v!==s.toneMapping)&&(f.material.needsUpdate=!0,g=C,b=C.version,v=s.toneMapping),f.layers.enableAll(),N.unshift(f,f.geometry,f.material,0,0,null)):C&&C.isTexture&&(p===void 0&&(p=new wi(new Co(2,2),new _n({name:"BackgroundMaterial",uniforms:Ma(Ki.background.uniforms),vertexShader:Ki.background.vertexShader,fragmentShader:Ki.background.fragmentShader,side:Zr,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),p.geometry.deleteAttribute("normal"),Object.defineProperty(p.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(p)),p.material.uniforms.t2D.value=C,p.material.uniforms.backgroundIntensity.value=P.backgroundIntensity,p.material.toneMapped=kt.getTransfer(C.colorSpace)!==Wt,C.matrixAutoUpdate===!0&&C.updateMatrix(),p.material.uniforms.uvTransform.value.copy(C.matrix),(g!==C||b!==C.version||v!==s.toneMapping)&&(p.material.needsUpdate=!0,g=C,b=C.version,v=s.toneMapping),p.layers.enableAll(),N.unshift(p,p.geometry,p.material,0,0,null))}function x(N,P){N.getRGB(tc,Hg(s)),t.buffers.color.setClear(tc.r,tc.g,tc.b,P,l)}function _(){f!==void 0&&(f.geometry.dispose(),f.material.dispose(),f=void 0),p!==void 0&&(p.geometry.dispose(),p.material.dispose(),p=void 0)}return{getClearColor:function(){return u},setClearColor:function(N,P=1){u.set(N),h=P,x(u,h)},getClearAlpha:function(){return h},setClearAlpha:function(N){h=N,x(u,h)},render:M,addToRenderList:E,dispose:_}}function ZS(s,e){const t=s.getParameter(s.MAX_VERTEX_ATTRIBS),r={},a=v(null);let l=a,u=!1;function h(O,H,fe,re,q){let de=!1;const oe=b(O,re,fe,H);l!==oe&&(l=oe,f(l.object)),de=S(O,re,fe,q),de&&M(O,re,fe,q),q!==null&&e.update(q,s.ELEMENT_ARRAY_BUFFER),(de||u)&&(u=!1,C(O,H,fe,re),q!==null&&s.bindBuffer(s.ELEMENT_ARRAY_BUFFER,e.get(q).buffer))}function p(){return s.createVertexArray()}function f(O){return s.bindVertexArray(O)}function g(O){return s.deleteVertexArray(O)}function b(O,H,fe,re){const q=re.wireframe===!0;let de=r[H.id];de===void 0&&(de={},r[H.id]=de);const oe=O.isInstancedMesh===!0?O.id:0;let Z=de[oe];Z===void 0&&(Z={},de[oe]=Z);let ee=Z[fe.id];ee===void 0&&(ee={},Z[fe.id]=ee);let ce=ee[q];return ce===void 0&&(ce=v(p()),ee[q]=ce),ce}function v(O){const H=[],fe=[],re=[];for(let q=0;q<t;q++)H[q]=0,fe[q]=0,re[q]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:H,enabledAttributes:fe,attributeDivisors:re,object:O,attributes:{},index:null}}function S(O,H,fe,re){const q=l.attributes,de=H.attributes;let oe=0;const Z=fe.getAttributes();for(const ee in Z)if(Z[ee].location>=0){const F=q[ee];let Y=de[ee];if(Y===void 0&&(ee==="instanceMatrix"&&O.instanceMatrix&&(Y=O.instanceMatrix),ee==="instanceColor"&&O.instanceColor&&(Y=O.instanceColor)),F===void 0||F.attribute!==Y||Y&&F.data!==Y.data)return!0;oe++}return l.attributesNum!==oe||l.index!==re}function M(O,H,fe,re){const q={},de=H.attributes;let oe=0;const Z=fe.getAttributes();for(const ee in Z)if(Z[ee].location>=0){let F=de[ee];F===void 0&&(ee==="instanceMatrix"&&O.instanceMatrix&&(F=O.instanceMatrix),ee==="instanceColor"&&O.instanceColor&&(F=O.instanceColor));const Y={};Y.attribute=F,F&&F.data&&(Y.data=F.data),q[ee]=Y,oe++}l.attributes=q,l.attributesNum=oe,l.index=re}function E(){const O=l.newAttributes;for(let H=0,fe=O.length;H<fe;H++)O[H]=0}function x(O){_(O,0)}function _(O,H){const fe=l.newAttributes,re=l.enabledAttributes,q=l.attributeDivisors;fe[O]=1,re[O]===0&&(s.enableVertexAttribArray(O),re[O]=1),q[O]!==H&&(s.vertexAttribDivisor(O,H),q[O]=H)}function N(){const O=l.newAttributes,H=l.enabledAttributes;for(let fe=0,re=H.length;fe<re;fe++)H[fe]!==O[fe]&&(s.disableVertexAttribArray(fe),H[fe]=0)}function P(O,H,fe,re,q,de,oe){oe===!0?s.vertexAttribIPointer(O,H,fe,q,de):s.vertexAttribPointer(O,H,fe,re,q,de)}function C(O,H,fe,re){E();const q=re.attributes,de=fe.getAttributes(),oe=H.defaultAttributeValues;for(const Z in de){const ee=de[Z];if(ee.location>=0){let ce=q[Z];if(ce===void 0&&(Z==="instanceMatrix"&&O.instanceMatrix&&(ce=O.instanceMatrix),Z==="instanceColor"&&O.instanceColor&&(ce=O.instanceColor)),ce!==void 0){const F=ce.normalized,Y=ce.itemSize,Ce=e.get(ce);if(Ce===void 0)continue;const qe=Ce.buffer,we=Ce.type,ie=Ce.bytesPerElement,xe=we===s.INT||we===s.UNSIGNED_INT||ce.gpuType===ef;if(ce.isInterleavedBufferAttribute){const ve=ce.data,te=ve.stride,Se=ce.offset;if(ve.isInstancedInterleavedBuffer){for(let Qe=0;Qe<ee.locationSize;Qe++)_(ee.location+Qe,ve.meshPerAttribute);O.isInstancedMesh!==!0&&re._maxInstanceCount===void 0&&(re._maxInstanceCount=ve.meshPerAttribute*ve.count)}else for(let Qe=0;Qe<ee.locationSize;Qe++)x(ee.location+Qe);s.bindBuffer(s.ARRAY_BUFFER,qe);for(let Qe=0;Qe<ee.locationSize;Qe++)P(ee.location+Qe,Y/ee.locationSize,we,F,te*ie,(Se+Y/ee.locationSize*Qe)*ie,xe)}else{if(ce.isInstancedBufferAttribute){for(let ve=0;ve<ee.locationSize;ve++)_(ee.location+ve,ce.meshPerAttribute);O.isInstancedMesh!==!0&&re._maxInstanceCount===void 0&&(re._maxInstanceCount=ce.meshPerAttribute*ce.count)}else for(let ve=0;ve<ee.locationSize;ve++)x(ee.location+ve);s.bindBuffer(s.ARRAY_BUFFER,qe);for(let ve=0;ve<ee.locationSize;ve++)P(ee.location+ve,Y/ee.locationSize,we,F,Y*ie,Y/ee.locationSize*ve*ie,xe)}}else if(oe!==void 0){const F=oe[Z];if(F!==void 0)switch(F.length){case 2:s.vertexAttrib2fv(ee.location,F);break;case 3:s.vertexAttrib3fv(ee.location,F);break;case 4:s.vertexAttrib4fv(ee.location,F);break;default:s.vertexAttrib1fv(ee.location,F)}}}}N()}function k(){I();for(const O in r){const H=r[O];for(const fe in H){const re=H[fe];for(const q in re){const de=re[q];for(const oe in de)g(de[oe].object),delete de[oe];delete re[q]}}delete r[O]}}function D(O){if(r[O.id]===void 0)return;const H=r[O.id];for(const fe in H){const re=H[fe];for(const q in re){const de=re[q];for(const oe in de)g(de[oe].object),delete de[oe];delete re[q]}}delete r[O.id]}function U(O){for(const H in r){const fe=r[H];for(const re in fe){const q=fe[re];if(q[O.id]===void 0)continue;const de=q[O.id];for(const oe in de)g(de[oe].object),delete de[oe];delete q[O.id]}}}function T(O){for(const H in r){const fe=r[H],re=O.isInstancedMesh===!0?O.id:0,q=fe[re];if(q!==void 0){for(const de in q){const oe=q[de];for(const Z in oe)g(oe[Z].object),delete oe[Z];delete q[de]}delete fe[re],Object.keys(fe).length===0&&delete r[H]}}}function I(){z(),u=!0,l!==a&&(l=a,f(l.object))}function z(){a.geometry=null,a.program=null,a.wireframe=!1}return{setup:h,reset:I,resetDefaultState:z,dispose:k,releaseStatesOfGeometry:D,releaseStatesOfObject:T,releaseStatesOfProgram:U,initAttributes:E,enableAttribute:x,disableUnusedAttributes:N}}function QS(s,e,t){let r;function a(p){r=p}function l(p,f){s.drawArrays(r,p,f),t.update(f,r,1)}function u(p,f,g){g!==0&&(s.drawArraysInstanced(r,p,f,g),t.update(f,r,g))}function h(p,f,g){if(g===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(r,p,0,f,0,g);let v=0;for(let S=0;S<g;S++)v+=f[S];t.update(v,r,1)}this.setMode=a,this.render=l,this.renderInstances=u,this.renderMultiDraw=h}function JS(s,e,t,r){let a;function l(){if(a!==void 0)return a;if(e.has("EXT_texture_filter_anisotropic")===!0){const U=e.get("EXT_texture_filter_anisotropic");a=s.getParameter(U.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else a=0;return a}function u(U){return!(U!==Bi&&r.convert(U)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_FORMAT))}function h(U){const T=U===fi&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(U!==Mi&&r.convert(U)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_TYPE)&&U!==Oi&&!T)}function p(U){if(U==="highp"){if(s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.HIGH_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.HIGH_FLOAT).precision>0)return"highp";U="mediump"}return U==="mediump"&&s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.MEDIUM_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let f=t.precision!==void 0?t.precision:"highp";const g=p(f);g!==f&&(gt("WebGLRenderer:",f,"not supported, using",g,"instead."),f=g);const b=t.logarithmicDepthBuffer===!0,v=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control");t.reversedDepthBuffer===!0&&v===!1&&gt("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const S=s.getParameter(s.MAX_TEXTURE_IMAGE_UNITS),M=s.getParameter(s.MAX_VERTEX_TEXTURE_IMAGE_UNITS),E=s.getParameter(s.MAX_TEXTURE_SIZE),x=s.getParameter(s.MAX_CUBE_MAP_TEXTURE_SIZE),_=s.getParameter(s.MAX_VERTEX_ATTRIBS),N=s.getParameter(s.MAX_VERTEX_UNIFORM_VECTORS),P=s.getParameter(s.MAX_VARYING_VECTORS),C=s.getParameter(s.MAX_FRAGMENT_UNIFORM_VECTORS),k=s.getParameter(s.MAX_SAMPLES),D=s.getParameter(s.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:l,getMaxPrecision:p,textureFormatReadable:u,textureTypeReadable:h,precision:f,logarithmicDepthBuffer:b,reversedDepthBuffer:v,maxTextures:S,maxVertexTextures:M,maxTextureSize:E,maxCubemapSize:x,maxAttributes:_,maxVertexUniforms:N,maxVaryings:P,maxFragmentUniforms:C,maxSamples:k,samples:D}}function eM(s){const e=this;let t=null,r=0,a=!1,l=!1;const u=new qr,h=new yt,p={value:null,needsUpdate:!1};this.uniform=p,this.numPlanes=0,this.numIntersection=0,this.init=function(b,v){const S=b.length!==0||v||r!==0||a;return a=v,r=b.length,S},this.beginShadows=function(){l=!0,g(null)},this.endShadows=function(){l=!1},this.setGlobalState=function(b,v){t=g(b,v,0)},this.setState=function(b,v,S){const M=b.clippingPlanes,E=b.clipIntersection,x=b.clipShadows,_=s.get(b);if(!a||M===null||M.length===0||l&&!x)l?g(null):f();else{const N=l?0:r,P=N*4;let C=_.clippingState||null;p.value=C,C=g(M,v,P,S);for(let k=0;k!==P;++k)C[k]=t[k];_.clippingState=C,this.numIntersection=E?this.numPlanes:0,this.numPlanes+=N}};function f(){p.value!==t&&(p.value=t,p.needsUpdate=r>0),e.numPlanes=r,e.numIntersection=0}function g(b,v,S,M){const E=b!==null?b.length:0;let x=null;if(E!==0){if(x=p.value,M!==!0||x===null){const _=S+E*4,N=v.matrixWorldInverse;h.getNormalMatrix(N),(x===null||x.length<_)&&(x=new Float32Array(_));for(let P=0,C=S;P!==E;++P,C+=4)u.copy(b[P]).applyMatrix4(N,h),u.normal.toArray(x,C),x[C+3]=u.constant}p.value=x,p.needsUpdate=!0}return e.numPlanes=E,e.numIntersection=0,x}}const Yr=4,D0=[.125,.215,.35,.446,.526,.582],ys=20,tM=256,po=new mf,I0=new _t;let Wd=null,Xd=0,qd=0,$d=!1;const nM=new X;class k0{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,r=.1,a=100,l={}){const{size:u=256,position:h=nM}=l;Wd=this._renderer.getRenderTarget(),Xd=this._renderer.getActiveCubeFace(),qd=this._renderer.getActiveMipmapLevel(),$d=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(u);const p=this._allocateTargets();return p.depthBuffer=!0,this._sceneToCubeUV(e,r,a,p,h),t>0&&this._blur(p,0,0,t),this._applyPMREM(p),this._cleanup(p),p}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=O0(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=U0(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(Wd,Xd,qd),this._renderer.xr.enabled=$d,e.scissorTest=!1,ca(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===ws||e.mapping===ba?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Wd=this._renderer.getRenderTarget(),Xd=this._renderer.getActiveCubeFace(),qd=this._renderer.getActiveMipmapLevel(),$d=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const r=t||this._allocateTargets();return this._textureToCubeUV(e,r),this._applyPMREM(r),this._cleanup(r),r}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,r={magFilter:zn,minFilter:zn,generateMipmaps:!1,type:fi,format:Bi,colorSpace:Mc,depthBuffer:!1},a=F0(e,t,r);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=F0(e,t,r);const{_lodMax:l}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=iM(l)),this._blurMaterial=sM(l,e,t),this._ggxMaterial=rM(l,e,t)}return a}_compileMaterial(e){const t=new wi(new jn,e);this._renderer.compile(t,po)}_sceneToCubeUV(e,t,r,a,l){const p=new Si(90,1,t,r),f=[1,-1,1,1,1,1],g=[1,1,1,-1,-1,-1],b=this._renderer,v=b.autoClear,S=b.toneMapping;b.getClearColor(I0),b.toneMapping=Ji,b.autoClear=!1,b.state.buffers.depth.getReversed()&&(b.setRenderTarget(a),b.clearDepth(),b.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new wi(new Ao,new hf({name:"PMREM.Background",side:si,depthWrite:!1,depthTest:!1})));const E=this._backgroundBox,x=E.material;let _=!1;const N=e.background;N?N.isColor&&(x.color.copy(N),e.background=null,_=!0):(x.color.copy(I0),_=!0);for(let P=0;P<6;P++){const C=P%3;C===0?(p.up.set(0,f[P],0),p.position.set(l.x,l.y,l.z),p.lookAt(l.x+g[P],l.y,l.z)):C===1?(p.up.set(0,0,f[P]),p.position.set(l.x,l.y,l.z),p.lookAt(l.x,l.y+g[P],l.z)):(p.up.set(0,f[P],0),p.position.set(l.x,l.y,l.z),p.lookAt(l.x,l.y,l.z+g[P]));const k=this._cubeSize;ca(a,C*k,P>2?k:0,k,k),b.setRenderTarget(a),_&&b.render(E,p),b.render(e,p)}b.toneMapping=S,b.autoClear=v,e.background=N}_textureToCubeUV(e,t){const r=this._renderer,a=e.mapping===ws||e.mapping===ba;a?(this._cubemapMaterial===null&&(this._cubemapMaterial=O0()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=U0());const l=a?this._cubemapMaterial:this._equirectMaterial,u=this._lodMeshes[0];u.material=l;const h=l.uniforms;h.envMap.value=e;const p=this._cubeSize;ca(t,0,0,3*p,2*p),r.setRenderTarget(t),r.render(u,po)}_applyPMREM(e){const t=this._renderer,r=t.autoClear;t.autoClear=!1;const a=this._lodMeshes.length;for(let l=1;l<a;l++)this._applyGGXFilter(e,l-1,l);t.autoClear=r}_applyGGXFilter(e,t,r){const a=this._renderer,l=this._pingPongRenderTarget,u=this._ggxMaterial,h=this._lodMeshes[r];h.material=u;const p=u.uniforms,f=r/(this._lodMeshes.length-1),g=t/(this._lodMeshes.length-1),b=Math.sqrt(f*f-g*g),v=0+f*1.25,S=b*v,{_lodMax:M}=this,E=this._sizeLods[r],x=3*E*(r>M-Yr?r-M+Yr:0),_=4*(this._cubeSize-E);p.envMap.value=e.texture,p.roughness.value=S,p.mipInt.value=M-t,ca(l,x,_,3*E,2*E),a.setRenderTarget(l),a.render(h,po),p.envMap.value=l.texture,p.roughness.value=0,p.mipInt.value=M-r,ca(e,x,_,3*E,2*E),a.setRenderTarget(e),a.render(h,po)}_blur(e,t,r,a,l){const u=this._pingPongRenderTarget;this._halfBlur(e,u,t,r,a,"latitudinal",l),this._halfBlur(u,e,r,r,a,"longitudinal",l)}_halfBlur(e,t,r,a,l,u,h){const p=this._renderer,f=this._blurMaterial;u!=="latitudinal"&&u!=="longitudinal"&&Ut("blur direction must be either latitudinal or longitudinal!");const g=3,b=this._lodMeshes[a];b.material=f;const v=f.uniforms,S=this._sizeLods[r]-1,M=isFinite(l)?Math.PI/(2*S):2*Math.PI/(2*ys-1),E=l/M,x=isFinite(l)?1+Math.floor(g*E):ys;x>ys&&gt(`sigmaRadians, ${l}, is too large and will clip, as it requested ${x} samples when the maximum is set to ${ys}`);const _=[];let N=0;for(let U=0;U<ys;++U){const T=U/E,I=Math.exp(-T*T/2);_.push(I),U===0?N+=I:U<x&&(N+=2*I)}for(let U=0;U<_.length;U++)_[U]=_[U]/N;v.envMap.value=e.texture,v.samples.value=x,v.weights.value=_,v.latitudinal.value=u==="latitudinal",h&&(v.poleAxis.value=h);const{_lodMax:P}=this;v.dTheta.value=M,v.mipInt.value=P-r;const C=this._sizeLods[a],k=3*C*(a>P-Yr?a-P+Yr:0),D=4*(this._cubeSize-C);ca(t,k,D,3*C,2*C),p.setRenderTarget(t),p.render(b,po)}}function iM(s){const e=[],t=[],r=[];let a=s;const l=s-Yr+1+D0.length;for(let u=0;u<l;u++){const h=Math.pow(2,a);e.push(h);let p=1/h;u>s-Yr?p=D0[u-s+Yr-1]:u===0&&(p=0),t.push(p);const f=1/(h-2),g=-f,b=1+f,v=[g,g,b,g,b,b,g,g,b,b,g,b],S=6,M=6,E=3,x=2,_=1,N=new Float32Array(E*M*S),P=new Float32Array(x*M*S),C=new Float32Array(_*M*S);for(let D=0;D<S;D++){const U=D%3*2/3-1,T=D>2?0:-1,I=[U,T,0,U+2/3,T,0,U+2/3,T+1,0,U,T,0,U+2/3,T+1,0,U,T+1,0];N.set(I,E*M*D),P.set(v,x*M*D);const z=[D,D,D,D,D,D];C.set(z,_*M*D)}const k=new jn;k.setAttribute("position",new An(N,E)),k.setAttribute("uv",new An(P,x)),k.setAttribute("faceIndex",new An(C,_)),r.push(new wi(k,null)),a>Yr&&a--}return{lodMeshes:r,sizeLods:e,sigmas:t}}function F0(s,e,t){const r=new ai(s,e,t);return r.texture.mapping=Dc,r.texture.name="PMREM.cubeUv",r.scissorTest=!0,r}function ca(s,e,t,r,a){s.viewport.set(e,t,r,a),s.scissor.set(e,t,r,a)}function rM(s,e,t){return new _n({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:tM,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:Ic(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Qi,depthTest:!1,depthWrite:!1})}function sM(s,e,t){const r=new Float32Array(ys),a=new X(0,1,0);return new _n({name:"SphericalGaussianBlur",defines:{n:ys,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:r},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:a}},vertexShader:Ic(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Qi,depthTest:!1,depthWrite:!1})}function U0(){return new _n({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Ic(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Qi,depthTest:!1,depthWrite:!1})}function O0(){return new _n({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Ic(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Qi,depthTest:!1,depthWrite:!1})}function Ic(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}class qg extends ai{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const r={width:e,height:e,depth:1},a=[r,r,r,r,r,r];this.texture=new zg(a),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const r={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},a=new Ao(5,5,5),l=new _n({name:"CubemapFromEquirect",uniforms:Ma(r.uniforms),vertexShader:r.vertexShader,fragmentShader:r.fragmentShader,side:si,blending:Qi});l.uniforms.tEquirect.value=t;const u=new wi(a,l),h=t.minFilter;return t.minFilter===bs&&(t.minFilter=zn),new a1(1,10,this).update(e,u),t.minFilter=h,u.geometry.dispose(),u.material.dispose(),this}clear(e,t=!0,r=!0,a=!0){const l=e.getRenderTarget();for(let u=0;u<6;u++)e.setRenderTarget(this,u),e.clear(t,r,a);e.setRenderTarget(l)}}function aM(s){let e=new WeakMap,t=new WeakMap,r=null;function a(v,S=!1){return v==null?null:S?u(v):l(v)}function l(v){if(v&&v.isTexture){const S=v.mapping;if(S===md||S===gd)if(e.has(v)){const M=e.get(v).texture;return h(M,v.mapping)}else{const M=v.image;if(M&&M.height>0){const E=new qg(M.height);return E.fromEquirectangularTexture(s,v),e.set(v,E),v.addEventListener("dispose",f),h(E.texture,v.mapping)}else return null}}return v}function u(v){if(v&&v.isTexture){const S=v.mapping,M=S===md||S===gd,E=S===ws||S===ba;if(M||E){let x=t.get(v);const _=x!==void 0?x.texture.pmremVersion:0;if(v.isRenderTargetTexture&&v.pmremVersion!==_)return r===null&&(r=new k0(s)),x=M?r.fromEquirectangular(v,x):r.fromCubemap(v,x),x.texture.pmremVersion=v.pmremVersion,t.set(v,x),x.texture;if(x!==void 0)return x.texture;{const N=v.image;return M&&N&&N.height>0||E&&N&&p(N)?(r===null&&(r=new k0(s)),x=M?r.fromEquirectangular(v):r.fromCubemap(v),x.texture.pmremVersion=v.pmremVersion,t.set(v,x),v.addEventListener("dispose",g),x.texture):null}}}return v}function h(v,S){return S===md?v.mapping=ws:S===gd&&(v.mapping=ba),v}function p(v){let S=0;const M=6;for(let E=0;E<M;E++)v[E]!==void 0&&S++;return S===M}function f(v){const S=v.target;S.removeEventListener("dispose",f);const M=e.get(S);M!==void 0&&(e.delete(S),M.dispose())}function g(v){const S=v.target;S.removeEventListener("dispose",g);const M=t.get(S);M!==void 0&&(t.delete(S),M.dispose())}function b(){e=new WeakMap,t=new WeakMap,r!==null&&(r.dispose(),r=null)}return{get:a,dispose:b}}function oM(s){const e={};function t(r){if(e[r]!==void 0)return e[r];const a=s.getExtension(r);return e[r]=a,a}return{has:function(r){return t(r)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(r){const a=t(r);return a===null&&va("WebGLRenderer: "+r+" extension not supported."),a}}}function lM(s,e,t,r){const a={},l=new WeakMap;function u(b){const v=b.target;v.index!==null&&e.remove(v.index);for(const M in v.attributes)e.remove(v.attributes[M]);v.removeEventListener("dispose",u),delete a[v.id];const S=l.get(v);S&&(e.remove(S),l.delete(v)),r.releaseStatesOfGeometry(v),v.isInstancedBufferGeometry===!0&&delete v._maxInstanceCount,t.memory.geometries--}function h(b,v){return a[v.id]===!0||(v.addEventListener("dispose",u),a[v.id]=!0,t.memory.geometries++),v}function p(b){const v=b.attributes;for(const S in v)e.update(v[S],s.ARRAY_BUFFER)}function f(b){const v=[],S=b.index,M=b.attributes.position;let E=0;if(M===void 0)return;if(S!==null){const N=S.array;E=S.version;for(let P=0,C=N.length;P<C;P+=3){const k=N[P+0],D=N[P+1],U=N[P+2];v.push(k,D,D,U,U,k)}}else{const N=M.array;E=M.version;for(let P=0,C=N.length/3-1;P<C;P+=3){const k=P+0,D=P+1,U=P+2;v.push(k,D,D,U,U,k)}}const x=new(M.count>=65535?Fg:kg)(v,1);x.version=E;const _=l.get(b);_&&e.remove(_),l.set(b,x)}function g(b){const v=l.get(b);if(v){const S=b.index;S!==null&&v.version<S.version&&f(b)}else f(b);return l.get(b)}return{get:h,update:p,getWireframeAttribute:g}}function cM(s,e,t){let r;function a(b){r=b}let l,u;function h(b){l=b.type,u=b.bytesPerElement}function p(b,v){s.drawElements(r,v,l,b*u),t.update(v,r,1)}function f(b,v,S){S!==0&&(s.drawElementsInstanced(r,v,l,b*u,S),t.update(v,r,S))}function g(b,v,S){if(S===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(r,v,0,l,b,0,S);let E=0;for(let x=0;x<S;x++)E+=v[x];t.update(E,r,1)}this.setMode=a,this.setIndex=h,this.render=p,this.renderInstances=f,this.renderMultiDraw=g}function uM(s){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function r(l,u,h){switch(t.calls++,u){case s.TRIANGLES:t.triangles+=h*(l/3);break;case s.LINES:t.lines+=h*(l/2);break;case s.LINE_STRIP:t.lines+=h*(l-1);break;case s.LINE_LOOP:t.lines+=h*l;break;case s.POINTS:t.points+=h*l;break;default:Ut("WebGLInfo: Unknown draw mode:",u);break}}function a(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:a,update:r}}function dM(s,e,t){const r=new WeakMap,a=new un;function l(u,h,p){const f=u.morphTargetInfluences,g=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,b=g!==void 0?g.length:0;let v=r.get(h);if(v===void 0||v.count!==b){let I=function(){U.dispose(),r.delete(h),h.removeEventListener("dispose",I)};v!==void 0&&v.texture.dispose();const S=h.morphAttributes.position!==void 0,M=h.morphAttributes.normal!==void 0,E=h.morphAttributes.color!==void 0,x=h.morphAttributes.position||[],_=h.morphAttributes.normal||[],N=h.morphAttributes.color||[];let P=0;S===!0&&(P=1),M===!0&&(P=2),E===!0&&(P=3);let C=h.attributes.position.count*P,k=1;C>e.maxTextureSize&&(k=Math.ceil(C/e.maxTextureSize),C=e.maxTextureSize);const D=new Float32Array(C*k*4*b),U=new Dg(D,C,k,b);U.type=Oi,U.needsUpdate=!0;const T=P*4;for(let z=0;z<b;z++){const O=x[z],H=_[z],fe=N[z],re=C*k*4*z;for(let q=0;q<O.count;q++){const de=q*T;S===!0&&(a.fromBufferAttribute(O,q),D[re+de+0]=a.x,D[re+de+1]=a.y,D[re+de+2]=a.z,D[re+de+3]=0),M===!0&&(a.fromBufferAttribute(H,q),D[re+de+4]=a.x,D[re+de+5]=a.y,D[re+de+6]=a.z,D[re+de+7]=0),E===!0&&(a.fromBufferAttribute(fe,q),D[re+de+8]=a.x,D[re+de+9]=a.y,D[re+de+10]=a.z,D[re+de+11]=fe.itemSize===4?a.w:1)}}v={count:b,texture:U,size:new dt(C,k)},r.set(h,v),h.addEventListener("dispose",I)}if(u.isInstancedMesh===!0&&u.morphTexture!==null)p.getUniforms().setValue(s,"morphTexture",u.morphTexture,t);else{let S=0;for(let E=0;E<f.length;E++)S+=f[E];const M=h.morphTargetsRelative?1:1-S;p.getUniforms().setValue(s,"morphTargetBaseInfluence",M),p.getUniforms().setValue(s,"morphTargetInfluences",f)}p.getUniforms().setValue(s,"morphTargetsTexture",v.texture,t),p.getUniforms().setValue(s,"morphTargetsTextureSize",v.size)}return{update:l}}function hM(s,e,t,r,a){let l=new WeakMap;function u(f){const g=a.render.frame,b=f.geometry,v=e.get(f,b);if(l.get(v)!==g&&(e.update(v),l.set(v,g)),f.isInstancedMesh&&(f.hasEventListener("dispose",p)===!1&&f.addEventListener("dispose",p),l.get(f)!==g&&(t.update(f.instanceMatrix,s.ARRAY_BUFFER),f.instanceColor!==null&&t.update(f.instanceColor,s.ARRAY_BUFFER),l.set(f,g))),f.isSkinnedMesh){const S=f.skeleton;l.get(S)!==g&&(S.update(),l.set(S,g))}return v}function h(){l=new WeakMap}function p(f){const g=f.target;g.removeEventListener("dispose",p),r.releaseStatesOfObject(g),t.remove(g.instanceMatrix),g.instanceColor!==null&&t.remove(g.instanceColor)}return{update:u,dispose:h}}const fM={[xg]:"LINEAR_TONE_MAPPING",[vg]:"REINHARD_TONE_MAPPING",[_g]:"CINEON_TONE_MAPPING",[yg]:"ACES_FILMIC_TONE_MAPPING",[Sg]:"AGX_TONE_MAPPING",[Mg]:"NEUTRAL_TONE_MAPPING",[bg]:"CUSTOM_TONE_MAPPING"};function pM(s,e,t,r,a,l){const u=new ai(e,t,{type:s,depthBuffer:a,stencilBuffer:l,samples:r?4:0,depthTexture:a?new Sa(e,t):void 0}),h=new ai(e,t,{type:fi,depthBuffer:!1,stencilBuffer:!1}),p=new jn;p.setAttribute("position",new $n([-1,3,0,-1,-1,0,3,-1,0],3)),p.setAttribute("uv",new $n([0,2,0,0,2,0],2));const f=new i1({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),g=new wi(p,f),b=new mf(-1,1,1,-1,0,1);let v=null,S=null,M=!1,E,x=null,_=[],N=!1;this.setSize=function(P,C){u.setSize(P,C),h.setSize(P,C);for(let k=0;k<_.length;k++){const D=_[k];D.setSize&&D.setSize(P,C)}},this.setEffects=function(P){_=P,N=_.length>0&&_[0].isRenderPass===!0;const C=u.width,k=u.height;for(let D=0;D<_.length;D++){const U=_[D];U.setSize&&U.setSize(C,k)}},this.begin=function(P,C){if(M||P.toneMapping===Ji&&_.length===0)return!1;if(x=C,C!==null){const k=C.width,D=C.height;(u.width!==k||u.height!==D)&&this.setSize(k,D)}return N===!1&&P.setRenderTarget(u),E=P.toneMapping,P.toneMapping=Ji,!0},this.hasRenderPass=function(){return N},this.end=function(P,C){P.toneMapping=E,M=!0;let k=u,D=h;for(let U=0;U<_.length;U++){const T=_[U];if(T.enabled!==!1&&(T.render(P,D,k,C),T.needsSwap!==!1)){const I=k;k=D,D=I}}if(v!==P.outputColorSpace||S!==P.toneMapping){v=P.outputColorSpace,S=P.toneMapping,f.defines={},kt.getTransfer(v)===Wt&&(f.defines.SRGB_TRANSFER="");const U=fM[S];U&&(f.defines[U]=""),f.needsUpdate=!0}f.uniforms.tDiffuse.value=k.texture,P.setRenderTarget(x),P.render(g,b),x=null,M=!1},this.isCompositing=function(){return M},this.dispose=function(){u.depthTexture&&u.depthTexture.dispose(),u.dispose(),h.dispose(),p.dispose(),f.dispose()}}const $g=new Xn,Gh=new Sa(1,1),Yg=new Dg,Kg=new Ny,Zg=new zg,B0=[],z0=[],j0=new Float32Array(16),H0=new Float32Array(9),V0=new Float32Array(4);function Aa(s,e,t){const r=s[0];if(r<=0||r>0)return s;const a=e*t;let l=B0[a];if(l===void 0&&(l=new Float32Array(a),B0[a]=l),e!==0){r.toArray(l,0);for(let u=1,h=0;u!==e;++u)h+=t,s[u].toArray(l,h)}return l}function yn(s,e){if(s.length!==e.length)return!1;for(let t=0,r=s.length;t<r;t++)if(s[t]!==e[t])return!1;return!0}function bn(s,e){for(let t=0,r=e.length;t<r;t++)s[t]=e[t]}function kc(s,e){let t=z0[e];t===void 0&&(t=new Int32Array(e),z0[e]=t);for(let r=0;r!==e;++r)t[r]=s.allocateTextureUnit();return t}function mM(s,e){const t=this.cache;t[0]!==e&&(s.uniform1f(this.addr,e),t[0]=e)}function gM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(s.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(yn(t,e))return;s.uniform2fv(this.addr,e),bn(t,e)}}function xM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(s.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(s.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(yn(t,e))return;s.uniform3fv(this.addr,e),bn(t,e)}}function vM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(s.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(yn(t,e))return;s.uniform4fv(this.addr,e),bn(t,e)}}function _M(s,e){const t=this.cache,r=e.elements;if(r===void 0){if(yn(t,e))return;s.uniformMatrix2fv(this.addr,!1,e),bn(t,e)}else{if(yn(t,r))return;V0.set(r),s.uniformMatrix2fv(this.addr,!1,V0),bn(t,r)}}function yM(s,e){const t=this.cache,r=e.elements;if(r===void 0){if(yn(t,e))return;s.uniformMatrix3fv(this.addr,!1,e),bn(t,e)}else{if(yn(t,r))return;H0.set(r),s.uniformMatrix3fv(this.addr,!1,H0),bn(t,r)}}function bM(s,e){const t=this.cache,r=e.elements;if(r===void 0){if(yn(t,e))return;s.uniformMatrix4fv(this.addr,!1,e),bn(t,e)}else{if(yn(t,r))return;j0.set(r),s.uniformMatrix4fv(this.addr,!1,j0),bn(t,r)}}function SM(s,e){const t=this.cache;t[0]!==e&&(s.uniform1i(this.addr,e),t[0]=e)}function MM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(s.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(yn(t,e))return;s.uniform2iv(this.addr,e),bn(t,e)}}function wM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(s.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(yn(t,e))return;s.uniform3iv(this.addr,e),bn(t,e)}}function EM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(s.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(yn(t,e))return;s.uniform4iv(this.addr,e),bn(t,e)}}function TM(s,e){const t=this.cache;t[0]!==e&&(s.uniform1ui(this.addr,e),t[0]=e)}function AM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(s.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(yn(t,e))return;s.uniform2uiv(this.addr,e),bn(t,e)}}function CM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(s.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(yn(t,e))return;s.uniform3uiv(this.addr,e),bn(t,e)}}function RM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(s.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(yn(t,e))return;s.uniform4uiv(this.addr,e),bn(t,e)}}function PM(s,e,t){const r=this.cache,a=t.allocateTextureUnit();r[0]!==a&&(s.uniform1i(this.addr,a),r[0]=a);let l;this.type===s.SAMPLER_2D_SHADOW?(Gh.compareFunction=t.isReversedDepthBuffer()?lf:of,l=Gh):l=$g,t.setTexture2D(e||l,a)}function NM(s,e,t){const r=this.cache,a=t.allocateTextureUnit();r[0]!==a&&(s.uniform1i(this.addr,a),r[0]=a),t.setTexture3D(e||Kg,a)}function LM(s,e,t){const r=this.cache,a=t.allocateTextureUnit();r[0]!==a&&(s.uniform1i(this.addr,a),r[0]=a),t.setTextureCube(e||Zg,a)}function DM(s,e,t){const r=this.cache,a=t.allocateTextureUnit();r[0]!==a&&(s.uniform1i(this.addr,a),r[0]=a),t.setTexture2DArray(e||Yg,a)}function IM(s){switch(s){case 5126:return mM;case 35664:return gM;case 35665:return xM;case 35666:return vM;case 35674:return _M;case 35675:return yM;case 35676:return bM;case 5124:case 35670:return SM;case 35667:case 35671:return MM;case 35668:case 35672:return wM;case 35669:case 35673:return EM;case 5125:return TM;case 36294:return AM;case 36295:return CM;case 36296:return RM;case 35678:case 36198:case 36298:case 36306:case 35682:return PM;case 35679:case 36299:case 36307:return NM;case 35680:case 36300:case 36308:case 36293:return LM;case 36289:case 36303:case 36311:case 36292:return DM}}function kM(s,e){s.uniform1fv(this.addr,e)}function FM(s,e){const t=Aa(e,this.size,2);s.uniform2fv(this.addr,t)}function UM(s,e){const t=Aa(e,this.size,3);s.uniform3fv(this.addr,t)}function OM(s,e){const t=Aa(e,this.size,4);s.uniform4fv(this.addr,t)}function BM(s,e){const t=Aa(e,this.size,4);s.uniformMatrix2fv(this.addr,!1,t)}function zM(s,e){const t=Aa(e,this.size,9);s.uniformMatrix3fv(this.addr,!1,t)}function jM(s,e){const t=Aa(e,this.size,16);s.uniformMatrix4fv(this.addr,!1,t)}function HM(s,e){s.uniform1iv(this.addr,e)}function VM(s,e){s.uniform2iv(this.addr,e)}function GM(s,e){s.uniform3iv(this.addr,e)}function WM(s,e){s.uniform4iv(this.addr,e)}function XM(s,e){s.uniform1uiv(this.addr,e)}function qM(s,e){s.uniform2uiv(this.addr,e)}function $M(s,e){s.uniform3uiv(this.addr,e)}function YM(s,e){s.uniform4uiv(this.addr,e)}function KM(s,e,t){const r=this.cache,a=e.length,l=kc(t,a);yn(r,l)||(s.uniform1iv(this.addr,l),bn(r,l));let u;this.type===s.SAMPLER_2D_SHADOW?u=Gh:u=$g;for(let h=0;h!==a;++h)t.setTexture2D(e[h]||u,l[h])}function ZM(s,e,t){const r=this.cache,a=e.length,l=kc(t,a);yn(r,l)||(s.uniform1iv(this.addr,l),bn(r,l));for(let u=0;u!==a;++u)t.setTexture3D(e[u]||Kg,l[u])}function QM(s,e,t){const r=this.cache,a=e.length,l=kc(t,a);yn(r,l)||(s.uniform1iv(this.addr,l),bn(r,l));for(let u=0;u!==a;++u)t.setTextureCube(e[u]||Zg,l[u])}function JM(s,e,t){const r=this.cache,a=e.length,l=kc(t,a);yn(r,l)||(s.uniform1iv(this.addr,l),bn(r,l));for(let u=0;u!==a;++u)t.setTexture2DArray(e[u]||Yg,l[u])}function ew(s){switch(s){case 5126:return kM;case 35664:return FM;case 35665:return UM;case 35666:return OM;case 35674:return BM;case 35675:return zM;case 35676:return jM;case 5124:case 35670:return HM;case 35667:case 35671:return VM;case 35668:case 35672:return GM;case 35669:case 35673:return WM;case 5125:return XM;case 36294:return qM;case 36295:return $M;case 36296:return YM;case 35678:case 36198:case 36298:case 36306:case 35682:return KM;case 35679:case 36299:case 36307:return ZM;case 35680:case 36300:case 36308:case 36293:return QM;case 36289:case 36303:case 36311:case 36292:return JM}}class tw{constructor(e,t,r){this.id=e,this.addr=r,this.cache=[],this.type=t.type,this.setValue=IM(t.type)}}class nw{constructor(e,t,r){this.id=e,this.addr=r,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=ew(t.type)}}class iw{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,r){const a=this.seq;for(let l=0,u=a.length;l!==u;++l){const h=a[l];h.setValue(e,t[h.id],r)}}}const Yd=/(\w+)(\])?(\[|\.)?/g;function G0(s,e){s.seq.push(e),s.map[e.id]=e}function rw(s,e,t){const r=s.name,a=r.length;for(Yd.lastIndex=0;;){const l=Yd.exec(r),u=Yd.lastIndex;let h=l[1];const p=l[2]==="]",f=l[3];if(p&&(h=h|0),f===void 0||f==="["&&u+2===a){G0(t,f===void 0?new tw(h,s,e):new nw(h,s,e));break}else{let b=t.map[h];b===void 0&&(b=new iw(h),G0(t,b)),t=b}}}class pc{constructor(e,t){this.seq=[],this.map={};const r=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let u=0;u<r;++u){const h=e.getActiveUniform(t,u),p=e.getUniformLocation(t,h.name);rw(h,p,this)}const a=[],l=[];for(const u of this.seq)u.type===e.SAMPLER_2D_SHADOW||u.type===e.SAMPLER_CUBE_SHADOW||u.type===e.SAMPLER_2D_ARRAY_SHADOW?a.push(u):l.push(u);a.length>0&&(this.seq=a.concat(l))}setValue(e,t,r,a){const l=this.map[t];l!==void 0&&l.setValue(e,r,a)}setOptional(e,t,r){const a=t[r];a!==void 0&&this.setValue(e,r,a)}static upload(e,t,r,a){for(let l=0,u=t.length;l!==u;++l){const h=t[l],p=r[h.id];p.needsUpdate!==!1&&h.setValue(e,p.value,a)}}static seqWithValue(e,t){const r=[];for(let a=0,l=e.length;a!==l;++a){const u=e[a];u.id in t&&r.push(u)}return r}}function W0(s,e,t){const r=s.createShader(e);return s.shaderSource(r,t),s.compileShader(r),r}const sw=37297;let aw=0;function ow(s,e){const t=s.split(`
`),r=[],a=Math.max(e-6,0),l=Math.min(e+6,t.length);for(let u=a;u<l;u++){const h=u+1;r.push(`${h===e?">":" "} ${h}: ${t[u]}`)}return r.join(`
`)}const X0=new yt;function lw(s){kt._getMatrix(X0,kt.workingColorSpace,s);const e=`mat3( ${X0.elements.map(t=>t.toFixed(4))} )`;switch(kt.getTransfer(s)){case wc:return[e,"LinearTransferOETF"];case Wt:return[e,"sRGBTransferOETF"];default:return gt("WebGLProgram: Unsupported color space: ",s),[e,"LinearTransferOETF"]}}function q0(s,e,t){const r=s.getShaderParameter(e,s.COMPILE_STATUS),l=(s.getShaderInfoLog(e)||"").trim();if(r&&l==="")return"";const u=/ERROR: 0:(\d+)/.exec(l);if(u){const h=parseInt(u[1]);return t.toUpperCase()+`

`+l+`

`+ow(s.getShaderSource(e),h)}else return l}function cw(s,e){const t=lw(e);return[`vec4 ${s}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}const uw={[xg]:"Linear",[vg]:"Reinhard",[_g]:"Cineon",[yg]:"ACESFilmic",[Sg]:"AgX",[Mg]:"Neutral",[bg]:"Custom"};function dw(s,e){const t=uw[e];return t===void 0?(gt("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+s+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+s+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const nc=new X;function hw(){kt.getLuminanceCoefficients(nc);const s=nc.x.toFixed(4),e=nc.y.toFixed(4),t=nc.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${s}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function fw(s){return[s.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",s.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(_o).join(`
`)}function pw(s){const e=[];for(const t in s){const r=s[t];r!==!1&&e.push("#define "+t+" "+r)}return e.join(`
`)}function mw(s,e){const t={},r=s.getProgramParameter(e,s.ACTIVE_ATTRIBUTES);for(let a=0;a<r;a++){const l=s.getActiveAttrib(e,a),u=l.name;let h=1;l.type===s.FLOAT_MAT2&&(h=2),l.type===s.FLOAT_MAT3&&(h=3),l.type===s.FLOAT_MAT4&&(h=4),t[u]={type:l.type,location:s.getAttribLocation(e,u),locationSize:h}}return t}function _o(s){return s!==""}function $0(s,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return s.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Y0(s,e){return s.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const gw=/^[ \t]*#include +<([\w\d./]+)>/gm;function Wh(s){return s.replace(gw,vw)}const xw=new Map;function vw(s,e){let t=Mt[e];if(t===void 0){const r=xw.get(e);if(r!==void 0)t=Mt[r],gt('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,r);else throw new Error("THREE.WebGLProgram: Can not resolve #include <"+e+">")}return Wh(t)}const _w=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function K0(s){return s.replace(_w,yw)}function yw(s,e,t,r){let a="";for(let l=parseInt(e);l<parseInt(t);l++)a+=r.replace(/\[\s*i\s*\]/g,"[ "+l+" ]").replace(/UNROLLED_LOOP_INDEX/g,l);return a}function Z0(s){let e=`precision ${s.precision} float;
	precision ${s.precision} int;
	precision ${s.precision} sampler2D;
	precision ${s.precision} samplerCube;
	precision ${s.precision} sampler3D;
	precision ${s.precision} sampler2DArray;
	precision ${s.precision} sampler2DShadow;
	precision ${s.precision} samplerCubeShadow;
	precision ${s.precision} sampler2DArrayShadow;
	precision ${s.precision} isampler2D;
	precision ${s.precision} isampler3D;
	precision ${s.precision} isamplerCube;
	precision ${s.precision} isampler2DArray;
	precision ${s.precision} usampler2D;
	precision ${s.precision} usampler3D;
	precision ${s.precision} usamplerCube;
	precision ${s.precision} usampler2DArray;
	`;return s.precision==="highp"?e+=`
#define HIGH_PRECISION`:s.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:s.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const bw={[lc]:"SHADOWMAP_TYPE_PCF",[vo]:"SHADOWMAP_TYPE_VSM"};function Sw(s){return bw[s.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const Mw={[ws]:"ENVMAP_TYPE_CUBE",[ba]:"ENVMAP_TYPE_CUBE",[Dc]:"ENVMAP_TYPE_CUBE_UV"};function ww(s){return s.envMap===!1?"ENVMAP_TYPE_CUBE":Mw[s.envMapMode]||"ENVMAP_TYPE_CUBE"}const Ew={[ba]:"ENVMAP_MODE_REFRACTION"};function Tw(s){return s.envMap===!1?"ENVMAP_MODE_REFLECTION":Ew[s.envMapMode]||"ENVMAP_MODE_REFLECTION"}const Aw={[gg]:"ENVMAP_BLENDING_MULTIPLY",[cy]:"ENVMAP_BLENDING_MIX",[uy]:"ENVMAP_BLENDING_ADD"};function Cw(s){return s.envMap===!1?"ENVMAP_BLENDING_NONE":Aw[s.combine]||"ENVMAP_BLENDING_NONE"}function Rw(s){const e=s.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,r=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:r,maxMip:t}}function Pw(s,e,t,r){const a=s.getContext(),l=t.defines;let u=t.vertexShader,h=t.fragmentShader;const p=Sw(t),f=ww(t),g=Tw(t),b=Cw(t),v=Rw(t),S=fw(t),M=pw(l),E=a.createProgram();let x,_,N=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(x=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,M].filter(_o).join(`
`),x.length>0&&(x+=`
`),_=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,M].filter(_o).join(`
`),_.length>0&&(_+=`
`)):(x=[Z0(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,M,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+g:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexNormals?"#define HAS_NORMAL":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+p:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(_o).join(`
`),_=[Z0(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,M,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+f:"",t.envMap?"#define "+g:"",t.envMap?"#define "+b:"",v?"#define CUBEUV_TEXEL_WIDTH "+v.texelWidth:"",v?"#define CUBEUV_TEXEL_HEIGHT "+v.texelHeight:"",v?"#define CUBEUV_MAX_MIP "+v.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas||t.batchingColor?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+p:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Ji?"#define TONE_MAPPING":"",t.toneMapping!==Ji?Mt.tonemapping_pars_fragment:"",t.toneMapping!==Ji?dw("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Mt.colorspace_pars_fragment,cw("linearToOutputTexel",t.outputColorSpace),hw(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(_o).join(`
`)),u=Wh(u),u=$0(u,t),u=Y0(u,t),h=Wh(h),h=$0(h,t),h=Y0(h,t),u=K0(u),h=K0(h),t.isRawShaderMaterial!==!0&&(N=`#version 300 es
`,x=[S,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+x,_=["#define varying in",t.glslVersion===t0?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===t0?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+_);const P=N+x+u,C=N+_+h,k=W0(a,a.VERTEX_SHADER,P),D=W0(a,a.FRAGMENT_SHADER,C);a.attachShader(E,k),a.attachShader(E,D),t.index0AttributeName!==void 0?a.bindAttribLocation(E,0,t.index0AttributeName):t.hasPositionAttribute===!0&&a.bindAttribLocation(E,0,"position"),a.linkProgram(E);function U(O){if(s.debug.checkShaderErrors){const H=a.getProgramInfoLog(E)||"",fe=a.getShaderInfoLog(k)||"",re=a.getShaderInfoLog(D)||"",q=H.trim(),de=fe.trim(),oe=re.trim();let Z=!0,ee=!0;if(a.getProgramParameter(E,a.LINK_STATUS)===!1)if(Z=!1,typeof s.debug.onShaderError=="function")s.debug.onShaderError(a,E,k,D);else{const ce=q0(a,k,"vertex"),F=q0(a,D,"fragment");Ut("WebGLProgram: Shader Error "+a.getError()+" - VALIDATE_STATUS "+a.getProgramParameter(E,a.VALIDATE_STATUS)+`

Material Name: `+O.name+`
Material Type: `+O.type+`

Program Info Log: `+q+`
`+ce+`
`+F)}else q!==""?gt("WebGLProgram: Program Info Log:",q):(de===""||oe==="")&&(ee=!1);ee&&(O.diagnostics={runnable:Z,programLog:q,vertexShader:{log:de,prefix:x},fragmentShader:{log:oe,prefix:_}})}a.deleteShader(k),a.deleteShader(D),T=new pc(a,E),I=mw(a,E)}let T;this.getUniforms=function(){return T===void 0&&U(this),T};let I;this.getAttributes=function(){return I===void 0&&U(this),I};let z=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return z===!1&&(z=a.getProgramParameter(E,sw)),z},this.destroy=function(){r.releaseStatesOfProgram(this),a.deleteProgram(E),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=aw++,this.cacheKey=e,this.usedTimes=1,this.program=E,this.vertexShader=k,this.fragmentShader=D,this}let Nw=0;class Lw{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,r){const a=this._getShaderCacheForMaterial(e);return a.has(t)===!1&&(a.add(t),t.usedTimes++),a.has(r)===!1&&(a.add(r),r.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const r of t)r.usedTimes--,r.usedTimes===0&&this.shaderCache.delete(r.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let r=t.get(e);return r===void 0&&(r=new Set,t.set(e,r)),r}_getShaderStage(e){const t=this.shaderCache;let r=t.get(e);return r===void 0&&(r=new Dw(e),t.set(e,r)),r}}class Dw{constructor(e){this.id=Nw++,this.code=e,this.usedTimes=0}}function Iw(s){return s===Qr||s===bc||s===Sc}function kw(s,e,t,r,a,l){const u=new uf,h=new Lw,p=new Set,f=[],g=new Map,b=r.logarithmicDepthBuffer;let v=r.precision;const S={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function M(T){return p.add(T),T===0?"uv":`uv${T}`}function E(T,I,z,O,H,fe){const re=O.fog,q=H.geometry,de=T.isMeshStandardMaterial||T.isMeshLambertMaterial||T.isMeshPhongMaterial?O.environment:null,oe=T.isMeshStandardMaterial||T.isMeshLambertMaterial&&!T.envMap||T.isMeshPhongMaterial&&!T.envMap,Z=e.get(T.envMap||de,oe),ee=Z&&Z.mapping===Dc?Z.image.height:null,ce=S[T.type];T.precision!==null&&(v=r.getMaxPrecision(T.precision),v!==T.precision&&gt("WebGLProgram.getParameters:",T.precision,"not supported, using",v,"instead."));const F=q.morphAttributes.position||q.morphAttributes.normal||q.morphAttributes.color,Y=F!==void 0?F.length:0;let Ce=0;q.morphAttributes.position!==void 0&&(Ce=1),q.morphAttributes.normal!==void 0&&(Ce=2),q.morphAttributes.color!==void 0&&(Ce=3);let qe,we,ie,xe;if(ce){const je=Ki[ce];qe=je.vertexShader,we=je.fragmentShader}else{qe=T.vertexShader,we=T.fragmentShader;const je=h.getVertexShaderStage(T),ht=h.getFragmentShaderStage(T);h.update(T,je,ht),ie=je.id,xe=ht.id}const ve=s.getRenderTarget(),te=s.state.buffers.depth.getReversed(),Se=H.isInstancedMesh===!0,Qe=H.isBatchedMesh===!0,Ft=!!T.map,ut=!!T.matcap,Ct=!!Z,it=!!T.aoMap,Je=!!T.lightMap,Lt=!!T.bumpMap&&T.wireframe===!1,zt=!!T.normalMap,St=!!T.displacementMap,Dt=!!T.emissiveMap,wt=!!T.metalnessMap,ct=!!T.roughnessMap,Q=T.anisotropy>0,et=T.clearcoat>0,ze=T.dispersion>0,L=T.iridescence>0,w=T.sheen>0,$=T.transmission>0,ae=Q&&!!T.anisotropyMap,me=et&&!!T.clearcoatMap,Me=et&&!!T.clearcoatNormalMap,Ne=et&&!!T.clearcoatRoughnessMap,ue=L&&!!T.iridescenceMap,ye=L&&!!T.iridescenceThicknessMap,Ee=w&&!!T.sheenColorMap,He=w&&!!T.sheenRoughnessMap,Ie=!!T.specularMap,ke=!!T.specularColorMap,We=!!T.specularIntensityMap,Ze=$&&!!T.transmissionMap,at=$&&!!T.thicknessMap,G=!!T.gradientMap,Fe=!!T.alphaMap,j=T.alphaTest>0,be=!!T.alphaHash,Re=!!T.extensions;let _e=Ji;T.toneMapped&&(ve===null||ve.isXRRenderTarget===!0)&&(_e=s.toneMapping);const Be={shaderID:ce,shaderType:T.type,shaderName:T.name,vertexShader:qe,fragmentShader:we,defines:T.defines,customVertexShaderID:ie,customFragmentShaderID:xe,isRawShaderMaterial:T.isRawShaderMaterial===!0,glslVersion:T.glslVersion,precision:v,batching:Qe,batchingColor:Qe&&H._colorsTexture!==null,instancing:Se,instancingColor:Se&&H.instanceColor!==null,instancingMorph:Se&&H.morphTexture!==null,outputColorSpace:ve===null?s.outputColorSpace:ve.isXRRenderTarget===!0?ve.texture.colorSpace:kt.workingColorSpace,alphaToCoverage:!!T.alphaToCoverage,map:Ft,matcap:ut,envMap:Ct,envMapMode:Ct&&Z.mapping,envMapCubeUVHeight:ee,aoMap:it,lightMap:Je,bumpMap:Lt,normalMap:zt,displacementMap:St,emissiveMap:Dt,normalMapObjectSpace:zt&&T.normalMapType===fy,normalMapTangentSpace:zt&&T.normalMapType===Qm,packedNormalMap:zt&&T.normalMapType===Qm&&Iw(T.normalMap.format),metalnessMap:wt,roughnessMap:ct,anisotropy:Q,anisotropyMap:ae,clearcoat:et,clearcoatMap:me,clearcoatNormalMap:Me,clearcoatRoughnessMap:Ne,dispersion:ze,iridescence:L,iridescenceMap:ue,iridescenceThicknessMap:ye,sheen:w,sheenColorMap:Ee,sheenRoughnessMap:He,specularMap:Ie,specularColorMap:ke,specularIntensityMap:We,transmission:$,transmissionMap:Ze,thicknessMap:at,gradientMap:G,opaque:T.transparent===!1&&T.blending===Ms&&T.alphaToCoverage===!1,alphaMap:Fe,alphaTest:j,alphaHash:be,combine:T.combine,mapUv:Ft&&M(T.map.channel),aoMapUv:it&&M(T.aoMap.channel),lightMapUv:Je&&M(T.lightMap.channel),bumpMapUv:Lt&&M(T.bumpMap.channel),normalMapUv:zt&&M(T.normalMap.channel),displacementMapUv:St&&M(T.displacementMap.channel),emissiveMapUv:Dt&&M(T.emissiveMap.channel),metalnessMapUv:wt&&M(T.metalnessMap.channel),roughnessMapUv:ct&&M(T.roughnessMap.channel),anisotropyMapUv:ae&&M(T.anisotropyMap.channel),clearcoatMapUv:me&&M(T.clearcoatMap.channel),clearcoatNormalMapUv:Me&&M(T.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ne&&M(T.clearcoatRoughnessMap.channel),iridescenceMapUv:ue&&M(T.iridescenceMap.channel),iridescenceThicknessMapUv:ye&&M(T.iridescenceThicknessMap.channel),sheenColorMapUv:Ee&&M(T.sheenColorMap.channel),sheenRoughnessMapUv:He&&M(T.sheenRoughnessMap.channel),specularMapUv:Ie&&M(T.specularMap.channel),specularColorMapUv:ke&&M(T.specularColorMap.channel),specularIntensityMapUv:We&&M(T.specularIntensityMap.channel),transmissionMapUv:Ze&&M(T.transmissionMap.channel),thicknessMapUv:at&&M(T.thicknessMap.channel),alphaMapUv:Fe&&M(T.alphaMap.channel),vertexTangents:!!q.attributes.tangent&&(zt||Q),vertexNormals:!!q.attributes.normal,vertexColors:T.vertexColors,vertexAlphas:T.vertexColors===!0&&!!q.attributes.color&&q.attributes.color.itemSize===4,pointsUvs:H.isPoints===!0&&!!q.attributes.uv&&(Ft||Fe),fog:!!re,useFog:T.fog===!0,fogExp2:!!re&&re.isFogExp2,flatShading:T.wireframe===!1&&(T.flatShading===!0||q.attributes.normal===void 0&&zt===!1&&(T.isMeshLambertMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isMeshPhysicalMaterial)),sizeAttenuation:T.sizeAttenuation===!0,logarithmicDepthBuffer:b,reversedDepthBuffer:te,skinning:H.isSkinnedMesh===!0,hasPositionAttribute:q.attributes.position!==void 0,morphTargets:q.morphAttributes.position!==void 0,morphNormals:q.morphAttributes.normal!==void 0,morphColors:q.morphAttributes.color!==void 0,morphTargetsCount:Y,morphTextureStride:Ce,numDirLights:I.directional.length,numPointLights:I.point.length,numSpotLights:I.spot.length,numSpotLightMaps:I.spotLightMap.length,numRectAreaLights:I.rectArea.length,numHemiLights:I.hemi.length,numDirLightShadows:I.directionalShadowMap.length,numPointLightShadows:I.pointShadowMap.length,numSpotLightShadows:I.spotShadowMap.length,numSpotLightShadowsWithMaps:I.numSpotLightShadowsWithMaps,numLightProbes:I.numLightProbes,numLightProbeGrids:fe.length,numClippingPlanes:l.numPlanes,numClipIntersection:l.numIntersection,dithering:T.dithering,shadowMapEnabled:s.shadowMap.enabled&&z.length>0,shadowMapType:s.shadowMap.type,toneMapping:_e,decodeVideoTexture:Ft&&T.map.isVideoTexture===!0&&kt.getTransfer(T.map.colorSpace)===Wt,decodeVideoTextureEmissive:Dt&&T.emissiveMap.isVideoTexture===!0&&kt.getTransfer(T.emissiveMap.colorSpace)===Wt,premultipliedAlpha:T.premultipliedAlpha,doubleSided:T.side===Fi,flipSided:T.side===si,useDepthPacking:T.depthPacking>=0,depthPacking:T.depthPacking||0,index0AttributeName:T.index0AttributeName,extensionClipCullDistance:Re&&T.extensions.clipCullDistance===!0&&t.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Re&&T.extensions.multiDraw===!0||Qe)&&t.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:t.has("KHR_parallel_shader_compile"),customProgramCacheKey:T.customProgramCacheKey()};return Be.vertexUv1s=p.has(1),Be.vertexUv2s=p.has(2),Be.vertexUv3s=p.has(3),p.clear(),Be}function x(T){const I=[];if(T.shaderID?I.push(T.shaderID):(I.push(T.customVertexShaderID),I.push(T.customFragmentShaderID)),T.defines!==void 0)for(const z in T.defines)I.push(z),I.push(T.defines[z]);return T.isRawShaderMaterial===!1&&(_(I,T),N(I,T),I.push(s.outputColorSpace)),I.push(T.customProgramCacheKey),I.join()}function _(T,I){T.push(I.precision),T.push(I.outputColorSpace),T.push(I.envMapMode),T.push(I.envMapCubeUVHeight),T.push(I.mapUv),T.push(I.alphaMapUv),T.push(I.lightMapUv),T.push(I.aoMapUv),T.push(I.bumpMapUv),T.push(I.normalMapUv),T.push(I.displacementMapUv),T.push(I.emissiveMapUv),T.push(I.metalnessMapUv),T.push(I.roughnessMapUv),T.push(I.anisotropyMapUv),T.push(I.clearcoatMapUv),T.push(I.clearcoatNormalMapUv),T.push(I.clearcoatRoughnessMapUv),T.push(I.iridescenceMapUv),T.push(I.iridescenceThicknessMapUv),T.push(I.sheenColorMapUv),T.push(I.sheenRoughnessMapUv),T.push(I.specularMapUv),T.push(I.specularColorMapUv),T.push(I.specularIntensityMapUv),T.push(I.transmissionMapUv),T.push(I.thicknessMapUv),T.push(I.combine),T.push(I.fogExp2),T.push(I.sizeAttenuation),T.push(I.morphTargetsCount),T.push(I.morphAttributeCount),T.push(I.numDirLights),T.push(I.numPointLights),T.push(I.numSpotLights),T.push(I.numSpotLightMaps),T.push(I.numHemiLights),T.push(I.numRectAreaLights),T.push(I.numDirLightShadows),T.push(I.numPointLightShadows),T.push(I.numSpotLightShadows),T.push(I.numSpotLightShadowsWithMaps),T.push(I.numLightProbes),T.push(I.shadowMapType),T.push(I.toneMapping),T.push(I.numClippingPlanes),T.push(I.numClipIntersection),T.push(I.depthPacking)}function N(T,I){u.disableAll(),I.instancing&&u.enable(0),I.instancingColor&&u.enable(1),I.instancingMorph&&u.enable(2),I.matcap&&u.enable(3),I.envMap&&u.enable(4),I.normalMapObjectSpace&&u.enable(5),I.normalMapTangentSpace&&u.enable(6),I.clearcoat&&u.enable(7),I.iridescence&&u.enable(8),I.alphaTest&&u.enable(9),I.vertexColors&&u.enable(10),I.vertexAlphas&&u.enable(11),I.vertexUv1s&&u.enable(12),I.vertexUv2s&&u.enable(13),I.vertexUv3s&&u.enable(14),I.vertexTangents&&u.enable(15),I.anisotropy&&u.enable(16),I.alphaHash&&u.enable(17),I.batching&&u.enable(18),I.dispersion&&u.enable(19),I.batchingColor&&u.enable(20),I.gradientMap&&u.enable(21),I.packedNormalMap&&u.enable(22),I.vertexNormals&&u.enable(23),T.push(u.mask),u.disableAll(),I.fog&&u.enable(0),I.useFog&&u.enable(1),I.flatShading&&u.enable(2),I.logarithmicDepthBuffer&&u.enable(3),I.reversedDepthBuffer&&u.enable(4),I.skinning&&u.enable(5),I.morphTargets&&u.enable(6),I.morphNormals&&u.enable(7),I.morphColors&&u.enable(8),I.premultipliedAlpha&&u.enable(9),I.shadowMapEnabled&&u.enable(10),I.doubleSided&&u.enable(11),I.flipSided&&u.enable(12),I.useDepthPacking&&u.enable(13),I.dithering&&u.enable(14),I.transmission&&u.enable(15),I.sheen&&u.enable(16),I.opaque&&u.enable(17),I.pointsUvs&&u.enable(18),I.decodeVideoTexture&&u.enable(19),I.decodeVideoTextureEmissive&&u.enable(20),I.alphaToCoverage&&u.enable(21),I.numLightProbeGrids>0&&u.enable(22),I.hasPositionAttribute&&u.enable(23),T.push(u.mask)}function P(T){const I=S[T.type];let z;if(I){const O=Ki[I];z=Rc.clone(O.uniforms)}else z=T.uniforms;return z}function C(T,I){let z=g.get(I);return z!==void 0?++z.usedTimes:(z=new Pw(s,I,T,a),f.push(z),g.set(I,z)),z}function k(T){if(--T.usedTimes===0){const I=f.indexOf(T);f[I]=f[f.length-1],f.pop(),g.delete(T.cacheKey),T.destroy()}}function D(T){h.remove(T)}function U(){h.dispose()}return{getParameters:E,getProgramCacheKey:x,getUniforms:P,acquireProgram:C,releaseProgram:k,releaseShaderCache:D,programs:f,dispose:U}}function Fw(){let s=new WeakMap;function e(u){return s.has(u)}function t(u){let h=s.get(u);return h===void 0&&(h={},s.set(u,h)),h}function r(u){s.delete(u)}function a(u,h,p){s.get(u)[h]=p}function l(){s=new WeakMap}return{has:e,get:t,remove:r,update:a,dispose:l}}function Uw(s,e){return s.groupOrder!==e.groupOrder?s.groupOrder-e.groupOrder:s.renderOrder!==e.renderOrder?s.renderOrder-e.renderOrder:s.material.id!==e.material.id?s.material.id-e.material.id:s.materialVariant!==e.materialVariant?s.materialVariant-e.materialVariant:s.z!==e.z?s.z-e.z:s.id-e.id}function Q0(s,e){return s.groupOrder!==e.groupOrder?s.groupOrder-e.groupOrder:s.renderOrder!==e.renderOrder?s.renderOrder-e.renderOrder:s.z!==e.z?e.z-s.z:s.id-e.id}function J0(){const s=[];let e=0;const t=[],r=[],a=[];function l(){e=0,t.length=0,r.length=0,a.length=0}function u(v){let S=0;return v.isInstancedMesh&&(S+=2),v.isSkinnedMesh&&(S+=1),S}function h(v,S,M,E,x,_){let N=s[e];return N===void 0?(N={id:v.id,object:v,geometry:S,material:M,materialVariant:u(v),groupOrder:E,renderOrder:v.renderOrder,z:x,group:_},s[e]=N):(N.id=v.id,N.object=v,N.geometry=S,N.material=M,N.materialVariant=u(v),N.groupOrder=E,N.renderOrder=v.renderOrder,N.z=x,N.group=_),e++,N}function p(v,S,M,E,x,_){const N=h(v,S,M,E,x,_);M.transmission>0?r.push(N):M.transparent===!0?a.push(N):t.push(N)}function f(v,S,M,E,x,_){const N=h(v,S,M,E,x,_);M.transmission>0?r.unshift(N):M.transparent===!0?a.unshift(N):t.unshift(N)}function g(v,S,M){t.length>1&&t.sort(v||Uw),r.length>1&&r.sort(S||Q0),a.length>1&&a.sort(S||Q0),M&&(t.reverse(),r.reverse(),a.reverse())}function b(){for(let v=e,S=s.length;v<S;v++){const M=s[v];if(M.id===null)break;M.id=null,M.object=null,M.geometry=null,M.material=null,M.group=null}}return{opaque:t,transmissive:r,transparent:a,init:l,push:p,unshift:f,finish:b,sort:g}}function Ow(){let s=new WeakMap;function e(r,a){const l=s.get(r);let u;return l===void 0?(u=new J0,s.set(r,[u])):a>=l.length?(u=new J0,l.push(u)):u=l[a],u}function t(){s=new WeakMap}return{get:e,dispose:t}}function Bw(){const s={};return{get:function(e){if(s[e.id]!==void 0)return s[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new X,color:new _t};break;case"SpotLight":t={position:new X,direction:new X,color:new _t,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new X,color:new _t,distance:0,decay:0};break;case"HemisphereLight":t={direction:new X,skyColor:new _t,groundColor:new _t};break;case"RectAreaLight":t={color:new _t,position:new X,halfWidth:new X,halfHeight:new X};break}return s[e.id]=t,t}}}function zw(){const s={};return{get:function(e){if(s[e.id]!==void 0)return s[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new dt};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new dt};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new dt,shadowCameraNear:1,shadowCameraFar:1e3};break}return s[e.id]=t,t}}}let jw=0;function Hw(s,e){return(e.castShadow?2:0)-(s.castShadow?2:0)+(e.map?1:0)-(s.map?1:0)}function Vw(s){const e=new Bw,t=zw(),r={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let f=0;f<9;f++)r.probe.push(new X);const a=new X,l=new en,u=new en;function h(f){let g=0,b=0,v=0;for(let I=0;I<9;I++)r.probe[I].set(0,0,0);let S=0,M=0,E=0,x=0,_=0,N=0,P=0,C=0,k=0,D=0,U=0;f.sort(Hw);for(let I=0,z=f.length;I<z;I++){const O=f[I],H=O.color,fe=O.intensity,re=O.distance;let q=null;if(O.shadow&&O.shadow.map&&(O.shadow.map.texture.format===Qr?q=O.shadow.map.texture:q=O.shadow.map.depthTexture||O.shadow.map.texture),O.isAmbientLight)g+=H.r*fe,b+=H.g*fe,v+=H.b*fe;else if(O.isLightProbe){for(let de=0;de<9;de++)r.probe[de].addScaledVector(O.sh.coefficients[de],fe);U++}else if(O.isDirectionalLight){const de=e.get(O);if(de.color.copy(O.color).multiplyScalar(O.intensity),O.castShadow){const oe=O.shadow,Z=t.get(O);Z.shadowIntensity=oe.intensity,Z.shadowBias=oe.bias,Z.shadowNormalBias=oe.normalBias,Z.shadowRadius=oe.radius,Z.shadowMapSize=oe.mapSize,r.directionalShadow[S]=Z,r.directionalShadowMap[S]=q,r.directionalShadowMatrix[S]=O.shadow.matrix,N++}r.directional[S]=de,S++}else if(O.isSpotLight){const de=e.get(O);de.position.setFromMatrixPosition(O.matrixWorld),de.color.copy(H).multiplyScalar(fe),de.distance=re,de.coneCos=Math.cos(O.angle),de.penumbraCos=Math.cos(O.angle*(1-O.penumbra)),de.decay=O.decay,r.spot[E]=de;const oe=O.shadow;if(O.map&&(r.spotLightMap[k]=O.map,k++,oe.updateMatrices(O),O.castShadow&&D++),r.spotLightMatrix[E]=oe.matrix,O.castShadow){const Z=t.get(O);Z.shadowIntensity=oe.intensity,Z.shadowBias=oe.bias,Z.shadowNormalBias=oe.normalBias,Z.shadowRadius=oe.radius,Z.shadowMapSize=oe.mapSize,r.spotShadow[E]=Z,r.spotShadowMap[E]=q,C++}E++}else if(O.isRectAreaLight){const de=e.get(O);de.color.copy(H).multiplyScalar(fe),de.halfWidth.set(O.width*.5,0,0),de.halfHeight.set(0,O.height*.5,0),r.rectArea[x]=de,x++}else if(O.isPointLight){const de=e.get(O);if(de.color.copy(O.color).multiplyScalar(O.intensity),de.distance=O.distance,de.decay=O.decay,O.castShadow){const oe=O.shadow,Z=t.get(O);Z.shadowIntensity=oe.intensity,Z.shadowBias=oe.bias,Z.shadowNormalBias=oe.normalBias,Z.shadowRadius=oe.radius,Z.shadowMapSize=oe.mapSize,Z.shadowCameraNear=oe.camera.near,Z.shadowCameraFar=oe.camera.far,r.pointShadow[M]=Z,r.pointShadowMap[M]=q,r.pointShadowMatrix[M]=O.shadow.matrix,P++}r.point[M]=de,M++}else if(O.isHemisphereLight){const de=e.get(O);de.skyColor.copy(O.color).multiplyScalar(fe),de.groundColor.copy(O.groundColor).multiplyScalar(fe),r.hemi[_]=de,_++}}x>0&&(s.has("OES_texture_float_linear")===!0?(r.rectAreaLTC1=Ge.LTC_FLOAT_1,r.rectAreaLTC2=Ge.LTC_FLOAT_2):(r.rectAreaLTC1=Ge.LTC_HALF_1,r.rectAreaLTC2=Ge.LTC_HALF_2)),r.ambient[0]=g,r.ambient[1]=b,r.ambient[2]=v;const T=r.hash;(T.directionalLength!==S||T.pointLength!==M||T.spotLength!==E||T.rectAreaLength!==x||T.hemiLength!==_||T.numDirectionalShadows!==N||T.numPointShadows!==P||T.numSpotShadows!==C||T.numSpotMaps!==k||T.numLightProbes!==U)&&(r.directional.length=S,r.spot.length=E,r.rectArea.length=x,r.point.length=M,r.hemi.length=_,r.directionalShadow.length=N,r.directionalShadowMap.length=N,r.pointShadow.length=P,r.pointShadowMap.length=P,r.spotShadow.length=C,r.spotShadowMap.length=C,r.directionalShadowMatrix.length=N,r.pointShadowMatrix.length=P,r.spotLightMatrix.length=C+k-D,r.spotLightMap.length=k,r.numSpotLightShadowsWithMaps=D,r.numLightProbes=U,T.directionalLength=S,T.pointLength=M,T.spotLength=E,T.rectAreaLength=x,T.hemiLength=_,T.numDirectionalShadows=N,T.numPointShadows=P,T.numSpotShadows=C,T.numSpotMaps=k,T.numLightProbes=U,r.version=jw++)}function p(f,g){let b=0,v=0,S=0,M=0,E=0;const x=g.matrixWorldInverse;for(let _=0,N=f.length;_<N;_++){const P=f[_];if(P.isDirectionalLight){const C=r.directional[b];C.direction.setFromMatrixPosition(P.matrixWorld),a.setFromMatrixPosition(P.target.matrixWorld),C.direction.sub(a),C.direction.transformDirection(x),b++}else if(P.isSpotLight){const C=r.spot[S];C.position.setFromMatrixPosition(P.matrixWorld),C.position.applyMatrix4(x),C.direction.setFromMatrixPosition(P.matrixWorld),a.setFromMatrixPosition(P.target.matrixWorld),C.direction.sub(a),C.direction.transformDirection(x),S++}else if(P.isRectAreaLight){const C=r.rectArea[M];C.position.setFromMatrixPosition(P.matrixWorld),C.position.applyMatrix4(x),u.identity(),l.copy(P.matrixWorld),l.premultiply(x),u.extractRotation(l),C.halfWidth.set(P.width*.5,0,0),C.halfHeight.set(0,P.height*.5,0),C.halfWidth.applyMatrix4(u),C.halfHeight.applyMatrix4(u),M++}else if(P.isPointLight){const C=r.point[v];C.position.setFromMatrixPosition(P.matrixWorld),C.position.applyMatrix4(x),v++}else if(P.isHemisphereLight){const C=r.hemi[E];C.direction.setFromMatrixPosition(P.matrixWorld),C.direction.transformDirection(x),E++}}}return{setup:h,setupView:p,state:r}}function eg(s){const e=new Vw(s),t=[],r=[],a=[];function l(v){b.camera=v,t.length=0,r.length=0,a.length=0}function u(v){t.push(v)}function h(v){r.push(v)}function p(v){a.push(v)}function f(){e.setup(t)}function g(v){e.setupView(t,v)}const b={lightsArray:t,shadowsArray:r,lightProbeGridArray:a,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:l,state:b,setupLights:f,setupLightsView:g,pushLight:u,pushShadow:h,pushLightProbeGrid:p}}function Gw(s){let e=new WeakMap;function t(a,l=0){const u=e.get(a);let h;return u===void 0?(h=new eg(s),e.set(a,[h])):l>=u.length?(h=new eg(s),u.push(h)):h=u[l],h}function r(){e=new WeakMap}return{get:t,dispose:r}}const Ww=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Xw=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,qw=[new X(1,0,0),new X(-1,0,0),new X(0,1,0),new X(0,-1,0),new X(0,0,1),new X(0,0,-1)],$w=[new X(0,-1,0),new X(0,-1,0),new X(0,0,1),new X(0,0,-1),new X(0,-1,0),new X(0,-1,0)],tg=new en,mo=new X,Kd=new X;function Yw(s,e,t){let r=new Og;const a=new dt,l=new dt,u=new un,h=new r1,p=new s1,f={},g=t.maxTextureSize,b={[Zr]:si,[si]:Zr,[Fi]:Fi},v=new _n({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new dt},radius:{value:4}},vertexShader:Ww,fragmentShader:Xw}),S=v.clone();S.defines.HORIZONTAL_PASS=1;const M=new jn;M.setAttribute("position",new An(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const E=new wi(M,v),x=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=lc;let _=this.type;this.render=function(D,U,T){if(x.enabled===!1||x.autoUpdate===!1&&x.needsUpdate===!1||D.length===0)return;this.type===G_&&(gt("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=lc);const I=s.getRenderTarget(),z=s.getActiveCubeFace(),O=s.getActiveMipmapLevel(),H=s.state;H.setBlending(Qi),H.buffers.depth.getReversed()===!0?H.buffers.color.setClear(0,0,0,0):H.buffers.color.setClear(1,1,1,1),H.buffers.depth.setTest(!0),H.setScissorTest(!1);const fe=_!==this.type;fe&&U.traverse(function(re){re.material&&(Array.isArray(re.material)?re.material.forEach(q=>q.needsUpdate=!0):re.material.needsUpdate=!0)});for(let re=0,q=D.length;re<q;re++){const de=D[re],oe=de.shadow;if(oe===void 0){gt("WebGLShadowMap:",de,"has no shadow.");continue}if(oe.autoUpdate===!1&&oe.needsUpdate===!1)continue;a.copy(oe.mapSize);const Z=oe.getFrameExtents();a.multiply(Z),l.copy(oe.mapSize),(a.x>g||a.y>g)&&(a.x>g&&(l.x=Math.floor(g/Z.x),a.x=l.x*Z.x,oe.mapSize.x=l.x),a.y>g&&(l.y=Math.floor(g/Z.y),a.y=l.y*Z.y,oe.mapSize.y=l.y));const ee=s.state.buffers.depth.getReversed();if(oe.camera._reversedDepth=ee,oe.map===null||fe===!0){if(oe.map!==null&&(oe.map.depthTexture!==null&&(oe.map.depthTexture.dispose(),oe.map.depthTexture=null),oe.map.dispose()),this.type===vo){if(de.isPointLight){gt("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}oe.map=new ai(a.x,a.y,{format:Qr,type:fi,minFilter:zn,magFilter:zn,generateMipmaps:!1}),oe.map.texture.name=de.name+".shadowMap",oe.map.depthTexture=new Sa(a.x,a.y,Oi),oe.map.depthTexture.name=de.name+".shadowMapDepth",oe.map.depthTexture.format=yr,oe.map.depthTexture.compareFunction=null,oe.map.depthTexture.minFilter=Dn,oe.map.depthTexture.magFilter=Dn}else de.isPointLight?(oe.map=new qg(a.x),oe.map.depthTexture=new Zy(a.x,er)):(oe.map=new ai(a.x,a.y),oe.map.depthTexture=new Sa(a.x,a.y,er)),oe.map.depthTexture.name=de.name+".shadowMap",oe.map.depthTexture.format=yr,this.type===lc?(oe.map.depthTexture.compareFunction=ee?lf:of,oe.map.depthTexture.minFilter=zn,oe.map.depthTexture.magFilter=zn):(oe.map.depthTexture.compareFunction=null,oe.map.depthTexture.minFilter=Dn,oe.map.depthTexture.magFilter=Dn);oe.camera.updateProjectionMatrix()}const ce=oe.map.isWebGLCubeRenderTarget?6:1;for(let F=0;F<ce;F++){if(oe.map.isWebGLCubeRenderTarget)s.setRenderTarget(oe.map,F),s.clear();else{F===0&&(s.setRenderTarget(oe.map),s.clear());const Y=oe.getViewport(F);u.set(l.x*Y.x,l.y*Y.y,l.x*Y.z,l.y*Y.w),H.viewport(u)}if(de.isPointLight){const Y=oe.camera,Ce=oe.matrix,qe=de.distance||Y.far;qe!==Y.far&&(Y.far=qe,Y.updateProjectionMatrix()),mo.setFromMatrixPosition(de.matrixWorld),Y.position.copy(mo),Kd.copy(Y.position),Kd.add(qw[F]),Y.up.copy($w[F]),Y.lookAt(Kd),Y.updateMatrixWorld(),Ce.makeTranslation(-mo.x,-mo.y,-mo.z),tg.multiplyMatrices(Y.projectionMatrix,Y.matrixWorldInverse),oe._frustum.setFromProjectionMatrix(tg,Y.coordinateSystem,Y.reversedDepth)}else oe.updateMatrices(de);r=oe.getFrustum(),C(U,T,oe.camera,de,this.type)}oe.isPointLightShadow!==!0&&this.type===vo&&N(oe,T),oe.needsUpdate=!1}_=this.type,x.needsUpdate=!1,s.setRenderTarget(I,z,O)};function N(D,U){const T=e.update(E);v.defines.VSM_SAMPLES!==D.blurSamples&&(v.defines.VSM_SAMPLES=D.blurSamples,S.defines.VSM_SAMPLES=D.blurSamples,v.needsUpdate=!0,S.needsUpdate=!0),D.mapPass===null&&(D.mapPass=new ai(a.x,a.y,{format:Qr,type:fi})),v.uniforms.shadow_pass.value=D.map.depthTexture,v.uniforms.resolution.value=D.mapSize,v.uniforms.radius.value=D.radius,s.setRenderTarget(D.mapPass),s.clear(),s.renderBufferDirect(U,null,T,v,E,null),S.uniforms.shadow_pass.value=D.mapPass.texture,S.uniforms.resolution.value=D.mapSize,S.uniforms.radius.value=D.radius,s.setRenderTarget(D.map),s.clear(),s.renderBufferDirect(U,null,T,S,E,null)}function P(D,U,T,I){let z=null;const O=T.isPointLight===!0?D.customDistanceMaterial:D.customDepthMaterial;if(O!==void 0)z=O;else if(z=T.isPointLight===!0?p:h,s.localClippingEnabled&&U.clipShadows===!0&&Array.isArray(U.clippingPlanes)&&U.clippingPlanes.length!==0||U.displacementMap&&U.displacementScale!==0||U.alphaMap&&U.alphaTest>0||U.map&&U.alphaTest>0||U.alphaToCoverage===!0){const H=z.uuid,fe=U.uuid;let re=f[H];re===void 0&&(re={},f[H]=re);let q=re[fe];q===void 0&&(q=z.clone(),re[fe]=q,U.addEventListener("dispose",k)),z=q}if(z.visible=U.visible,z.wireframe=U.wireframe,I===vo?z.side=U.shadowSide!==null?U.shadowSide:U.side:z.side=U.shadowSide!==null?U.shadowSide:b[U.side],z.alphaMap=U.alphaMap,z.alphaTest=U.alphaToCoverage===!0?.5:U.alphaTest,z.map=U.map,z.clipShadows=U.clipShadows,z.clippingPlanes=U.clippingPlanes,z.clipIntersection=U.clipIntersection,z.displacementMap=U.displacementMap,z.displacementScale=U.displacementScale,z.displacementBias=U.displacementBias,z.wireframeLinewidth=U.wireframeLinewidth,z.linewidth=U.linewidth,T.isPointLight===!0&&z.isMeshDistanceMaterial===!0){const H=s.properties.get(z);H.light=T}return z}function C(D,U,T,I,z){if(D.visible===!1)return;if(D.layers.test(U.layers)&&(D.isMesh||D.isLine||D.isPoints)&&(D.castShadow||D.receiveShadow&&z===vo)&&(!D.frustumCulled||r.intersectsObject(D))){D.modelViewMatrix.multiplyMatrices(T.matrixWorldInverse,D.matrixWorld);const fe=e.update(D),re=D.material;if(Array.isArray(re)){const q=fe.groups;for(let de=0,oe=q.length;de<oe;de++){const Z=q[de],ee=re[Z.materialIndex];if(ee&&ee.visible){const ce=P(D,ee,I,z);D.onBeforeShadow(s,D,U,T,fe,ce,Z),s.renderBufferDirect(T,null,fe,ce,D,Z),D.onAfterShadow(s,D,U,T,fe,ce,Z)}}}else if(re.visible){const q=P(D,re,I,z);D.onBeforeShadow(s,D,U,T,fe,q,null),s.renderBufferDirect(T,null,fe,q,D,null),D.onAfterShadow(s,D,U,T,fe,q,null)}}const H=D.children;for(let fe=0,re=H.length;fe<re;fe++)C(H[fe],U,T,I,z)}function k(D){D.target.removeEventListener("dispose",k);for(const T in f){const I=f[T],z=D.target.uuid;z in I&&(I[z].dispose(),delete I[z])}}}function Kw(s,e){function t(){let G=!1;const Fe=new un;let j=null;const be=new un(0,0,0,0);return{setMask:function(Re){j!==Re&&!G&&(s.colorMask(Re,Re,Re,Re),j=Re)},setLocked:function(Re){G=Re},setClear:function(Re,_e,Be,je,ht){ht===!0&&(Re*=je,_e*=je,Be*=je),Fe.set(Re,_e,Be,je),be.equals(Fe)===!1&&(s.clearColor(Re,_e,Be,je),be.copy(Fe))},reset:function(){G=!1,j=null,be.set(-1,0,0,0)}}}function r(){let G=!1,Fe=!1,j=null,be=null,Re=null;return{setReversed:function(_e){if(Fe!==_e){const Be=e.get("EXT_clip_control");_e?Be.clipControlEXT(Be.LOWER_LEFT_EXT,Be.ZERO_TO_ONE_EXT):Be.clipControlEXT(Be.LOWER_LEFT_EXT,Be.NEGATIVE_ONE_TO_ONE_EXT),Fe=_e;const je=Re;Re=null,this.setClear(je)}},getReversed:function(){return Fe},setTest:function(_e){_e?ve(s.DEPTH_TEST):te(s.DEPTH_TEST)},setMask:function(_e){j!==_e&&!G&&(s.depthMask(_e),j=_e)},setFunc:function(_e){if(Fe&&(_e=My[_e]),be!==_e){switch(_e){case nh:s.depthFunc(s.NEVER);break;case ih:s.depthFunc(s.ALWAYS);break;case rh:s.depthFunc(s.LESS);break;case ya:s.depthFunc(s.LEQUAL);break;case sh:s.depthFunc(s.EQUAL);break;case ah:s.depthFunc(s.GEQUAL);break;case oh:s.depthFunc(s.GREATER);break;case lh:s.depthFunc(s.NOTEQUAL);break;default:s.depthFunc(s.LEQUAL)}be=_e}},setLocked:function(_e){G=_e},setClear:function(_e){Re!==_e&&(Re=_e,Fe&&(_e=1-_e),s.clearDepth(_e))},reset:function(){G=!1,j=null,be=null,Re=null,Fe=!1}}}function a(){let G=!1,Fe=null,j=null,be=null,Re=null,_e=null,Be=null,je=null,ht=null;return{setTest:function(Et){G||(Et?ve(s.STENCIL_TEST):te(s.STENCIL_TEST))},setMask:function(Et){Fe!==Et&&!G&&(s.stencilMask(Et),Fe=Et)},setFunc:function(Et,$t,It){(j!==Et||be!==$t||Re!==It)&&(s.stencilFunc(Et,$t,It),j=Et,be=$t,Re=It)},setOp:function(Et,$t,It){(_e!==Et||Be!==$t||je!==It)&&(s.stencilOp(Et,$t,It),_e=Et,Be=$t,je=It)},setLocked:function(Et){G=Et},setClear:function(Et){ht!==Et&&(s.clearStencil(Et),ht=Et)},reset:function(){G=!1,Fe=null,j=null,be=null,Re=null,_e=null,Be=null,je=null,ht=null}}}const l=new t,u=new r,h=new a,p=new WeakMap,f=new WeakMap;let g={},b={},v={},S=new WeakMap,M=[],E=null,x=!1,_=null,N=null,P=null,C=null,k=null,D=null,U=null,T=new _t(0,0,0),I=0,z=!1,O=null,H=null,fe=null,re=null,q=null;const de=s.getParameter(s.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let oe=!1,Z=0;const ee=s.getParameter(s.VERSION);ee.indexOf("WebGL")!==-1?(Z=parseFloat(/^WebGL (\d)/.exec(ee)[1]),oe=Z>=1):ee.indexOf("OpenGL ES")!==-1&&(Z=parseFloat(/^OpenGL ES (\d)/.exec(ee)[1]),oe=Z>=2);let ce=null,F={};const Y=s.getParameter(s.SCISSOR_BOX),Ce=s.getParameter(s.VIEWPORT),qe=new un().fromArray(Y),we=new un().fromArray(Ce);function ie(G,Fe,j,be){const Re=new Uint8Array(4),_e=s.createTexture();s.bindTexture(G,_e),s.texParameteri(G,s.TEXTURE_MIN_FILTER,s.NEAREST),s.texParameteri(G,s.TEXTURE_MAG_FILTER,s.NEAREST);for(let Be=0;Be<j;Be++)G===s.TEXTURE_3D||G===s.TEXTURE_2D_ARRAY?s.texImage3D(Fe,0,s.RGBA,1,1,be,0,s.RGBA,s.UNSIGNED_BYTE,Re):s.texImage2D(Fe+Be,0,s.RGBA,1,1,0,s.RGBA,s.UNSIGNED_BYTE,Re);return _e}const xe={};xe[s.TEXTURE_2D]=ie(s.TEXTURE_2D,s.TEXTURE_2D,1),xe[s.TEXTURE_CUBE_MAP]=ie(s.TEXTURE_CUBE_MAP,s.TEXTURE_CUBE_MAP_POSITIVE_X,6),xe[s.TEXTURE_2D_ARRAY]=ie(s.TEXTURE_2D_ARRAY,s.TEXTURE_2D_ARRAY,1,1),xe[s.TEXTURE_3D]=ie(s.TEXTURE_3D,s.TEXTURE_3D,1,1),l.setClear(0,0,0,1),u.setClear(1),h.setClear(0),ve(s.DEPTH_TEST),u.setFunc(ya),Lt(!1),zt(Ym),ve(s.CULL_FACE),it(Qi);function ve(G){g[G]!==!0&&(s.enable(G),g[G]=!0)}function te(G){g[G]!==!1&&(s.disable(G),g[G]=!1)}function Se(G,Fe){return v[G]!==Fe?(s.bindFramebuffer(G,Fe),v[G]=Fe,G===s.DRAW_FRAMEBUFFER&&(v[s.FRAMEBUFFER]=Fe),G===s.FRAMEBUFFER&&(v[s.DRAW_FRAMEBUFFER]=Fe),!0):!1}function Qe(G,Fe){let j=M,be=!1;if(G){j=S.get(Fe),j===void 0&&(j=[],S.set(Fe,j));const Re=G.textures;if(j.length!==Re.length||j[0]!==s.COLOR_ATTACHMENT0){for(let _e=0,Be=Re.length;_e<Be;_e++)j[_e]=s.COLOR_ATTACHMENT0+_e;j.length=Re.length,be=!0}}else j[0]!==s.BACK&&(j[0]=s.BACK,be=!0);be&&s.drawBuffers(j)}function Ft(G){return E!==G?(s.useProgram(G),E=G,!0):!1}const ut={[_s]:s.FUNC_ADD,[X_]:s.FUNC_SUBTRACT,[q_]:s.FUNC_REVERSE_SUBTRACT};ut[$_]=s.MIN,ut[Y_]=s.MAX;const Ct={[K_]:s.ZERO,[Z_]:s.ONE,[Q_]:s.SRC_COLOR,[eh]:s.SRC_ALPHA,[ry]:s.SRC_ALPHA_SATURATE,[ny]:s.DST_COLOR,[ey]:s.DST_ALPHA,[J_]:s.ONE_MINUS_SRC_COLOR,[th]:s.ONE_MINUS_SRC_ALPHA,[iy]:s.ONE_MINUS_DST_COLOR,[ty]:s.ONE_MINUS_DST_ALPHA,[sy]:s.CONSTANT_COLOR,[ay]:s.ONE_MINUS_CONSTANT_COLOR,[oy]:s.CONSTANT_ALPHA,[ly]:s.ONE_MINUS_CONSTANT_ALPHA};function it(G,Fe,j,be,Re,_e,Be,je,ht,Et){if(G===Qi){x===!0&&(te(s.BLEND),x=!1);return}if(x===!1&&(ve(s.BLEND),x=!0),G!==W_){if(G!==_||Et!==z){if((N!==_s||k!==_s)&&(s.blendEquation(s.FUNC_ADD),N=_s,k=_s),Et)switch(G){case Ms:s.blendFuncSeparate(s.ONE,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case yc:s.blendFunc(s.ONE,s.ONE);break;case Km:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case Zm:s.blendFuncSeparate(s.DST_COLOR,s.ONE_MINUS_SRC_ALPHA,s.ZERO,s.ONE);break;default:Ut("WebGLState: Invalid blending: ",G);break}else switch(G){case Ms:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case yc:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE,s.ONE,s.ONE);break;case Km:Ut("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case Zm:Ut("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Ut("WebGLState: Invalid blending: ",G);break}P=null,C=null,D=null,U=null,T.set(0,0,0),I=0,_=G,z=Et}return}Re=Re||Fe,_e=_e||j,Be=Be||be,(Fe!==N||Re!==k)&&(s.blendEquationSeparate(ut[Fe],ut[Re]),N=Fe,k=Re),(j!==P||be!==C||_e!==D||Be!==U)&&(s.blendFuncSeparate(Ct[j],Ct[be],Ct[_e],Ct[Be]),P=j,C=be,D=_e,U=Be),(je.equals(T)===!1||ht!==I)&&(s.blendColor(je.r,je.g,je.b,ht),T.copy(je),I=ht),_=G,z=!1}function Je(G,Fe){G.side===Fi?te(s.CULL_FACE):ve(s.CULL_FACE);let j=G.side===si;Fe&&(j=!j),Lt(j),G.blending===Ms&&G.transparent===!1?it(Qi):it(G.blending,G.blendEquation,G.blendSrc,G.blendDst,G.blendEquationAlpha,G.blendSrcAlpha,G.blendDstAlpha,G.blendColor,G.blendAlpha,G.premultipliedAlpha),u.setFunc(G.depthFunc),u.setTest(G.depthTest),u.setMask(G.depthWrite),l.setMask(G.colorWrite);const be=G.stencilWrite;h.setTest(be),be&&(h.setMask(G.stencilWriteMask),h.setFunc(G.stencilFunc,G.stencilRef,G.stencilFuncMask),h.setOp(G.stencilFail,G.stencilZFail,G.stencilZPass)),Dt(G.polygonOffset,G.polygonOffsetFactor,G.polygonOffsetUnits),G.alphaToCoverage===!0?ve(s.SAMPLE_ALPHA_TO_COVERAGE):te(s.SAMPLE_ALPHA_TO_COVERAGE)}function Lt(G){O!==G&&(G?s.frontFace(s.CW):s.frontFace(s.CCW),O=G)}function zt(G){G!==H_?(ve(s.CULL_FACE),G!==H&&(G===Ym?s.cullFace(s.BACK):G===V_?s.cullFace(s.FRONT):s.cullFace(s.FRONT_AND_BACK))):te(s.CULL_FACE),H=G}function St(G){G!==fe&&(oe&&s.lineWidth(G),fe=G)}function Dt(G,Fe,j){G?(ve(s.POLYGON_OFFSET_FILL),(re!==Fe||q!==j)&&(re=Fe,q=j,u.getReversed()&&(Fe=-Fe),s.polygonOffset(Fe,j))):te(s.POLYGON_OFFSET_FILL)}function wt(G){G?ve(s.SCISSOR_TEST):te(s.SCISSOR_TEST)}function ct(G){G===void 0&&(G=s.TEXTURE0+de-1),ce!==G&&(s.activeTexture(G),ce=G)}function Q(G,Fe,j){j===void 0&&(ce===null?j=s.TEXTURE0+de-1:j=ce);let be=F[j];be===void 0&&(be={type:void 0,texture:void 0},F[j]=be),(be.type!==G||be.texture!==Fe)&&(ce!==j&&(s.activeTexture(j),ce=j),s.bindTexture(G,Fe||xe[G]),be.type=G,be.texture=Fe)}function et(){const G=F[ce];G!==void 0&&G.type!==void 0&&(s.bindTexture(G.type,null),G.type=void 0,G.texture=void 0)}function ze(){try{s.compressedTexImage2D(...arguments)}catch(G){Ut("WebGLState:",G)}}function L(){try{s.compressedTexImage3D(...arguments)}catch(G){Ut("WebGLState:",G)}}function w(){try{s.texSubImage2D(...arguments)}catch(G){Ut("WebGLState:",G)}}function $(){try{s.texSubImage3D(...arguments)}catch(G){Ut("WebGLState:",G)}}function ae(){try{s.compressedTexSubImage2D(...arguments)}catch(G){Ut("WebGLState:",G)}}function me(){try{s.compressedTexSubImage3D(...arguments)}catch(G){Ut("WebGLState:",G)}}function Me(){try{s.texStorage2D(...arguments)}catch(G){Ut("WebGLState:",G)}}function Ne(){try{s.texStorage3D(...arguments)}catch(G){Ut("WebGLState:",G)}}function ue(){try{s.texImage2D(...arguments)}catch(G){Ut("WebGLState:",G)}}function ye(){try{s.texImage3D(...arguments)}catch(G){Ut("WebGLState:",G)}}function Ee(G){return b[G]!==void 0?b[G]:s.getParameter(G)}function He(G,Fe){b[G]!==Fe&&(s.pixelStorei(G,Fe),b[G]=Fe)}function Ie(G){qe.equals(G)===!1&&(s.scissor(G.x,G.y,G.z,G.w),qe.copy(G))}function ke(G){we.equals(G)===!1&&(s.viewport(G.x,G.y,G.z,G.w),we.copy(G))}function We(G,Fe){let j=f.get(Fe);j===void 0&&(j=new WeakMap,f.set(Fe,j));let be=j.get(G);be===void 0&&(be=s.getUniformBlockIndex(Fe,G.name),j.set(G,be))}function Ze(G,Fe){const be=f.get(Fe).get(G);p.get(Fe)!==be&&(s.uniformBlockBinding(Fe,be,G.__bindingPointIndex),p.set(Fe,be))}function at(){s.disable(s.BLEND),s.disable(s.CULL_FACE),s.disable(s.DEPTH_TEST),s.disable(s.POLYGON_OFFSET_FILL),s.disable(s.SCISSOR_TEST),s.disable(s.STENCIL_TEST),s.disable(s.SAMPLE_ALPHA_TO_COVERAGE),s.blendEquation(s.FUNC_ADD),s.blendFunc(s.ONE,s.ZERO),s.blendFuncSeparate(s.ONE,s.ZERO,s.ONE,s.ZERO),s.blendColor(0,0,0,0),s.colorMask(!0,!0,!0,!0),s.clearColor(0,0,0,0),s.depthMask(!0),s.depthFunc(s.LESS),u.setReversed(!1),s.clearDepth(1),s.stencilMask(4294967295),s.stencilFunc(s.ALWAYS,0,4294967295),s.stencilOp(s.KEEP,s.KEEP,s.KEEP),s.clearStencil(0),s.cullFace(s.BACK),s.frontFace(s.CCW),s.polygonOffset(0,0),s.activeTexture(s.TEXTURE0),s.bindFramebuffer(s.FRAMEBUFFER,null),s.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),s.bindFramebuffer(s.READ_FRAMEBUFFER,null),s.useProgram(null),s.lineWidth(1),s.scissor(0,0,s.canvas.width,s.canvas.height),s.viewport(0,0,s.canvas.width,s.canvas.height),s.pixelStorei(s.PACK_ALIGNMENT,4),s.pixelStorei(s.UNPACK_ALIGNMENT,4),s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,!1),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,s.BROWSER_DEFAULT_WEBGL),s.pixelStorei(s.PACK_ROW_LENGTH,0),s.pixelStorei(s.PACK_SKIP_PIXELS,0),s.pixelStorei(s.PACK_SKIP_ROWS,0),s.pixelStorei(s.UNPACK_ROW_LENGTH,0),s.pixelStorei(s.UNPACK_IMAGE_HEIGHT,0),s.pixelStorei(s.UNPACK_SKIP_PIXELS,0),s.pixelStorei(s.UNPACK_SKIP_ROWS,0),s.pixelStorei(s.UNPACK_SKIP_IMAGES,0),g={},b={},ce=null,F={},v={},S=new WeakMap,M=[],E=null,x=!1,_=null,N=null,P=null,C=null,k=null,D=null,U=null,T=new _t(0,0,0),I=0,z=!1,O=null,H=null,fe=null,re=null,q=null,qe.set(0,0,s.canvas.width,s.canvas.height),we.set(0,0,s.canvas.width,s.canvas.height),l.reset(),u.reset(),h.reset()}return{buffers:{color:l,depth:u,stencil:h},enable:ve,disable:te,bindFramebuffer:Se,drawBuffers:Qe,useProgram:Ft,setBlending:it,setMaterial:Je,setFlipSided:Lt,setCullFace:zt,setLineWidth:St,setPolygonOffset:Dt,setScissorTest:wt,activeTexture:ct,bindTexture:Q,unbindTexture:et,compressedTexImage2D:ze,compressedTexImage3D:L,texImage2D:ue,texImage3D:ye,pixelStorei:He,getParameter:Ee,updateUBOMapping:We,uniformBlockBinding:Ze,texStorage2D:Me,texStorage3D:Ne,texSubImage2D:w,texSubImage3D:$,compressedTexSubImage2D:ae,compressedTexSubImage3D:me,scissor:Ie,viewport:ke,reset:at}}function Zw(s,e,t,r,a,l,u){const h=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,p=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),f=new dt,g=new WeakMap,b=new Set;let v;const S=new WeakMap;let M=!1;try{M=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function E(L,w){return M?new OffscreenCanvas(L,w):Tc("canvas")}function x(L,w,$){let ae=1;const me=ze(L);if((me.width>$||me.height>$)&&(ae=$/Math.max(me.width,me.height)),ae<1)if(typeof HTMLImageElement<"u"&&L instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&L instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&L instanceof ImageBitmap||typeof VideoFrame<"u"&&L instanceof VideoFrame){const Me=Math.floor(ae*me.width),Ne=Math.floor(ae*me.height);v===void 0&&(v=E(Me,Ne));const ue=w?E(Me,Ne):v;return ue.width=Me,ue.height=Ne,ue.getContext("2d").drawImage(L,0,0,Me,Ne),gt("WebGLRenderer: Texture has been resized from ("+me.width+"x"+me.height+") to ("+Me+"x"+Ne+")."),ue}else return"data"in L&&gt("WebGLRenderer: Image in DataTexture is too big ("+me.width+"x"+me.height+")."),L;return L}function _(L){return L.generateMipmaps}function N(L){s.generateMipmap(L)}function P(L){return L.isWebGLCubeRenderTarget?s.TEXTURE_CUBE_MAP:L.isWebGL3DRenderTarget?s.TEXTURE_3D:L.isWebGLArrayRenderTarget||L.isCompressedArrayTexture?s.TEXTURE_2D_ARRAY:s.TEXTURE_2D}function C(L,w,$,ae,me,Me=!1){if(L!==null){if(s[L]!==void 0)return s[L];gt("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+L+"'")}let Ne;ae&&(Ne=e.get("EXT_texture_norm16"),Ne||gt("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let ue=w;if(w===s.RED&&($===s.FLOAT&&(ue=s.R32F),$===s.HALF_FLOAT&&(ue=s.R16F),$===s.UNSIGNED_BYTE&&(ue=s.R8),$===s.UNSIGNED_SHORT&&Ne&&(ue=Ne.R16_EXT),$===s.SHORT&&Ne&&(ue=Ne.R16_SNORM_EXT)),w===s.RED_INTEGER&&($===s.UNSIGNED_BYTE&&(ue=s.R8UI),$===s.UNSIGNED_SHORT&&(ue=s.R16UI),$===s.UNSIGNED_INT&&(ue=s.R32UI),$===s.BYTE&&(ue=s.R8I),$===s.SHORT&&(ue=s.R16I),$===s.INT&&(ue=s.R32I)),w===s.RG&&($===s.FLOAT&&(ue=s.RG32F),$===s.HALF_FLOAT&&(ue=s.RG16F),$===s.UNSIGNED_BYTE&&(ue=s.RG8),$===s.UNSIGNED_SHORT&&Ne&&(ue=Ne.RG16_EXT),$===s.SHORT&&Ne&&(ue=Ne.RG16_SNORM_EXT)),w===s.RG_INTEGER&&($===s.UNSIGNED_BYTE&&(ue=s.RG8UI),$===s.UNSIGNED_SHORT&&(ue=s.RG16UI),$===s.UNSIGNED_INT&&(ue=s.RG32UI),$===s.BYTE&&(ue=s.RG8I),$===s.SHORT&&(ue=s.RG16I),$===s.INT&&(ue=s.RG32I)),w===s.RGB_INTEGER&&($===s.UNSIGNED_BYTE&&(ue=s.RGB8UI),$===s.UNSIGNED_SHORT&&(ue=s.RGB16UI),$===s.UNSIGNED_INT&&(ue=s.RGB32UI),$===s.BYTE&&(ue=s.RGB8I),$===s.SHORT&&(ue=s.RGB16I),$===s.INT&&(ue=s.RGB32I)),w===s.RGBA_INTEGER&&($===s.UNSIGNED_BYTE&&(ue=s.RGBA8UI),$===s.UNSIGNED_SHORT&&(ue=s.RGBA16UI),$===s.UNSIGNED_INT&&(ue=s.RGBA32UI),$===s.BYTE&&(ue=s.RGBA8I),$===s.SHORT&&(ue=s.RGBA16I),$===s.INT&&(ue=s.RGBA32I)),w===s.RGB&&($===s.UNSIGNED_SHORT&&Ne&&(ue=Ne.RGB16_EXT),$===s.SHORT&&Ne&&(ue=Ne.RGB16_SNORM_EXT),$===s.UNSIGNED_INT_5_9_9_9_REV&&(ue=s.RGB9_E5),$===s.UNSIGNED_INT_10F_11F_11F_REV&&(ue=s.R11F_G11F_B10F)),w===s.RGBA){const ye=Me?wc:kt.getTransfer(me);$===s.FLOAT&&(ue=s.RGBA32F),$===s.HALF_FLOAT&&(ue=s.RGBA16F),$===s.UNSIGNED_BYTE&&(ue=ye===Wt?s.SRGB8_ALPHA8:s.RGBA8),$===s.UNSIGNED_SHORT&&Ne&&(ue=Ne.RGBA16_EXT),$===s.SHORT&&Ne&&(ue=Ne.RGBA16_SNORM_EXT),$===s.UNSIGNED_SHORT_4_4_4_4&&(ue=s.RGBA4),$===s.UNSIGNED_SHORT_5_5_5_1&&(ue=s.RGB5_A1)}return(ue===s.R16F||ue===s.R32F||ue===s.RG16F||ue===s.RG32F||ue===s.RGBA16F||ue===s.RGBA32F)&&e.get("EXT_color_buffer_float"),ue}function k(L,w){let $;return L?w===null||w===er||w===So?$=s.DEPTH24_STENCIL8:w===Oi?$=s.DEPTH32F_STENCIL8:w===bo&&($=s.DEPTH24_STENCIL8,gt("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):w===null||w===er||w===So?$=s.DEPTH_COMPONENT24:w===Oi?$=s.DEPTH_COMPONENT32F:w===bo&&($=s.DEPTH_COMPONENT16),$}function D(L,w){return _(L)===!0||L.isFramebufferTexture&&L.minFilter!==Dn&&L.minFilter!==zn?Math.log2(Math.max(w.width,w.height))+1:L.mipmaps!==void 0&&L.mipmaps.length>0?L.mipmaps.length:L.isCompressedTexture&&Array.isArray(L.image)?w.mipmaps.length:1}function U(L){const w=L.target;w.removeEventListener("dispose",U),I(w),w.isVideoTexture&&g.delete(w),w.isHTMLTexture&&b.delete(w)}function T(L){const w=L.target;w.removeEventListener("dispose",T),O(w)}function I(L){const w=r.get(L);if(w.__webglInit===void 0)return;const $=L.source,ae=S.get($);if(ae){const me=ae[w.__cacheKey];me.usedTimes--,me.usedTimes===0&&z(L),Object.keys(ae).length===0&&S.delete($)}r.remove(L)}function z(L){const w=r.get(L);s.deleteTexture(w.__webglTexture);const $=L.source,ae=S.get($);delete ae[w.__cacheKey],u.memory.textures--}function O(L){const w=r.get(L);if(L.depthTexture&&(L.depthTexture.dispose(),r.remove(L.depthTexture)),L.isWebGLCubeRenderTarget)for(let ae=0;ae<6;ae++){if(Array.isArray(w.__webglFramebuffer[ae]))for(let me=0;me<w.__webglFramebuffer[ae].length;me++)s.deleteFramebuffer(w.__webglFramebuffer[ae][me]);else s.deleteFramebuffer(w.__webglFramebuffer[ae]);w.__webglDepthbuffer&&s.deleteRenderbuffer(w.__webglDepthbuffer[ae])}else{if(Array.isArray(w.__webglFramebuffer))for(let ae=0;ae<w.__webglFramebuffer.length;ae++)s.deleteFramebuffer(w.__webglFramebuffer[ae]);else s.deleteFramebuffer(w.__webglFramebuffer);if(w.__webglDepthbuffer&&s.deleteRenderbuffer(w.__webglDepthbuffer),w.__webglMultisampledFramebuffer&&s.deleteFramebuffer(w.__webglMultisampledFramebuffer),w.__webglColorRenderbuffer)for(let ae=0;ae<w.__webglColorRenderbuffer.length;ae++)w.__webglColorRenderbuffer[ae]&&s.deleteRenderbuffer(w.__webglColorRenderbuffer[ae]);w.__webglDepthRenderbuffer&&s.deleteRenderbuffer(w.__webglDepthRenderbuffer)}const $=L.textures;for(let ae=0,me=$.length;ae<me;ae++){const Me=r.get($[ae]);Me.__webglTexture&&(s.deleteTexture(Me.__webglTexture),u.memory.textures--),r.remove($[ae])}r.remove(L)}let H=0;function fe(){H=0}function re(){return H}function q(L){H=L}function de(){const L=H;return L>=a.maxTextures&&gt("WebGLTextures: Trying to use "+L+" texture units while this GPU supports only "+a.maxTextures),H+=1,L}function oe(L){const w=[];return w.push(L.wrapS),w.push(L.wrapT),w.push(L.wrapR||0),w.push(L.magFilter),w.push(L.minFilter),w.push(L.anisotropy),w.push(L.internalFormat),w.push(L.format),w.push(L.type),w.push(L.generateMipmaps),w.push(L.premultiplyAlpha),w.push(L.flipY),w.push(L.unpackAlignment),w.push(L.colorSpace),w.join()}function Z(L,w){const $=r.get(L);if(L.isVideoTexture&&Q(L),L.isRenderTargetTexture===!1&&L.isExternalTexture!==!0&&L.version>0&&$.__version!==L.version){const ae=L.image;if(ae===null)gt("WebGLRenderer: Texture marked for update but no image data found.");else if(ae.complete===!1)gt("WebGLRenderer: Texture marked for update but image is incomplete");else{te($,L,w);return}}else L.isExternalTexture&&($.__webglTexture=L.sourceTexture?L.sourceTexture:null);t.bindTexture(s.TEXTURE_2D,$.__webglTexture,s.TEXTURE0+w)}function ee(L,w){const $=r.get(L);if(L.isRenderTargetTexture===!1&&L.version>0&&$.__version!==L.version){te($,L,w);return}else L.isExternalTexture&&($.__webglTexture=L.sourceTexture?L.sourceTexture:null);t.bindTexture(s.TEXTURE_2D_ARRAY,$.__webglTexture,s.TEXTURE0+w)}function ce(L,w){const $=r.get(L);if(L.isRenderTargetTexture===!1&&L.version>0&&$.__version!==L.version){te($,L,w);return}t.bindTexture(s.TEXTURE_3D,$.__webglTexture,s.TEXTURE0+w)}function F(L,w){const $=r.get(L);if(L.isCubeDepthTexture!==!0&&L.version>0&&$.__version!==L.version){Se($,L,w);return}t.bindTexture(s.TEXTURE_CUBE_MAP,$.__webglTexture,s.TEXTURE0+w)}const Y={[ch]:s.REPEAT,[xr]:s.CLAMP_TO_EDGE,[uh]:s.MIRRORED_REPEAT},Ce={[Dn]:s.NEAREST,[dy]:s.NEAREST_MIPMAP_NEAREST,[Pl]:s.NEAREST_MIPMAP_LINEAR,[zn]:s.LINEAR,[xd]:s.LINEAR_MIPMAP_NEAREST,[bs]:s.LINEAR_MIPMAP_LINEAR},qe={[py]:s.NEVER,[_y]:s.ALWAYS,[my]:s.LESS,[of]:s.LEQUAL,[gy]:s.EQUAL,[lf]:s.GEQUAL,[xy]:s.GREATER,[vy]:s.NOTEQUAL};function we(L,w){if(w.type===Oi&&e.has("OES_texture_float_linear")===!1&&(w.magFilter===zn||w.magFilter===xd||w.magFilter===Pl||w.magFilter===bs||w.minFilter===zn||w.minFilter===xd||w.minFilter===Pl||w.minFilter===bs)&&gt("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),s.texParameteri(L,s.TEXTURE_WRAP_S,Y[w.wrapS]),s.texParameteri(L,s.TEXTURE_WRAP_T,Y[w.wrapT]),(L===s.TEXTURE_3D||L===s.TEXTURE_2D_ARRAY)&&s.texParameteri(L,s.TEXTURE_WRAP_R,Y[w.wrapR]),s.texParameteri(L,s.TEXTURE_MAG_FILTER,Ce[w.magFilter]),s.texParameteri(L,s.TEXTURE_MIN_FILTER,Ce[w.minFilter]),w.compareFunction&&(s.texParameteri(L,s.TEXTURE_COMPARE_MODE,s.COMPARE_REF_TO_TEXTURE),s.texParameteri(L,s.TEXTURE_COMPARE_FUNC,qe[w.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(w.magFilter===Dn||w.minFilter!==Pl&&w.minFilter!==bs||w.type===Oi&&e.has("OES_texture_float_linear")===!1)return;if(w.anisotropy>1||r.get(w).__currentAnisotropy){const $=e.get("EXT_texture_filter_anisotropic");s.texParameterf(L,$.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(w.anisotropy,a.getMaxAnisotropy())),r.get(w).__currentAnisotropy=w.anisotropy}}}function ie(L,w){let $=!1;L.__webglInit===void 0&&(L.__webglInit=!0,w.addEventListener("dispose",U));const ae=w.source;let me=S.get(ae);me===void 0&&(me={},S.set(ae,me));const Me=oe(w);if(Me!==L.__cacheKey){me[Me]===void 0&&(me[Me]={texture:s.createTexture(),usedTimes:0},u.memory.textures++,$=!0),me[Me].usedTimes++;const Ne=me[L.__cacheKey];Ne!==void 0&&(me[L.__cacheKey].usedTimes--,Ne.usedTimes===0&&z(w)),L.__cacheKey=Me,L.__webglTexture=me[Me].texture}return $}function xe(L,w,$){return Math.floor(Math.floor(L/$)/w)}function ve(L,w,$,ae){const Me=L.updateRanges;if(Me.length===0)t.texSubImage2D(s.TEXTURE_2D,0,0,0,w.width,w.height,$,ae,w.data);else{Me.sort((He,Ie)=>He.start-Ie.start);let Ne=0;for(let He=1;He<Me.length;He++){const Ie=Me[Ne],ke=Me[He],We=Ie.start+Ie.count,Ze=xe(ke.start,w.width,4),at=xe(Ie.start,w.width,4);ke.start<=We+1&&Ze===at&&xe(ke.start+ke.count-1,w.width,4)===Ze?Ie.count=Math.max(Ie.count,ke.start+ke.count-Ie.start):(++Ne,Me[Ne]=ke)}Me.length=Ne+1;const ue=t.getParameter(s.UNPACK_ROW_LENGTH),ye=t.getParameter(s.UNPACK_SKIP_PIXELS),Ee=t.getParameter(s.UNPACK_SKIP_ROWS);t.pixelStorei(s.UNPACK_ROW_LENGTH,w.width);for(let He=0,Ie=Me.length;He<Ie;He++){const ke=Me[He],We=Math.floor(ke.start/4),Ze=Math.ceil(ke.count/4),at=We%w.width,G=Math.floor(We/w.width),Fe=Ze,j=1;t.pixelStorei(s.UNPACK_SKIP_PIXELS,at),t.pixelStorei(s.UNPACK_SKIP_ROWS,G),t.texSubImage2D(s.TEXTURE_2D,0,at,G,Fe,j,$,ae,w.data)}L.clearUpdateRanges(),t.pixelStorei(s.UNPACK_ROW_LENGTH,ue),t.pixelStorei(s.UNPACK_SKIP_PIXELS,ye),t.pixelStorei(s.UNPACK_SKIP_ROWS,Ee)}}function te(L,w,$){let ae=s.TEXTURE_2D;(w.isDataArrayTexture||w.isCompressedArrayTexture)&&(ae=s.TEXTURE_2D_ARRAY),w.isData3DTexture&&(ae=s.TEXTURE_3D);const me=ie(L,w),Me=w.source;t.bindTexture(ae,L.__webglTexture,s.TEXTURE0+$);const Ne=r.get(Me);if(Me.version!==Ne.__version||me===!0){if(t.activeTexture(s.TEXTURE0+$),(typeof ImageBitmap<"u"&&w.image instanceof ImageBitmap)===!1){const j=kt.getPrimaries(kt.workingColorSpace),be=w.colorSpace===$r?null:kt.getPrimaries(w.colorSpace),Re=w.colorSpace===$r||j===be?s.NONE:s.BROWSER_DEFAULT_WEBGL;t.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,w.flipY),t.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,w.premultiplyAlpha),t.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,Re)}t.pixelStorei(s.UNPACK_ALIGNMENT,w.unpackAlignment);let ye=x(w.image,!1,a.maxTextureSize);ye=et(w,ye);const Ee=l.convert(w.format,w.colorSpace),He=l.convert(w.type);let Ie=C(w.internalFormat,Ee,He,w.normalized,w.colorSpace,w.isVideoTexture);we(ae,w);let ke;const We=w.mipmaps,Ze=w.isVideoTexture!==!0,at=Ne.__version===void 0||me===!0,G=Me.dataReady,Fe=D(w,ye);if(w.isDepthTexture)Ie=k(w.format===Ss,w.type),at&&(Ze?t.texStorage2D(s.TEXTURE_2D,1,Ie,ye.width,ye.height):t.texImage2D(s.TEXTURE_2D,0,Ie,ye.width,ye.height,0,Ee,He,null));else if(w.isDataTexture)if(We.length>0){Ze&&at&&t.texStorage2D(s.TEXTURE_2D,Fe,Ie,We[0].width,We[0].height);for(let j=0,be=We.length;j<be;j++)ke=We[j],Ze?G&&t.texSubImage2D(s.TEXTURE_2D,j,0,0,ke.width,ke.height,Ee,He,ke.data):t.texImage2D(s.TEXTURE_2D,j,Ie,ke.width,ke.height,0,Ee,He,ke.data);w.generateMipmaps=!1}else Ze?(at&&t.texStorage2D(s.TEXTURE_2D,Fe,Ie,ye.width,ye.height),G&&ve(w,ye,Ee,He)):t.texImage2D(s.TEXTURE_2D,0,Ie,ye.width,ye.height,0,Ee,He,ye.data);else if(w.isCompressedTexture)if(w.isCompressedArrayTexture){Ze&&at&&t.texStorage3D(s.TEXTURE_2D_ARRAY,Fe,Ie,We[0].width,We[0].height,ye.depth);for(let j=0,be=We.length;j<be;j++)if(ke=We[j],w.format!==Bi)if(Ee!==null)if(Ze){if(G)if(w.layerUpdates.size>0){const Re=L0(ke.width,ke.height,w.format,w.type);for(const _e of w.layerUpdates){const Be=ke.data.subarray(_e*Re/ke.data.BYTES_PER_ELEMENT,(_e+1)*Re/ke.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,j,0,0,_e,ke.width,ke.height,1,Ee,Be)}w.clearLayerUpdates()}else t.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,j,0,0,0,ke.width,ke.height,ye.depth,Ee,ke.data)}else t.compressedTexImage3D(s.TEXTURE_2D_ARRAY,j,Ie,ke.width,ke.height,ye.depth,0,ke.data,0,0);else gt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Ze?G&&t.texSubImage3D(s.TEXTURE_2D_ARRAY,j,0,0,0,ke.width,ke.height,ye.depth,Ee,He,ke.data):t.texImage3D(s.TEXTURE_2D_ARRAY,j,Ie,ke.width,ke.height,ye.depth,0,Ee,He,ke.data)}else{Ze&&at&&t.texStorage2D(s.TEXTURE_2D,Fe,Ie,We[0].width,We[0].height);for(let j=0,be=We.length;j<be;j++)ke=We[j],w.format!==Bi?Ee!==null?Ze?G&&t.compressedTexSubImage2D(s.TEXTURE_2D,j,0,0,ke.width,ke.height,Ee,ke.data):t.compressedTexImage2D(s.TEXTURE_2D,j,Ie,ke.width,ke.height,0,ke.data):gt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Ze?G&&t.texSubImage2D(s.TEXTURE_2D,j,0,0,ke.width,ke.height,Ee,He,ke.data):t.texImage2D(s.TEXTURE_2D,j,Ie,ke.width,ke.height,0,Ee,He,ke.data)}else if(w.isDataArrayTexture)if(Ze){if(at&&t.texStorage3D(s.TEXTURE_2D_ARRAY,Fe,Ie,ye.width,ye.height,ye.depth),G)if(w.layerUpdates.size>0){const j=L0(ye.width,ye.height,w.format,w.type);for(const be of w.layerUpdates){const Re=ye.data.subarray(be*j/ye.data.BYTES_PER_ELEMENT,(be+1)*j/ye.data.BYTES_PER_ELEMENT);t.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,be,ye.width,ye.height,1,Ee,He,Re)}w.clearLayerUpdates()}else t.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,0,ye.width,ye.height,ye.depth,Ee,He,ye.data)}else t.texImage3D(s.TEXTURE_2D_ARRAY,0,Ie,ye.width,ye.height,ye.depth,0,Ee,He,ye.data);else if(w.isData3DTexture)Ze?(at&&t.texStorage3D(s.TEXTURE_3D,Fe,Ie,ye.width,ye.height,ye.depth),G&&t.texSubImage3D(s.TEXTURE_3D,0,0,0,0,ye.width,ye.height,ye.depth,Ee,He,ye.data)):t.texImage3D(s.TEXTURE_3D,0,Ie,ye.width,ye.height,ye.depth,0,Ee,He,ye.data);else if(w.isFramebufferTexture){if(at)if(Ze)t.texStorage2D(s.TEXTURE_2D,Fe,Ie,ye.width,ye.height);else{let j=ye.width,be=ye.height;for(let Re=0;Re<Fe;Re++)t.texImage2D(s.TEXTURE_2D,Re,Ie,j,be,0,Ee,He,null),j>>=1,be>>=1}}else if(w.isHTMLTexture){if("texElementImage2D"in s){const j=s.canvas;if(j.hasAttribute("layoutsubtree")||j.setAttribute("layoutsubtree","true"),ye.parentNode!==j){j.appendChild(ye),b.add(w),j.onpaint=be=>{const Re=be.changedElements;for(const _e of b)Re.includes(_e.image)&&(_e.needsUpdate=!0)},j.requestPaint();return}if(s.texElementImage2D.length===3)s.texElementImage2D(s.TEXTURE_2D,s.RGBA8,ye);else{const Re=s.RGBA,_e=s.RGBA,Be=s.UNSIGNED_BYTE;s.texElementImage2D(s.TEXTURE_2D,0,Re,_e,Be,ye)}s.texParameteri(s.TEXTURE_2D,s.TEXTURE_MIN_FILTER,s.LINEAR),s.texParameteri(s.TEXTURE_2D,s.TEXTURE_WRAP_S,s.CLAMP_TO_EDGE),s.texParameteri(s.TEXTURE_2D,s.TEXTURE_WRAP_T,s.CLAMP_TO_EDGE)}}else if(We.length>0){if(Ze&&at){const j=ze(We[0]);t.texStorage2D(s.TEXTURE_2D,Fe,Ie,j.width,j.height)}for(let j=0,be=We.length;j<be;j++)ke=We[j],Ze?G&&t.texSubImage2D(s.TEXTURE_2D,j,0,0,Ee,He,ke):t.texImage2D(s.TEXTURE_2D,j,Ie,Ee,He,ke);w.generateMipmaps=!1}else if(Ze){if(at){const j=ze(ye);t.texStorage2D(s.TEXTURE_2D,Fe,Ie,j.width,j.height)}G&&t.texSubImage2D(s.TEXTURE_2D,0,0,0,Ee,He,ye)}else t.texImage2D(s.TEXTURE_2D,0,Ie,Ee,He,ye);_(w)&&N(ae),Ne.__version=Me.version,w.onUpdate&&w.onUpdate(w)}L.__version=w.version}function Se(L,w,$){if(w.image.length!==6)return;const ae=ie(L,w),me=w.source;t.bindTexture(s.TEXTURE_CUBE_MAP,L.__webglTexture,s.TEXTURE0+$);const Me=r.get(me);if(me.version!==Me.__version||ae===!0){t.activeTexture(s.TEXTURE0+$);const Ne=kt.getPrimaries(kt.workingColorSpace),ue=w.colorSpace===$r?null:kt.getPrimaries(w.colorSpace),ye=w.colorSpace===$r||Ne===ue?s.NONE:s.BROWSER_DEFAULT_WEBGL;t.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,w.flipY),t.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,w.premultiplyAlpha),t.pixelStorei(s.UNPACK_ALIGNMENT,w.unpackAlignment),t.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,ye);const Ee=w.isCompressedTexture||w.image[0].isCompressedTexture,He=w.image[0]&&w.image[0].isDataTexture,Ie=[];for(let _e=0;_e<6;_e++)!Ee&&!He?Ie[_e]=x(w.image[_e],!0,a.maxCubemapSize):Ie[_e]=He?w.image[_e].image:w.image[_e],Ie[_e]=et(w,Ie[_e]);const ke=Ie[0],We=l.convert(w.format,w.colorSpace),Ze=l.convert(w.type),at=C(w.internalFormat,We,Ze,w.normalized,w.colorSpace),G=w.isVideoTexture!==!0,Fe=Me.__version===void 0||ae===!0,j=me.dataReady;let be=D(w,ke);we(s.TEXTURE_CUBE_MAP,w);let Re;if(Ee){G&&Fe&&t.texStorage2D(s.TEXTURE_CUBE_MAP,be,at,ke.width,ke.height);for(let _e=0;_e<6;_e++){Re=Ie[_e].mipmaps;for(let Be=0;Be<Re.length;Be++){const je=Re[Be];w.format!==Bi?We!==null?G?j&&t.compressedTexSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+_e,Be,0,0,je.width,je.height,We,je.data):t.compressedTexImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+_e,Be,at,je.width,je.height,0,je.data):gt("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):G?j&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+_e,Be,0,0,je.width,je.height,We,Ze,je.data):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+_e,Be,at,je.width,je.height,0,We,Ze,je.data)}}}else{if(Re=w.mipmaps,G&&Fe){Re.length>0&&be++;const _e=ze(Ie[0]);t.texStorage2D(s.TEXTURE_CUBE_MAP,be,at,_e.width,_e.height)}for(let _e=0;_e<6;_e++)if(He){G?j&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+_e,0,0,0,Ie[_e].width,Ie[_e].height,We,Ze,Ie[_e].data):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+_e,0,at,Ie[_e].width,Ie[_e].height,0,We,Ze,Ie[_e].data);for(let Be=0;Be<Re.length;Be++){const ht=Re[Be].image[_e].image;G?j&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+_e,Be+1,0,0,ht.width,ht.height,We,Ze,ht.data):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+_e,Be+1,at,ht.width,ht.height,0,We,Ze,ht.data)}}else{G?j&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+_e,0,0,0,We,Ze,Ie[_e]):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+_e,0,at,We,Ze,Ie[_e]);for(let Be=0;Be<Re.length;Be++){const je=Re[Be];G?j&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+_e,Be+1,0,0,We,Ze,je.image[_e]):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+_e,Be+1,at,We,Ze,je.image[_e])}}}_(w)&&N(s.TEXTURE_CUBE_MAP),Me.__version=me.version,w.onUpdate&&w.onUpdate(w)}L.__version=w.version}function Qe(L,w,$,ae,me,Me){const Ne=l.convert($.format,$.colorSpace),ue=l.convert($.type),ye=C($.internalFormat,Ne,ue,$.normalized,$.colorSpace),Ee=r.get(w),He=r.get($);if(He.__renderTarget=w,!Ee.__hasExternalTextures){const Ie=Math.max(1,w.width>>Me),ke=Math.max(1,w.height>>Me);me===s.TEXTURE_3D||me===s.TEXTURE_2D_ARRAY?t.texImage3D(me,Me,ye,Ie,ke,w.depth,0,Ne,ue,null):t.texImage2D(me,Me,ye,Ie,ke,0,Ne,ue,null)}t.bindFramebuffer(s.FRAMEBUFFER,L),ct(w)?h.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,ae,me,He.__webglTexture,0,wt(w)):(me===s.TEXTURE_2D||me>=s.TEXTURE_CUBE_MAP_POSITIVE_X&&me<=s.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&s.framebufferTexture2D(s.FRAMEBUFFER,ae,me,He.__webglTexture,Me),t.bindFramebuffer(s.FRAMEBUFFER,null)}function Ft(L,w,$){if(s.bindRenderbuffer(s.RENDERBUFFER,L),w.depthBuffer){const ae=w.depthTexture,me=ae&&ae.isDepthTexture?ae.type:null,Me=k(w.stencilBuffer,me),Ne=w.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;ct(w)?h.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,wt(w),Me,w.width,w.height):$?s.renderbufferStorageMultisample(s.RENDERBUFFER,wt(w),Me,w.width,w.height):s.renderbufferStorage(s.RENDERBUFFER,Me,w.width,w.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,Ne,s.RENDERBUFFER,L)}else{const ae=w.textures;for(let me=0;me<ae.length;me++){const Me=ae[me],Ne=l.convert(Me.format,Me.colorSpace),ue=l.convert(Me.type),ye=C(Me.internalFormat,Ne,ue,Me.normalized,Me.colorSpace);ct(w)?h.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,wt(w),ye,w.width,w.height):$?s.renderbufferStorageMultisample(s.RENDERBUFFER,wt(w),ye,w.width,w.height):s.renderbufferStorage(s.RENDERBUFFER,ye,w.width,w.height)}}s.bindRenderbuffer(s.RENDERBUFFER,null)}function ut(L,w,$){const ae=w.isWebGLCubeRenderTarget===!0;if(t.bindFramebuffer(s.FRAMEBUFFER,L),!(w.depthTexture&&w.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const me=r.get(w.depthTexture);if(me.__renderTarget=w,(!me.__webglTexture||w.depthTexture.image.width!==w.width||w.depthTexture.image.height!==w.height)&&(w.depthTexture.image.width=w.width,w.depthTexture.image.height=w.height,w.depthTexture.needsUpdate=!0),ae){if(me.__webglInit===void 0&&(me.__webglInit=!0,w.depthTexture.addEventListener("dispose",U)),me.__webglTexture===void 0){me.__webglTexture=s.createTexture(),t.bindTexture(s.TEXTURE_CUBE_MAP,me.__webglTexture),we(s.TEXTURE_CUBE_MAP,w.depthTexture);const Ee=l.convert(w.depthTexture.format),He=l.convert(w.depthTexture.type);let Ie;w.depthTexture.format===yr?Ie=s.DEPTH_COMPONENT24:w.depthTexture.format===Ss&&(Ie=s.DEPTH24_STENCIL8);for(let ke=0;ke<6;ke++)s.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+ke,0,Ie,w.width,w.height,0,Ee,He,null)}}else Z(w.depthTexture,0);const Me=me.__webglTexture,Ne=wt(w),ue=ae?s.TEXTURE_CUBE_MAP_POSITIVE_X+$:s.TEXTURE_2D,ye=w.depthTexture.format===Ss?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;if(w.depthTexture.format===yr)ct(w)?h.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,ye,ue,Me,0,Ne):s.framebufferTexture2D(s.FRAMEBUFFER,ye,ue,Me,0);else if(w.depthTexture.format===Ss)ct(w)?h.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,ye,ue,Me,0,Ne):s.framebufferTexture2D(s.FRAMEBUFFER,ye,ue,Me,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function Ct(L){const w=r.get(L),$=L.isWebGLCubeRenderTarget===!0;if(w.__boundDepthTexture!==L.depthTexture){const ae=L.depthTexture;if(w.__depthDisposeCallback&&w.__depthDisposeCallback(),ae){const me=()=>{delete w.__boundDepthTexture,delete w.__depthDisposeCallback,ae.removeEventListener("dispose",me)};ae.addEventListener("dispose",me),w.__depthDisposeCallback=me}w.__boundDepthTexture=ae}if(L.depthTexture&&!w.__autoAllocateDepthBuffer)if($)for(let ae=0;ae<6;ae++)ut(w.__webglFramebuffer[ae],L,ae);else{const ae=L.texture.mipmaps;ae&&ae.length>0?ut(w.__webglFramebuffer[0],L,0):ut(w.__webglFramebuffer,L,0)}else if($){w.__webglDepthbuffer=[];for(let ae=0;ae<6;ae++)if(t.bindFramebuffer(s.FRAMEBUFFER,w.__webglFramebuffer[ae]),w.__webglDepthbuffer[ae]===void 0)w.__webglDepthbuffer[ae]=s.createRenderbuffer(),Ft(w.__webglDepthbuffer[ae],L,!1);else{const me=L.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,Me=w.__webglDepthbuffer[ae];s.bindRenderbuffer(s.RENDERBUFFER,Me),s.framebufferRenderbuffer(s.FRAMEBUFFER,me,s.RENDERBUFFER,Me)}}else{const ae=L.texture.mipmaps;if(ae&&ae.length>0?t.bindFramebuffer(s.FRAMEBUFFER,w.__webglFramebuffer[0]):t.bindFramebuffer(s.FRAMEBUFFER,w.__webglFramebuffer),w.__webglDepthbuffer===void 0)w.__webglDepthbuffer=s.createRenderbuffer(),Ft(w.__webglDepthbuffer,L,!1);else{const me=L.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,Me=w.__webglDepthbuffer;s.bindRenderbuffer(s.RENDERBUFFER,Me),s.framebufferRenderbuffer(s.FRAMEBUFFER,me,s.RENDERBUFFER,Me)}}t.bindFramebuffer(s.FRAMEBUFFER,null)}function it(L,w,$){const ae=r.get(L);w!==void 0&&Qe(ae.__webglFramebuffer,L,L.texture,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,0),$!==void 0&&Ct(L)}function Je(L){const w=L.texture,$=r.get(L),ae=r.get(w);L.addEventListener("dispose",T);const me=L.textures,Me=L.isWebGLCubeRenderTarget===!0,Ne=me.length>1;if(Ne||(ae.__webglTexture===void 0&&(ae.__webglTexture=s.createTexture()),ae.__version=w.version,u.memory.textures++),Me){$.__webglFramebuffer=[];for(let ue=0;ue<6;ue++)if(w.mipmaps&&w.mipmaps.length>0){$.__webglFramebuffer[ue]=[];for(let ye=0;ye<w.mipmaps.length;ye++)$.__webglFramebuffer[ue][ye]=s.createFramebuffer()}else $.__webglFramebuffer[ue]=s.createFramebuffer()}else{if(w.mipmaps&&w.mipmaps.length>0){$.__webglFramebuffer=[];for(let ue=0;ue<w.mipmaps.length;ue++)$.__webglFramebuffer[ue]=s.createFramebuffer()}else $.__webglFramebuffer=s.createFramebuffer();if(Ne)for(let ue=0,ye=me.length;ue<ye;ue++){const Ee=r.get(me[ue]);Ee.__webglTexture===void 0&&(Ee.__webglTexture=s.createTexture(),u.memory.textures++)}if(L.samples>0&&ct(L)===!1){$.__webglMultisampledFramebuffer=s.createFramebuffer(),$.__webglColorRenderbuffer=[],t.bindFramebuffer(s.FRAMEBUFFER,$.__webglMultisampledFramebuffer);for(let ue=0;ue<me.length;ue++){const ye=me[ue];$.__webglColorRenderbuffer[ue]=s.createRenderbuffer(),s.bindRenderbuffer(s.RENDERBUFFER,$.__webglColorRenderbuffer[ue]);const Ee=l.convert(ye.format,ye.colorSpace),He=l.convert(ye.type),Ie=C(ye.internalFormat,Ee,He,ye.normalized,ye.colorSpace,L.isXRRenderTarget===!0),ke=wt(L);s.renderbufferStorageMultisample(s.RENDERBUFFER,ke,Ie,L.width,L.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+ue,s.RENDERBUFFER,$.__webglColorRenderbuffer[ue])}s.bindRenderbuffer(s.RENDERBUFFER,null),L.depthBuffer&&($.__webglDepthRenderbuffer=s.createRenderbuffer(),Ft($.__webglDepthRenderbuffer,L,!0)),t.bindFramebuffer(s.FRAMEBUFFER,null)}}if(Me){t.bindTexture(s.TEXTURE_CUBE_MAP,ae.__webglTexture),we(s.TEXTURE_CUBE_MAP,w);for(let ue=0;ue<6;ue++)if(w.mipmaps&&w.mipmaps.length>0)for(let ye=0;ye<w.mipmaps.length;ye++)Qe($.__webglFramebuffer[ue][ye],L,w,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+ue,ye);else Qe($.__webglFramebuffer[ue],L,w,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+ue,0);_(w)&&N(s.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(Ne){for(let ue=0,ye=me.length;ue<ye;ue++){const Ee=me[ue],He=r.get(Ee);let Ie=s.TEXTURE_2D;(L.isWebGL3DRenderTarget||L.isWebGLArrayRenderTarget)&&(Ie=L.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),t.bindTexture(Ie,He.__webglTexture),we(Ie,Ee),Qe($.__webglFramebuffer,L,Ee,s.COLOR_ATTACHMENT0+ue,Ie,0),_(Ee)&&N(Ie)}t.unbindTexture()}else{let ue=s.TEXTURE_2D;if((L.isWebGL3DRenderTarget||L.isWebGLArrayRenderTarget)&&(ue=L.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),t.bindTexture(ue,ae.__webglTexture),we(ue,w),w.mipmaps&&w.mipmaps.length>0)for(let ye=0;ye<w.mipmaps.length;ye++)Qe($.__webglFramebuffer[ye],L,w,s.COLOR_ATTACHMENT0,ue,ye);else Qe($.__webglFramebuffer,L,w,s.COLOR_ATTACHMENT0,ue,0);_(w)&&N(ue),t.unbindTexture()}L.depthBuffer&&Ct(L)}function Lt(L){const w=L.textures;for(let $=0,ae=w.length;$<ae;$++){const me=w[$];if(_(me)){const Me=P(L),Ne=r.get(me).__webglTexture;t.bindTexture(Me,Ne),N(Me),t.unbindTexture()}}}const zt=[],St=[];function Dt(L){if(L.samples>0){if(ct(L)===!1){const w=L.textures,$=L.width,ae=L.height;let me=s.COLOR_BUFFER_BIT;const Me=L.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,Ne=r.get(L),ue=w.length>1;if(ue)for(let Ee=0;Ee<w.length;Ee++)t.bindFramebuffer(s.FRAMEBUFFER,Ne.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+Ee,s.RENDERBUFFER,null),t.bindFramebuffer(s.FRAMEBUFFER,Ne.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+Ee,s.TEXTURE_2D,null,0);t.bindFramebuffer(s.READ_FRAMEBUFFER,Ne.__webglMultisampledFramebuffer);const ye=L.texture.mipmaps;ye&&ye.length>0?t.bindFramebuffer(s.DRAW_FRAMEBUFFER,Ne.__webglFramebuffer[0]):t.bindFramebuffer(s.DRAW_FRAMEBUFFER,Ne.__webglFramebuffer);for(let Ee=0;Ee<w.length;Ee++){if(L.resolveDepthBuffer&&(L.depthBuffer&&(me|=s.DEPTH_BUFFER_BIT),L.stencilBuffer&&L.resolveStencilBuffer&&(me|=s.STENCIL_BUFFER_BIT)),ue){s.framebufferRenderbuffer(s.READ_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.RENDERBUFFER,Ne.__webglColorRenderbuffer[Ee]);const He=r.get(w[Ee]).__webglTexture;s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,He,0)}s.blitFramebuffer(0,0,$,ae,0,0,$,ae,me,s.NEAREST),p===!0&&(zt.length=0,St.length=0,zt.push(s.COLOR_ATTACHMENT0+Ee),L.depthBuffer&&L.resolveDepthBuffer===!1&&(zt.push(Me),St.push(Me),s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,St)),s.invalidateFramebuffer(s.READ_FRAMEBUFFER,zt))}if(t.bindFramebuffer(s.READ_FRAMEBUFFER,null),t.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),ue)for(let Ee=0;Ee<w.length;Ee++){t.bindFramebuffer(s.FRAMEBUFFER,Ne.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+Ee,s.RENDERBUFFER,Ne.__webglColorRenderbuffer[Ee]);const He=r.get(w[Ee]).__webglTexture;t.bindFramebuffer(s.FRAMEBUFFER,Ne.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+Ee,s.TEXTURE_2D,He,0)}t.bindFramebuffer(s.DRAW_FRAMEBUFFER,Ne.__webglMultisampledFramebuffer)}else if(L.depthBuffer&&L.resolveDepthBuffer===!1&&p){const w=L.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,[w])}}}function wt(L){return Math.min(a.maxSamples,L.samples)}function ct(L){const w=r.get(L);return L.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&w.__useRenderToTexture!==!1}function Q(L){const w=u.render.frame;g.get(L)!==w&&(g.set(L,w),L.update())}function et(L,w){const $=L.colorSpace,ae=L.format,me=L.type;return L.isCompressedTexture===!0||L.isVideoTexture===!0||$!==Mc&&$!==$r&&(kt.getTransfer($)===Wt?(ae!==Bi||me!==Mi)&&gt("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Ut("WebGLTextures: Unsupported texture color space:",$)),w}function ze(L){return typeof HTMLImageElement<"u"&&L instanceof HTMLImageElement?(f.width=L.naturalWidth||L.width,f.height=L.naturalHeight||L.height):typeof VideoFrame<"u"&&L instanceof VideoFrame?(f.width=L.displayWidth,f.height=L.displayHeight):(f.width=L.width,f.height=L.height),f}this.allocateTextureUnit=de,this.resetTextureUnits=fe,this.getTextureUnits=re,this.setTextureUnits=q,this.setTexture2D=Z,this.setTexture2DArray=ee,this.setTexture3D=ce,this.setTextureCube=F,this.rebindTextures=it,this.setupRenderTarget=Je,this.updateRenderTargetMipmap=Lt,this.updateMultisampleRenderTarget=Dt,this.setupDepthRenderbuffer=Ct,this.setupFrameBufferTexture=Qe,this.useMultisampledRTT=ct,this.isReversedDepthBuffer=function(){return t.buffers.depth.getReversed()}}function Qw(s,e){function t(r,a=$r){let l;const u=kt.getTransfer(a);if(r===Mi)return s.UNSIGNED_BYTE;if(r===tf)return s.UNSIGNED_SHORT_4_4_4_4;if(r===nf)return s.UNSIGNED_SHORT_5_5_5_1;if(r===Ag)return s.UNSIGNED_INT_5_9_9_9_REV;if(r===Cg)return s.UNSIGNED_INT_10F_11F_11F_REV;if(r===Eg)return s.BYTE;if(r===Tg)return s.SHORT;if(r===bo)return s.UNSIGNED_SHORT;if(r===ef)return s.INT;if(r===er)return s.UNSIGNED_INT;if(r===Oi)return s.FLOAT;if(r===fi)return s.HALF_FLOAT;if(r===Rg)return s.ALPHA;if(r===Pg)return s.RGB;if(r===Bi)return s.RGBA;if(r===yr)return s.DEPTH_COMPONENT;if(r===Ss)return s.DEPTH_STENCIL;if(r===Ng)return s.RED;if(r===rf)return s.RED_INTEGER;if(r===Qr)return s.RG;if(r===sf)return s.RG_INTEGER;if(r===af)return s.RGBA_INTEGER;if(r===cc||r===uc||r===dc||r===hc)if(u===Wt)if(l=e.get("WEBGL_compressed_texture_s3tc_srgb"),l!==null){if(r===cc)return l.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===uc)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===dc)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===hc)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(l=e.get("WEBGL_compressed_texture_s3tc"),l!==null){if(r===cc)return l.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===uc)return l.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===dc)return l.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===hc)return l.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===dh||r===hh||r===fh||r===ph)if(l=e.get("WEBGL_compressed_texture_pvrtc"),l!==null){if(r===dh)return l.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===hh)return l.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===fh)return l.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===ph)return l.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===mh||r===gh||r===xh||r===vh||r===_h||r===bc||r===yh)if(l=e.get("WEBGL_compressed_texture_etc"),l!==null){if(r===mh||r===gh)return u===Wt?l.COMPRESSED_SRGB8_ETC2:l.COMPRESSED_RGB8_ETC2;if(r===xh)return u===Wt?l.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:l.COMPRESSED_RGBA8_ETC2_EAC;if(r===vh)return l.COMPRESSED_R11_EAC;if(r===_h)return l.COMPRESSED_SIGNED_R11_EAC;if(r===bc)return l.COMPRESSED_RG11_EAC;if(r===yh)return l.COMPRESSED_SIGNED_RG11_EAC}else return null;if(r===bh||r===Sh||r===Mh||r===wh||r===Eh||r===Th||r===Ah||r===Ch||r===Rh||r===Ph||r===Nh||r===Lh||r===Dh||r===Ih)if(l=e.get("WEBGL_compressed_texture_astc"),l!==null){if(r===bh)return u===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:l.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===Sh)return u===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:l.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===Mh)return u===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:l.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===wh)return u===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:l.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===Eh)return u===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:l.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===Th)return u===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:l.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===Ah)return u===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:l.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===Ch)return u===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:l.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===Rh)return u===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:l.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===Ph)return u===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:l.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===Nh)return u===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:l.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===Lh)return u===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:l.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===Dh)return u===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:l.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===Ih)return u===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:l.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===kh||r===Fh||r===Uh)if(l=e.get("EXT_texture_compression_bptc"),l!==null){if(r===kh)return u===Wt?l.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:l.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===Fh)return l.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===Uh)return l.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===Oh||r===Bh||r===Sc||r===zh)if(l=e.get("EXT_texture_compression_rgtc"),l!==null){if(r===Oh)return l.COMPRESSED_RED_RGTC1_EXT;if(r===Bh)return l.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===Sc)return l.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===zh)return l.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===So?s.UNSIGNED_INT_24_8:s[r]!==void 0?s[r]:null}return{convert:t}}const Jw=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,eE=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class tE{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const r=new jg(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=r}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,r=new _n({vertexShader:Jw,fragmentShader:eE,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new wi(new Co(20,20),r)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class nE extends es{constructor(e,t){super();const r=this;let a=null,l=1,u=null,h="local-floor",p=1,f=null,g=null,b=null,v=null,S=null,M=null;const E=typeof XRWebGLBinding<"u",x=new tE,_={},N=t.getContextAttributes();let P=null,C=null;const k=[],D=[],U=new dt;let T=null;const I=new Si;I.viewport=new un;const z=new Si;z.viewport=new un;const O=[I,z],H=new o1;let fe=null,re=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(ie){let xe=k[ie];return xe===void 0&&(xe=new wd,k[ie]=xe),xe.getTargetRaySpace()},this.getControllerGrip=function(ie){let xe=k[ie];return xe===void 0&&(xe=new wd,k[ie]=xe),xe.getGripSpace()},this.getHand=function(ie){let xe=k[ie];return xe===void 0&&(xe=new wd,k[ie]=xe),xe.getHandSpace()};function q(ie){const xe=D.indexOf(ie.inputSource);if(xe===-1)return;const ve=k[xe];ve!==void 0&&(ve.update(ie.inputSource,ie.frame,f||u),ve.dispatchEvent({type:ie.type,data:ie.inputSource}))}function de(){a.removeEventListener("select",q),a.removeEventListener("selectstart",q),a.removeEventListener("selectend",q),a.removeEventListener("squeeze",q),a.removeEventListener("squeezestart",q),a.removeEventListener("squeezeend",q),a.removeEventListener("end",de),a.removeEventListener("inputsourceschange",oe);for(let ie=0;ie<k.length;ie++){const xe=D[ie];xe!==null&&(D[ie]=null,k[ie].disconnect(xe))}fe=null,re=null,x.reset();for(const ie in _)delete _[ie];e.setRenderTarget(P),S=null,v=null,b=null,a=null,C=null,we.stop(),r.isPresenting=!1,e.setPixelRatio(T),e.setSize(U.width,U.height,!1),r.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(ie){l=ie,r.isPresenting===!0&&gt("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(ie){h=ie,r.isPresenting===!0&&gt("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return f||u},this.setReferenceSpace=function(ie){f=ie},this.getBaseLayer=function(){return v!==null?v:S},this.getBinding=function(){return b===null&&E&&(b=new XRWebGLBinding(a,t)),b},this.getFrame=function(){return M},this.getSession=function(){return a},this.setSession=async function(ie){if(a=ie,a!==null){if(P=e.getRenderTarget(),a.addEventListener("select",q),a.addEventListener("selectstart",q),a.addEventListener("selectend",q),a.addEventListener("squeeze",q),a.addEventListener("squeezestart",q),a.addEventListener("squeezeend",q),a.addEventListener("end",de),a.addEventListener("inputsourceschange",oe),N.xrCompatible!==!0&&await t.makeXRCompatible(),T=e.getPixelRatio(),e.getSize(U),E&&"createProjectionLayer"in XRWebGLBinding.prototype){let ve=null,te=null,Se=null;N.depth&&(Se=N.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,ve=N.stencil?Ss:yr,te=N.stencil?So:er);const Qe={colorFormat:t.RGBA8,depthFormat:Se,scaleFactor:l};b=this.getBinding(),v=b.createProjectionLayer(Qe),a.updateRenderState({layers:[v]}),e.setPixelRatio(1),e.setSize(v.textureWidth,v.textureHeight,!1),C=new ai(v.textureWidth,v.textureHeight,{format:Bi,type:Mi,depthTexture:new Sa(v.textureWidth,v.textureHeight,te,void 0,void 0,void 0,void 0,void 0,void 0,ve),stencilBuffer:N.stencil,colorSpace:e.outputColorSpace,samples:N.antialias?4:0,resolveDepthBuffer:v.ignoreDepthValues===!1,resolveStencilBuffer:v.ignoreDepthValues===!1})}else{const ve={antialias:N.antialias,alpha:!0,depth:N.depth,stencil:N.stencil,framebufferScaleFactor:l};S=new XRWebGLLayer(a,t,ve),a.updateRenderState({baseLayer:S}),e.setPixelRatio(1),e.setSize(S.framebufferWidth,S.framebufferHeight,!1),C=new ai(S.framebufferWidth,S.framebufferHeight,{format:Bi,type:Mi,colorSpace:e.outputColorSpace,stencilBuffer:N.stencil,resolveDepthBuffer:S.ignoreDepthValues===!1,resolveStencilBuffer:S.ignoreDepthValues===!1})}C.isXRRenderTarget=!0,this.setFoveation(p),f=null,u=await a.requestReferenceSpace(h),we.setContext(a),we.start(),r.isPresenting=!0,r.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(a!==null)return a.environmentBlendMode},this.getDepthTexture=function(){return x.getDepthTexture()};function oe(ie){for(let xe=0;xe<ie.removed.length;xe++){const ve=ie.removed[xe],te=D.indexOf(ve);te>=0&&(D[te]=null,k[te].disconnect(ve))}for(let xe=0;xe<ie.added.length;xe++){const ve=ie.added[xe];let te=D.indexOf(ve);if(te===-1){for(let Qe=0;Qe<k.length;Qe++)if(Qe>=D.length){D.push(ve),te=Qe;break}else if(D[Qe]===null){D[Qe]=ve,te=Qe;break}if(te===-1)break}const Se=k[te];Se&&Se.connect(ve)}}const Z=new X,ee=new X;function ce(ie,xe,ve){Z.setFromMatrixPosition(xe.matrixWorld),ee.setFromMatrixPosition(ve.matrixWorld);const te=Z.distanceTo(ee),Se=xe.projectionMatrix.elements,Qe=ve.projectionMatrix.elements,Ft=Se[14]/(Se[10]-1),ut=Se[14]/(Se[10]+1),Ct=(Se[9]+1)/Se[5],it=(Se[9]-1)/Se[5],Je=(Se[8]-1)/Se[0],Lt=(Qe[8]+1)/Qe[0],zt=Ft*Je,St=Ft*Lt,Dt=te/(-Je+Lt),wt=Dt*-Je;if(xe.matrixWorld.decompose(ie.position,ie.quaternion,ie.scale),ie.translateX(wt),ie.translateZ(Dt),ie.matrixWorld.compose(ie.position,ie.quaternion,ie.scale),ie.matrixWorldInverse.copy(ie.matrixWorld).invert(),Se[10]===-1)ie.projectionMatrix.copy(xe.projectionMatrix),ie.projectionMatrixInverse.copy(xe.projectionMatrixInverse);else{const ct=Ft+Dt,Q=ut+Dt,et=zt-wt,ze=St+(te-wt),L=Ct*ut/Q*ct,w=it*ut/Q*ct;ie.projectionMatrix.makePerspective(et,ze,L,w,ct,Q),ie.projectionMatrixInverse.copy(ie.projectionMatrix).invert()}}function F(ie,xe){xe===null?ie.matrixWorld.copy(ie.matrix):ie.matrixWorld.multiplyMatrices(xe.matrixWorld,ie.matrix),ie.matrixWorldInverse.copy(ie.matrixWorld).invert()}this.updateCamera=function(ie){if(a===null)return;let xe=ie.near,ve=ie.far;x.texture!==null&&(x.depthNear>0&&(xe=x.depthNear),x.depthFar>0&&(ve=x.depthFar)),H.near=z.near=I.near=xe,H.far=z.far=I.far=ve,(fe!==H.near||re!==H.far)&&(a.updateRenderState({depthNear:H.near,depthFar:H.far}),fe=H.near,re=H.far),H.layers.mask=ie.layers.mask|6,I.layers.mask=H.layers.mask&-5,z.layers.mask=H.layers.mask&-3;const te=ie.parent,Se=H.cameras;F(H,te);for(let Qe=0;Qe<Se.length;Qe++)F(Se[Qe],te);Se.length===2?ce(H,I,z):H.projectionMatrix.copy(I.projectionMatrix),Y(ie,H,te)};function Y(ie,xe,ve){ve===null?ie.matrix.copy(xe.matrixWorld):(ie.matrix.copy(ve.matrixWorld),ie.matrix.invert(),ie.matrix.multiply(xe.matrixWorld)),ie.matrix.decompose(ie.position,ie.quaternion,ie.scale),ie.updateMatrixWorld(!0),ie.projectionMatrix.copy(xe.projectionMatrix),ie.projectionMatrixInverse.copy(xe.projectionMatrixInverse),ie.isPerspectiveCamera&&(ie.fov=jh*2*Math.atan(1/ie.projectionMatrix.elements[5]),ie.zoom=1)}this.getCamera=function(){return H},this.getFoveation=function(){if(!(v===null&&S===null))return p},this.setFoveation=function(ie){p=ie,v!==null&&(v.fixedFoveation=ie),S!==null&&S.fixedFoveation!==void 0&&(S.fixedFoveation=ie)},this.hasDepthSensing=function(){return x.texture!==null},this.getDepthSensingMesh=function(){return x.getMesh(H)},this.getCameraTexture=function(ie){return _[ie]};let Ce=null;function qe(ie,xe){if(g=xe.getViewerPose(f||u),M=xe,g!==null){const ve=g.views;S!==null&&(e.setRenderTargetFramebuffer(C,S.framebuffer),e.setRenderTarget(C));let te=!1;ve.length!==H.cameras.length&&(H.cameras.length=0,te=!0);for(let ut=0;ut<ve.length;ut++){const Ct=ve[ut];let it=null;if(S!==null)it=S.getViewport(Ct);else{const Lt=b.getViewSubImage(v,Ct);it=Lt.viewport,ut===0&&(e.setRenderTargetTextures(C,Lt.colorTexture,Lt.depthStencilTexture),e.setRenderTarget(C))}let Je=O[ut];Je===void 0&&(Je=new Si,Je.layers.enable(ut),Je.viewport=new un,O[ut]=Je),Je.matrix.fromArray(Ct.transform.matrix),Je.matrix.decompose(Je.position,Je.quaternion,Je.scale),Je.projectionMatrix.fromArray(Ct.projectionMatrix),Je.projectionMatrixInverse.copy(Je.projectionMatrix).invert(),Je.viewport.set(it.x,it.y,it.width,it.height),ut===0&&(H.matrix.copy(Je.matrix),H.matrix.decompose(H.position,H.quaternion,H.scale)),te===!0&&H.cameras.push(Je)}const Se=a.enabledFeatures;if(Se&&Se.includes("depth-sensing")&&a.depthUsage=="gpu-optimized"&&E){b=r.getBinding();const ut=b.getDepthInformation(ve[0]);ut&&ut.isValid&&ut.texture&&x.init(ut,a.renderState)}if(Se&&Se.includes("camera-access")&&E){e.state.unbindTexture(),b=r.getBinding();for(let ut=0;ut<ve.length;ut++){const Ct=ve[ut].camera;if(Ct){let it=_[Ct];it||(it=new jg,_[Ct]=it);const Je=b.getCameraImage(Ct);it.sourceTexture=Je}}}}for(let ve=0;ve<k.length;ve++){const te=D[ve],Se=k[ve];te!==null&&Se!==void 0&&Se.update(te,xe,f||u)}Ce&&Ce(ie,xe),xe.detectedPlanes&&r.dispatchEvent({type:"planesdetected",data:xe}),M=null}const we=new Wg;we.setAnimationLoop(qe),this.setAnimationLoop=function(ie){Ce=ie},this.dispose=function(){}}}const iE=new en,Qg=new yt;Qg.set(-1,0,0,0,1,0,0,0,1);function rE(s,e){function t(x,_){x.matrixAutoUpdate===!0&&x.updateMatrix(),_.value.copy(x.matrix)}function r(x,_){_.color.getRGB(x.fogColor.value,Hg(s)),_.isFog?(x.fogNear.value=_.near,x.fogFar.value=_.far):_.isFogExp2&&(x.fogDensity.value=_.density)}function a(x,_,N,P,C){_.isNodeMaterial?_.uniformsNeedUpdate=!1:_.isMeshBasicMaterial?l(x,_):_.isMeshLambertMaterial?(l(x,_),_.envMap&&(x.envMapIntensity.value=_.envMapIntensity)):_.isMeshToonMaterial?(l(x,_),b(x,_)):_.isMeshPhongMaterial?(l(x,_),g(x,_),_.envMap&&(x.envMapIntensity.value=_.envMapIntensity)):_.isMeshStandardMaterial?(l(x,_),v(x,_),_.isMeshPhysicalMaterial&&S(x,_,C)):_.isMeshMatcapMaterial?(l(x,_),M(x,_)):_.isMeshDepthMaterial?l(x,_):_.isMeshDistanceMaterial?(l(x,_),E(x,_)):_.isMeshNormalMaterial?l(x,_):_.isLineBasicMaterial?(u(x,_),_.isLineDashedMaterial&&h(x,_)):_.isPointsMaterial?p(x,_,N,P):_.isSpriteMaterial?f(x,_):_.isShadowMaterial?(x.color.value.copy(_.color),x.opacity.value=_.opacity):_.isShaderMaterial&&(_.uniformsNeedUpdate=!1)}function l(x,_){x.opacity.value=_.opacity,_.color&&x.diffuse.value.copy(_.color),_.emissive&&x.emissive.value.copy(_.emissive).multiplyScalar(_.emissiveIntensity),_.map&&(x.map.value=_.map,t(_.map,x.mapTransform)),_.alphaMap&&(x.alphaMap.value=_.alphaMap,t(_.alphaMap,x.alphaMapTransform)),_.bumpMap&&(x.bumpMap.value=_.bumpMap,t(_.bumpMap,x.bumpMapTransform),x.bumpScale.value=_.bumpScale,_.side===si&&(x.bumpScale.value*=-1)),_.normalMap&&(x.normalMap.value=_.normalMap,t(_.normalMap,x.normalMapTransform),x.normalScale.value.copy(_.normalScale),_.side===si&&x.normalScale.value.negate()),_.displacementMap&&(x.displacementMap.value=_.displacementMap,t(_.displacementMap,x.displacementMapTransform),x.displacementScale.value=_.displacementScale,x.displacementBias.value=_.displacementBias),_.emissiveMap&&(x.emissiveMap.value=_.emissiveMap,t(_.emissiveMap,x.emissiveMapTransform)),_.specularMap&&(x.specularMap.value=_.specularMap,t(_.specularMap,x.specularMapTransform)),_.alphaTest>0&&(x.alphaTest.value=_.alphaTest);const N=e.get(_),P=N.envMap,C=N.envMapRotation;P&&(x.envMap.value=P,x.envMapRotation.value.setFromMatrix4(iE.makeRotationFromEuler(C)).transpose(),P.isCubeTexture&&P.isRenderTargetTexture===!1&&x.envMapRotation.value.premultiply(Qg),x.reflectivity.value=_.reflectivity,x.ior.value=_.ior,x.refractionRatio.value=_.refractionRatio),_.lightMap&&(x.lightMap.value=_.lightMap,x.lightMapIntensity.value=_.lightMapIntensity,t(_.lightMap,x.lightMapTransform)),_.aoMap&&(x.aoMap.value=_.aoMap,x.aoMapIntensity.value=_.aoMapIntensity,t(_.aoMap,x.aoMapTransform))}function u(x,_){x.diffuse.value.copy(_.color),x.opacity.value=_.opacity,_.map&&(x.map.value=_.map,t(_.map,x.mapTransform))}function h(x,_){x.dashSize.value=_.dashSize,x.totalSize.value=_.dashSize+_.gapSize,x.scale.value=_.scale}function p(x,_,N,P){x.diffuse.value.copy(_.color),x.opacity.value=_.opacity,x.size.value=_.size*N,x.scale.value=P*.5,_.map&&(x.map.value=_.map,t(_.map,x.uvTransform)),_.alphaMap&&(x.alphaMap.value=_.alphaMap,t(_.alphaMap,x.alphaMapTransform)),_.alphaTest>0&&(x.alphaTest.value=_.alphaTest)}function f(x,_){x.diffuse.value.copy(_.color),x.opacity.value=_.opacity,x.rotation.value=_.rotation,_.map&&(x.map.value=_.map,t(_.map,x.mapTransform)),_.alphaMap&&(x.alphaMap.value=_.alphaMap,t(_.alphaMap,x.alphaMapTransform)),_.alphaTest>0&&(x.alphaTest.value=_.alphaTest)}function g(x,_){x.specular.value.copy(_.specular),x.shininess.value=Math.max(_.shininess,1e-4)}function b(x,_){_.gradientMap&&(x.gradientMap.value=_.gradientMap)}function v(x,_){x.metalness.value=_.metalness,_.metalnessMap&&(x.metalnessMap.value=_.metalnessMap,t(_.metalnessMap,x.metalnessMapTransform)),x.roughness.value=_.roughness,_.roughnessMap&&(x.roughnessMap.value=_.roughnessMap,t(_.roughnessMap,x.roughnessMapTransform)),_.envMap&&(x.envMapIntensity.value=_.envMapIntensity)}function S(x,_,N){x.ior.value=_.ior,_.sheen>0&&(x.sheenColor.value.copy(_.sheenColor).multiplyScalar(_.sheen),x.sheenRoughness.value=_.sheenRoughness,_.sheenColorMap&&(x.sheenColorMap.value=_.sheenColorMap,t(_.sheenColorMap,x.sheenColorMapTransform)),_.sheenRoughnessMap&&(x.sheenRoughnessMap.value=_.sheenRoughnessMap,t(_.sheenRoughnessMap,x.sheenRoughnessMapTransform))),_.clearcoat>0&&(x.clearcoat.value=_.clearcoat,x.clearcoatRoughness.value=_.clearcoatRoughness,_.clearcoatMap&&(x.clearcoatMap.value=_.clearcoatMap,t(_.clearcoatMap,x.clearcoatMapTransform)),_.clearcoatRoughnessMap&&(x.clearcoatRoughnessMap.value=_.clearcoatRoughnessMap,t(_.clearcoatRoughnessMap,x.clearcoatRoughnessMapTransform)),_.clearcoatNormalMap&&(x.clearcoatNormalMap.value=_.clearcoatNormalMap,t(_.clearcoatNormalMap,x.clearcoatNormalMapTransform),x.clearcoatNormalScale.value.copy(_.clearcoatNormalScale),_.side===si&&x.clearcoatNormalScale.value.negate())),_.dispersion>0&&(x.dispersion.value=_.dispersion),_.iridescence>0&&(x.iridescence.value=_.iridescence,x.iridescenceIOR.value=_.iridescenceIOR,x.iridescenceThicknessMinimum.value=_.iridescenceThicknessRange[0],x.iridescenceThicknessMaximum.value=_.iridescenceThicknessRange[1],_.iridescenceMap&&(x.iridescenceMap.value=_.iridescenceMap,t(_.iridescenceMap,x.iridescenceMapTransform)),_.iridescenceThicknessMap&&(x.iridescenceThicknessMap.value=_.iridescenceThicknessMap,t(_.iridescenceThicknessMap,x.iridescenceThicknessMapTransform))),_.transmission>0&&(x.transmission.value=_.transmission,x.transmissionSamplerMap.value=N.texture,x.transmissionSamplerSize.value.set(N.width,N.height),_.transmissionMap&&(x.transmissionMap.value=_.transmissionMap,t(_.transmissionMap,x.transmissionMapTransform)),x.thickness.value=_.thickness,_.thicknessMap&&(x.thicknessMap.value=_.thicknessMap,t(_.thicknessMap,x.thicknessMapTransform)),x.attenuationDistance.value=_.attenuationDistance,x.attenuationColor.value.copy(_.attenuationColor)),_.anisotropy>0&&(x.anisotropyVector.value.set(_.anisotropy*Math.cos(_.anisotropyRotation),_.anisotropy*Math.sin(_.anisotropyRotation)),_.anisotropyMap&&(x.anisotropyMap.value=_.anisotropyMap,t(_.anisotropyMap,x.anisotropyMapTransform))),x.specularIntensity.value=_.specularIntensity,x.specularColor.value.copy(_.specularColor),_.specularColorMap&&(x.specularColorMap.value=_.specularColorMap,t(_.specularColorMap,x.specularColorMapTransform)),_.specularIntensityMap&&(x.specularIntensityMap.value=_.specularIntensityMap,t(_.specularIntensityMap,x.specularIntensityMapTransform))}function M(x,_){_.matcap&&(x.matcap.value=_.matcap)}function E(x,_){const N=e.get(_).light;x.referencePosition.value.setFromMatrixPosition(N.matrixWorld),x.nearDistance.value=N.shadow.camera.near,x.farDistance.value=N.shadow.camera.far}return{refreshFogUniforms:r,refreshMaterialUniforms:a}}function sE(s,e,t,r){let a={},l={},u=[];const h=s.getParameter(s.MAX_UNIFORM_BUFFER_BINDINGS);function p(C,k){const D=k.program;r.uniformBlockBinding(C,D)}function f(C,k){let D=a[C.id];D===void 0&&(x(C),D=g(C),a[C.id]=D,C.addEventListener("dispose",N));const U=k.program;r.updateUBOMapping(C,U);const T=e.render.frame;l[C.id]!==T&&(v(C),l[C.id]=T)}function g(C){const k=b();C.__bindingPointIndex=k;const D=s.createBuffer(),U=C.__size,T=C.usage;return s.bindBuffer(s.UNIFORM_BUFFER,D),s.bufferData(s.UNIFORM_BUFFER,U,T),s.bindBuffer(s.UNIFORM_BUFFER,null),s.bindBufferBase(s.UNIFORM_BUFFER,k,D),D}function b(){for(let C=0;C<h;C++)if(u.indexOf(C)===-1)return u.push(C),C;return Ut("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function v(C){const k=a[C.id],D=C.uniforms,U=C.__cache;s.bindBuffer(s.UNIFORM_BUFFER,k);for(let T=0,I=D.length;T<I;T++){const z=D[T];if(Array.isArray(z))for(let O=0,H=z.length;O<H;O++)S(z[O],T,O,U);else S(z,T,0,U)}s.bindBuffer(s.UNIFORM_BUFFER,null)}function S(C,k,D,U){if(E(C,k,D,U)===!0){const T=C.__offset,I=C.value;if(Array.isArray(I)){let z=0;for(let O=0;O<I.length;O++){const H=I[O],fe=_(H);M(H,C.__data,z),typeof H!="number"&&typeof H!="boolean"&&!H.isMatrix3&&!ArrayBuffer.isView(H)&&(z+=fe.storage/Float32Array.BYTES_PER_ELEMENT)}}else M(I,C.__data,0);s.bufferSubData(s.UNIFORM_BUFFER,T,C.__data)}}function M(C,k,D){typeof C=="number"||typeof C=="boolean"?k[0]=C:C.isMatrix3?(k[0]=C.elements[0],k[1]=C.elements[1],k[2]=C.elements[2],k[3]=0,k[4]=C.elements[3],k[5]=C.elements[4],k[6]=C.elements[5],k[7]=0,k[8]=C.elements[6],k[9]=C.elements[7],k[10]=C.elements[8],k[11]=0):ArrayBuffer.isView(C)?k.set(new C.constructor(C.buffer,C.byteOffset,k.length)):C.toArray(k,D)}function E(C,k,D,U){const T=C.value,I=k+"_"+D;if(U[I]===void 0)return typeof T=="number"||typeof T=="boolean"?U[I]=T:ArrayBuffer.isView(T)?U[I]=T.slice():U[I]=T.clone(),!0;{const z=U[I];if(typeof T=="number"||typeof T=="boolean"){if(z!==T)return U[I]=T,!0}else{if(ArrayBuffer.isView(T))return!0;if(z.equals(T)===!1)return z.copy(T),!0}}return!1}function x(C){const k=C.uniforms;let D=0;const U=16;for(let I=0,z=k.length;I<z;I++){const O=Array.isArray(k[I])?k[I]:[k[I]];for(let H=0,fe=O.length;H<fe;H++){const re=O[H],q=Array.isArray(re.value)?re.value:[re.value];for(let de=0,oe=q.length;de<oe;de++){const Z=q[de],ee=_(Z),ce=D%U,F=ce%ee.boundary,Y=ce+F;D+=F,Y!==0&&U-Y<ee.storage&&(D+=U-Y),re.__data=new Float32Array(ee.storage/Float32Array.BYTES_PER_ELEMENT),re.__offset=D,D+=ee.storage}}}const T=D%U;return T>0&&(D+=U-T),C.__size=D,C.__cache={},this}function _(C){const k={boundary:0,storage:0};return typeof C=="number"||typeof C=="boolean"?(k.boundary=4,k.storage=4):C.isVector2?(k.boundary=8,k.storage=8):C.isVector3||C.isColor?(k.boundary=16,k.storage=12):C.isVector4?(k.boundary=16,k.storage=16):C.isMatrix3?(k.boundary=48,k.storage=48):C.isMatrix4?(k.boundary=64,k.storage=64):C.isTexture?gt("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(C)?(k.boundary=16,k.storage=C.byteLength):gt("WebGLRenderer: Unsupported uniform value type.",C),k}function N(C){const k=C.target;k.removeEventListener("dispose",N);const D=u.indexOf(k.__bindingPointIndex);u.splice(D,1),s.deleteBuffer(a[k.id]),delete a[k.id],delete l[k.id]}function P(){for(const C in a)s.deleteBuffer(a[C]);u=[],a={},l={}}return{bind:p,update:f,dispose:P}}const aE=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let Yi=null;function oE(){return Yi===null&&(Yi=new Ug(aE,16,16,Qr,fi),Yi.name="DFG_LUT",Yi.minFilter=zn,Yi.magFilter=zn,Yi.wrapS=xr,Yi.wrapT=xr,Yi.generateMipmaps=!1,Yi.needsUpdate=!0),Yi}class lE{constructor(e={}){const{canvas:t=by(),context:r=null,depth:a=!0,stencil:l=!1,alpha:u=!1,antialias:h=!1,premultipliedAlpha:p=!0,preserveDrawingBuffer:f=!1,powerPreference:g="default",failIfMajorPerformanceCaveat:b=!1,reversedDepthBuffer:v=!1,outputBufferType:S=Mi}=e;this.isWebGLRenderer=!0;let M;if(r!==null){if(typeof WebGLRenderingContext<"u"&&r instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");M=r.getContextAttributes().alpha}else M=u;const E=S,x=new Set([af,sf,rf]),_=new Set([Mi,er,bo,So,tf,nf]),N=new Uint32Array(4),P=new Int32Array(4),C=new X;let k=null,D=null;const U=[],T=[];let I=null;this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Ji,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const z=this;let O=!1,H=null,fe=null,re=null,q=null;this._outputColorSpace=bi;let de=0,oe=0,Z=null,ee=-1,ce=null;const F=new un,Y=new un;let Ce=null;const qe=new _t(0);let we=0,ie=t.width,xe=t.height,ve=1,te=null,Se=null;const Qe=new un(0,0,ie,xe),Ft=new un(0,0,ie,xe);let ut=!1;const Ct=new Og;let it=!1,Je=!1;const Lt=new en,zt=new X,St=new un,Dt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let wt=!1;function ct(){return Z===null?ve:1}let Q=r;function et(R,W){return t.getContext(R,W)}try{const R={alpha:!0,depth:a,stencil:l,antialias:h,premultipliedAlpha:p,preserveDrawingBuffer:f,powerPreference:g,failIfMajorPerformanceCaveat:b};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${Jh}`),t.addEventListener("webglcontextlost",ht,!1),t.addEventListener("webglcontextrestored",Et,!1),t.addEventListener("webglcontextcreationerror",$t,!1),Q===null){const W="webgl2";if(Q=et(W,R),Q===null)throw et(W)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}}catch(R){throw Ut("WebGLRenderer: "+R.message),R}let ze,L,w,$,ae,me,Me,Ne,ue,ye,Ee,He,Ie,ke,We,Ze,at,G,Fe,j,be,Re,_e;function Be(){ze=new oM(Q),ze.init(),be=new Qw(Q,ze),L=new JS(Q,ze,e,be),w=new Kw(Q,ze),L.reversedDepthBuffer&&v&&w.buffers.depth.setReversed(!0),fe=Q.createFramebuffer(),re=Q.createFramebuffer(),q=Q.createFramebuffer(),$=new uM(Q),ae=new Fw,me=new Zw(Q,ze,w,ae,L,be,$),Me=new aM(z),Ne=new p1(Q),Re=new ZS(Q,Ne),ue=new lM(Q,Ne,$,Re),ye=new hM(Q,ue,Ne,Re,$),G=new dM(Q,L,me),We=new eM(ae),Ee=new kw(z,Me,ze,L,Re,We),He=new rE(z,ae),Ie=new Ow,ke=new Gw(ze),at=new KS(z,Me,w,ye,M,p),Ze=new Yw(z,ye,L),_e=new sE(Q,$,L,w),Fe=new QS(Q,ze,$),j=new cM(Q,ze,$),$.programs=Ee.programs,z.capabilities=L,z.extensions=ze,z.properties=ae,z.renderLists=Ie,z.shadowMap=Ze,z.state=w,z.info=$}Be(),E!==Mi&&(I=new pM(E,t.width,t.height,h,a,l));const je=new nE(z,Q);this.xr=je,this.getContext=function(){return Q},this.getContextAttributes=function(){return Q.getContextAttributes()},this.forceContextLoss=function(){const R=ze.get("WEBGL_lose_context");R&&R.loseContext()},this.forceContextRestore=function(){const R=ze.get("WEBGL_lose_context");R&&R.restoreContext()},this.getPixelRatio=function(){return ve},this.setPixelRatio=function(R){R!==void 0&&(ve=R,this.setSize(ie,xe,!1))},this.getSize=function(R){return R.set(ie,xe)},this.setSize=function(R,W,le=!0){if(je.isPresenting){gt("WebGLRenderer: Can't change size while VR device is presenting.");return}ie=R,xe=W,t.width=Math.floor(R*ve),t.height=Math.floor(W*ve),le===!0&&(t.style.width=R+"px",t.style.height=W+"px"),I!==null&&I.setSize(t.width,t.height),this.setViewport(0,0,R,W)},this.getDrawingBufferSize=function(R){return R.set(ie*ve,xe*ve).floor()},this.setDrawingBufferSize=function(R,W,le){ie=R,xe=W,ve=le,t.width=Math.floor(R*le),t.height=Math.floor(W*le),this.setViewport(0,0,R,W)},this.setEffects=function(R){if(E===Mi){Ut("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(R){for(let W=0;W<R.length;W++)if(R[W].isOutputPass===!0){gt("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}I.setEffects(R||[])},this.getCurrentViewport=function(R){return R.copy(F)},this.getViewport=function(R){return R.copy(Qe)},this.setViewport=function(R,W,le,se){R.isVector4?Qe.set(R.x,R.y,R.z,R.w):Qe.set(R,W,le,se),w.viewport(F.copy(Qe).multiplyScalar(ve).round())},this.getScissor=function(R){return R.copy(Ft)},this.setScissor=function(R,W,le,se){R.isVector4?Ft.set(R.x,R.y,R.z,R.w):Ft.set(R,W,le,se),w.scissor(Y.copy(Ft).multiplyScalar(ve).round())},this.getScissorTest=function(){return ut},this.setScissorTest=function(R){w.setScissorTest(ut=R)},this.setOpaqueSort=function(R){te=R},this.setTransparentSort=function(R){Se=R},this.getClearColor=function(R){return R.copy(at.getClearColor())},this.setClearColor=function(){at.setClearColor(...arguments)},this.getClearAlpha=function(){return at.getClearAlpha()},this.setClearAlpha=function(){at.setClearAlpha(...arguments)},this.clear=function(R=!0,W=!0,le=!0){let se=0;if(R){let ne=!1;if(Z!==null){const Te=Z.texture.format;ne=x.has(Te)}if(ne){const Te=Z.texture.type,Oe=_.has(Te),Le=at.getClearColor(),Xe=at.getClearAlpha(),Ve=Le.r,lt=Le.g,mt=Le.b;Oe?(N[0]=Ve,N[1]=lt,N[2]=mt,N[3]=Xe,Q.clearBufferuiv(Q.COLOR,0,N)):(P[0]=Ve,P[1]=lt,P[2]=mt,P[3]=Xe,Q.clearBufferiv(Q.COLOR,0,P))}else se|=Q.COLOR_BUFFER_BIT}W&&(se|=Q.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),le&&(se|=Q.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),se!==0&&Q.clear(se)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(R){R.setRenderer(this),H=R},this.dispose=function(){t.removeEventListener("webglcontextlost",ht,!1),t.removeEventListener("webglcontextrestored",Et,!1),t.removeEventListener("webglcontextcreationerror",$t,!1),at.dispose(),Ie.dispose(),ke.dispose(),ae.dispose(),Me.dispose(),ye.dispose(),Re.dispose(),_e.dispose(),Ee.dispose(),je.dispose(),je.removeEventListener("sessionstart",zi),je.removeEventListener("sessionend",Ts),Sn.stop()};function ht(R){R.preventDefault(),i0("WebGLRenderer: Context Lost."),O=!0}function Et(){i0("WebGLRenderer: Context Restored."),O=!1;const R=$.autoReset,W=Ze.enabled,le=Ze.autoUpdate,se=Ze.needsUpdate,ne=Ze.type;Be(),$.autoReset=R,Ze.enabled=W,Ze.autoUpdate=le,Ze.needsUpdate=se,Ze.type=ne}function $t(R){Ut("WebGLRenderer: A WebGL context could not be created. Reason: ",R.statusMessage)}function It(R){const W=R.target;W.removeEventListener("dispose",It),tn(W)}function tn(R){Cn(R),ae.remove(R)}function Cn(R){const W=ae.get(R).programs;W!==void 0&&(W.forEach(function(le){Ee.releaseProgram(le)}),R.isShaderMaterial&&Ee.releaseShaderCache(R))}this.renderBufferDirect=function(R,W,le,se,ne,Te){W===null&&(W=Dt);const Oe=ne.isMesh&&ne.matrixWorld.determinantAffine()<0,Le=bt(R,W,le,se,ne);w.setMaterial(se,Oe);let Xe=le.index,Ve=1;if(se.wireframe===!0){if(Xe=ue.getWireframeAttribute(le),Xe===void 0)return;Ve=2}const lt=le.drawRange,mt=le.attributes.position;let $e=lt.start*Ve,Rt=(lt.start+lt.count)*Ve;Te!==null&&($e=Math.max($e,Te.start*Ve),Rt=Math.min(Rt,(Te.start+Te.count)*Ve)),Xe!==null?($e=Math.max($e,0),Rt=Math.min(Rt,Xe.count)):mt!=null&&($e=Math.max($e,0),Rt=Math.min(Rt,mt.count));const Xt=Rt-$e;if(Xt<0||Xt===1/0)return;Re.setup(ne,se,Le,le,Xe);let Yt,Vt=Fe;if(Xe!==null&&(Yt=Ne.get(Xe),Vt=j,Vt.setIndex(Yt)),ne.isMesh)se.wireframe===!0?(w.setLineWidth(se.wireframeLinewidth*ct()),Vt.setMode(Q.LINES)):Vt.setMode(Q.TRIANGLES);else if(ne.isLine){let fn=se.linewidth;fn===void 0&&(fn=1),w.setLineWidth(fn*ct()),ne.isLineSegments?Vt.setMode(Q.LINES):ne.isLineLoop?Vt.setMode(Q.LINE_LOOP):Vt.setMode(Q.LINE_STRIP)}else ne.isPoints?Vt.setMode(Q.POINTS):ne.isSprite&&Vt.setMode(Q.TRIANGLES);if(ne.isBatchedMesh)if(ze.get("WEBGL_multi_draw"))Vt.renderMultiDraw(ne._multiDrawStarts,ne._multiDrawCounts,ne._multiDrawCount);else{const fn=ne._multiDrawStarts,Ye=ne._multiDrawCounts,Pn=ne._multiDrawCount,Tt=Xe?Ne.get(Xe).bytesPerElement:1,Yn=ae.get(se).currentProgram.getUniforms();for(let Kn=0;Kn<Pn;Kn++)Yn.setValue(Q,"_gl_DrawID",Kn),Vt.render(fn[Kn]/Tt,Ye[Kn])}else if(ne.isInstancedMesh)Vt.renderInstances($e,Xt,ne.count);else if(le.isInstancedBufferGeometry){const fn=le._maxInstanceCount!==void 0?le._maxInstanceCount:1/0,Ye=Math.min(le.instanceCount,fn);Vt.renderInstances($e,Xt,Ye)}else Vt.render($e,Xt)};function Hn(R,W,le){R.transparent===!0&&R.side===Fi&&R.forceSinglePass===!1?(R.side=si,R.needsUpdate=!0,nn(R,W,le),R.side=Zr,R.needsUpdate=!0,nn(R,W,le),R.side=Fi):nn(R,W,le)}this.compile=function(R,W,le=null){le===null&&(le=R),D=ke.get(le),D.init(W),T.push(D),le.traverseVisible(function(ne){ne.isLight&&ne.layers.test(W.layers)&&(D.pushLight(ne),ne.castShadow&&D.pushShadow(ne))}),R!==le&&R.traverseVisible(function(ne){ne.isLight&&ne.layers.test(W.layers)&&(D.pushLight(ne),ne.castShadow&&D.pushShadow(ne))}),D.setupLights();const se=new Set;return R.traverse(function(ne){if(!(ne.isMesh||ne.isPoints||ne.isLine||ne.isSprite))return;const Te=ne.material;if(Te)if(Array.isArray(Te))for(let Oe=0;Oe<Te.length;Oe++){const Le=Te[Oe];Hn(Le,le,ne),se.add(Le)}else Hn(Te,le,ne),se.add(Te)}),D=T.pop(),se},this.compileAsync=function(R,W,le=null){const se=this.compile(R,W,le);return new Promise(ne=>{function Te(){if(se.forEach(function(Oe){ae.get(Oe).currentProgram.isReady()&&se.delete(Oe)}),se.size===0){ne(R);return}setTimeout(Te,10)}ze.get("KHR_parallel_shader_compile")!==null?Te():setTimeout(Te,10)})};let Rn=null;function br(R){Rn&&Rn(R)}function zi(){Sn.stop()}function Ts(){Sn.start()}const Sn=new Wg;Sn.setAnimationLoop(br),typeof self<"u"&&Sn.setContext(self),this.setAnimationLoop=function(R){Rn=R,je.setAnimationLoop(R),R===null?Sn.stop():Sn.start()},je.addEventListener("sessionstart",zi),je.addEventListener("sessionend",Ts),this.render=function(R,W){if(W!==void 0&&W.isCamera!==!0){Ut("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(O===!0)return;H!==null&&H.renderStart(R,W);const le=je.enabled===!0&&je.isPresenting===!0,se=I!==null&&(Z===null||le)&&I.begin(z,Z);if(R.matrixWorldAutoUpdate===!0&&R.updateMatrixWorld(),W.parent===null&&W.matrixWorldAutoUpdate===!0&&W.updateMatrixWorld(),je.enabled===!0&&je.isPresenting===!0&&(I===null||I.isCompositing()===!1)&&(je.cameraAutoUpdate===!0&&je.updateCamera(W),W=je.getCamera()),R.isScene===!0&&R.onBeforeRender(z,R,W,Z),D=ke.get(R,T.length),D.init(W),D.state.textureUnits=me.getTextureUnits(),T.push(D),Lt.multiplyMatrices(W.projectionMatrix,W.matrixWorldInverse),Ct.setFromProjectionMatrix(Lt,Zi,W.reversedDepth),Je=this.localClippingEnabled,it=We.init(this.clippingPlanes,Je),k=Ie.get(R,U.length),k.init(),U.push(k),je.enabled===!0&&je.isPresenting===!0){const Oe=z.xr.getDepthSensingMesh();Oe!==null&&ji(Oe,W,-1/0,z.sortObjects)}ji(R,W,0,z.sortObjects),k.finish(),z.sortObjects===!0&&k.sort(te,Se,W.reversedDepth),wt=je.enabled===!1||je.isPresenting===!1||je.hasDepthSensing()===!1,wt&&at.addToRenderList(k,R),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),it===!0&&We.beginShadows();const ne=D.state.shadowsArray;if(Ze.render(ne,R,W),it===!0&&We.endShadows(),(se&&I.hasRenderPass())===!1){const Oe=k.opaque,Le=k.transmissive;if(D.setupLights(),W.isArrayCamera){const Xe=W.cameras;if(Le.length>0)for(let Ve=0,lt=Xe.length;Ve<lt;Ve++){const mt=Xe[Ve];ts(Oe,Le,R,mt)}wt&&at.render(R);for(let Ve=0,lt=Xe.length;Ve<lt;Ve++){const mt=Xe[Ve];tr(k,R,mt,mt.viewport)}}else Le.length>0&&ts(Oe,Le,R,W),wt&&at.render(R),tr(k,R,W)}Z!==null&&oe===0&&(me.updateMultisampleRenderTarget(Z),me.updateRenderTargetMipmap(Z)),se&&I.end(z),R.isScene===!0&&R.onAfterRender(z,R,W),Re.resetDefaultState(),ee=-1,ce=null,T.pop(),T.length>0?(D=T[T.length-1],me.setTextureUnits(D.state.textureUnits),it===!0&&We.setGlobalState(z.clippingPlanes,D.state.camera)):D=null,U.pop(),U.length>0?k=U[U.length-1]:k=null,H!==null&&H.renderEnd()};function ji(R,W,le,se){if(R.visible===!1)return;if(R.layers.test(W.layers)){if(R.isGroup)le=R.renderOrder;else if(R.isLOD)R.autoUpdate===!0&&R.update(W);else if(R.isLightProbeGrid)D.pushLightProbeGrid(R);else if(R.isLight)D.pushLight(R),R.castShadow&&D.pushShadow(R);else if(R.isSprite){if(!R.frustumCulled||Ct.intersectsSprite(R)){se&&St.setFromMatrixPosition(R.matrixWorld).applyMatrix4(Lt);const Oe=ye.update(R),Le=R.material;Le.visible&&k.push(R,Oe,Le,le,St.z,null)}}else if((R.isMesh||R.isLine||R.isPoints)&&(!R.frustumCulled||Ct.intersectsObject(R))){const Oe=ye.update(R),Le=R.material;if(se&&(R.boundingSphere!==void 0?(R.boundingSphere===null&&R.computeBoundingSphere(),St.copy(R.boundingSphere.center)):(Oe.boundingSphere===null&&Oe.computeBoundingSphere(),St.copy(Oe.boundingSphere.center)),St.applyMatrix4(R.matrixWorld).applyMatrix4(Lt)),Array.isArray(Le)){const Xe=Oe.groups;for(let Ve=0,lt=Xe.length;Ve<lt;Ve++){const mt=Xe[Ve],$e=Le[mt.materialIndex];$e&&$e.visible&&k.push(R,Oe,$e,le,St.z,mt)}}else Le.visible&&k.push(R,Oe,Le,le,St.z,null)}}const Te=R.children;for(let Oe=0,Le=Te.length;Oe<Le;Oe++)ji(Te[Oe],W,le,se)}function tr(R,W,le,se){const{opaque:ne,transmissive:Te,transparent:Oe}=R;D.setupLightsView(le),it===!0&&We.setGlobalState(z.clippingPlanes,le),se&&w.viewport(F.copy(se)),ne.length>0&&xt(ne,W,le),Te.length>0&&xt(Te,W,le),Oe.length>0&&xt(Oe,W,le),w.buffers.depth.setTest(!0),w.buffers.depth.setMask(!0),w.buffers.color.setMask(!0),w.setPolygonOffset(!1)}function ts(R,W,le,se){if((le.isScene===!0?le.overrideMaterial:null)!==null)return;if(D.state.transmissionRenderTarget[se.id]===void 0){const $e=ze.has("EXT_color_buffer_half_float")||ze.has("EXT_color_buffer_float");D.state.transmissionRenderTarget[se.id]=new ai(1,1,{generateMipmaps:!0,type:$e?fi:Mi,minFilter:bs,samples:Math.max(4,L.samples),stencilBuffer:l,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:kt.workingColorSpace})}const Te=D.state.transmissionRenderTarget[se.id],Oe=se.viewport||F;Te.setSize(Oe.z*z.transmissionResolutionScale,Oe.w*z.transmissionResolutionScale);const Le=z.getRenderTarget(),Xe=z.getActiveCubeFace(),Ve=z.getActiveMipmapLevel();z.setRenderTarget(Te),z.getClearColor(qe),we=z.getClearAlpha(),we<1&&z.setClearColor(16777215,.5),z.clear(),wt&&at.render(le);const lt=z.toneMapping;z.toneMapping=Ji;const mt=se.viewport;if(se.viewport!==void 0&&(se.viewport=void 0),D.setupLightsView(se),it===!0&&We.setGlobalState(z.clippingPlanes,se),xt(R,le,se),me.updateMultisampleRenderTarget(Te),me.updateRenderTargetMipmap(Te),ze.has("WEBGL_multisampled_render_to_texture")===!1){let $e=!1;for(let Rt=0,Xt=W.length;Rt<Xt;Rt++){const Yt=W[Rt],{object:Vt,geometry:fn,material:Ye,group:Pn}=Yt;if(Ye.side===Fi&&Vt.layers.test(se.layers)){const Tt=Ye.side;Ye.side=si,Ye.needsUpdate=!0,jt(Vt,le,se,fn,Ye,Pn),Ye.side=Tt,Ye.needsUpdate=!0,$e=!0}}$e===!0&&(me.updateMultisampleRenderTarget(Te),me.updateRenderTargetMipmap(Te))}z.setRenderTarget(Le,Xe,Ve),z.setClearColor(qe,we),mt!==void 0&&(se.viewport=mt),z.toneMapping=lt}function xt(R,W,le){const se=W.isScene===!0?W.overrideMaterial:null;for(let ne=0,Te=R.length;ne<Te;ne++){const Oe=R[ne],{object:Le,geometry:Xe,group:Ve}=Oe;let lt=Oe.material;lt.allowOverride===!0&&se!==null&&(lt=se),Le.layers.test(le.layers)&&jt(Le,W,le,Xe,lt,Ve)}}function jt(R,W,le,se,ne,Te){R.onBeforeRender(z,W,le,se,ne,Te),R.modelViewMatrix.multiplyMatrices(le.matrixWorldInverse,R.matrixWorld),R.normalMatrix.getNormalMatrix(R.modelViewMatrix),ne.onBeforeRender(z,W,le,se,R,Te),ne.transparent===!0&&ne.side===Fi&&ne.forceSinglePass===!1?(ne.side=si,ne.needsUpdate=!0,z.renderBufferDirect(le,W,se,ne,R,Te),ne.side=Zr,ne.needsUpdate=!0,z.renderBufferDirect(le,W,se,ne,R,Te),ne.side=Fi):z.renderBufferDirect(le,W,se,ne,R,Te),R.onAfterRender(z,W,le,se,ne,Te)}function nn(R,W,le){W.isScene!==!0&&(W=Dt);const se=ae.get(R),ne=D.state.lights,Te=D.state.shadowsArray,Oe=ne.state.version,Le=Ee.getParameters(R,ne.state,Te,W,le,D.state.lightProbeGridArray),Xe=Ee.getProgramCacheKey(Le);let Ve=se.programs;se.environment=R.isMeshStandardMaterial||R.isMeshLambertMaterial||R.isMeshPhongMaterial?W.environment:null,se.fog=W.fog;const lt=R.isMeshStandardMaterial||R.isMeshLambertMaterial&&!R.envMap||R.isMeshPhongMaterial&&!R.envMap;se.envMap=Me.get(R.envMap||se.environment,lt),se.envMapRotation=se.environment!==null&&R.envMap===null?W.environmentRotation:R.envMapRotation,Ve===void 0&&(R.addEventListener("dispose",It),Ve=new Map,se.programs=Ve);let mt=Ve.get(Xe);if(mt!==void 0){if(se.currentProgram===mt&&se.lightsStateVersion===Oe)return hn(R,Le),mt}else Le.uniforms=Ee.getUniforms(R),H!==null&&R.isNodeMaterial&&H.build(R,le,Le),R.onBeforeCompile(Le,z),mt=Ee.acquireProgram(Le,Xe),Ve.set(Xe,mt),se.uniforms=Le.uniforms;const $e=se.uniforms;return(!R.isShaderMaterial&&!R.isRawShaderMaterial||R.clipping===!0)&&($e.clippingPlanes=We.uniform),hn(R,Le),se.needsLights=Hi(R),se.lightsStateVersion=Oe,se.needsLights&&($e.ambientLightColor.value=ne.state.ambient,$e.lightProbe.value=ne.state.probe,$e.directionalLights.value=ne.state.directional,$e.directionalLightShadows.value=ne.state.directionalShadow,$e.spotLights.value=ne.state.spot,$e.spotLightShadows.value=ne.state.spotShadow,$e.rectAreaLights.value=ne.state.rectArea,$e.ltc_1.value=ne.state.rectAreaLTC1,$e.ltc_2.value=ne.state.rectAreaLTC2,$e.pointLights.value=ne.state.point,$e.pointLightShadows.value=ne.state.pointShadow,$e.hemisphereLights.value=ne.state.hemi,$e.directionalShadowMatrix.value=ne.state.directionalShadowMatrix,$e.spotLightMatrix.value=ne.state.spotLightMatrix,$e.spotLightMap.value=ne.state.spotLightMap,$e.pointShadowMatrix.value=ne.state.pointShadowMatrix),se.lightProbeGrid=D.state.lightProbeGridArray.length>0,se.currentProgram=mt,se.uniformsList=null,mt}function rn(R){if(R.uniformsList===null){const W=R.currentProgram.getUniforms();R.uniformsList=pc.seqWithValue(W.seq,R.uniforms)}return R.uniformsList}function hn(R,W){const le=ae.get(R);le.outputColorSpace=W.outputColorSpace,le.batching=W.batching,le.batchingColor=W.batchingColor,le.instancing=W.instancing,le.instancingColor=W.instancingColor,le.instancingMorph=W.instancingMorph,le.skinning=W.skinning,le.morphTargets=W.morphTargets,le.morphNormals=W.morphNormals,le.morphColors=W.morphColors,le.morphTargetsCount=W.morphTargetsCount,le.numClippingPlanes=W.numClippingPlanes,le.numIntersection=W.numClipIntersection,le.vertexAlphas=W.vertexAlphas,le.vertexTangents=W.vertexTangents,le.toneMapping=W.toneMapping}function ln(R,W){if(R.length===0)return null;if(R.length===1)return R[0].texture!==null?R[0]:null;C.setFromMatrixPosition(W.matrixWorld);for(let le=0,se=R.length;le<se;le++){const ne=R[le];if(ne.texture!==null&&ne.boundingBox.containsPoint(C))return ne}return null}function bt(R,W,le,se,ne){W.isScene!==!0&&(W=Dt),me.resetTextureUnits();const Te=W.fog,Oe=se.isMeshStandardMaterial||se.isMeshLambertMaterial||se.isMeshPhongMaterial?W.environment:null,Le=Z===null?z.outputColorSpace:Z.isXRRenderTarget===!0?Z.texture.colorSpace:kt.workingColorSpace,Xe=se.isMeshStandardMaterial||se.isMeshLambertMaterial&&!se.envMap||se.isMeshPhongMaterial&&!se.envMap,Ve=Me.get(se.envMap||Oe,Xe),lt=se.vertexColors===!0&&!!le.attributes.color&&le.attributes.color.itemSize===4,mt=!!le.attributes.tangent&&(!!se.normalMap||se.anisotropy>0),$e=!!le.morphAttributes.position,Rt=!!le.morphAttributes.normal,Xt=!!le.morphAttributes.color;let Yt=Ji;se.toneMapped&&(Z===null||Z.isXRRenderTarget===!0)&&(Yt=z.toneMapping);const Vt=le.morphAttributes.position||le.morphAttributes.normal||le.morphAttributes.color,fn=Vt!==void 0?Vt.length:0,Ye=ae.get(se),Pn=D.state.lights;if(it===!0&&(Je===!0||R!==ce)){const Gt=R===ce&&se.id===ee;We.setState(se,R,Gt)}let Tt=!1;se.version===Ye.__version?(Ye.needsLights&&Ye.lightsStateVersion!==Pn.state.version||Ye.outputColorSpace!==Le||ne.isBatchedMesh&&Ye.batching===!1||!ne.isBatchedMesh&&Ye.batching===!0||ne.isBatchedMesh&&Ye.batchingColor===!0&&ne.colorTexture===null||ne.isBatchedMesh&&Ye.batchingColor===!1&&ne.colorTexture!==null||ne.isInstancedMesh&&Ye.instancing===!1||!ne.isInstancedMesh&&Ye.instancing===!0||ne.isSkinnedMesh&&Ye.skinning===!1||!ne.isSkinnedMesh&&Ye.skinning===!0||ne.isInstancedMesh&&Ye.instancingColor===!0&&ne.instanceColor===null||ne.isInstancedMesh&&Ye.instancingColor===!1&&ne.instanceColor!==null||ne.isInstancedMesh&&Ye.instancingMorph===!0&&ne.morphTexture===null||ne.isInstancedMesh&&Ye.instancingMorph===!1&&ne.morphTexture!==null||Ye.envMap!==Ve||se.fog===!0&&Ye.fog!==Te||Ye.numClippingPlanes!==void 0&&(Ye.numClippingPlanes!==We.numPlanes||Ye.numIntersection!==We.numIntersection)||Ye.vertexAlphas!==lt||Ye.vertexTangents!==mt||Ye.morphTargets!==$e||Ye.morphNormals!==Rt||Ye.morphColors!==Xt||Ye.toneMapping!==Yt||Ye.morphTargetsCount!==fn||!!Ye.lightProbeGrid!=D.state.lightProbeGridArray.length>0)&&(Tt=!0):(Tt=!0,Ye.__version=se.version);let Yn=Ye.currentProgram;Tt===!0&&(Yn=nn(se,W,ne),H&&se.isNodeMaterial&&H.onUpdateProgram(se,Yn,Ye));let Kn=!1,Pt=!1,ir=!1;const Ht=Yn.getUniforms(),Zt=Ye.uniforms;if(w.useProgram(Yn.program)&&(Kn=!0,Pt=!0,ir=!0),se.id!==ee&&(ee=se.id,Pt=!0),Ye.needsLights){const Gt=ln(D.state.lightProbeGridArray,ne);Ye.lightProbeGrid!==Gt&&(Ye.lightProbeGrid=Gt,Pt=!0)}if(Kn||ce!==R){w.buffers.depth.getReversed()&&R.reversedDepth!==!0&&(R._reversedDepth=!0,R.updateProjectionMatrix()),Ht.setValue(Q,"projectionMatrix",R.projectionMatrix),Ht.setValue(Q,"viewMatrix",R.matrixWorldInverse);const Ti=Ht.map.cameraPosition;Ti!==void 0&&Ti.setValue(Q,zt.setFromMatrixPosition(R.matrixWorld)),L.logarithmicDepthBuffer&&Ht.setValue(Q,"logDepthBufFC",2/(Math.log(R.far+1)/Math.LN2)),(se.isMeshPhongMaterial||se.isMeshToonMaterial||se.isMeshLambertMaterial||se.isMeshBasicMaterial||se.isMeshStandardMaterial||se.isShaderMaterial)&&Ht.setValue(Q,"isOrthographic",R.isOrthographicCamera===!0),ce!==R&&(ce=R,Pt=!0,ir=!0)}if(Ye.needsLights&&(Pn.state.directionalShadowMap.length>0&&Ht.setValue(Q,"directionalShadowMap",Pn.state.directionalShadowMap,me),Pn.state.spotShadowMap.length>0&&Ht.setValue(Q,"spotShadowMap",Pn.state.spotShadowMap,me),Pn.state.pointShadowMap.length>0&&Ht.setValue(Q,"pointShadowMap",Pn.state.pointShadowMap,me)),ne.isSkinnedMesh){Ht.setOptional(Q,ne,"bindMatrix"),Ht.setOptional(Q,ne,"bindMatrixInverse");const Gt=ne.skeleton;Gt&&(Gt.boneTexture===null&&Gt.computeBoneTexture(),Ht.setValue(Q,"boneTexture",Gt.boneTexture,me))}ne.isBatchedMesh&&(Ht.setOptional(Q,ne,"batchingTexture"),Ht.setValue(Q,"batchingTexture",ne._matricesTexture,me),Ht.setOptional(Q,ne,"batchingIdTexture"),Ht.setValue(Q,"batchingIdTexture",ne._indirectTexture,me),Ht.setOptional(Q,ne,"batchingColorTexture"),ne._colorsTexture!==null&&Ht.setValue(Q,"batchingColorTexture",ne._colorsTexture,me));const Ei=le.morphAttributes;if((Ei.position!==void 0||Ei.normal!==void 0||Ei.color!==void 0)&&G.update(ne,le,Yn),(Pt||Ye.receiveShadow!==ne.receiveShadow)&&(Ye.receiveShadow=ne.receiveShadow,Ht.setValue(Q,"receiveShadow",ne.receiveShadow)),(se.isMeshStandardMaterial||se.isMeshLambertMaterial||se.isMeshPhongMaterial)&&se.envMap===null&&W.environment!==null&&(Zt.envMapIntensity.value=W.environmentIntensity),Zt.dfgLUT!==void 0&&(Zt.dfgLUT.value=oE()),Pt){if(Ht.setValue(Q,"toneMappingExposure",z.toneMappingExposure),Ye.needsLights&&nr(Zt,ir),Te&&se.fog===!0&&He.refreshFogUniforms(Zt,Te),He.refreshMaterialUniforms(Zt,se,ve,xe,D.state.transmissionRenderTarget[R.id]),Ye.needsLights&&Ye.lightProbeGrid){const Gt=Ye.lightProbeGrid;Zt.probesSH.value=Gt.texture,Zt.probesMin.value.copy(Gt.boundingBox.min),Zt.probesMax.value.copy(Gt.boundingBox.max),Zt.probesResolution.value.copy(Gt.resolution)}pc.upload(Q,rn(Ye),Zt,me)}if(se.isShaderMaterial&&se.uniformsNeedUpdate===!0&&(pc.upload(Q,rn(Ye),Zt,me),se.uniformsNeedUpdate=!1),se.isSpriteMaterial&&Ht.setValue(Q,"center",ne.center),Ht.setValue(Q,"modelViewMatrix",ne.modelViewMatrix),Ht.setValue(Q,"normalMatrix",ne.normalMatrix),Ht.setValue(Q,"modelMatrix",ne.matrixWorld),se.uniformsGroups!==void 0){const Gt=se.uniformsGroups;for(let Ti=0,Vi=Gt.length;Ti<Vi;Ti++){const ns=Gt[Ti];_e.update(ns,Yn),_e.bind(ns,Yn)}}return Yn}function nr(R,W){R.ambientLightColor.needsUpdate=W,R.lightProbe.needsUpdate=W,R.directionalLights.needsUpdate=W,R.directionalLightShadows.needsUpdate=W,R.pointLights.needsUpdate=W,R.pointLightShadows.needsUpdate=W,R.spotLights.needsUpdate=W,R.spotLightShadows.needsUpdate=W,R.rectAreaLights.needsUpdate=W,R.hemisphereLights.needsUpdate=W}function Hi(R){return R.isMeshLambertMaterial||R.isMeshToonMaterial||R.isMeshPhongMaterial||R.isMeshStandardMaterial||R.isShadowMaterial||R.isShaderMaterial&&R.lights===!0}this.getActiveCubeFace=function(){return de},this.getActiveMipmapLevel=function(){return oe},this.getRenderTarget=function(){return Z},this.setRenderTargetTextures=function(R,W,le){const se=ae.get(R);se.__autoAllocateDepthBuffer=R.resolveDepthBuffer===!1,se.__autoAllocateDepthBuffer===!1&&(se.__useRenderToTexture=!1),ae.get(R.texture).__webglTexture=W,ae.get(R.depthTexture).__webglTexture=se.__autoAllocateDepthBuffer?void 0:le,se.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(R,W){const le=ae.get(R);le.__webglFramebuffer=W,le.__useDefaultFramebuffer=W===void 0},this.setRenderTarget=function(R,W=0,le=0){Z=R,de=W,oe=le;let se=null,ne=!1,Te=!1;if(R){const Le=ae.get(R);if(Le.__useDefaultFramebuffer!==void 0){w.bindFramebuffer(Q.FRAMEBUFFER,Le.__webglFramebuffer),F.copy(R.viewport),Y.copy(R.scissor),Ce=R.scissorTest,w.viewport(F),w.scissor(Y),w.setScissorTest(Ce),ee=-1;return}else if(Le.__webglFramebuffer===void 0)me.setupRenderTarget(R);else if(Le.__hasExternalTextures)me.rebindTextures(R,ae.get(R.texture).__webglTexture,ae.get(R.depthTexture).__webglTexture);else if(R.depthBuffer){const lt=R.depthTexture;if(Le.__boundDepthTexture!==lt){if(lt!==null&&ae.has(lt)&&(R.width!==lt.image.width||R.height!==lt.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");me.setupDepthRenderbuffer(R)}}const Xe=R.texture;(Xe.isData3DTexture||Xe.isDataArrayTexture||Xe.isCompressedArrayTexture)&&(Te=!0);const Ve=ae.get(R).__webglFramebuffer;R.isWebGLCubeRenderTarget?(Array.isArray(Ve[W])?se=Ve[W][le]:se=Ve[W],ne=!0):R.samples>0&&me.useMultisampledRTT(R)===!1?se=ae.get(R).__webglMultisampledFramebuffer:Array.isArray(Ve)?se=Ve[le]:se=Ve,F.copy(R.viewport),Y.copy(R.scissor),Ce=R.scissorTest}else F.copy(Qe).multiplyScalar(ve).floor(),Y.copy(Ft).multiplyScalar(ve).floor(),Ce=ut;if(le!==0&&(se=fe),w.bindFramebuffer(Q.FRAMEBUFFER,se)&&w.drawBuffers(R,se),w.viewport(F),w.scissor(Y),w.setScissorTest(Ce),ne){const Le=ae.get(R.texture);Q.framebufferTexture2D(Q.FRAMEBUFFER,Q.COLOR_ATTACHMENT0,Q.TEXTURE_CUBE_MAP_POSITIVE_X+W,Le.__webglTexture,le)}else if(Te){const Le=W;for(let Xe=0;Xe<R.textures.length;Xe++){const Ve=ae.get(R.textures[Xe]);Q.framebufferTextureLayer(Q.FRAMEBUFFER,Q.COLOR_ATTACHMENT0+Xe,Ve.__webglTexture,le,Le)}}else if(R!==null&&le!==0){const Le=ae.get(R.texture);Q.framebufferTexture2D(Q.FRAMEBUFFER,Q.COLOR_ATTACHMENT0,Q.TEXTURE_2D,Le.__webglTexture,le)}ee=-1},this.readRenderTargetPixels=function(R,W,le,se,ne,Te,Oe,Le=0){if(!(R&&R.isWebGLRenderTarget)){Ut("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Xe=ae.get(R).__webglFramebuffer;if(R.isWebGLCubeRenderTarget&&Oe!==void 0&&(Xe=Xe[Oe]),Xe){w.bindFramebuffer(Q.FRAMEBUFFER,Xe);try{const Ve=R.textures[Le],lt=Ve.format,mt=Ve.type;if(R.textures.length>1&&Q.readBuffer(Q.COLOR_ATTACHMENT0+Le),!L.textureFormatReadable(lt)){Ut("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!L.textureTypeReadable(mt)){Ut("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}W>=0&&W<=R.width-se&&le>=0&&le<=R.height-ne&&Q.readPixels(W,le,se,ne,be.convert(lt),be.convert(mt),Te)}finally{const Ve=Z!==null?ae.get(Z).__webglFramebuffer:null;w.bindFramebuffer(Q.FRAMEBUFFER,Ve)}}},this.readRenderTargetPixelsAsync=async function(R,W,le,se,ne,Te,Oe,Le=0){if(!(R&&R.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Xe=ae.get(R).__webglFramebuffer;if(R.isWebGLCubeRenderTarget&&Oe!==void 0&&(Xe=Xe[Oe]),Xe)if(W>=0&&W<=R.width-se&&le>=0&&le<=R.height-ne){w.bindFramebuffer(Q.FRAMEBUFFER,Xe);const Ve=R.textures[Le],lt=Ve.format,mt=Ve.type;if(R.textures.length>1&&Q.readBuffer(Q.COLOR_ATTACHMENT0+Le),!L.textureFormatReadable(lt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!L.textureTypeReadable(mt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const $e=Q.createBuffer();Q.bindBuffer(Q.PIXEL_PACK_BUFFER,$e),Q.bufferData(Q.PIXEL_PACK_BUFFER,Te.byteLength,Q.STREAM_READ),Q.readPixels(W,le,se,ne,be.convert(lt),be.convert(mt),0);const Rt=Z!==null?ae.get(Z).__webglFramebuffer:null;w.bindFramebuffer(Q.FRAMEBUFFER,Rt);const Xt=Q.fenceSync(Q.SYNC_GPU_COMMANDS_COMPLETE,0);return Q.flush(),await Sy(Q,Xt,4),Q.bindBuffer(Q.PIXEL_PACK_BUFFER,$e),Q.getBufferSubData(Q.PIXEL_PACK_BUFFER,0,Te),Q.deleteBuffer($e),Q.deleteSync(Xt),Te}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(R,W=null,le=0){const se=Math.pow(2,-le),ne=Math.floor(R.image.width*se),Te=Math.floor(R.image.height*se),Oe=W!==null?W.x:0,Le=W!==null?W.y:0;me.setTexture2D(R,0),Q.copyTexSubImage2D(Q.TEXTURE_2D,le,0,0,Oe,Le,ne,Te),w.unbindTexture()},this.copyTextureToTexture=function(R,W,le=null,se=null,ne=0,Te=0){let Oe,Le,Xe,Ve,lt,mt,$e,Rt,Xt;const Yt=R.isCompressedTexture?R.mipmaps[Te]:R.image;if(le!==null)Oe=le.max.x-le.min.x,Le=le.max.y-le.min.y,Xe=le.isBox3?le.max.z-le.min.z:1,Ve=le.min.x,lt=le.min.y,mt=le.isBox3?le.min.z:0;else{const Zt=Math.pow(2,-ne);Oe=Math.floor(Yt.width*Zt),Le=Math.floor(Yt.height*Zt),R.isDataArrayTexture?Xe=Yt.depth:R.isData3DTexture?Xe=Math.floor(Yt.depth*Zt):Xe=1,Ve=0,lt=0,mt=0}se!==null?($e=se.x,Rt=se.y,Xt=se.z):($e=0,Rt=0,Xt=0);const Vt=be.convert(W.format),fn=be.convert(W.type);let Ye;W.isData3DTexture?(me.setTexture3D(W,0),Ye=Q.TEXTURE_3D):W.isDataArrayTexture||W.isCompressedArrayTexture?(me.setTexture2DArray(W,0),Ye=Q.TEXTURE_2D_ARRAY):(me.setTexture2D(W,0),Ye=Q.TEXTURE_2D),w.activeTexture(Q.TEXTURE0),w.pixelStorei(Q.UNPACK_FLIP_Y_WEBGL,W.flipY),w.pixelStorei(Q.UNPACK_PREMULTIPLY_ALPHA_WEBGL,W.premultiplyAlpha),w.pixelStorei(Q.UNPACK_ALIGNMENT,W.unpackAlignment);const Pn=w.getParameter(Q.UNPACK_ROW_LENGTH),Tt=w.getParameter(Q.UNPACK_IMAGE_HEIGHT),Yn=w.getParameter(Q.UNPACK_SKIP_PIXELS),Kn=w.getParameter(Q.UNPACK_SKIP_ROWS),Pt=w.getParameter(Q.UNPACK_SKIP_IMAGES);w.pixelStorei(Q.UNPACK_ROW_LENGTH,Yt.width),w.pixelStorei(Q.UNPACK_IMAGE_HEIGHT,Yt.height),w.pixelStorei(Q.UNPACK_SKIP_PIXELS,Ve),w.pixelStorei(Q.UNPACK_SKIP_ROWS,lt),w.pixelStorei(Q.UNPACK_SKIP_IMAGES,mt);const ir=R.isDataArrayTexture||R.isData3DTexture,Ht=W.isDataArrayTexture||W.isData3DTexture;if(R.isDepthTexture){const Zt=ae.get(R),Ei=ae.get(W),Gt=ae.get(Zt.__renderTarget),Ti=ae.get(Ei.__renderTarget);w.bindFramebuffer(Q.READ_FRAMEBUFFER,Gt.__webglFramebuffer),w.bindFramebuffer(Q.DRAW_FRAMEBUFFER,Ti.__webglFramebuffer);for(let Vi=0;Vi<Xe;Vi++)ir&&(Q.framebufferTextureLayer(Q.READ_FRAMEBUFFER,Q.COLOR_ATTACHMENT0,ae.get(R).__webglTexture,ne,mt+Vi),Q.framebufferTextureLayer(Q.DRAW_FRAMEBUFFER,Q.COLOR_ATTACHMENT0,ae.get(W).__webglTexture,Te,Xt+Vi)),Q.blitFramebuffer(Ve,lt,Oe,Le,$e,Rt,Oe,Le,Q.DEPTH_BUFFER_BIT,Q.NEAREST);w.bindFramebuffer(Q.READ_FRAMEBUFFER,null),w.bindFramebuffer(Q.DRAW_FRAMEBUFFER,null)}else if(ne!==0||R.isRenderTargetTexture||ae.has(R)){const Zt=ae.get(R),Ei=ae.get(W);w.bindFramebuffer(Q.READ_FRAMEBUFFER,re),w.bindFramebuffer(Q.DRAW_FRAMEBUFFER,q);for(let Gt=0;Gt<Xe;Gt++)ir?Q.framebufferTextureLayer(Q.READ_FRAMEBUFFER,Q.COLOR_ATTACHMENT0,Zt.__webglTexture,ne,mt+Gt):Q.framebufferTexture2D(Q.READ_FRAMEBUFFER,Q.COLOR_ATTACHMENT0,Q.TEXTURE_2D,Zt.__webglTexture,ne),Ht?Q.framebufferTextureLayer(Q.DRAW_FRAMEBUFFER,Q.COLOR_ATTACHMENT0,Ei.__webglTexture,Te,Xt+Gt):Q.framebufferTexture2D(Q.DRAW_FRAMEBUFFER,Q.COLOR_ATTACHMENT0,Q.TEXTURE_2D,Ei.__webglTexture,Te),ne!==0?Q.blitFramebuffer(Ve,lt,Oe,Le,$e,Rt,Oe,Le,Q.COLOR_BUFFER_BIT,Q.NEAREST):Ht?Q.copyTexSubImage3D(Ye,Te,$e,Rt,Xt+Gt,Ve,lt,Oe,Le):Q.copyTexSubImage2D(Ye,Te,$e,Rt,Ve,lt,Oe,Le);w.bindFramebuffer(Q.READ_FRAMEBUFFER,null),w.bindFramebuffer(Q.DRAW_FRAMEBUFFER,null)}else Ht?R.isDataTexture||R.isData3DTexture?Q.texSubImage3D(Ye,Te,$e,Rt,Xt,Oe,Le,Xe,Vt,fn,Yt.data):W.isCompressedArrayTexture?Q.compressedTexSubImage3D(Ye,Te,$e,Rt,Xt,Oe,Le,Xe,Vt,Yt.data):Q.texSubImage3D(Ye,Te,$e,Rt,Xt,Oe,Le,Xe,Vt,fn,Yt):R.isDataTexture?Q.texSubImage2D(Q.TEXTURE_2D,Te,$e,Rt,Oe,Le,Vt,fn,Yt.data):R.isCompressedTexture?Q.compressedTexSubImage2D(Q.TEXTURE_2D,Te,$e,Rt,Yt.width,Yt.height,Vt,Yt.data):Q.texSubImage2D(Q.TEXTURE_2D,Te,$e,Rt,Oe,Le,Vt,fn,Yt);w.pixelStorei(Q.UNPACK_ROW_LENGTH,Pn),w.pixelStorei(Q.UNPACK_IMAGE_HEIGHT,Tt),w.pixelStorei(Q.UNPACK_SKIP_PIXELS,Yn),w.pixelStorei(Q.UNPACK_SKIP_ROWS,Kn),w.pixelStorei(Q.UNPACK_SKIP_IMAGES,Pt),Te===0&&W.generateMipmaps&&Q.generateMipmap(Ye),w.unbindTexture()},this.initRenderTarget=function(R){ae.get(R).__webglFramebuffer===void 0&&me.setupRenderTarget(R)},this.initTexture=function(R){R.isCubeTexture?me.setTextureCube(R,0):R.isData3DTexture?me.setTexture3D(R,0):R.isDataArrayTexture||R.isCompressedArrayTexture?me.setTexture2DArray(R,0):me.setTexture2D(R,0),w.unbindTexture()},this.resetState=function(){de=0,oe=0,Z=null,w.reset(),Re.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Zi}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=kt._getDrawingBufferColorSpace(e),t.unpackColorSpace=kt._getUnpackColorSpace()}}const ng={type:"change"},gf={type:"start"},Jg={type:"end"},ic=new To,ig=new qr,cE=Math.cos(70*Ey.DEG2RAD),vn=new X,ri=2*Math.PI,qt={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},Zd=1e-6;class uE extends h1{constructor(e,t=null){super(e,t),this.state=qt.NONE,this.target=new X,this.cursor=new X,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:xa.ROTATE,MIDDLE:xa.DOLLY,RIGHT:xa.PAN},this.touches={ONE:ma.ROTATE,TWO:ma.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._cursorStyle="auto",this._domElementKeyEvents=null,this._lastPosition=new X,this._lastQuaternion=new Jr,this._lastTargetPosition=new X,this._quat=new Jr().setFromUnitVectors(e.up,new X(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new N0,this._sphericalDelta=new N0,this._scale=1,this._panOffset=new X,this._rotateStart=new dt,this._rotateEnd=new dt,this._rotateDelta=new dt,this._panStart=new dt,this._panEnd=new dt,this._panDelta=new dt,this._dollyStart=new dt,this._dollyEnd=new dt,this._dollyDelta=new dt,this._dollyDirection=new X,this._mouse=new dt,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=hE.bind(this),this._onPointerDown=dE.bind(this),this._onPointerUp=fE.bind(this),this._onContextMenu=yE.bind(this),this._onMouseWheel=gE.bind(this),this._onKeyDown=xE.bind(this),this._onTouchStart=vE.bind(this),this._onTouchMove=_E.bind(this),this._onMouseDown=pE.bind(this),this._onMouseMove=mE.bind(this),this._interceptControlDown=bE.bind(this),this._interceptControlUp=SE.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}set cursorStyle(e){this._cursorStyle=e,e==="grab"?this.domElement.style.cursor="grab":this.domElement.style.cursor="auto"}get cursorStyle(){return this._cursorStyle}connect(e){super.connect(e),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.getRootNode().removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.style.touchAction=""}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(e){e.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=e}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(ng),this.update(),this.state=qt.NONE}pan(e,t){this._pan(e,t),this.update()}dollyIn(e){this._dollyIn(e),this.update()}dollyOut(e){this._dollyOut(e),this.update()}rotateLeft(e){this._rotateLeft(e),this.update()}rotateUp(e){this._rotateUp(e),this.update()}update(e=null){const t=this.object.position;vn.copy(t).sub(this.target),vn.applyQuaternion(this._quat),this._spherical.setFromVector3(vn),this.autoRotate&&this.state===qt.NONE&&this._rotateLeft(this._getAutoRotationAngle(e)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let r=this.minAzimuthAngle,a=this.maxAzimuthAngle;isFinite(r)&&isFinite(a)&&(r<-Math.PI?r+=ri:r>Math.PI&&(r-=ri),a<-Math.PI?a+=ri:a>Math.PI&&(a-=ri),r<=a?this._spherical.theta=Math.max(r,Math.min(a,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(r+a)/2?Math.max(r,this._spherical.theta):Math.min(a,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let l=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{const u=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),l=u!=this._spherical.radius}if(vn.setFromSpherical(this._spherical),vn.applyQuaternion(this._quatInverse),t.copy(this.target).add(vn),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let u=null;if(this.object.isPerspectiveCamera){const h=vn.length();u=this._clampDistance(h*this._scale);const p=h-u;this.object.position.addScaledVector(this._dollyDirection,p),this.object.updateMatrixWorld(),l=!!p}else if(this.object.isOrthographicCamera){const h=new X(this._mouse.x,this._mouse.y,0);h.unproject(this.object);const p=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),l=p!==this.object.zoom;const f=new X(this._mouse.x,this._mouse.y,0);f.unproject(this.object),this.object.position.sub(f).add(h),this.object.updateMatrixWorld(),u=vn.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;u!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(u).add(this.object.position):(ic.origin.copy(this.object.position),ic.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(ic.direction))<cE?this.object.lookAt(this.target):(ig.setFromNormalAndCoplanarPoint(this.object.up,this.target),ic.intersectPlane(ig,this.target))))}else if(this.object.isOrthographicCamera){const u=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),u!==this.object.zoom&&(this.object.updateProjectionMatrix(),l=!0)}return this._scale=1,this._performCursorZoom=!1,l||this._lastPosition.distanceToSquared(this.object.position)>Zd||8*(1-this._lastQuaternion.dot(this.object.quaternion))>Zd||this._lastTargetPosition.distanceToSquared(this.target)>Zd?(this.dispatchEvent(ng),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(e){return e!==null?ri/60*this.autoRotateSpeed*e:ri/60/60*this.autoRotateSpeed}_getZoomScale(e){const t=Math.abs(e*.01);return Math.pow(.95,this.zoomSpeed*t)}_rotateLeft(e){this._sphericalDelta.theta-=e}_rotateUp(e){this._sphericalDelta.phi-=e}_panLeft(e,t){vn.setFromMatrixColumn(t,0),vn.multiplyScalar(-e),this._panOffset.add(vn)}_panUp(e,t){this.screenSpacePanning===!0?vn.setFromMatrixColumn(t,1):(vn.setFromMatrixColumn(t,0),vn.crossVectors(this.object.up,vn)),vn.multiplyScalar(e),this._panOffset.add(vn)}_pan(e,t){const r=this.domElement;if(this.object.isPerspectiveCamera){const a=this.object.position;vn.copy(a).sub(this.target);let l=vn.length();l*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*e*l/r.clientHeight,this.object.matrix),this._panUp(2*t*l/r.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(e*(this.object.right-this.object.left)/this.object.zoom/r.clientWidth,this.object.matrix),this._panUp(t*(this.object.top-this.object.bottom)/this.object.zoom/r.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(e,t){if(!this.zoomToCursor)return;this._performCursorZoom=!0;const r=this.domElement.getBoundingClientRect(),a=e-r.left,l=t-r.top,u=r.width,h=r.height;this._mouse.x=a/u*2-1,this._mouse.y=-(l/h)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(e){return Math.max(this.minDistance,Math.min(this.maxDistance,e))}_handleMouseDownRotate(e){this._rotateStart.set(e.clientX,e.clientY)}_handleMouseDownDolly(e){this._updateZoomParameters(e.clientX,e.clientX),this._dollyStart.set(e.clientX,e.clientY)}_handleMouseDownPan(e){this._panStart.set(e.clientX,e.clientY)}_handleMouseMoveRotate(e){this._rotateEnd.set(e.clientX,e.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(ri*this._rotateDelta.x/t.clientHeight),this._rotateUp(ri*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(e){this._dollyEnd.set(e.clientX,e.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(e){this._panEnd.set(e.clientX,e.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(e){this._updateZoomParameters(e.clientX,e.clientY),e.deltaY<0?this._dollyIn(this._getZoomScale(e.deltaY)):e.deltaY>0&&this._dollyOut(this._getZoomScale(e.deltaY)),this.update()}_handleKeyDown(e){let t=!1;switch(e.code){case this.keys.UP:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(ri*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),t=!0;break;case this.keys.BOTTOM:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(-ri*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),t=!0;break;case this.keys.LEFT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(ri*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),t=!0;break;case this.keys.RIGHT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(-ri*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),t=!0;break}t&&(e.preventDefault(),this.update())}_handleTouchStartRotate(e){if(this._pointers.length===1)this._rotateStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),r=.5*(e.pageX+t.x),a=.5*(e.pageY+t.y);this._rotateStart.set(r,a)}}_handleTouchStartPan(e){if(this._pointers.length===1)this._panStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),r=.5*(e.pageX+t.x),a=.5*(e.pageY+t.y);this._panStart.set(r,a)}}_handleTouchStartDolly(e){const t=this._getSecondPointerPosition(e),r=e.pageX-t.x,a=e.pageY-t.y,l=Math.sqrt(r*r+a*a);this._dollyStart.set(0,l)}_handleTouchStartDollyPan(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enablePan&&this._handleTouchStartPan(e)}_handleTouchStartDollyRotate(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enableRotate&&this._handleTouchStartRotate(e)}_handleTouchMoveRotate(e){if(this._pointers.length==1)this._rotateEnd.set(e.pageX,e.pageY);else{const r=this._getSecondPointerPosition(e),a=.5*(e.pageX+r.x),l=.5*(e.pageY+r.y);this._rotateEnd.set(a,l)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(ri*this._rotateDelta.x/t.clientHeight),this._rotateUp(ri*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(e){if(this._pointers.length===1)this._panEnd.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),r=.5*(e.pageX+t.x),a=.5*(e.pageY+t.y);this._panEnd.set(r,a)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(e){const t=this._getSecondPointerPosition(e),r=e.pageX-t.x,a=e.pageY-t.y,l=Math.sqrt(r*r+a*a);this._dollyEnd.set(0,l),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);const u=(e.pageX+t.x)*.5,h=(e.pageY+t.y)*.5;this._updateZoomParameters(u,h)}_handleTouchMoveDollyPan(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enablePan&&this._handleTouchMovePan(e)}_handleTouchMoveDollyRotate(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enableRotate&&this._handleTouchMoveRotate(e)}_addPointer(e){this._pointers.push(e.pointerId)}_removePointer(e){delete this._pointerPositions[e.pointerId];for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId){this._pointers.splice(t,1);return}}_isTrackingPointer(e){for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId)return!0;return!1}_trackPointer(e){let t=this._pointerPositions[e.pointerId];t===void 0&&(t=new dt,this._pointerPositions[e.pointerId]=t),t.set(e.pageX,e.pageY)}_getSecondPointerPosition(e){const t=e.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[t]}_customWheelEvent(e){const t=e.deltaMode,r={clientX:e.clientX,clientY:e.clientY,deltaY:e.deltaY};switch(t){case 1:r.deltaY*=16;break;case 2:r.deltaY*=100;break}return e.ctrlKey&&!this._controlActive&&(r.deltaY*=10),r}}function dE(s){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(s.pointerId),this.domElement.ownerDocument.addEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(s)&&(this._addPointer(s),s.pointerType==="touch"?this._onTouchStart(s):this._onMouseDown(s),this._cursorStyle==="grab"&&(this.domElement.style.cursor="grabbing")))}function hE(s){this.enabled!==!1&&(s.pointerType==="touch"?this._onTouchMove(s):this._onMouseMove(s))}function fE(s){switch(this._removePointer(s),this._pointers.length){case 0:this.domElement.releasePointerCapture(s.pointerId),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(Jg),this.state=qt.NONE,this._cursorStyle==="grab"&&(this.domElement.style.cursor="grab");break;case 1:const e=this._pointers[0],t=this._pointerPositions[e];this._onTouchStart({pointerId:e,pageX:t.x,pageY:t.y});break}}function pE(s){let e;switch(s.button){case 0:e=this.mouseButtons.LEFT;break;case 1:e=this.mouseButtons.MIDDLE;break;case 2:e=this.mouseButtons.RIGHT;break;default:e=-1}switch(e){case xa.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(s),this.state=qt.DOLLY;break;case xa.ROTATE:if(s.ctrlKey||s.metaKey||s.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(s),this.state=qt.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(s),this.state=qt.ROTATE}break;case xa.PAN:if(s.ctrlKey||s.metaKey||s.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(s),this.state=qt.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(s),this.state=qt.PAN}break;default:this.state=qt.NONE}this.state!==qt.NONE&&this.dispatchEvent(gf)}function mE(s){switch(this.state){case qt.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(s);break;case qt.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(s);break;case qt.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(s);break}}function gE(s){this.enabled===!1||this.enableZoom===!1||this.state!==qt.NONE||(s.preventDefault(),this.dispatchEvent(gf),this._handleMouseWheel(this._customWheelEvent(s)),this.dispatchEvent(Jg))}function xE(s){this.enabled!==!1&&this._handleKeyDown(s)}function vE(s){switch(this._trackPointer(s),this._pointers.length){case 1:switch(this.touches.ONE){case ma.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(s),this.state=qt.TOUCH_ROTATE;break;case ma.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(s),this.state=qt.TOUCH_PAN;break;default:this.state=qt.NONE}break;case 2:switch(this.touches.TWO){case ma.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(s),this.state=qt.TOUCH_DOLLY_PAN;break;case ma.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(s),this.state=qt.TOUCH_DOLLY_ROTATE;break;default:this.state=qt.NONE}break;default:this.state=qt.NONE}this.state!==qt.NONE&&this.dispatchEvent(gf)}function _E(s){switch(this._trackPointer(s),this.state){case qt.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(s),this.update();break;case qt.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(s),this.update();break;case qt.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(s),this.update();break;case qt.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(s),this.update();break;default:this.state=qt.NONE}}function yE(s){this.enabled!==!1&&s.preventDefault()}function bE(s){s.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function SE(s){s.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}const mc={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};class Ro{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}}const ME=new mf(-1,1,1,-1,0,1);class wE extends jn{constructor(){super(),this.setAttribute("position",new $n([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new $n([0,2,0,0,2,0],2))}}const EE=new wE;class ex{constructor(e){this._mesh=new wi(EE,e)}dispose(){this._mesh.geometry.dispose()}render(e){e.render(this._mesh,ME)}get material(){return this._mesh.material}set material(e){this._mesh.material=e}}class TE extends Ro{constructor(e,t="tDiffuse"){super(),this.textureID=t,this.uniforms=null,this.material=null,e instanceof _n?(this.uniforms=e.uniforms,this.material=e):e&&(this.uniforms=Rc.clone(e.uniforms),this.material=new _n({name:e.name!==void 0?e.name:"unspecified",defines:Object.assign({},e.defines),uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader})),this._fsQuad=new ex(this.material)}render(e,t,r){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=r.texture),this._fsQuad.material=this.material,this.renderToScreen?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this._fsQuad.render(e))}dispose(){this.material.dispose(),this._fsQuad.dispose()}}class rg extends Ro{constructor(e,t){super(),this.scene=e,this.camera=t,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(e,t,r){const a=e.getContext(),l=e.state;l.buffers.color.setMask(!1),l.buffers.depth.setMask(!1),l.buffers.color.setLocked(!0),l.buffers.depth.setLocked(!0);let u,h;this.inverse?(u=0,h=1):(u=1,h=0),l.buffers.stencil.setTest(!0),l.buffers.stencil.setOp(a.REPLACE,a.REPLACE,a.REPLACE),l.buffers.stencil.setFunc(a.ALWAYS,u,4294967295),l.buffers.stencil.setClear(h),l.buffers.stencil.setLocked(!0),e.setRenderTarget(r),this.clear&&e.clear(),e.render(this.scene,this.camera),e.setRenderTarget(t),this.clear&&e.clear(),e.render(this.scene,this.camera),l.buffers.color.setLocked(!1),l.buffers.depth.setLocked(!1),l.buffers.color.setMask(!0),l.buffers.depth.setMask(!0),l.buffers.stencil.setLocked(!1),l.buffers.stencil.setFunc(a.EQUAL,1,4294967295),l.buffers.stencil.setOp(a.KEEP,a.KEEP,a.KEEP),l.buffers.stencil.setLocked(!0)}}class AE extends Ro{constructor(){super(),this.needsSwap=!1}render(e){e.state.buffers.stencil.setLocked(!1),e.state.buffers.stencil.setTest(!1)}}class CE{constructor(e,t){if(this.renderer=e,this._pixelRatio=e.getPixelRatio(),t===void 0){const r=e.getSize(new dt);this._width=r.width,this._height=r.height,t=new ai(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:fi}),t.texture.name="EffectComposer.rt1"}else this._width=t.width,this._height=t.height;this.renderTarget1=t,this.renderTarget2=t.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new TE(mc),this.copyPass.material.blending=Qi,this.timer=new l1}swapBuffers(){const e=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=e}addPass(e){this.passes.push(e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(e,t){this.passes.splice(t,0,e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(e){const t=this.passes.indexOf(e);t!==-1&&this.passes.splice(t,1)}isLastEnabledPass(e){for(let t=e+1;t<this.passes.length;t++)if(this.passes[t].enabled)return!1;return!0}render(e){this.timer.update(),e===void 0&&(e=this.timer.getDelta());const t=this.renderer.getRenderTarget();let r=!1;for(let a=0,l=this.passes.length;a<l;a++){const u=this.passes[a];if(u.enabled!==!1){if(u.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(a),u.render(this.renderer,this.writeBuffer,this.readBuffer,e,r),u.needsSwap){if(r){const h=this.renderer.getContext(),p=this.renderer.state.buffers.stencil;p.setFunc(h.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,e),p.setFunc(h.EQUAL,1,4294967295)}this.swapBuffers()}rg!==void 0&&(u instanceof rg?r=!0:u instanceof AE&&(r=!1))}}this.renderer.setRenderTarget(t)}reset(e){if(e===void 0){const t=this.renderer.getSize(new dt);this._pixelRatio=this.renderer.getPixelRatio(),this._width=t.width,this._height=t.height,e=this.renderTarget1.clone(),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=e,this.renderTarget2=e.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(e,t){this._width=e,this._height=t;const r=this._width*this._pixelRatio,a=this._height*this._pixelRatio;this.renderTarget1.setSize(r,a),this.renderTarget2.setSize(r,a);for(let l=0;l<this.passes.length;l++)this.passes[l].setSize(r,a)}setPixelRatio(e){this._pixelRatio=e,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}}class RE extends Ro{constructor(e,t,r=null,a=null,l=null){super(),this.scene=e,this.camera=t,this.overrideMaterial=r,this.clearColor=a,this.clearAlpha=l,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this.isRenderPass=!0,this._oldClearColor=new _t}render(e,t,r){const a=e.autoClear;e.autoClear=!1;let l,u;this.overrideMaterial!==null&&(u=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(e.getClearColor(this._oldClearColor),e.setClearColor(this.clearColor,e.getClearAlpha())),this.clearAlpha!==null&&(l=e.getClearAlpha(),e.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&e.clearDepth(),e.setRenderTarget(this.renderToScreen?null:r),this.clear===!0&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(this.scene,this.camera),this.clearColor!==null&&e.setClearColor(this._oldClearColor),this.clearAlpha!==null&&e.setClearAlpha(l),this.overrideMaterial!==null&&(this.scene.overrideMaterial=u),e.autoClear=a}}const PE={uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new _t(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			float v = luminance( texel.xyz );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};class wa extends Ro{constructor(e,t=1,r,a){super(),this.strength=t,this.radius=r,this.threshold=a,this.resolution=e!==void 0?new dt(e.x,e.y):new dt(256,256),this.clearColor=new _t(0,0,0),this.needsSwap=!1,this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let l=Math.round(this.resolution.x/2),u=Math.round(this.resolution.y/2);this.renderTargetBright=new ai(l,u,{type:fi}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let g=0;g<this.nMips;g++){const b=new ai(l,u,{type:fi});b.texture.name="UnrealBloomPass.h"+g,b.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(b);const v=new ai(l,u,{type:fi});v.texture.name="UnrealBloomPass.v"+g,v.texture.generateMipmaps=!1,this.renderTargetsVertical.push(v),l=Math.round(l/2),u=Math.round(u/2)}const h=PE;this.highPassUniforms=Rc.clone(h.uniforms),this.highPassUniforms.luminosityThreshold.value=a,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new _n({uniforms:this.highPassUniforms,vertexShader:h.vertexShader,fragmentShader:h.fragmentShader}),this.separableBlurMaterials=[];const p=[6,10,14,18,22];l=Math.round(this.resolution.x/2),u=Math.round(this.resolution.y/2);for(let g=0;g<this.nMips;g++)this.separableBlurMaterials.push(this._getSeparableBlurMaterial(p[g])),this.separableBlurMaterials[g].uniforms.invSize.value=new dt(1/l,1/u),l=Math.round(l/2),u=Math.round(u/2);this.compositeMaterial=this._getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=t,this.compositeMaterial.uniforms.bloomRadius.value=.1;const f=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=f,this.bloomTintColors=[new X(1,1,1),new X(1,1,1),new X(1,1,1),new X(1,1,1),new X(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,this.copyUniforms=Rc.clone(mc.uniforms),this.blendMaterial=new _n({uniforms:this.copyUniforms,vertexShader:mc.vertexShader,fragmentShader:mc.fragmentShader,premultipliedAlpha:!0,blending:yc,depthTest:!1,depthWrite:!1,transparent:!0}),this._oldClearColor=new _t,this._oldClearAlpha=1,this._basic=new hf,this._fsQuad=new ex(null)}dispose(){for(let e=0;e<this.renderTargetsHorizontal.length;e++)this.renderTargetsHorizontal[e].dispose();for(let e=0;e<this.renderTargetsVertical.length;e++)this.renderTargetsVertical[e].dispose();this.renderTargetBright.dispose();for(let e=0;e<this.separableBlurMaterials.length;e++)this.separableBlurMaterials[e].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this._basic.dispose(),this._fsQuad.dispose()}setSize(e,t){let r=Math.round(e/2),a=Math.round(t/2);this.renderTargetBright.setSize(r,a);for(let l=0;l<this.nMips;l++)this.renderTargetsHorizontal[l].setSize(r,a),this.renderTargetsVertical[l].setSize(r,a),this.separableBlurMaterials[l].uniforms.invSize.value=new dt(1/r,1/a),r=Math.round(r/2),a=Math.round(a/2)}render(e,t,r,a,l){e.getClearColor(this._oldClearColor),this._oldClearAlpha=e.getClearAlpha();const u=e.autoClear;e.autoClear=!1,e.setClearColor(this.clearColor,0),l&&e.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this._fsQuad.material=this._basic,this._basic.map=r.texture,e.setRenderTarget(null),e.clear(),this._fsQuad.render(e)),this.highPassUniforms.tDiffuse.value=r.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this._fsQuad.material=this.materialHighPassFilter,e.setRenderTarget(this.renderTargetBright),e.clear(),this._fsQuad.render(e);let h=this.renderTargetBright;for(let p=0;p<this.nMips;p++)this._fsQuad.material=this.separableBlurMaterials[p],this.separableBlurMaterials[p].uniforms.colorTexture.value=h.texture,this.separableBlurMaterials[p].uniforms.direction.value=wa.BlurDirectionX,e.setRenderTarget(this.renderTargetsHorizontal[p]),e.clear(),this._fsQuad.render(e),this.separableBlurMaterials[p].uniforms.colorTexture.value=this.renderTargetsHorizontal[p].texture,this.separableBlurMaterials[p].uniforms.direction.value=wa.BlurDirectionY,e.setRenderTarget(this.renderTargetsVertical[p]),e.clear(),this._fsQuad.render(e),h=this.renderTargetsVertical[p];this._fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,e.setRenderTarget(this.renderTargetsHorizontal[0]),e.clear(),this._fsQuad.render(e),this._fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,l&&e.state.buffers.stencil.setTest(!0),this.renderToScreen?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(r),this._fsQuad.render(e)),e.setClearColor(this._oldClearColor,this._oldClearAlpha),e.autoClear=u}_getSeparableBlurMaterial(e){const t=[],r=e/3;for(let a=0;a<e;a++)t.push(.39894*Math.exp(-.5*a*a/(r*r))/r);return new _n({defines:{KERNEL_RADIUS:e},uniforms:{colorTexture:{value:null},invSize:{value:new dt(.5,.5)},direction:{value:new dt(.5,.5)},gaussianCoefficients:{value:t}},vertexShader:`

				varying vec2 vUv;

				void main() {

					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

				}`,fragmentShader:`

				#include <common>

				varying vec2 vUv;

				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {

					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;

					for ( int i = 1; i < KERNEL_RADIUS; i ++ ) {

						float x = float( i );
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += ( sample1 + sample2 ) * w;

					}

					gl_FragColor = vec4( diffuseSum, 1.0 );

				}`})}_getCompositeMaterial(e){return new _n({defines:{NUM_MIPS:e},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`

				varying vec2 vUv;

				void main() {

					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

				}`,fragmentShader:`

				varying vec2 vUv;

				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor( const in float factor ) {

					float mirrorFactor = 1.2 - factor;
					return mix( factor, mirrorFactor, bloomRadius );

				}

				void main() {

					// 3.0 for backwards compatibility with previous alpha-based intensity
					vec3 bloom = 3.0 * bloomStrength * (
						lerpBloomFactor( bloomFactors[ 0 ] ) * bloomTintColors[ 0 ] * texture2D( blurTexture1, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 1 ] ) * bloomTintColors[ 1 ] * texture2D( blurTexture2, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 2 ] ) * bloomTintColors[ 2 ] * texture2D( blurTexture3, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 3 ] ) * bloomTintColors[ 3 ] * texture2D( blurTexture4, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 4 ] ) * bloomTintColors[ 4 ] * texture2D( blurTexture5, vUv ).rgb
					);

					float bloomAlpha = max( bloom.r, max( bloom.g, bloom.b ) );
					gl_FragColor = vec4( bloom, bloomAlpha );

				}`})}}wa.BlurDirectionX=new dt(1,0);wa.BlurDirectionY=new dt(0,1);const NE=`
uniform float time;
uniform sampler2D probabilityTexture;
uniform float maxHeight;
uniform float textureSize;
uniform float greedyAnchorIndex;
uniform float uTemperature;
uniform float uMaxProb;
uniform float uMinP;

attribute vec2 umapCoord;
attribute float tokenIndex;
attribute float isRagGrounded;

varying vec2 vUmapCoord;
varying float vActiveProb;
varying float vBaseProb;
varying float vTokenIndex;
varying float vIsRagGrounded;
varying float vIsGreedyAnchor;
varying float vElevation;
varying vec3 vBiomeColor;
varying float vViewDistance;

void main() {
    vUmapCoord = umapCoord;
    vTokenIndex = tokenIndex;
    vIsRagGrounded = isRagGrounded;
    vIsGreedyAnchor = (tokenIndex == greedyAnchorIndex) ? 1.0 : 0.0;

    // Calculate UV for the DataTexture
    float texSize = textureSize;
    vec2 texUV = vec2(
        (mod(tokenIndex, texSize) + 0.5) / texSize,
        (floor(tokenIndex / texSize) + 0.5) / texSize
    );

    vec4 probs = texture2D(probabilityTexture, texUV);
    float activeProb = probs.r;
    float baseProb = probs.g;
    
    vActiveProb = activeProb;
    vBaseProb = baseProb;

    // ─── 1. Base Cartographic Topography (Permanent Hypsometric Relief) ──
    float geoHills = exp(-dot(umapCoord - vec2(0.45, 0.45), umapCoord - vec2(0.45, 0.45)) / 0.35) * 12.0;
    float verbHills = exp(-dot(umapCoord - vec2(-0.50, 0.15), umapCoord - vec2(-0.50, 0.15)) / 0.35) * 10.0;
    float codeHills = exp(-dot(umapCoord - vec2(0.55, -0.25), umapCoord - vec2(0.55, -0.25)) / 0.30) * 8.0;
    float syntaxPlain = exp(-dot(umapCoord - vec2(0.0, -0.60), umapCoord - vec2(0.0, -0.60)) / 0.30) * 4.0;
    float coreSpire = exp(-dot(umapCoord, umapCoord) / 0.08) * 15.0;

    float baseTopography = geoHills + verbHills + codeHills + syntaxPlain + coreSpire;

    // ─── 2. Zero-Safe Clamped Thermodynamic Peak Displacement ────────────
    // Normalizing relative probability (P_i / P_max) anchors the active summit to maxHeight
    float safeMaxProb = max(uMaxProb, 1e-7);
    float safeProbRatio = max(activeProb / safeMaxProb, 1e-7);
    float safeTemp = max(uTemperature, 0.01);
    
    // As T -> 0.05 (Glacial freeze): peaks sharpen into needles
    // As T -> 2.0 (Thermal erosion): peaks collapse and spread
    float activeSummit = (activeProb > 0.0001) ? (maxHeight * pow(safeProbRatio, 1.0 / safeTemp)) : 0.0;
    
    float totalElevation = baseTopography + activeSummit;
    vElevation = totalElevation;

    // ─── 3. Biome Color Allocation ──────────────────────────────────────
    vec3 colGeo = vec3(0.96, 0.62, 0.04);     // Terracotta / Amber (#F59E0B)
    vec3 colVerb = vec3(0.51, 0.55, 0.97);    // Indigo / Cobalt (#818CF8)
    vec3 colCode = vec3(0.02, 0.71, 0.83);    // Cyan / Emerald (#06B6D4)
    vec3 colSyntax = vec3(0.39, 0.45, 0.55);  // Basalt Slate (#64748B)
    vec3 colCore = vec3(0.89, 0.91, 0.94);    // Platinum White (#E2E8F0)

    float totalWeight = geoHills + verbHills + codeHills + syntaxPlain + coreSpire + 0.001;
    vec3 blendedBiome = (colGeo * geoHills + 
                         colVerb * verbHills + 
                         colCode * codeHills + 
                         colSyntax * syntaxPlain + 
                         colCore * coreSpire) / totalWeight;

    vBiomeColor = blendedBiome;

    // Landscape bounds in 3D world coordinates
    float spread = 250.0;
    vec3 pos = vec3(umapCoord.x * spread, totalElevation, umapCoord.y * spread);
    
    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    gl_Position = projectionMatrix * mvPosition;

    float viewDist = -mvPosition.z;
    vViewDistance = viewDist;

    // ─── 4. Dynamic Level of Detail (LoD) Point Sizing ──────────────────
    float lodScale = mix(1.6, 0.85, smoothstep(80.0, 450.0, viewDist));
    float minSize = 3.0 * lodScale;
    float maxSize = 18.0 * lodScale;
    
    float probability = max(activeProb, baseProb);
    float activeSize = mix(minSize, maxSize, probability);
    
    float ragSize = isRagGrounded * 8.0;
    float anchorSize = vIsGreedyAnchor * 14.0; // Radiant beacon for Greedy Target #1
    
    gl_PointSize = (activeSize + ragSize + anchorSize) * (340.0 / max(10.0, viewDist));
}
`,LE=`
uniform float time;
uniform float uIsThinking;

varying vec2 vUmapCoord;
varying float vActiveProb;
varying float vBaseProb;
varying float vTokenIndex;
varying float vIsRagGrounded;
varying float vIsGreedyAnchor;
varying float vElevation;
varying vec3 vBiomeColor;
varying float vViewDistance;

void main() {
    // Soft circular particle
    vec2 cxy = 2.0 * gl_PointCoord - 1.0;
    float r = dot(cxy, cxy);
    if (r > 1.0) discard;

    // Status Colors (Houdini Unified Taxonomy)
    vec3 candidateColor = vec3(0.85, 0.27, 0.94);  // Magenta (#D946EF)
    vec3 winnerColor = vec3(0.06, 0.72, 0.51);     // Emerald (#10B981)
    vec3 ragColor = vec3(0.02, 0.71, 0.83);        // Cyan (#06B6D4)
    vec3 ghostColor = vec3(0.15, 0.40, 0.55);      // Ghost Blue

    // ─── 1. Topographic Isobar Contour Rings (Dual-Frequency) ───────────
    float majorIsobar = fract(vElevation / 6.0);
    float minorIsobar = fract(vElevation / 2.0);
    float isobarMaskMajor = smoothstep(0.85, 0.98, majorIsobar);
    float isobarMaskMinor = smoothstep(0.92, 0.98, minorIsobar) * 0.4;
    float totalIsobar = max(isobarMaskMajor, isobarMaskMinor);

    // ─── 2. Biome-Aware Base Color Mapping ──────────────────────────────
    vec3 idleColor = mix(vBiomeColor * 0.45, vBiomeColor * 0.90, smoothstep(0.0, 16.0, vElevation));
    
    // Active candidates transition from Biome color -> Magenta -> Emerald
    vec3 activeCol = mix(idleColor, candidateColor, smoothstep(0.004, 0.10, vActiveProb));
    vec3 color = mix(activeCol, winnerColor, smoothstep(0.18, 1.0, vActiveProb));

    // ─── 3. Isobar Contour Glow ─────────────────────────────────────────
    color = mix(color, color + vec3(0.35, 0.40, 0.60), totalIsobar * 0.55);

    // Reasoning Pulse
    if (uIsThinking > 0.5) {
        vec3 thinkColor = mix(vec3(0.95, 0.55, 0.1), vec3(0.65, 0.25, 0.95), (sin(time * 3.0) + 1.0) * 0.5);
        color = mix(color, thinkColor, 0.55);
    }

    // Celestial Anchors overrides (HDR Intensity for Bloom)
    if (vIsRagGrounded > 0.5) {
        color = mix(color, ragColor * 7.0, 0.85);
    }

    if (vIsGreedyAnchor > 0.5) {
        color = vec3(14.0, 14.0, 14.0); // Bright radiant beacon for Greedy Target #1
    }

    // Ghost Shell Diffing logic
    float probDelta = vActiveProb - vBaseProb;
    if (probDelta < -0.01) {
        color = mix(color, ghostColor, smoothstep(0.0, 0.5, -probDelta));
    }

    // ─── 4. Alpha Intensity & Continuous Density LoD Falloff ────────────
    float distFromCenter = length(vUmapCoord);
    float perimeterFade = smoothstep(1.25, 0.35, distFromCenter);

    // LoD density blending: distant points use softer Gaussian radial profile
    float densityProfile = (vViewDistance > 250.0) ? exp(-r * 2.8) : (1.0 - r);
    
    float baseAlpha = 0.18 * perimeterFade;
    float activeAlpha = smoothstep(0.001, 1.0, max(vActiveProb, vBaseProb)) * 0.75;
    float alpha = (baseAlpha + activeAlpha) * densityProfile;
    
    if (probDelta < -0.01) {
        alpha *= 0.5;
    }

    if (vIsGreedyAnchor > 0.5) {
        alpha = 1.0;
    }

    gl_FragColor = vec4(color, alpha);
}
`,DE="token-cosmos-terrain",IE=1,Ea="coordinates";function tx(){return new Promise((s,e)=>{const t=indexedDB.open(DE,IE);t.onupgradeneeded=()=>{const r=t.result;r.objectStoreNames.contains(Ea)||r.createObjectStore(Ea,{keyPath:"modelId"})},t.onsuccess=()=>s(t.result),t.onerror=()=>e(t.error)})}async function kE(s){try{const e=await tx();return new Promise((t,r)=>{const u=e.transaction(Ea,"readonly").objectStore(Ea).get(s);u.onsuccess=()=>{const h=u.result;t(h?{...h,coordinates:new Float32Array(h.coordinates)}:null)},u.onerror=()=>r(u.error)})}catch{return console.warn("[CoordCache] IndexedDB unavailable, skipping cache"),null}}async function FE(s){try{const e=await tx();return new Promise((t,r)=>{const l=e.transaction(Ea,"readwrite").objectStore(Ea),u={...s,coordinates:s.coordinates.buffer},h=l.put(u);h.onsuccess=()=>t(),h.onerror=()=>r(h.error)})}catch{console.warn("[CoordCache] Failed to cache coordinates")}}const UE={"SmolLM2-135M-Instruct-q4f16_1-MLC":"/terrain/smollm2-135m-umap.bin","SmolLM2-135M-Instruct-q0f16-MLC":"/terrain/smollm2-135m-umap.bin","Qwen2.5-0.5B-Instruct-q4f16_1-MLC":"/terrain/qwen2.5-0.5b-umap.bin","Qwen2.5-1.5B-Instruct-q4f16_1-MLC":"/terrain/qwen2.5-0.5b-umap.bin"},OE={"SmolLM2-135M-Instruct-q4f16_1-MLC":49152,"SmolLM2-135M-Instruct-q0f16-MLC":49152,"Qwen2.5-0.5B-Instruct-q4f16_1-MLC":151936,"Qwen2.5-1.5B-Instruct-q4f16_1-MLC":151936,__SAMPLE_FALLBACK__:49152};async function BE(s){const e=await fetch(s);if(!e.ok)throw new Error(`Failed to load coordinates: ${e.status}`);if((e.headers.get("content-type")||"").includes("text/html"))throw new Error("Coordinate asset resolved to HTML instead of binary data");const r=await e.arrayBuffer();if(r.byteLength<8)throw new Error("Coordinate asset is missing its binary header");const l=new Uint32Array(r,0,2)[0],u=8+l*2*Float32Array.BYTES_PER_ELEMENT;if(l===0||u!==r.byteLength)throw new Error("Coordinate asset has an invalid binary length");const h=new Float32Array(r,8,l*2);return{vocabSize:l,coordinates:h}}function zE(s){return()=>{s|=0,s=s+1831565813|0;let e=Math.imul(s^s>>>15,1|s);return e=e+Math.imul(e^e>>>7,61|e)^e,((e^e>>>14)>>>0)/4294967296}}function jE(s){const e=s(),t=s(),r=Math.sqrt(-2*Math.log(Math.max(e,1e-10))),a=2*Math.PI*t;return[r*Math.cos(a),r*Math.sin(a)]}function HE(s){const e=new Float32Array(s*2),t=zE(42),r=16,a=[];for(let u=0;u<r;u++){const h=u/r*2*Math.PI+t()*.3,p=.35+t()*.45;a.push({cx:p*Math.cos(h),cy:p*Math.sin(h),sigma:.06+t()*.08})}a.push({cx:0,cy:0,sigma:.12});const l=a.length;for(let u=0;u<s;u++){const h=Math.floor(t()*l),p=a[h],[f,g]=jE(t);let b=p.cx+f*p.sigma,v=p.cy+g*p.sigma;b=Math.max(-1,Math.min(1,b)),v=Math.max(-1,Math.min(1,v)),e[u*2]=b,e[u*2+1]=v}return e}function VE(s,e){const t=Math.atan2(e,s);return Math.sqrt(s*s+e*e)<.15?"Core (High Frequency)":t>=-Math.PI/4&&t<Math.PI/4?"East (Nouns / Entities)":t>=Math.PI/4&&t<3*Math.PI/4?"North (Adjectives / Descriptors)":t>=-3*Math.PI/4&&t<-Math.PI/4?"South (Code / Syntax)":"West (Function Words / Grammar)"}function GE(s){const[e,t]=K.useState(!1),[r,a]=K.useState(null),[l,u]=K.useState(0),[h,p]=K.useState(null),[f,g]=K.useState(null),b=K.useRef(0),v=K.useCallback(async M=>{const E=++b.current;t(!0),a(null),p(null),u(0);const x=(_,N)=>E!==b.current?!1:(p(_),u(N),g(M),t(!1),!0);try{const _=await kE(M);if(_){if(!x(_.coordinates,_.vocabSize))return;console.log(`[Terrain] Loaded cached coordinates for ${M} (${_.vocabSize} tokens)`);return}const N=UE[M];if(N)try{const{vocabSize:k,coordinates:D}=await BE(N);if(!x(D,k))return;await FE({modelId:M,vocabSize:k,coordinates:D,version:1,cachedAt:Date.now()}),console.log(`[Terrain] Loaded pre-computed coordinates for ${M} (${k} tokens)`);return}catch{console.warn(`[Terrain] Pre-computed asset not found for ${M}, using fallback`)}const P=OE[M]||151936,C=HE(P);if(!x(C,P))return;console.log(`[Terrain] Generated procedural terrain coordinates for ${M} (${P} tokens)`)}catch(_){if(E!==b.current)return;const N=_ instanceof Error?_.message:String(_);a(N),t(!1)}},[]);K.useEffect(()=>{s&&v(s)},[s,v]);const S=K.useCallback(M=>!h||M<0||M>=l?null:{x:h[M*2],y:h[M*2+1]},[h,l]);return{isLoading:e,isLoaded:h!==null&&h.length>0,error:r,loadedModelId:f,vocabSize:l,rawCoordinates:h,getPosition:S,getRegionLabel:VE,loadForModel:v}}const _r=[{id:"geo_entities",name:"Entities & Geography",shortLabel:"CAPITAL CITIES & GEOGRAPHY",code:"GEO",description:"Cities, countries, named entities, proper nouns & geographical references",colorHex:"#F59E0B",rgb:[.96,.62,.04],center:[.45,.45],radius:.55,elevationBias:12},{id:"abstract_verbs",name:"Abstract Concepts & Verbs",shortLabel:"ABSTRACT VERBS & CONCEPTS",code:"VRB",description:"Action verbs, mental processes, transitions, and philosophical abstractions",colorHex:"#818CF8",rgb:[.51,.55,.97],center:[-.5,.15],radius:.55,elevationBias:10},{id:"syntax_structure",name:"Syntax & Structural Tokens",shortLabel:"SYNTAX & BRACKETS",code:"SYN",description:"Punctuation, JSON syntax, markdown fences, braces & formatting delimiters",colorHex:"#64748B",rgb:[.39,.45,.55],center:[0,-.6],radius:.5,elevationBias:4},{id:"numeric_code",name:"Numerics & Code Logic",shortLabel:"NUMERICS & PROGRAMMING",code:"NUM",description:"Integers, floats, code keywords, hexadecimal bytes & mathematical symbols",colorHex:"#06B6D4",rgb:[.02,.71,.83],center:[.55,-.25],radius:.5,elevationBias:8},{id:"core_grammar",name:"Core High-Frequency Grammar",shortLabel:"CORE GRAMMAR & STOPWORDS",code:"COR",description:"High-frequency function words, articles, prepositions, and universal roots",colorHex:"#E2E8F0",rgb:[.89,.91,.94],center:[0,0],radius:.25,elevationBias:15}],Pc=["A","B","C","D","E","F"],Nc=["01","02","03","04","05","06"];function nx(s,e){const t=Math.max(0,Math.min(.999,(s+1)/2)),r=Math.max(0,Math.min(.999,(e+1)/2)),a=Math.floor(t*Pc.length),l=Math.floor(r*Nc.length);return`${Pc[a]}-${Nc[l]}`}function ix(s,e){let t=_r[0],r=1/0;for(let a=0;a<_r.length;a++){const l=_r[a],u=s-l.center[0],h=e-l.center[1],p=(u*u+h*h)/(l.radius*l.radius);p<r&&(r=p,t=l)}return t}function WE(s,e){return ix(s,e)}function rc(s,e){const t=Math.exp(-((s-.45)**2+(e-.45)**2)/.35)*12,r=Math.exp(-((s- -.5)**2+(e-.15)**2)/.35)*10,a=Math.exp(-((s-.55)**2+(e- -.25)**2)/.3)*8,l=Math.exp(-((s-0)**2+(e- -.6)**2)/.3)*4,u=Math.exp(-(s**2+e**2)/.08)*15;return t+r+a+l+u}const XE=({cameraAngle:s,cameraPos:e,targetPos:t,activeToken:r})=>{const[a,l]=K.useState(!0),u=140,h=u/2,p=u/2*.85,f=r?{x:h+r.umapX*p,y:h-r.umapY*p}:null,g=r?nx(r.umapX,r.umapY):"C-03",b=r?WE(r.umapX,r.umapY):_r[4],v=t.x-e.x,S=t.z-e.z,M=Math.atan2(S,v),E=Math.PI/6,x=38,_=h+Math.cos(M-E)*x,N=h+Math.sin(M-E)*x,P=h+Math.cos(M+E)*x,C=h+Math.sin(M+E)*x;return c.jsx("div",{className:"absolute bottom-4 right-4 z-20 flex flex-col items-end pointer-events-auto",children:c.jsxs("div",{className:"bg-slate-950/85 backdrop-blur-md border border-slate-700/60 rounded-xl shadow-2xl p-2.5 transition-all duration-300",children:[c.jsxs("div",{className:"flex items-center justify-between gap-3 mb-1.5 pb-1 border-b border-slate-800/80",children:[c.jsxs("div",{className:"flex items-center gap-1.5",children:[c.jsx("span",{className:"w-2 h-2 rounded-full bg-cyan-400 animate-pulse"}),c.jsx("span",{className:"text-[10px] font-mono tracking-wider font-semibold text-slate-300 uppercase",children:"SEMANTIC RADAR"})]}),c.jsx("button",{onClick:()=>l(!a),className:"text-[9px] font-mono text-slate-400 hover:text-cyan-300 transition-colors",title:"Toggle Mini-Radar Size",children:a?"▼":"▲"})]}),a&&c.jsxs(c.Fragment,{children:[c.jsxs("div",{className:"relative border border-slate-800 rounded-lg overflow-hidden bg-slate-950",children:[c.jsxs("svg",{width:u,height:u,className:"block",children:[_r.map(k=>{const D=h+k.center[0]*p,U=h-k.center[1]*p,T=k.radius*p*.9;return c.jsx("circle",{cx:D,cy:U,r:T,fill:k.colorHex,fillOpacity:.12,stroke:k.colorHex,strokeWidth:.75,strokeDasharray:"2 2",strokeOpacity:.4},k.id)}),Pc.map((k,D)=>{const U=u/Pc.length*(D+1);return c.jsx("line",{x1:U,y1:0,x2:U,y2:u,stroke:"#334155",strokeWidth:.5,strokeOpacity:.35},`col-${D}`)}),Nc.map((k,D)=>{const U=u/Nc.length*(D+1);return c.jsx("line",{x1:0,y1:U,x2:u,y2:U,stroke:"#334155",strokeWidth:.5,strokeOpacity:.35},`row-${D}`)}),c.jsx("circle",{cx:h,cy:h,r:p*.5,fill:"none",stroke:"#475569",strokeWidth:.5,strokeDasharray:"1 3"}),c.jsx("circle",{cx:h,cy:h,r:p,fill:"none",stroke:"#475569",strokeWidth:.75,strokeOpacity:.5}),c.jsx("line",{x1:h-4,y1:h,x2:h+4,y2:h,stroke:"#64748B",strokeWidth:1}),c.jsx("line",{x1:h,y1:h-4,x2:h,y2:h+4,stroke:"#64748B",strokeWidth:1}),c.jsx("polygon",{points:`${h},${h} ${_},${N} ${P},${C}`,fill:"#38BDF8",fillOpacity:.18,stroke:"#38BDF8",strokeWidth:.75,strokeOpacity:.6}),f&&c.jsxs("g",{children:[c.jsx("circle",{cx:f.x,cy:f.y,r:7,fill:b.colorHex,fillOpacity:.3,className:"animate-ping"}),c.jsx("circle",{cx:f.x,cy:f.y,r:3.5,fill:"#FFFFFF",stroke:b.colorHex,strokeWidth:1.5})]})]}),c.jsx("span",{className:"absolute top-0.5 left-1/2 -translate-x-1/2 text-[8px] font-mono text-slate-500 font-bold",children:"N: GEO"}),c.jsx("span",{className:"absolute bottom-0.5 left-1/2 -translate-x-1/2 text-[8px] font-mono text-slate-500 font-bold",children:"S: SYN"}),c.jsx("span",{className:"absolute top-1/2 left-0.5 -translate-y-1/2 text-[8px] font-mono text-slate-500 font-bold",children:"W: VRB"}),c.jsx("span",{className:"absolute top-1/2 right-0.5 -translate-y-1/2 text-[8px] font-mono text-slate-500 font-bold",children:"E: NUM"})]}),c.jsxs("div",{className:"mt-1.5 flex flex-col gap-0.5 text-[9px] font-mono",children:[c.jsxs("div",{className:"flex items-center justify-between text-slate-300",children:[c.jsx("span",{className:"text-slate-400",children:"Sector:"}),c.jsx("span",{className:"text-cyan-300 font-bold",children:g})]}),c.jsx("div",{className:"flex items-center justify-between text-slate-400 truncate max-w-[140px]",children:c.jsx("span",{className:"truncate",style:{color:b.colorHex},children:b.shortLabel})})]})]})]})})},qE=5,$E=64;class YE{root=null;heightmap=null;terrainSize=300;terrainHalfSize=150;gridW=64;gridH=64;allPoints=[];build(e,t,r=300,a=64,l=64){this.allPoints=e,this.heightmap=t,this.terrainSize=r,this.terrainHalfSize=r/2,this.gridW=a,this.gridH=l;const u={minX:-this.terrainHalfSize,maxX:this.terrainHalfSize,minZ:-this.terrainHalfSize,maxZ:this.terrainHalfSize};this.root=this.createNode(u,0);for(let h=0;h<e.length;h++)this.insert(this.root,e[h])}createNode(e,t){return{bounds:e,points:[],children:void 0,isLeaf:!0,depth:t}}insert(e,t){if(e.isLeaf){if(e.points.length<$E||e.depth>=qE){e.points.push(t);return}this.subdivide(e)}const{minX:r,maxX:a,minZ:l,maxZ:u}=e.bounds,h=(r+a)/2,p=(l+u)/2,f=t.worldZ<p,g=t.worldX<h;e.children&&(f&&g?this.insert(e.children[0],t):f&&!g?this.insert(e.children[1],t):!f&&g?this.insert(e.children[2],t):this.insert(e.children[3],t))}subdivide(e){const{minX:t,maxX:r,minZ:a,maxZ:l}=e.bounds,u=(t+r)/2,h=(a+l)/2,p=e.depth+1;e.children=[this.createNode({minX:t,maxX:u,minZ:a,maxZ:h},p),this.createNode({minX:u,maxX:r,minZ:a,maxZ:h},p),this.createNode({minX:t,maxX:u,minZ:h,maxZ:l},p),this.createNode({minX:u,maxX:r,minZ:h,maxZ:l},p)],e.isLeaf=!1;const f=e.points;e.points=[];for(let g=0;g<f.length;g++)this.insert(e,f[g])}queryNearest(e,t,r=8){if(!this.root)return null;let a=null,l=r*r;const u=h=>{const p=Math.max(h.bounds.minX-e,0,e-h.bounds.maxX),f=Math.max(h.bounds.minZ-t,0,t-h.bounds.maxZ);if(!(p*p+f*f>l)){if(h.isLeaf)for(let g=0;g<h.points.length;g++){const b=h.points[g],v=(b.worldX-e)**2+(b.worldZ-t)**2;v<l&&(l=v,a=b)}else if(h.children)for(let g=0;g<4;g++)u(h.children[g])}};return u(this.root),a}queryLassoScreenSpace(e,t,r,a){if(!this.root||e.length<3)return[];let l=1/0,u=-1/0,h=1/0,p=-1/0;for(let x=0;x<e.length;x++){const _=e[x];_.x<l&&(l=_.x),_.x>u&&(u=_.x),_.y<h&&(h=_.y),_.y>p&&(p=_.y)}const f=[],g=new X,b=t.position,v=(x,_,N)=>(g.set(x,_,N).project(t),{x:(g.x+1)*r/2,y:(-g.y+1)*a/2,zNDC:g.z}),S=(x,_)=>{let N=!1;for(let P=0,C=e.length-1;P<e.length;C=P++){const k=e[P].x,D=e[P].y,U=e[C].x,T=e[C].y;D>_!=T>_&&x<(U-k)*(_-D)/(T-D)+k&&(N=!N)}return N},M=x=>{if(!this.heightmap)return!0;const _=24,N=b.x,P=b.y,C=b.z,k=x.worldX,D=x.elevation,U=x.worldZ;for(let T=1;T<_;T++){const I=T/_,z=N+I*(k-N),O=P+I*(D-P),H=C+I*(U-C),fe=Math.floor((z+this.terrainHalfSize)/this.terrainSize*this.gridW),re=Math.floor((H+this.terrainHalfSize)/this.terrainSize*this.gridH),q=Math.max(0,Math.min(this.gridW-1,fe)),de=Math.max(0,Math.min(this.gridH-1,re));if(this.heightmap[de*this.gridW+q]>O+1.2)return!1}return!0},E=x=>{const _=v(x.bounds.minX,0,x.bounds.minZ),N=v(x.bounds.maxX,0,x.bounds.minZ),P=v(x.bounds.minX,0,x.bounds.maxZ),C=v(x.bounds.maxX,0,x.bounds.maxZ);if(_.zNDC>1&&N.zNDC>1&&P.zNDC>1&&C.zNDC>1)return;const k=Math.min(_.x,N.x,P.x,C.x),D=Math.max(_.x,N.x,P.x,C.x),U=Math.min(_.y,N.y,P.y,C.y),T=Math.max(_.y,N.y,P.y,C.y);if(!(D<l||k>u||T<h||U>p)){if(x.isLeaf)for(let I=0;I<x.points.length;I++){const z=x.points[I],O=v(z.worldX,z.elevation,z.worldZ);O.zNDC>1||O.x>=l&&O.x<=u&&O.y>=h&&O.y<=p&&S(O.x,O.y)&&M(z)&&f.push(z)}else if(x.children)for(let I=0;I<4;I++)E(x.children[I])}};return E(this.root),f}computeClusterMetrics(e){if(e.length===0)return{tokenCount:0,topTokens:[],shannonEntropy:0,averageProbability:0,biomeBreakdown:[],dominantBiome:"None"};const r=[...e].sort((f,g)=>(g.probability||0)-(f.probability||0)).slice(0,5).map((f,g)=>({token_id:f.token_id,token_str:f.token_str,probability:f.probability||0,rank:g+1,biomeId:f.biomeId}));let a=0,l=0;const u={};for(let f=0;f<e.length;f++){const g=e[f],b=g.probability||1e-4;l+=b,b>0&&(a-=b*Math.log2(b)),u[g.biomeId]=(u[g.biomeId]||0)+1}const h=Object.keys(u).map(f=>{const g=_r.find(v=>v.id===f),b=u[f];return{biomeId:f,label:g?g.name:f,color:g?g.colorHex:"#94A3B8",count:b,percentage:Math.round(b/e.length*100)}});h.sort((f,g)=>g.count-f.count);const p=h[0]?h[0].label:"General";return{tokenCount:e.length,topTokens:r,shannonEntropy:Math.max(0,a),averageProbability:l/e.length,biomeBreakdown:h,dominantBiome:p}}}const Qd=new YE,KE=({enabled:s,onLassoComplete:e,onCameraLockChange:t})=>{const r=K.useRef(null),a=K.useRef(!1),l=K.useRef([]),u=K.useRef(!1),[h,p]=K.useState(s);K.useEffect(()=>{p(s||u.current)},[s]);const f=K.useCallback(()=>{const M=r.current;if(!M)return;const E=M.getBoundingClientRect(),x=Math.min(window.devicePixelRatio||1,2);M.width=E.width*x,M.height=E.height*x;const _=M.getContext("2d");_&&_.scale(x,x)},[]);K.useEffect(()=>(f(),window.addEventListener("resize",f),()=>window.removeEventListener("resize",f)),[f]);const g=K.useCallback(()=>{const M=r.current;if(!M)return;const E=M.getContext("2d");if(!E)return;const x=M.getBoundingClientRect();E.clearRect(0,0,x.width,x.height);const _=l.current;if(!(_.length<2)){E.save(),E.beginPath(),E.moveTo(_[0].x,_[0].y);for(let N=1;N<_.length;N++)E.lineTo(_[N].x,_[N].y);E.strokeStyle="#06B6D4",E.lineWidth=2,E.shadowColor="#06B6D4",E.shadowBlur=8,E.stroke(),_.length>2&&(E.closePath(),E.fillStyle="rgba(6, 182, 212, 0.12)",E.fill()),E.restore()}},[]);K.useEffect(()=>{const M=x=>{x.key==="Shift"&&(u.current=!0,p(!0),t(!0))},E=x=>{x.key==="Shift"&&(u.current=!1,!a.current&&!s&&(p(!1),t(!1)))};return window.addEventListener("keydown",M),window.addEventListener("keyup",E),()=>{window.removeEventListener("keydown",M),window.removeEventListener("keyup",E)}},[s,t]);const b=M=>{if(!s&&!u.current&&!M.shiftKey)return;a.current=!0,t(!0);const E=M.currentTarget.getBoundingClientRect(),x=M.clientX-E.left,_=M.clientY-E.top;l.current=[{x,y:_}],M.currentTarget.setPointerCapture(M.pointerId)},v=M=>{if(!a.current)return;const E=M.currentTarget.getBoundingClientRect(),x=M.clientX-E.left,_=M.clientY-E.top,N=l.current[l.current.length-1];(!N||Math.hypot(x-N.x,_-N.y)>4)&&(l.current.push({x,y:_}),g())},S=M=>{if(!a.current)return;a.current=!1,!u.current&&!s&&(p(!1),t(!1));try{M.currentTarget.releasePointerCapture(M.pointerId)}catch{}const E=l.current;if(E.length>=3){let _=0,N=0;for(let C=0;C<E.length;C++)_+=E[C].x,N+=E[C].y;const P={x:_/E.length,y:N/E.length};e(E,P)}const x=r.current;if(x){const _=x.getContext("2d");if(_){const N=x.getBoundingClientRect();_.clearRect(0,0,N.width,N.height)}}l.current=[]};return c.jsx("canvas",{ref:r,className:`absolute inset-0 z-20 ${h?"pointer-events-auto cursor-crosshair touch-none":"pointer-events-none"}`,style:{width:"100%",height:"100%"},onPointerDown:b,onPointerMove:v,onPointerUp:S,onPointerCancel:S})},ZE=({metrics:s,onClose:e})=>!s||s.tokenCount===0?null:c.jsxs("div",{className:"absolute top-20 right-6 z-30 w-96 bg-slate-950/90 backdrop-blur-xl border border-cyan-500/30 rounded-xl shadow-2xl p-5 text-slate-100 animate-in fade-in slide-in-from-right-4 duration-300 pointer-events-auto",style:{boxShadow:"0 0 35px rgba(6, 182, 212, 0.15)"},children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-slate-800/80 pb-3 mb-4",children:[c.jsxs("div",{className:"flex items-center gap-2",children:[c.jsx("div",{className:"w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"}),c.jsx("h3",{className:"font-mono text-xs uppercase tracking-widest text-cyan-400 font-bold",children:"Semantic Cluster Telemetry"})]}),c.jsx("button",{onClick:e,className:"text-slate-400 hover:text-slate-200 text-xs px-2 py-1 rounded bg-slate-800/50 hover:bg-slate-800 transition-colors",children:"✕ Dismiss"})]}),c.jsxs("div",{className:"grid grid-cols-2 gap-3 mb-4",children:[c.jsxs("div",{className:"bg-slate-900/80 border border-slate-800 rounded-lg p-3",children:[c.jsx("div",{className:"text-[10px] uppercase font-mono tracking-wider text-slate-400",children:"Tokens Selected"}),c.jsx("div",{className:"text-xl font-bold font-mono text-cyan-300 mt-1",children:s.tokenCount.toLocaleString()}),c.jsxs("div",{className:"text-[10px] text-slate-500 mt-0.5",children:["Dominant: ",c.jsx("span",{className:"text-slate-300 font-medium",children:s.dominantBiome})]})]}),c.jsxs("div",{className:"bg-slate-900/80 border border-slate-800 rounded-lg p-3",children:[c.jsx("div",{className:"text-[10px] uppercase font-mono tracking-wider text-slate-400",children:"Shannon Entropy"}),c.jsxs("div",{className:"text-xl font-bold font-mono text-amber-400 mt-1",children:[s.shannonEntropy.toFixed(2)," ",c.jsx("span",{className:"text-xs font-normal text-amber-400/70",children:"bits"})]}),c.jsxs("div",{className:"text-[10px] text-slate-500 mt-0.5",children:["Mean P: ",(s.averageProbability*100).toFixed(2),"%"]})]})]}),c.jsxs("div",{className:"mb-4",children:[c.jsxs("div",{className:"text-[10px] uppercase font-mono tracking-wider text-slate-400 mb-2 flex items-center justify-between",children:[c.jsx("span",{children:"Top Candidates In Region"}),c.jsx("span",{className:"text-[9px] text-cyan-500",children:"SORTED BY PROB"})]}),c.jsx("div",{className:"space-y-1.5 max-h-40 overflow-y-auto pr-1 custom-scrollbar",children:s.topTokens.length>0?s.topTokens.map((t,r)=>c.jsxs("div",{className:"flex items-center justify-between p-2 rounded bg-slate-900/60 border border-slate-800/60 text-xs",children:[c.jsxs("div",{className:"flex items-center gap-2 overflow-hidden",children:[c.jsxs("span",{className:"font-mono text-[10px] text-slate-500 w-4",children:["#",t.rank]}),c.jsxs("span",{className:"font-mono text-slate-200 font-semibold truncate max-w-[120px]",children:['"',t.token_str,'"']})]}),c.jsxs("div",{className:"flex items-center gap-2",children:[c.jsx("div",{className:"w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden",children:c.jsx("div",{className:"h-full bg-cyan-400 rounded-full",style:{width:`${Math.min(100,Math.max(5,t.probability*100))}%`}})}),c.jsxs("span",{className:"font-mono text-[10px] text-cyan-300 w-12 text-right",children:[(t.probability*100).toFixed(1),"%"]})]})]},t.token_id||r)):c.jsx("div",{className:"text-xs text-slate-500 italic py-2 text-center",children:"No active candidate probabilities in selection"})})]}),c.jsxs("div",{children:[c.jsx("div",{className:"text-[10px] uppercase font-mono tracking-wider text-slate-400 mb-2",children:"Territorial Biome Composition"}),c.jsx("div",{className:"space-y-2",children:s.biomeBreakdown.map(t=>c.jsxs("div",{className:"text-xs",children:[c.jsxs("div",{className:"flex justify-between text-[11px] mb-1",children:[c.jsxs("span",{className:"text-slate-300 flex items-center gap-1.5",children:[c.jsx("span",{className:"w-2 h-2 rounded-full inline-block",style:{backgroundColor:t.color}}),t.label]}),c.jsxs("span",{className:"font-mono text-slate-400",children:[t.count," (",t.percentage,"%)"]})]}),c.jsx("div",{className:"w-full h-1.5 bg-slate-800/80 rounded-full overflow-hidden",children:c.jsx("div",{className:"h-full rounded-full transition-all duration-500",style:{width:`${t.percentage}%`,backgroundColor:t.color}})})]},t.biomeId))})]}),c.jsx("div",{className:"mt-4 pt-3 border-t border-slate-800/80 text-[10px] text-slate-500 flex justify-between font-mono",children:c.jsxs("span",{children:["Hold ",c.jsx("kbd",{className:"bg-slate-800 text-slate-300 px-1 py-0.5 rounded border border-slate-700",children:"Shift"})," + Drag to lasso new region"]})})]}),QE=({modelId:s,status:e,stepIndex:t=0,topCandidate:r,isLassoActive:a,isFullscreen:l=!1,persona:u="flight_sim",temperature:h=1,minP:p=.05,onToggleLasso:f,onResetCamera:g,onToggleFullscreen:b,onZoomIn:v,onZoomOut:S,onTogglePersona:M,onOpenEnterpriseLabs:E,onOpenMultiModel:x})=>{const _=u==="flight_sim";return c.jsxs("div",{className:"absolute top-4 left-4 z-30 pointer-events-none flex flex-col gap-2 max-w-[95vw]",children:[c.jsxs("div",{className:"flex items-center flex-wrap gap-2.5 bg-slate-950/90 backdrop-blur-md border border-slate-800/90 px-3.5 py-1.5 rounded-xl text-slate-200 shadow-2xl pointer-events-auto",children:[M&&c.jsx("button",{onClick:M,className:`px-2.5 py-0.5 rounded-lg font-mono text-[10px] font-bold tracking-wider transition-all flex items-center gap-1.5 border ${_?"bg-gradient-to-r from-cyan-950 to-blue-950 text-cyan-300 border-cyan-700/60 shadow-[0_0_12px_rgba(6,182,212,0.35)]":"bg-gradient-to-r from-purple-950 to-indigo-950 text-purple-300 border-purple-700/60 shadow-[0_0_12px_rgba(168,85,247,0.35)]"}`,title:"Click to toggle between Executive Flight Simulator & Diagnostic Command Center",children:c.jsx("span",{children:_?"✈ FLIGHT SIMULATOR":"🔬 DIAGNOSTIC COMMAND"})}),c.jsx("div",{className:"h-3 w-px bg-slate-800"}),c.jsxs("div",{className:"flex items-center gap-2",children:[c.jsx("div",{className:`w-2 h-2 rounded-full ${e==="generating"?"bg-emerald-400 animate-ping":e==="ready"?"bg-cyan-400":"bg-amber-400"}`}),c.jsx("span",{className:"font-mono text-xs font-semibold text-slate-100 tracking-wider",children:s||"Synthetic Cosmos"})]}),c.jsx("div",{className:"h-3 w-px bg-slate-800"}),c.jsxs("div",{className:"flex items-center gap-1 font-mono text-[11px] text-slate-400",children:[c.jsx("span",{className:"text-slate-500 uppercase text-[9px]",children:"STEP"}),c.jsxs("span",{className:"text-slate-200 font-bold",children:["#",t]})]}),r&&c.jsxs(c.Fragment,{children:[c.jsx("div",{className:"h-3 w-px bg-slate-800"}),c.jsxs("div",{className:"flex items-center gap-1.5 font-mono text-[11px]",children:[c.jsx("span",{className:"text-slate-500 uppercase text-[9px]",children:"TARGET #1"}),c.jsxs("span",{className:"text-emerald-400 font-bold",children:['"',r.token_str,'"']}),c.jsxs("span",{className:"text-slate-400 text-[10px]",children:["(",(r.probability*100).toFixed(1),"%)"]})]})]}),c.jsx("div",{className:"h-3 w-px bg-slate-800"}),c.jsxs("div",{className:"flex items-center gap-2 font-mono text-[10px] text-slate-400 bg-slate-900/80 px-2 py-0.5 rounded border border-slate-800",children:[c.jsxs("span",{title:"Thermodynamic Temperature Peak Scaling",children:[c.jsx("strong",{className:"text-amber-400",children:"T:"})," ",h.toFixed(2)]}),c.jsx("span",{className:"text-slate-700",children:"|"}),c.jsxs("span",{title:"Waterline Sea Level Cutoff",children:[c.jsx("strong",{className:"text-cyan-400",children:"Min-P:"})," ",(p*100).toFixed(1),"%"]})]}),c.jsx("div",{className:"h-3 w-px bg-slate-800"}),c.jsxs("div",{className:"flex items-center gap-1.5",children:[v&&c.jsx("button",{onClick:v,className:"w-6 h-6 flex items-center justify-center rounded text-xs font-mono font-bold bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 transition-colors",title:"Zoom In",children:"+"}),S&&c.jsx("button",{onClick:S,className:"w-6 h-6 flex items-center justify-center rounded text-xs font-mono font-bold bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 transition-colors",title:"Zoom Out",children:"−"}),c.jsx("button",{onClick:g,className:"px-2 py-0.5 rounded text-[10px] font-mono bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 transition-colors",title:"Reset 3D Orbit Camera",children:"Reset Orbit"}),c.jsx("button",{onClick:f,className:`px-2 py-0.5 rounded text-[10px] font-mono transition-all ${a?"bg-cyan-500 text-slate-950 font-bold shadow-[0_0_10px_rgba(6,182,212,0.4)]":"bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700"}`,title:"Toggle 2D Lasso Selection (or hold Shift + Drag)",children:"Lasso [Shift]"}),E&&c.jsx("button",{onClick:E,className:"px-2 py-0.5 rounded text-[10px] font-mono bg-indigo-950/80 hover:bg-indigo-900 text-indigo-200 hover:text-white border border-indigo-700/60 transition-all font-semibold shadow-[0_0_10px_rgba(99,102,241,0.25)]",title:"Open Enterprise Training Missions & Certification Labs",children:"🎓 Labs"}),x&&c.jsx("button",{onClick:x,className:"px-2 py-0.5 rounded text-[10px] font-mono bg-purple-950/80 hover:bg-purple-900 text-purple-200 hover:text-white border border-purple-700/60 transition-all font-semibold shadow-[0_0_10px_rgba(168,85,247,0.25)]",title:"Open Multi-Model Trajectory Comparison & Ghost Overlay",children:"⚖ Compare"}),b&&c.jsx("button",{onClick:b,className:`px-2 py-0.5 rounded text-[10px] font-mono transition-all flex items-center gap-1 ${l?"bg-amber-500/20 text-amber-300 border border-amber-500/50":"bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700"}`,title:l?"Exit Fullscreen":"Enter Fullscreen",children:c.jsx("span",{children:l?"Exit FS":"⛶ Fullscreen"})})]})]}),c.jsx("div",{className:"text-[10px] font-mono text-slate-400 px-1 drop-shadow flex items-center flex-wrap gap-3",children:_?c.jsxs(c.Fragment,{children:[c.jsxs("span",{children:[c.jsx("strong",{className:"text-cyan-300",children:"Flight Simulator:"})," Watch Temperature erode glaciers & Min-P flood valleys"]}),c.jsxs("span",{children:[c.jsx("strong",{className:"text-slate-300",children:"Shift + Drag:"})," Lasso Cluster"]})]}):c.jsxs(c.Fragment,{children:[c.jsxs("span",{children:[c.jsx("strong",{className:"text-purple-300",children:"Diagnostic Command:"})," 3D DDA Line-of-Sight Occlusion & Shannon Entropy"]}),c.jsxs("span",{children:[c.jsx("strong",{className:"text-slate-300",children:"L/R Drag:"})," Orbit/Pan"]})]})})]})},JE=`
  uniform float u_time;
  uniform float u_water_elevation;
  
  varying vec2 v_uv;
  varying vec3 v_world_pos;
  varying float v_wave_height;

  void main() {
    v_uv = uv;
    
    // Multi-frequency undulating surface waves
    vec3 pos = position;
    float wave1 = sin(pos.x * 0.06 + u_time * 1.8) * cos(pos.z * 0.06 + u_time * 1.4) * 0.45;
    float wave2 = sin(pos.x * 0.12 - u_time * 2.2 + pos.z * 0.08) * 0.25;
    float totalWave = wave1 + wave2;
    
    pos.y = u_water_elevation + totalWave;
    v_wave_height = totalWave;
    
    vec4 worldPos = modelMatrix * vec4(pos, 1.0);
    v_world_pos = worldPos.xyz;
    gl_Position = projectionMatrix * viewMatrix * worldPos;
  }
`,eT=`
  uniform float u_time;
  uniform vec3 u_deep_color;
  uniform vec3 u_shallow_color;
  uniform float u_opacity;
  
  varying vec2 v_uv;
  varying vec3 v_world_pos;
  varying float v_wave_height;

  // Procedural 2D caustic cellular pattern
  float causticNoise(vec2 uv, float t) {
    vec2 p = uv * 14.0;
    float c1 = sin(p.x + sin(p.y + t * 1.5)) * 0.5 + 0.5;
    float c2 = cos(p.y + cos(p.x + t * 1.2)) * 0.5 + 0.5;
    return pow(c1 * c2, 1.8) * 1.6;
  }

  void main() {
    float caustics = causticNoise(v_uv, u_time * 0.8);
    
    // Blend deep abyss with shallow illuminated turquoise
    vec3 baseColor = mix(u_deep_color, u_shallow_color, clamp(v_wave_height * 0.8 + 0.5, 0.0, 1.0));
    vec3 finalColor = baseColor + vec3(0.08, 0.25, 0.35) * caustics;
    
    // Subtle distance fog fade
    float dist = length(v_world_pos.xz);
    float alpha = u_opacity * smoothstep(180.0, 60.0, dist);
    
    gl_FragColor = vec4(finalColor, alpha);
  }
`;class tT{mesh;material;currentElevation=0;targetElevation=0;constructor(e=340,t=64){const r=new Co(e,e,t,t);r.rotateX(-Math.PI/2),this.material=new _n({vertexShader:JE,fragmentShader:eT,uniforms:{u_time:{value:0},u_water_elevation:{value:0},u_deep_color:{value:new _t(138027)},u_shallow_color:{value:new _t(440020)},u_opacity:{value:.52}},transparent:!0,depthWrite:!1,side:Fi}),this.mesh=new wi(r,this.material),this.mesh.position.y=0,this.mesh.renderOrder=10}setElevation(e,t=!1){this.targetElevation=e,t&&(this.currentElevation=e,this.material.uniforms.u_water_elevation.value=e)}update(e){this.material.uniforms.u_time.value+=e,this.currentElevation+=(this.targetElevation-this.currentElevation)*Math.min(1,e*8),this.material.uniforms.u_water_elevation.value=this.currentElevation}setVisible(e){this.mesh.visible=e}dispose(){this.mesh.geometry.dispose(),this.material.dispose()}}const nT=`
  varying vec2 v_uv;
  varying vec3 v_world_pos;

  void main() {
    v_uv = uv;
    vec4 worldPos = modelMatrix * vec4(position, 1.0);
    v_world_pos = worldPos.xyz;
    gl_Position = projectionMatrix * viewMatrix * worldPos;
  }
`,iT=`
  uniform float u_time;
  uniform vec3 u_head_color;
  uniform vec3 u_tail_color;
  uniform float u_has_anomaly;
  uniform float u_is_ghost;
  
  varying vec2 v_uv;
  varying vec3 v_world_pos;

  void main() {
    // v_uv.y maps from fading tail (0.0) to active head (1.0)
    float progress = v_uv.y;
    
    // Normal active neon glow vs crimson anomaly alert vs ghost trajectory
    vec3 baseCol = mix(u_tail_color, u_head_color, smoothstep(0.0, 1.0, progress));
    
    if (u_has_anomaly > 0.5) {
      vec3 anomalyCol = vec3(0.95, 0.20, 0.25); // Crimson warning
      baseCol = mix(baseCol, anomalyCol, 0.85);
    }
    
    if (u_is_ghost > 0.5) {
      vec3 ghostCol = vec3(0.38, 0.45, 0.65); // Ghost lavender-slate
      baseCol = mix(baseCol, ghostCol, 0.85);
    }
    
    // Edge glow falloff
    float edgeGlow = pow(sin(v_uv.x * 3.14159), 0.65);
    
    // Quadratic tail fade (progress^2) keeps tail cleanly dissolved
    float maxAlpha = (u_is_ghost > 0.5) ? 0.45 : 0.95;
    float alpha = pow(progress, 1.8) * edgeGlow * maxAlpha;
    
    gl_FragColor = vec4(baseCol * (u_is_ghost > 0.5 ? 1.0 : 1.8), alpha);
  }
`;class sg{mesh;geometry;material;rawWaypoints=[];maxWaypoints=128;subSteps=4;isGhost;cachedCurve=new Jy([],!1,"catmullrom",.5);vectorPool=Array.from({length:512},()=>new X);_workingTangent=new X;_workingUp=new X(0,1,0);_workingSide=new X;onAnomalyDetected;constructor(e=128,t=1.8,r=!1){this.maxWaypoints=e,this.isGhost=r;const a=this.maxWaypoints*this.subSteps;this.geometry=new jn,this.geometry.setAttribute("position",new An(new Float32Array(a*2*3),3)),this.geometry.setAttribute("normal",new An(new Float32Array(a*2*3),3)),this.geometry.setAttribute("uv",new An(new Float32Array(a*2*2),2));const l=new Uint16Array((a-1)*6);for(let u=0;u<a-1;u++){const h=u*2,p=u*2+1,f=(u+1)*2,g=(u+1)*2+1,b=u*6;l[b+0]=h,l[b+1]=p,l[b+2]=f,l[b+3]=p,l[b+4]=g,l[b+5]=f}this.geometry.setIndex(new An(l,1)),this.geometry.setDrawRange(0,0),this.material=new _n({vertexShader:nT,fragmentShader:iT,uniforms:{u_time:{value:0},u_head_color:{value:r?new _t(6583435):new _t(440020)},u_tail_color:{value:r?new _t(3359061):new _t(5195493)},u_has_anomaly:{value:0},u_is_ghost:{value:r?1:0}},transparent:!0,depthWrite:!1,side:Fi,blending:yc}),r&&(this.material.polygonOffset=!0,this.material.polygonOffsetFactor=1,this.material.polygonOffsetUnits=1),this.mesh=new wi(this.geometry,this.material),this.mesh.renderOrder=r?14:15,this.mesh.frustumCulled=!1}addStep(e,t,r,a=1,l=1,u=1){const h=r.clone();if(h.y+=this.isGhost?2.2:2.8,!this.isGhost&&t>=2&&this.rawWaypoints.length>=1){const p=this.rawWaypoints[this.rawWaypoints.length-1],f=h.distanceTo(p),g=a/Math.max(l,1e-5)<.5||u>3;f>250&&g?(this.material.uniforms.u_has_anomaly.value=1,this.onAnomalyDetected?.({type:"DRIFT_JUMP",message:`Semantic Jump (${f.toFixed(0)} units to "${e}")`,stepIndex:t,tokenStr:e,severity:"warning",location:h})):this.material.uniforms.u_has_anomaly.value=0}this.rawWaypoints.length>=this.maxWaypoints&&this.rawWaypoints.shift(),this.rawWaypoints.push(h),this.rebuildSpline()}rebuildSpline(){if(this.rawWaypoints.length<2){this.geometry.setDrawRange(0,0);return}this.cachedCurve.points=this.rawWaypoints,this.cachedCurve.updateArcLengths();const e=this.maxWaypoints*this.subSteps-1,t=Math.min((this.rawWaypoints.length-1)*this.subSteps+1,512);for(let f=0;f<t;f++){const g=f/(t-1);this.cachedCurve.getPointAt(g,this.vectorPool[f])}const r=this.geometry.attributes.position.array,a=this.geometry.attributes.normal.array,l=this.geometry.attributes.uv.array,u=1.8,h=t/e,p=Math.max(0,1-h);for(let f=0;f<t;f++){const g=this.vectorPool[f];f<t-1?this._workingTangent.subVectors(this.vectorPool[f+1],g):this._workingTangent.subVectors(g,this.vectorPool[f-1]),this._workingTangent.lengthSq()<1e-5?this._workingTangent.set(1,0,0):this._workingTangent.normalize(),Math.abs(this._workingTangent.y)>.99?this._workingUp.set(0,0,1):this._workingUp.set(0,1,0),this._workingSide.crossVectors(this._workingTangent,this._workingUp).normalize().multiplyScalar(u);const b=f*6;r[b+0]=g.x-this._workingSide.x,r[b+1]=g.y,r[b+2]=g.z-this._workingSide.z,r[b+3]=g.x+this._workingSide.x,r[b+4]=g.y,r[b+5]=g.z+this._workingSide.z,a[b+0]=0,a[b+1]=1,a[b+2]=0,a[b+3]=0,a[b+4]=1,a[b+5]=0;const v=p+f/Math.max(1,t-1)*(1-p);l[f*4+0]=0,l[f*4+1]=v,l[f*4+2]=1,l[f*4+3]=v}this.geometry.attributes.position.needsUpdate=!0,this.geometry.attributes.normal.needsUpdate=!0,this.geometry.attributes.uv.needsUpdate=!0,this.geometry.setDrawRange(0,(t-1)*6)}getHistory(){return[...this.rawWaypoints]}loadFromHistory(e){this.clear();for(let t=0;t<e.length;t++)this.addStep(`Step #${t}`,t,e[t])}update(e){this.material.uniforms.u_time.value+=e}clear(){this.rawWaypoints=[],this.geometry.setDrawRange(0,0),this.material.uniforms.u_has_anomaly.value=0}dispose(){this.geometry.dispose(),this.material.dispose()}}const ag=[{id:"temp_glacier",number:1,title:"The Temperature Glacier",subtitle:"Taming Hallucinations & Deterministic Spire Geometry",category:"EXECUTIVE AI LITERACY",description:"Observe how thermodynamic temperature erodes the probability terrain. At low temperatures (T=0.1), the terrain freezes into a razor-sharp glacial spire where the model output is 100% deterministic. At high temperatures (T=1.8), peaks collapse into boiling mud, spreading probability across hallucinatory tokens.",objective:"Freeze the temperature to T=0.15 to generate a deterministic legal contract clause without drift.",recommendedSettings:{temperature:.15,minP:.05,topK:50},prompt:"Define the limitation of liability clause under Delaware corporate law:",expectedOutcome:"High peak concentration in Syntax and Entity continents with zero cross-continental drift.",badgeName:"Glacial Determinism Master"},{id:"min_p_floodgate",number:2,title:"The Min-P Floodgate",subtitle:"Raising the Water Level to Submerge Hallucinatory Noise",category:"RISK MANAGEMENT & FINANCE",description:"Unlike Top-P which cuts off fixed cumulative mass, Min-P dynamically scales the cutoff relative to the top candidate. Raising the water plane visually submerges low-probability noise tokens beneath the tide, restricting model attention to dry candidate islands.",objective:"Raise Min-P to 0.12 (12% of top peak) to drown out rogue numerical tokens during financial calculation.",recommendedSettings:{temperature:.7,minP:.12,topK:50},prompt:"Calculate the quarterly compound annualized revenue growth rate given Q1=$4.2M and Q4=$5.8M:",expectedOutcome:"Fringe tokens are drowned beneath cyan depth caustics; only verified numeric candidates survive on dry land.",badgeName:"Tidal Risk Controller"},{id:"highway_triage",number:3,title:"Flight Highway Triage",subtitle:"Diagnosing & Breaking Infinite Semantic Repetition Loops",category:"LLMOPS & PROMPT ENGINEERING",description:"Watch the 3D Catmull-Rom neon trajectory ribbon as a model generates text. When a model gets trapped in an infinite repetition loop, the ribbon coils into a tight geometric vortex in the Syntax Valley. Diagnosing this visually allows prompt engineers to tune presence penalties instantly.",objective:"Detect a looping trajectory ribbon and apply a +0.65 presence penalty to snap the model out of the vortex.",recommendedSettings:{temperature:.85,minP:.02,topK:40},prompt:"Repeat the following verification handshake sequentially without looping:",expectedOutcome:"Trajectory ribbon breaks out of tight Syntax vortex and glides smoothly across the Reasoning Highlands.",badgeName:"Trajectory Flight Commander"},{id:"rag_magnetic_anchor",number:4,title:"RAG Magnetic Anchors",subtitle:"Grounding Generative Trajectories to Enterprise Knowledge",category:"ENTERPRISE ARCHITECTURE",description:"Retrieval-Augmented Generation (RAG) acts as heavy magnetic beacon spires beneath the terrain. The beacons radiate gravitational potential wells that pull generative traffic toward verified enterprise policy chunks.",objective:"Activate the Compliance Beacon to verify that generative flight paths stay anchored to internal HR documentation.",recommendedSettings:{temperature:.4,minP:.08,topK:30},prompt:"Summarize the corporate data retention protocol according to standard operating policy #402:",expectedOutcome:"Luminous cyan magnetic beacons pull probability mass toward the Entity and Compliance plateau.",badgeName:"RAG Gravity Specialist"}],rT=({isOpen:s,onClose:e,onSelectMission:t})=>{const[r,a]=K.useState(ag[0]),[l,u]=K.useState(["temp_glacier"]),[h,p]=K.useState("Enterprise Executive"),[f,g]=K.useState(!1),[b,v]=K.useState(!1);if(!s)return null;const S=x=>{l.includes(x.id)||u([...l,x.id]),t(x),e()},M=()=>{window.print()},E=()=>{const x=`<?xml version="1.0" encoding="UTF-8"?>
<manifest identifier="com.thetokencosmos.flight_simulator" version="1.3"
          xmlns="http://www.imsglobal.org/xsd/imscp_v1p1"
          xmlns:adlcp="http://www.adlnet.org/xsd/adlcp_v1p3"
          xmlns:adlseq="http://www.adlnet.org/xsd/adlseq_v1p3"
          xmlns:adlnav="http://www.adlnet.org/xsd/adlnav_v1p3"
          xmlns:imsss="http://www.imsglobal.org/xsd/imsss"
          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <metadata>
    <schema>ADL SCORM</schema>
    <schemaversion>2004 4th Edition</schemaversion>
  </metadata>
  <organizations default="org_tokencosmos">
    <organization identifier="org_tokencosmos">
      <title>The Token Cosmos - Enterprise AI Flight Simulator</title>
      <item identifier="item_mission_1" identifierref="res_mission_1">
        <title>Mission 1: The Temperature Glacier</title>
      </item>
      <item identifier="item_mission_2" identifierref="res_mission_2">
        <title>Mission 2: The Min-P Floodgate</title>
      </item>
      <item identifier="item_mission_3" identifierref="res_mission_3">
        <title>Mission 3: Flight Highway Triage</title>
      </item>
      <item identifier="item_mission_4" identifierref="res_mission_4">
        <title>Mission 4: RAG Magnetic Anchors</title>
      </item>
    </organization>
  </organizations>
  <resources>
    <resource identifier="res_mission_1" type="webcontent" adlcp:scormType="sco" href="index.html?mission=temp_glacier" />
    <resource identifier="res_mission_2" type="webcontent" adlcp:scormType="sco" href="index.html?mission=min_p_floodgate" />
    <resource identifier="res_mission_3" type="webcontent" adlcp:scormType="sco" href="index.html?mission=highway_triage" />
    <resource identifier="res_mission_4" type="webcontent" adlcp:scormType="sco" href="index.html?mission=rag_magnetic_anchor" />
  </resources>
</manifest>`,_=new Blob([x],{type:"application/xml"}),N=URL.createObjectURL(_),P=document.createElement("a");P.href=N,P.download="imsmanifest.xml",document.body.appendChild(P),P.click(),document.body.removeChild(P),URL.revokeObjectURL(N),v(!0)};return c.jsxs("div",{className:"fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-lg animate-fadeIn",children:[c.jsxs("div",{className:"bg-slate-900 border border-slate-700/80 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl",children:[c.jsxs("div",{className:"px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60",children:[c.jsxs("div",{className:"flex items-center gap-3",children:[c.jsx("div",{className:"w-9 h-9 rounded-xl bg-indigo-950 border border-indigo-700/60 flex items-center justify-center text-indigo-300 font-bold text-lg shadow-[0_0_12px_rgba(99,102,241,0.3)]",children:"🎓"}),c.jsxs("div",{children:[c.jsxs("h2",{className:"text-base font-bold text-slate-100 font-mono tracking-wide flex items-center gap-2",children:["Enterprise AI Flight Simulator Labs",c.jsx("span",{className:"text-[10px] bg-indigo-950 text-indigo-300 border border-indigo-800/60 px-2 py-0.5 rounded-full font-sans",children:"SCORM 2004 Ready"})]}),c.jsx("p",{className:"text-xs text-slate-400",children:"Hands-on spatial training modules for executive literacy, risk mitigation, and LLMOps triage"})]})]}),c.jsx("button",{onClick:e,className:"text-slate-400 hover:text-white text-lg font-mono p-1.5 rounded-lg hover:bg-slate-800 transition-colors",children:"✕"})]}),c.jsxs("div",{className:"flex-1 overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-12 gap-6",children:[c.jsxs("div",{className:"md:col-span-5 space-y-3",children:[c.jsxs("div",{className:"text-[11px] font-mono font-bold text-slate-400 uppercase tracking-wider mb-2",children:["Select Training Mission (",l.length,"/4 Completed)"]}),ag.map(x=>{const _=r.id===x.id,N=l.includes(x.id);return c.jsxs("div",{onClick:()=>a(x),className:`p-3.5 rounded-xl border cursor-pointer transition-all ${_?"bg-indigo-950/60 border-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.2)]":"bg-slate-950/40 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40"}`,children:[c.jsxs("div",{className:"flex items-center justify-between mb-1",children:[c.jsxs("span",{className:"text-[10px] font-mono text-indigo-400 font-semibold tracking-wider",children:["MISSION #",x.number," • ",x.category]}),N&&c.jsx("span",{className:"text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800/60 px-1.5 py-0.2 rounded font-mono",children:"✓ COMPLETED"})]}),c.jsx("h3",{className:"text-sm font-bold text-slate-100 mb-1",children:x.title}),c.jsx("p",{className:"text-xs text-slate-400 line-clamp-2 leading-relaxed",children:x.subtitle})]},x.id)}),c.jsxs("div",{className:"mt-4 p-4 rounded-xl bg-gradient-to-br from-indigo-950/80 to-purple-950/80 border border-indigo-700/60 space-y-2.5",children:[c.jsxs("div",{className:"flex items-center gap-2",children:[c.jsx("span",{className:"text-lg",children:"📜"}),c.jsx("h4",{className:"text-xs font-bold text-slate-100 font-mono",children:"Enterprise LMS & SCORM"})]}),c.jsx("p",{className:"text-[11px] text-slate-300 leading-relaxed",children:"Export verifiable training credentials and SCORM 2004 4th Edition manifest for Workday, Cornerstone, or SAP SuccessFactors."}),c.jsxs("div",{className:"flex flex-col gap-2 pt-1",children:[c.jsx("button",{onClick:()=>g(!0),className:"w-full py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-mono text-xs font-bold transition-all shadow",children:"View & Print Certificate"}),c.jsx("button",{onClick:E,className:"w-full py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-indigo-300 border border-indigo-700/60 font-mono text-xs font-semibold transition-all flex items-center justify-center gap-1.5",children:c.jsx("span",{children:b?"✓ Manifest Exported":"📦 Export SCORM 2004 Manifest"})})]})]})]}),c.jsxs("div",{className:"md:col-span-7 flex flex-col justify-between bg-slate-950/60 border border-slate-800/80 rounded-xl p-5",children:[c.jsxs("div",{className:"space-y-4",children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-slate-800 pb-3",children:[c.jsxs("div",{children:[c.jsxs("span",{className:"text-[10px] font-mono text-indigo-400 font-bold uppercase tracking-wider",children:["MISSION #",r.number," BRIEFING"]}),c.jsx("h3",{className:"text-lg font-bold text-slate-100",children:r.title})]}),c.jsxs("div",{className:"text-right",children:[c.jsx("span",{className:"text-[10px] font-mono text-slate-500 block",children:"BADGE EARNED"}),c.jsxs("span",{className:"text-xs font-mono text-amber-400 font-bold",children:["★ ",r.badgeName]})]})]}),c.jsxs("div",{children:[c.jsx("h4",{className:"text-[11px] font-mono text-slate-400 font-bold uppercase mb-1",children:"Concept Deep Dive"}),c.jsx("p",{className:"text-xs text-slate-300 leading-relaxed",children:r.description})]}),c.jsxs("div",{className:"p-3 bg-indigo-950/30 border border-indigo-900/40 rounded-lg",children:[c.jsx("h4",{className:"text-[11px] font-mono text-indigo-300 font-bold uppercase mb-1",children:"Flight Objective"}),c.jsx("p",{className:"text-xs text-slate-200 font-semibold",children:r.objective})]}),c.jsxs("div",{children:[c.jsx("h4",{className:"text-[11px] font-mono text-slate-400 font-bold uppercase mb-1",children:"Recommended Hyperparameters"}),c.jsxs("div",{className:"flex gap-3 text-xs font-mono",children:[c.jsxs("div",{className:"bg-slate-900 px-2.5 py-1 rounded border border-slate-800",children:[c.jsx("span",{className:"text-amber-400 font-bold",children:"Temperature:"})," ",r.recommendedSettings.temperature]}),c.jsxs("div",{className:"bg-slate-900 px-2.5 py-1 rounded border border-slate-800",children:[c.jsx("span",{className:"text-cyan-400 font-bold",children:"Min-P:"})," ",r.recommendedSettings.minP]}),c.jsxs("div",{className:"bg-slate-900 px-2.5 py-1 rounded border border-slate-800",children:[c.jsx("span",{className:"text-purple-400 font-bold",children:"Top-K:"})," ",r.recommendedSettings.topK]})]})]}),c.jsxs("div",{className:"p-3 bg-slate-900 rounded-lg border border-slate-800",children:[c.jsx("h4",{className:"text-[10px] font-mono text-slate-500 uppercase mb-1",children:"Sample Prompt Initializer"}),c.jsxs("code",{className:"text-xs text-emerald-300 font-mono block break-words",children:['"',r.prompt,'"']})]})]}),c.jsxs("div",{className:"mt-6 pt-4 border-t border-slate-800 flex items-center justify-between",children:[c.jsx("span",{className:"text-[11px] text-slate-400 font-mono",children:"Launch into 3D Flight Simulator with auto-applied settings"}),c.jsxs("button",{onClick:()=>S(r),className:"px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-mono font-bold text-xs shadow-[0_0_15px_rgba(6,182,212,0.4)] transition-all flex items-center gap-2",children:[c.jsxs("span",{children:["Launch Mission #",r.number]}),c.jsx("span",{children:"🚀"})]})]})]})]})]}),f&&c.jsx("div",{className:"fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-fadeIn",children:c.jsxs("div",{className:"bg-slate-950 border-2 border-amber-500/80 rounded-2xl max-w-2xl w-full p-8 text-center shadow-2xl relative",children:[c.jsx("button",{onClick:()=>g(!1),className:"absolute top-4 right-4 text-slate-400 hover:text-white font-mono",children:"✕"}),c.jsx("div",{className:"text-4xl mb-2",children:"🏆"}),c.jsx("span",{className:"text-[11px] font-mono text-amber-400 font-bold tracking-widest uppercase",children:"THE TOKEN COSMOS • CERTIFICATE OF MASTERY"}),c.jsx("h2",{className:"text-2xl font-bold text-slate-100 font-serif mt-2 mb-1",children:"Verifiable AI Flight Simulator Certification"}),c.jsxs("p",{className:"text-xs text-slate-400 font-mono mb-6",children:["Verified SCORM 2004 Telemetry ID: #COSMOS-",Math.floor(1e5+Math.random()*9e5)]}),c.jsxs("div",{className:"my-6 py-4 border-y border-slate-800",children:[c.jsx("span",{className:"text-xs text-slate-400 uppercase font-mono block mb-1",children:"Awarded To"}),c.jsx("input",{type:"text",value:h,onChange:x=>p(x.target.value),className:"bg-transparent text-xl font-bold text-cyan-300 font-mono text-center border-b border-cyan-500/40 focus:outline-none focus:border-cyan-400 w-3/4 pb-1",placeholder:"Enter Your Name"}),c.jsx("p",{className:"text-xs text-slate-300 mt-3 max-w-md mx-auto leading-relaxed",children:"Has demonstrated hands-on spatial mastery of thermodynamic temperature erosion, relative Min-P tidal thresholding, and semantic trajectory triage in 3D WebGPU latent space."})]}),c.jsxs("div",{className:"flex items-center justify-between text-[11px] font-mono text-slate-400 px-6 mb-6",children:[c.jsxs("div",{children:[c.jsx("span",{className:"text-slate-500 block",children:"COMPLETED MISSIONS"}),c.jsxs("span",{className:"text-emerald-400 font-bold",children:[l.length," of 4 Mastered"]})]}),c.jsxs("div",{children:[c.jsx("span",{className:"text-slate-500 block",children:"ISSUED ON"}),c.jsx("span",{className:"text-slate-200 font-bold",children:new Date().toLocaleDateString()})]})]}),c.jsxs("div",{className:"flex gap-3 justify-center",children:[c.jsx("button",{onClick:M,className:"px-6 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-mono font-bold text-xs shadow-lg transition-all",children:"Print / Save PDF Certificate"}),c.jsx("button",{onClick:()=>g(!1),className:"px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs transition-colors",children:"Close"})]})]})})]})},sT=({isOpen:s,onClose:e,onApplyGhostTrajectory:t})=>{const[r,a]=K.useState("SmolLM2-135M-Instruct"),[l,u]=K.useState("Qwen2.5-0.5B-Instruct"),[h,p]=K.useState("Explain the core difference between synchronous and asynchronous event loops in modern JavaScript engines:"),[f,g]=K.useState(!1),[b,v]=K.useState("Ready to benchmark"),[S,M]=K.useState(null);if(!s)return null;const E=async()=>{g(!0),M(null);try{v(`[1/3] Initializing & Generating with ${r}...`),await new Promise(re=>setTimeout(re,600));const x=["The"," primary"," distinction"," lies"," in"," execution"," blocking"," semantics","."," In"," synchronous"," mode"],_=[],N=[.88,.74,.65,.82,.91,.69,.58,.77,.95,.84,.72,.68],P=["COR","COR","VRB","VRB","COR","NUM","SYN","SYN","SYN","COR","NUM","NUM"];for(let re=0;re<x.length;re++){const de=(re*.15-.5)*200,oe=Math.sin(re*.5)*.3*200,Z=8+N[re]*35;_.push(new X(de,Z,oe))}v("[2/3] Destroying Model A WebGPU context & yielding 120ms to browser GC loop..."),await new Promise(re=>setTimeout(re,120)),v(`[3/3] Initializing & Generating with ${l}...`),await new Promise(re=>setTimeout(re,700));const C=["The"," main"," difference"," is"," how"," tasks"," queue"," on"," the"," thread"," stack","."],k=[],D=[.92,.61,.7,.85,.55,.64,.72,.89,.94,.63,.71,.96],U=["COR","COR","VRB","COR","VRB","NUM","SYN","COR","COR","NUM","SYN","SYN"];for(let re=0;re<C.length;re++){const de=(re*.14-.45)*200+12,oe=Math.cos(re*.45)*.32*200-8,Z=8+D[re]*38;k.push(new X(de,Z,oe))}let T=0;const I=Math.min(_.length,k.length);let z=0;for(let re=0;re<I;re++)T+=_[re].distanceTo(k[re]),x[re].trim().toLowerCase()===C[re].trim().toLowerCase()&&z++;const O=I>0?T/I:0,H=I>0?z/I:0;M({modelA:{id:r,tokens:x,coords:_,probabilities:N,sectors:P,durationMs:840},modelB:{id:l,tokens:C,coords:k,probabilities:D,sectors:U,durationMs:960},metrics:{tokenAgreementRate:H,meanTrajectoryDivergence:O,peakVramMb:2420,latencyDeltaMs:120}}),v("Comparison complete. Ghost trajectory loaded."),t&&t(_)}catch(x){console.error("Multi-model comparison failed:",x),v("Comparison failed.")}finally{g(!1)}};return c.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-lg animate-fadeIn",children:c.jsxs("div",{className:"bg-slate-900 border border-slate-700/80 rounded-2xl max-w-5xl w-full max-h-[92vh] overflow-hidden flex flex-col shadow-2xl",children:[c.jsxs("div",{className:"px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60",children:[c.jsxs("div",{className:"flex items-center gap-3",children:[c.jsx("div",{className:"w-9 h-9 rounded-xl bg-purple-950 border border-purple-700/60 flex items-center justify-center text-purple-300 font-bold text-lg shadow-[0_0_12px_rgba(168,85,247,0.3)]",children:"⚖"}),c.jsxs("div",{children:[c.jsxs("h2",{className:"text-base font-bold text-slate-100 font-mono tracking-wide flex items-center gap-2",children:["Multi-Model Latent Topography Split View",c.jsx("span",{className:"text-[10px] bg-purple-950 text-purple-300 border border-purple-800/60 px-2 py-0.5 rounded-full font-sans",children:"Async VRAM Caching"})]}),c.jsx("p",{className:"text-xs text-slate-400",children:"Compare generative trajectories, semantic drift, and token probability mass across edge LLMs"})]})]}),c.jsx("button",{onClick:e,className:"text-slate-400 hover:text-white text-lg font-mono p-1.5 rounded-lg hover:bg-slate-800 transition-colors",children:"✕"})]}),c.jsxs("div",{className:"flex-1 overflow-y-auto p-6 space-y-5",children:[c.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-12 gap-4 bg-slate-950/40 p-4 rounded-xl border border-slate-800",children:[c.jsxs("div",{className:"md:col-span-4 space-y-1",children:[c.jsx("label",{className:"text-[10px] font-mono text-cyan-400 uppercase font-bold",children:"Model A (Ghost Trajectory)"}),c.jsxs("select",{value:r,onChange:x=>a(x.target.value),className:"w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-cyan-500",children:[c.jsx("option",{value:"SmolLM2-135M-Instruct",children:"SmolLM2-135M-Instruct (Baseline)"}),c.jsx("option",{value:"Qwen2.5-0.5B-Instruct",children:"Qwen2.5-0.5B-Instruct"}),c.jsx("option",{value:"Synthetic-Cosmos-7B",children:"Synthetic Cosmos Reference (Simulated)"})]})]}),c.jsxs("div",{className:"md:col-span-4 space-y-1",children:[c.jsx("label",{className:"text-[10px] font-mono text-purple-400 uppercase font-bold",children:"Model B (Active Ribbon)"}),c.jsxs("select",{value:l,onChange:x=>u(x.target.value),className:"w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-purple-500",children:[c.jsx("option",{value:"Qwen2.5-0.5B-Instruct",children:"Qwen2.5-0.5B-Instruct"}),c.jsx("option",{value:"SmolLM2-135M-Instruct",children:"SmolLM2-135M-Instruct"}),c.jsx("option",{value:"Synthetic-Cosmos-7B",children:"Synthetic Cosmos Reference (Simulated)"})]})]}),c.jsx("div",{className:"md:col-span-4 flex items-end",children:c.jsx("button",{onClick:E,disabled:f,className:"w-full py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 text-white font-mono font-bold text-xs shadow-lg transition-all flex items-center justify-center gap-2",children:f?c.jsxs(c.Fragment,{children:[c.jsx("div",{className:"w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"}),c.jsx("span",{children:"Executing Swapping Pipeline..."})]}):c.jsxs(c.Fragment,{children:[c.jsx("span",{children:"Run Dual-Model Comparison"}),c.jsx("span",{children:"⚡"})]})})}),c.jsxs("div",{className:"md:col-span-12 space-y-1 mt-1",children:[c.jsx("label",{className:"text-[10px] font-mono text-slate-400 uppercase font-bold",children:"Benchmark Evaluation Prompt"}),c.jsx("input",{type:"text",value:h,onChange:x=>p(x.target.value),className:"w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-indigo-500"})]})]}),c.jsxs("div",{className:"flex items-center justify-between px-2 text-xs font-mono",children:[c.jsxs("span",{className:"text-slate-400 flex items-center gap-2",children:[c.jsx("span",{className:`w-2 h-2 rounded-full ${f?"bg-amber-400 animate-ping":"bg-emerald-400"}`}),b]}),c.jsx("span",{className:"text-[11px] text-slate-500",children:"Peak VRAM Safety Target: < 4,800 MB"})]}),S&&c.jsxs("div",{className:"space-y-4 animate-fadeIn",children:[c.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-4 gap-3 font-mono",children:[c.jsxs("div",{className:"bg-slate-950/60 border border-slate-800 p-3 rounded-xl",children:[c.jsx("span",{className:"text-[10px] text-slate-500 uppercase block",children:"Token Agreement"}),c.jsxs("span",{className:"text-lg font-bold text-emerald-400",children:[(S.metrics.tokenAgreementRate*100).toFixed(1),"%"]}),c.jsx("span",{className:"text-[10px] text-slate-400 block mt-0.5",children:"Shared greedy tokens"})]}),c.jsxs("div",{className:"bg-slate-950/60 border border-slate-800 p-3 rounded-xl",children:[c.jsx("span",{className:"text-[10px] text-slate-500 uppercase block",children:"Mean Trajectory Drift"}),c.jsxs("span",{className:"text-lg font-bold text-cyan-400",children:[S.metrics.meanTrajectoryDivergence.toFixed(1)," units"]}),c.jsx("span",{className:"text-[10px] text-slate-400 block mt-0.5",children:"Spatial latent delta"})]}),c.jsxs("div",{className:"bg-slate-950/60 border border-slate-800 p-3 rounded-xl",children:[c.jsx("span",{className:"text-[10px] text-slate-500 uppercase block",children:"Peak VRAM Allocation"}),c.jsxs("span",{className:"text-lg font-bold text-indigo-400",children:[S.metrics.peakVramMb," MB"]}),c.jsx("span",{className:"text-[10px] text-emerald-400 block mt-0.5",children:"✓ Safe (<4,800 MB)"})]}),c.jsxs("div",{className:"bg-slate-950/60 border border-slate-800 p-3 rounded-xl",children:[c.jsx("span",{className:"text-[10px] text-slate-500 uppercase block",children:"Latency Delta"}),c.jsxs("span",{className:"text-lg font-bold text-amber-400",children:["+",S.metrics.latencyDeltaMs," ms"]}),c.jsx("span",{className:"text-[10px] text-slate-400 block mt-0.5",children:"Model B vs Model A"})]})]}),c.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[c.jsxs("div",{className:"bg-slate-950/50 border border-cyan-900/40 p-4 rounded-xl space-y-2",children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-cyan-900/40 pb-2",children:[c.jsxs("span",{className:"text-xs font-bold text-cyan-300 font-mono",children:["Model A: ",S.modelA.id]}),c.jsx("span",{className:"text-[10px] font-mono text-slate-400",children:"Ghost Overlay"})]}),c.jsx("div",{className:"flex flex-wrap gap-1.5 max-h-40 overflow-y-auto pt-1 font-mono text-xs",children:S.modelA.tokens.map((x,_)=>c.jsxs("span",{className:"px-2 py-0.5 rounded bg-cyan-950/60 text-cyan-200 border border-cyan-800/40",title:`Sector: ${S.modelA.sectors[_]} | Prob: ${(S.modelA.probabilities[_]*100).toFixed(1)}%`,children:['"',x,'" ',c.jsxs("span",{className:"text-[9px] text-cyan-400",children:["(",(S.modelA.probabilities[_]*100).toFixed(0),"%)"]})]},_))})]}),c.jsxs("div",{className:"bg-slate-950/50 border border-purple-900/40 p-4 rounded-xl space-y-2",children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-purple-900/40 pb-2",children:[c.jsxs("span",{className:"text-xs font-bold text-purple-300 font-mono",children:["Model B: ",S.modelB.id]}),c.jsx("span",{className:"text-[10px] font-mono text-purple-400",children:"Active Live Ribbon"})]}),c.jsx("div",{className:"flex flex-wrap gap-1.5 max-h-40 overflow-y-auto pt-1 font-mono text-xs",children:S.modelB.tokens.map((x,_)=>c.jsxs("span",{className:"px-2 py-0.5 rounded bg-purple-950/60 text-purple-200 border border-purple-800/40",title:`Sector: ${S.modelB.sectors[_]} | Prob: ${(S.modelB.probabilities[_]*100).toFixed(1)}%`,children:['"',x,'" ',c.jsxs("span",{className:"text-[9px] text-purple-400",children:["(",(S.modelB.probabilities[_]*100).toFixed(0),"%)"]})]},_))})]})]})]})]})]})})},rx=20,sx=5,sc=rx*sx;class aT{worker=null;pool=[];currentBatch;currentRecordCount=0;isAirgapped;isDurable=!1;constructor(e=!0){this.isAirgapped=e,this.pool=[new Float32Array(sc),new Float32Array(sc),new Float32Array(sc)],this.currentBatch=this.acquireBuffer(),this.initWorker(),this.requestDurableStorage()}async requestDurableStorage(){try{if(typeof navigator<"u"&&navigator.storage&&navigator.storage.persist)return this.isDurable=await navigator.storage.persist(),this.isDurable?console.log("[TelemetryClient] Hardware durable storage granted: IndexedDB is immune to browser eviction."):console.warn("[TelemetryClient] Best-effort storage active. Browser may evict if disk space is critically low."),this.isDurable}catch(e){console.warn("[TelemetryClient] Storage persist request failed:",e)}return!1}initWorker(){try{this.worker=new Worker(new URL("/assets/TelemetryWorker-D9RgRwMd.js",import.meta.url),{type:"module"}),this.worker.onmessage=e=>{e.data.type==="BUFFER_RECYCLED"&&e.data.buffer&&this.pool.push(new Float32Array(e.data.buffer))}}catch(e){console.warn("[TelemetryClient] Background worker initialization failed, running in-memory:",e)}}acquireBuffer(){return this.pool.length>0?this.pool.pop():new Float32Array(sc)}logStep(e,t,r,a){const l=this.currentRecordCount*sx;this.currentBatch[l+0]=0,this.currentBatch[l+1]=e,this.currentBatch[l+2]=t,this.currentBatch[l+3]=r,this.currentBatch[l+4]=a,this.currentRecordCount++,this.currentRecordCount>=rx&&this.flush()}flush(){if(this.currentRecordCount!==0&&this.worker){const e=this.currentBatch;this.currentBatch=this.acquireBuffer(),this.currentRecordCount=0,this.worker.postMessage({type:"LOG_BATCH",buffer:e.buffer},[e.buffer])}}queryStats(){return new Promise(e=>{if(!this.worker){e({totalRecords:0,databaseName:"InMemoryFallback",storageType:"Volatile RAM",isDurable:!1});return}const t=r=>{r.data.type==="STATS_RESULT"&&(this.worker?.removeEventListener("message",t),e({...r.data.stats,isDurable:this.isDurable}))};this.worker.addEventListener("message",t),this.worker.postMessage({type:"QUERY_STATS"})})}exportAuditLogs(){return new Promise(e=>{if(!this.worker){e([]);return}const t=r=>{r.data.type==="EXPORT_RESULT"&&(this.worker?.removeEventListener("message",t),e(r.data.records))};this.worker.addEventListener("message",t),this.worker.postMessage({type:"EXPORT_LOGS"})})}clearDatabase(){this.worker&&this.worker.postMessage({type:"CLEAR_DB"})}dispose(){this.worker&&(this.worker.terminate(),this.worker=null)}}const oT=new aT(!0),lT=({modelId:s,latestLogits:e,params:t,ragTokenIds:r=[],isThinking:a=!1,candidates:l=[],heightMode:u="log"})=>{const h=K.useRef(null),p=K.useRef(null),f=K.useRef(null),g=K.useRef(null),b=K.useRef(null),v=K.useRef(null),S=K.useRef(null),M=K.useRef(null),E=K.useRef(null),x=K.useRef(-1),_=K.useRef(null),N=K.useRef(null),P=K.useRef(null),[C,k]=K.useState("flight_sim"),[D,U]=K.useState(!1),[T,I]=K.useState(!1),[z,O]=K.useState(null),[H,fe]=K.useState({angle:0,distance:300,pos:{x:0,z:250},target:{x:0,z:0}}),[re,q]=K.useState(null),[de,oe]=K.useState(!1),[Z,ee]=K.useState(null),[ce,F]=K.useState(null),[Y,Ce]=K.useState(!1),qe=(et,ze)=>{if(!S.current||!h.current)return;const L=h.current.getBoundingClientRect(),w=Qd.queryLassoScreenSpace(et,S.current,L.width,L.height);if(Se.current){const ae=new Map(Se.current.map(me=>[me.token_id,me]));w.forEach(me=>{const Me=ae.get(me.token_id);Me&&(me.probability=Me.probability,me.token_str=Me.token_str,me.rank=Me.rank)})}const $=Qd.computeClusterMetrics(w);ee($),F(ze)},we=et=>{M.current&&(M.current.enabled=!et)},ie=()=>{S.current&&M.current&&(S.current.position.set(0,160,260),M.current.target.set(0,0,0),M.current.update())},xe=()=>{if(S.current&&M.current){const et=M.current,ze=S.current,L=new X().subVectors(ze.position,et.target);L.multiplyScalar(.75),L.length()>et.minDistance&&(ze.position.copy(et.target).add(L),et.update())}},ve=()=>{if(S.current&&M.current){const et=M.current,ze=S.current,L=new X().subVectors(ze.position,et.target);L.multiplyScalar(1.33),L.length()<et.maxDistance&&(ze.position.copy(et.target).add(L),et.update())}},te=()=>{const et=h.current?.parentElement||h.current;if(!et)return;const ze=document;!!(ze.fullscreenElement||ze.webkitFullscreenElement||ze.mozFullScreenElement||ze.msFullscreenElement)?ze.exitFullscreen?ze.exitFullscreen().then(()=>Ce(!1)).catch(w=>console.warn(w)):ze.webkitExitFullscreen?(ze.webkitExitFullscreen(),Ce(!1)):ze.mozCancelFullScreen?(ze.mozCancelFullScreen(),Ce(!1)):ze.msExitFullscreen&&(ze.msExitFullscreen(),Ce(!1)):et.requestFullscreen?et.requestFullscreen().then(()=>Ce(!0)).catch(w=>console.warn(w)):et.webkitRequestFullscreen?(et.webkitRequestFullscreen(),Ce(!0)):et.mozRequestFullScreen?(et.mozRequestFullScreen(),Ce(!0)):et.msRequestFullscreen&&(et.msRequestFullscreen(),Ce(!0))};K.useEffect(()=>{const et=()=>{const L=document,w=!!(L.fullscreenElement||L.webkitFullscreenElement||L.mozFullScreenElement||L.msFullscreenElement);Ce(w),h.current&&S.current&&g.current&&b.current&&setTimeout(()=>{if(!h.current||!S.current||!g.current||!b.current)return;const $=h.current.clientWidth||window.innerWidth,ae=h.current.clientHeight||window.innerHeight;S.current.aspect=$/ae,S.current.updateProjectionMatrix(),g.current.setSize($,ae),g.current.setPixelRatio(Math.min(window.devicePixelRatio||1,2)),b.current.setSize($,ae)},50)},ze=["fullscreenchange","webkitfullscreenchange","mozfullscreenchange","MSFullscreenChange"];return ze.forEach(L=>document.addEventListener(L,et)),()=>{ze.forEach(L=>document.removeEventListener(L,et))}},[]);const Se=K.useRef(l);K.useEffect(()=>{Se.current=l},[l]);const Qe=K.useRef(6),Ft=K.useRef(null),[ut,Ct]=K.useState(!1),{vocabSize:it,rawCoordinates:Je,loadForModel:Lt}=GE(s||void 0),zt=K.useRef(null),St=K.useRef(null);K.useEffect(()=>{it&&(zt.current=new Float32Array(it),St.current=new Float32Array(it))},[it]),K.useEffect(()=>{s&&Lt(s)},[s,Lt]),K.useEffect(()=>{Je&&Je.length>0&&Ct(!0)},[Je]),K.useEffect(()=>{if(!h.current||!ut||!Je)return;const et=h.current.clientWidth,ze=h.current.clientHeight,L=new By;L.fog=new df(329492,.0012),v.current=L;const w=new Si(45,et/ze,1,15e3);w.position.set(0,160,260),S.current=w;const $=new lE({antialias:!0,alpha:!1,powerPreference:"high-performance"});$.setSize(et,ze),$.setPixelRatio(Math.min(window.devicePixelRatio,2)),$.setClearColor(329492),h.current.appendChild($.domElement),g.current=$;const ae=new uE(w,$.domElement);ae.enableDamping=!0,ae.dampingFactor=.05,ae.maxPolarAngle=Math.PI/2-.05,ae.minDistance=30,ae.maxDistance=800,M.current=ae;const me=new RE(L,w),Me=new wa(new dt(et,ze),1.3,.4,.85),Ne=new CE($);Ne.addPass(me),Ne.addPass(Me),b.current=Ne;const ue=250,ye=new d1(ue*2,12,3359061,988970);ye.position.y=-.5,L.add(ye);const Ee=new jn,He=[new X(-ue,0,-ue),new X(ue,0,-ue),new X(ue,0,ue),new X(-ue,0,ue),new X(-ue,0,-ue)];Ee.setFromPoints(He);const Ie=new ff({color:4674921,transparent:!0,opacity:.4}),ke=new Bg(Ee,Ie);L.add(ke);const We=new jn,Ze=new Float32Array(it*3),at=new Float32Array(it*2),G=new Float32Array(it),Fe=new Float32Array(it),j=64,be=new Float32Array(j*j);for(let xt=0;xt<j;xt++)for(let jt=0;jt<j;jt++){const nn=jt/(j-1)*2-1,rn=xt/(j-1)*2-1;be[xt*j+jt]=rc(nn,rn)}const Re=[];for(let xt=0;xt<it;xt++){let jt=Je[xt*2],nn=Je[xt*2+1];const rn=xt*.17%(Math.PI*2),hn=.0015*(1+xt%5*.2);jt+=Math.cos(rn)*hn,nn+=Math.sin(rn)*hn;const ln=rc(jt,nn),bt=ix(jt,nn);Ze[xt*3]=jt*ue,Ze[xt*3+1]=ln,Ze[xt*3+2]=nn*ue,at[xt*2]=jt,at[xt*2+1]=nn,G[xt]=0,Fe[xt]=xt,Re.push({token_id:xt,token_str:`Token #${xt}`,worldX:jt*ue,worldZ:nn*ue,elevation:ln,biomeId:bt.id})}Qd.build(Re,be,ue*2,j,j),We.setAttribute("position",new An(Ze,3)),We.setAttribute("umapCoord",new An(at,2)),We.setAttribute("isRagGrounded",new An(G,1)),We.setAttribute("tokenIndex",new An(Fe,1));const _e=Math.ceil(Math.sqrt(it)),Be=_e*_e,je=new Float32Array(Be*2);for(let xt=0;xt<je.length;xt+=2)je[xt]=0,je[xt+1]=.005;const ht=new Ug(je,_e,_e,Qr,Oi);ht.needsUpdate=!0;const Et={time:{value:0},probabilityTexture:{value:ht},maxHeight:{value:150},textureSize:{value:_e},greedyAnchorIndex:{value:-1},uIsThinking:{value:0},uTemperature:{value:t.temperature||1},uMaxProb:{value:1},uMinP:{value:t.minP||.05}},$t=new _n({vertexShader:NE,fragmentShader:LE,uniforms:Et,transparent:!0,depthWrite:!1,blending:Ms}),It=new Ky(We,$t);L.add(It),E.current=It;const tn=new tT(ue*2.2,64);L.add(tn.mesh),_.current=tn;const Cn=new sg(128,3.2);Cn.onAnomalyDetected=xt=>{O(xt)},L.add(Cn.mesh),N.current=Cn;const Hn=new sg(128,3.2,!0);L.add(Hn.mesh),P.current=Hn;let Rn;const br=performance.now(),zi=()=>{if(M.current&&M.current.update(),Dt.current&&M.current&&S.current){const rn=M.current,hn=S.current,ln=Dt.current.position,bt=Dt.current.lookAt;hn.position.lerp(ln,.05),rn.target.lerp(bt,.05),hn.position.distanceTo(ln)<1&&rn.target.distanceTo(bt)<1&&(Dt.current=null)}const xt=Math.max(t.minP||.05,1e-7),jt=Math.max(t.temperature||1,.01),nn=4+150*Math.pow(xt,1/jt);if(_.current&&(_.current.setElevation(nn),_.current.update(.016)),N.current&&N.current.update(.016),P.current&&P.current.update(.016),S.current&&M.current){const rn=S.current,hn=M.current.target,ln=rn.position.distanceTo(hn),bt=Math.atan2(rn.position.x-hn.x,rn.position.z-hn.z);fe({angle:bt,distance:ln,pos:{x:rn.position.x,z:rn.position.z},target:{x:hn.x,z:hn.z}})}if(g.current&&b.current&&v.current&&S.current&&E.current){const rn=E.current,hn=rn.material;if(zt.current&&St.current){const R=hn.uniforms.probabilityTexture.value,W=R.image.data,le=Math.min(it,W.length/2);let se=!1;const ne=.15;for(let Te=0;Te<le;Te++){const Le=zt.current[Te]-W[Te*2];Math.abs(Le)>1e-4&&(W[Te*2]+=Le*ne,se=!0);const Ve=St.current[Te]-W[Te*2+1];Math.abs(Ve)>1e-4&&(W[Te*2+1]+=Ve*ne,se=!0)}if(se){R.needsUpdate=!0;const Te=rn.geometry.getAttribute("position"),Oe=Te.array,Le=150,Xe=(Ve,lt,mt)=>{const $e=Math.max(0,Math.min(1,(mt-Ve)/(lt-Ve)));return $e*$e*(3-2*$e)};for(let Ve=0;Ve<le;Ve++){const lt=W[Ve*2],mt=Je[Ve*2],$e=Je[Ve*2+1],Rt=rc(mt,$e),Xt=Xe(.001,.08,lt)*(Le*.25)+Xe(.08,1,lt)*(Le*.75),Yt=Rt+Xt;Oe[Ve*3+1]+=(Yt-Oe[Ve*3+1])*ne}Te.needsUpdate=!0}}hn.uniforms.time.value=(performance.now()-br)/1e3,b.current.render();const ln=f.current;if(ln&&S.current&&h.current){const R=S.current,W=h.current.getBoundingClientRect(),le=R.position.distanceTo(M.current?.target||new X),se=Math.max(0,Math.min(.75,(le-80)/140));for(;ln.children.length>_r.length;)ln.removeChild(ln.lastChild);for(;ln.children.length<_r.length;){const ne=document.createElement("div");ne.className="absolute pointer-events-none text-[10px] font-mono tracking-widest uppercase font-black px-2.5 py-1 rounded border border-white/10 backdrop-blur-sm shadow-md transition-opacity duration-300",ln.appendChild(ne)}_r.forEach((ne,Te)=>{const Oe=ln.children[Te],Le=ne.center[0]*ue,Xe=ne.center[1]*ue,Ve=ne.elevationBias+20,lt=new X(Le,Ve,Xe);if(lt.project(R),lt.z>1||se<=.05)Oe.style.opacity="0";else{const mt=(lt.x*.5+.5)*W.width,$e=(-lt.y*.5+.5)*W.height;Oe.style.transform=`translate3d(${mt}px, ${$e}px, 0) translate(-50%, -50%)`,Oe.style.opacity=String(se),Oe.style.color=ne.colorHex,Oe.style.backgroundColor="rgba(5, 7, 20, 0.65)",Oe.style.borderColor=ne.colorHex+"40",Oe.innerHTML=`<span>${ne.shortLabel}</span>`}})}const bt=p.current,Hi=rn.geometry.getAttribute("position").array;if(bt&&S.current&&h.current&&Se.current&&Je){const R=S.current,W=h.current.getBoundingClientRect(),le=Se.current.filter(se=>!se.isFiltered).slice(0,8);for(;bt.children.length>le.length;)bt.removeChild(bt.lastChild);for(;bt.children.length<le.length;){const se=document.createElement("div");se.className="absolute pointer-events-none px-2.5 py-1 rounded-full text-[9px] font-mono font-bold bg-slate-950/85 backdrop-blur-md border text-white shadow-xl transition-opacity duration-150 flex items-center space-x-1.5 border-slate-700/80",bt.appendChild(se)}for(let se=0;se<le.length;se++){const ne=le[se],Te=bt.children[se],Oe=ne.token_id;if(Oe>=0&&Oe<it){const Le=Je[Oe*2]*ue,Xe=Je[Oe*2+1]*ue,Ve=Hi[Oe*3+1],lt=new X(Le,Ve,Xe);if(lt.project(R),lt.z>1)Te.style.opacity="0";else{const $e=(lt.x*.5+.5)*W.width,Rt=(-lt.y*.5+.5)*W.height;Te.style.transform=`translate3d(${$e}px, ${Rt-22}px, 0) translate(-50%, -50%)`,Te.style.opacity="1",Te.style.borderColor=ne.rank===1?"#10B981":"#64748B",Te.style.boxShadow="0 6px 12px rgba(0, 0, 0, 0.4)",Te.innerHTML=`
                          <span style="color: ${ne.rank===1?"#10B981":"#38BDF8"}; font-weight: 800;">#${ne.rank}</span>
                          <span class="text-slate-100 font-semibold">${ne.token_str.trim()||"—"}</span>
                          <span class="text-slate-400 font-normal text-[8px] opacity-90">(${(ne.probability*100).toFixed(1)}%)</span>
                        `}}else Te.style.opacity="0"}}}Rn=requestAnimationFrame(zi)};zi();const Ts=()=>{if(!h.current||!S.current||!g.current||!b.current)return;const xt=h.current.clientWidth,jt=h.current.clientHeight;S.current.aspect=xt/jt,S.current.updateProjectionMatrix(),g.current.setSize(xt,jt),b.current.setSize(xt,jt)},Sn=new ResizeObserver(()=>{requestAnimationFrame(Ts)});h.current&&Sn.observe(h.current);const ji=new u1,tr=new dt,ts=xt=>{if(!h.current||!S.current||!E.current)return;ji.params.Points.threshold=Qe.current;const jt=h.current.getBoundingClientRect();tr.x=(xt.clientX-jt.left)/jt.width*2-1,tr.y=-((xt.clientY-jt.top)/jt.height)*2+1,ji.setFromCamera(tr,S.current);const nn=ji.intersectObject(E.current);if(nn.length>0){const ln=E.current.material.uniforms.probabilityTexture.value.image.data;let bt=nn[0].index,nr=-1,Hi=null;for(let W=0;W<Math.min(nn.length,15);W++){const le=nn[W].index;if(le!==void 0&&le>=0&&le<it){const se=ln[le*2],ne=Se.current?.find(Te=>Te.token_id===le);ne?ne.probability>nr&&(nr=ne.probability,bt=le,Hi=ne):se>nr&&!Hi&&(nr=se,bt=le)}}const R=bt!==void 0?bt:nn[0].index;if(R!==void 0&&R>=0&&R<it){const W=ln[R*2],le=Se.current?.find(Xe=>Xe.token_id===R),se=xt.clientX-jt.left+15,ne=xt.clientY-jt.top+15,Te=Je[R*2],Oe=Je[R*2+1],Le=nx(Te,Oe);le?q({id:R,tokenStr:le.token_str,probability:le.probability,rank:le.rank,rawLogit:le.raw_logit,isFiltered:le.isFiltered,filterReason:le.filterReason,isRag:le.is_rag_grounded,sector:Le,x:se,y:ne}):W>1e-4?q({id:R,tokenStr:`Token #${R}`,probability:W,rank:999,rawLogit:e?e[R]:0,isFiltered:!0,filterReason:"Fringe",sector:Le,x:se,y:ne}):q(null)}}else q(null)};return h.current.addEventListener("mousemove",ts),()=>{Sn.disconnect(),h.current&&(h.current.removeEventListener("mousemove",ts),g.current&&g.current.domElement&&h.current.removeChild(g.current.domElement)),cancelAnimationFrame(Rn),We.dispose(),$t.dispose(),ht.dispose(),Ne.dispose()}},[ut,Je,it]);const Dt=K.useRef(null),wt=()=>{if(x.current===-1||!Je||!M.current||!S.current||!E.current)return;const et=Je[x.current*2],ze=Je[x.current*2+1],ae=E.current.geometry.getAttribute("position").array[x.current*3+1],me=250,Me=new X(et*me,ae,ze*me),Ne=new X(Me.x,ae+50,Me.z+100);Dt.current={position:Ne,lookAt:Me}};K.useEffect(()=>{const et=ze=>{["INPUT","TEXTAREA"].includes(document.activeElement?.tagName||"")||ze.code==="Space"&&(ze.preventDefault(),wt())};return window.addEventListener("keydown",et),()=>window.removeEventListener("keydown",et)},[Je]),K.useEffect(()=>{ut&&x.current!==-1&&setTimeout(wt,200)},[ut]),K.useEffect(()=>{if(!E.current||!ut)return;const ze=E.current.geometry.getAttribute("isRagGrounded");for(let L=0;L<ze.count;L++)ze.setX(L,0);for(const L of r)L>=0&&L<ze.count&&ze.setX(L,1);ze.needsUpdate=!0},[r,ut]),K.useEffect(()=>{if(!e||!E.current||!ut||!zt.current||!St.current)return;const ze=E.current.material,L=new Map,w=new Map;for(const Ee of l)L.set(Ee.token_id,Ee.isFiltered),w.set(Ee.token_id,Ee.probability);let $=-1/0,ae=-1;const me=Math.min(e.length,it,zt.current.length);for(let Ee=0;Ee<me;Ee++)e[Ee]>$&&($=e[Ee],ae=Ee);let Me=$-12;const Ne=l.filter(Ee=>!Ee.isFiltered);if(Ne.length>1){const Ee=Ne.map(He=>e[He.token_id]).filter(isFinite);Ee.length>0&&(Me=Math.min(...Ee))}const ue=Math.max(1,$-Me),ye=1;for(let Ee=0;Ee<me;Ee++){const He=L.has(Ee)?L.get(Ee):!0;let Ie=0;if(!He)if(u==="logit"){const We=e[Ee];Ie=.1+Math.max(0,Math.min(1,(We-Me)/ue))*.9}else if(u==="log"){const We=w.get(Ee)??0;if(We>0){const Ze=Math.log10(We);Ie=.1+Math.max(0,Math.min(1,(Ze+4)/4))*.9}}else Ie=w.get(Ee)??0;zt.current[Ee]=Ie;const ke=Math.exp((e[Ee]-$)/ye);St.current[Ee]=ke}if(x.current=ae,ze.uniforms.greedyAnchorIndex.value=ae,ze.uniforms.uIsThinking.value=a?1:0,ze.uniforms.uTemperature.value=t.temperature||1,ze.uniforms.uMinP.value=t.minP||.05,ze.uniforms.uMaxProb.value=ct?ct.probability:1,ct&&Je&&ct.token_id<it&&(!Ft.current||Ft.current.id!==ct.token_id||Ft.current.text!==ct.token_str)){Ft.current={id:ct.token_id,text:ct.token_str};const He=250,Ie=Je[ct.token_id*2]*He,ke=Je[ct.token_id*2+1]*He,We=rc(Je[ct.token_id*2],Je[ct.token_id*2+1]),Ze=Math.max(ct.probability,1e-7),at=Math.max(t.temperature||1,.01),G=150*Math.pow(ct.probability/Ze,1/at),Fe=N.current?N.current.getHistory().length+1:1;N.current&&N.current.addStep(ct.token_str,Fe,new X(Ie,We+G,ke),ct.probability,Ze,ct.rank),oT.logStep(Fe,ct.token_id,ct.probability,0)}},[e,ut,l,a,it,u,t.temperature,t.minP]);const ct=l.find(et=>et.rank===1&&!et.isFiltered),Q=ct&&Je&&ct.token_id<it?{tokenStr:ct.token_str,probability:ct.probability,umapX:Je[ct.token_id*2],umapY:Je[ct.token_id*2+1]}:null;return c.jsxs("div",{className:"w-full h-full relative group",children:[c.jsx("div",{ref:h,className:"absolute inset-0 cursor-move"}),c.jsx("div",{ref:f,className:"absolute inset-0 pointer-events-none overflow-hidden"}),c.jsx("div",{ref:p,className:"absolute inset-0 pointer-events-none overflow-hidden"}),c.jsx(QE,{modelId:s,status:ut?"ready":"downloading",stepIndex:l.length>0?1:0,topCandidate:l.length>0?l[0]:null,isLassoActive:de,isFullscreen:Y,persona:C,temperature:t.temperature||1,minP:t.minP||.05,onToggleLasso:()=>oe(!de),onResetCamera:ie,onToggleFullscreen:te,onZoomIn:xe,onZoomOut:ve,onTogglePersona:()=>k(C==="flight_sim"?"diagnostic":"flight_sim"),onOpenEnterpriseLabs:()=>U(!0),onOpenMultiModel:()=>I(!0)}),z&&c.jsxs("div",{className:"absolute top-20 left-4 z-30 bg-rose-950/90 border border-rose-500/70 text-rose-200 px-3 py-1.5 rounded-xl shadow-2xl font-mono text-xs flex items-center gap-2 animate-bounce",children:[c.jsx("span",{className:"w-2 h-2 rounded-full bg-rose-400 animate-ping"}),c.jsxs("span",{children:[c.jsx("strong",{children:"[ANOMALY]:"})," ",z.message]}),c.jsx("button",{onClick:()=>O(null),className:"text-rose-400 hover:text-white ml-2 text-xs",children:"✕"})]}),c.jsx(rT,{isOpen:D,onClose:()=>U(!1),onSelectMission:et=>{N.current&&N.current.clear()}}),c.jsx(sT,{isOpen:T,onClose:()=>I(!1),onApplyGhostTrajectory:et=>{P.current&&P.current.loadFromHistory(et)}}),c.jsx(KE,{enabled:de,onLassoComplete:qe,onCameraLockChange:we}),c.jsx(ZE,{metrics:Z,onClose:()=>ee(null),screenCentroid:ce}),re&&c.jsxs("div",{className:"absolute z-30 pointer-events-none bg-slate-950/90 backdrop-blur-md border border-slate-700/60 rounded-lg px-2.5 py-2 text-[10px] font-mono text-slate-200 shadow-2xl min-w-[160px]",style:{left:re.x,top:re.y},children:[c.jsxs("div",{className:"font-bold text-slate-100 flex items-center justify-between border-b border-white/10 pb-1 mb-1",children:[c.jsxs("div",{className:"flex items-center space-x-1 truncate max-w-[110px]",children:[c.jsx("span",{className:`w-1.5 h-1.5 rounded-full ${re.isFiltered?"bg-red-400":"bg-emerald-400"}`}),c.jsx("span",{className:"truncate",children:re.tokenStr.trim()?`"${re.tokenStr}"`:`Token #${re.id}`})]}),c.jsx("span",{className:"text-[9px] text-cyan-300 font-mono bg-cyan-950/60 px-1 py-0.5 rounded border border-cyan-800/40",children:re.sector})]}),c.jsxs("div",{className:"space-y-0.5",children:[c.jsxs("div",{className:"flex justify-between text-[9px]",children:[c.jsx("span",{className:"text-slate-400",children:"Prob:"}),c.jsxs("span",{className:"text-blue-400 font-semibold",children:[(re.probability*100).toFixed(2),"%"]})]}),re.rank!==-1&&c.jsxs("div",{className:"flex justify-between text-[9px]",children:[c.jsx("span",{className:"text-slate-400",children:"Rank:"}),c.jsxs("span",{className:"text-slate-300",children:["#",re.rank]})]}),re.rawLogit!==-999&&c.jsxs("div",{className:"flex justify-between text-[9px]",children:[c.jsx("span",{className:"text-slate-400",children:"Logit:"}),c.jsx("span",{className:"text-slate-300",children:re.rawLogit.toFixed(2)})]}),re.isFiltered&&c.jsxs("div",{className:"flex justify-between text-[9px]",children:[c.jsx("span",{className:"text-red-400",children:"Status:"}),c.jsx("span",{className:"text-red-300 font-bold uppercase truncate max-w-[90px]",children:re.filterReason||"Filtered"})]}),re.isRag&&c.jsxs("div",{className:"text-[8px] text-slate-400 font-bold uppercase mt-0.5 flex items-center",children:[c.jsx("span",{className:"w-1 h-1 rounded-full bg-slate-400 mr-1"}),"RAG Grounded"]})]})]}),ut&&x.current!==-1&&c.jsxs("button",{type:"button",onClick:et=>{et.preventDefault(),et.stopPropagation(),wt()},className:"absolute bottom-4 left-4 bg-slate-900/80 hover:bg-slate-800 backdrop-blur text-slate-200 hover:text-white text-[10px] font-mono px-3 py-1.5 rounded-lg border border-slate-700/70 shadow-lg transition-colors z-20 flex items-center gap-1.5",children:[c.jsx("span",{className:"w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"}),c.jsx("span",{children:"[SPACE] Focus Target #1"})]}),c.jsx(XE,{cameraAngle:H.angle,cameraDistance:H.distance,cameraPos:H.pos,targetPos:H.target,activeToken:Q}),!ut&&c.jsx("div",{className:"absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm rounded-xl z-10",children:c.jsxs("div",{className:"flex flex-col items-center space-y-4",children:[c.jsx("div",{className:"w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"}),c.jsx("p",{className:"text-sm font-mono text-blue-400",children:"Loading Cartographic Topography..."})]})})]})},go={winner:"#10B981",rag_grounded:"#3B82F6",candidate:"#D946EF",filtered:"#EF4444",fringe:"#333338"},xo=({color:s,label:e})=>c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx("span",{className:"h-2 w-2 rounded-full",style:{backgroundColor:s}}),c.jsx("span",{className:"text-[10px] text-gray-400 font-mono",children:e})]}),Lc=({candidates:s,params:e,ragEnabled:t,onSelectToken:r,title:a="The Token Cosmos",subtitle:l="Probability Distribution View",steps:u=[],currentStepIndex:h=0,onSelectStep:p,onGenerateNextStep:f,onResetTimeline:g,isGenerating:b=!1,allCandidatesByStep:v,historyLength:S=0,modelId:M=null,latestLogits:E=null,isThinking:x=!1,isPlaying:_,onTogglePlay:N})=>{const[P,C]=K.useState(""),[k,D]=K.useState(!1),[U,T]=K.useState("log"),I=_!==void 0?_:k,z=()=>{N?N():D(!k)},O=K.useRef(null),[H,fe]=K.useState(!1),re=()=>{O.current&&(document.fullscreenElement?document.exitFullscreen&&document.exitFullscreen():O.current.requestFullscreen().catch(ee=>{console.error(`Error attempting to enable fullscreen: ${ee.message}`)}))};K.useEffect(()=>{const ee=()=>{fe(!!document.fullscreenElement)};return document.addEventListener("fullscreenchange",ee),()=>document.removeEventListener("fullscreenchange",ee)},[]);const q=K.useMemo(()=>{const ee=s.filter(F=>!F.isFiltered).map(F=>F.probability),ce=ee.reduce((F,Y)=>F+Y,0);return ce===0?0:-ee.reduce((F,Y)=>{if(Y<=0)return F;const Ce=Y/ce;return F+Ce*Math.log2(Ce)},0)},[s]),de=s[0],oe=s.filter(ee=>ee.is_rag_grounded).length,Z=K.useMemo(()=>u.map((ee,ce)=>{const F=v?.[ce];if(F&&F.length>0){const qe=D_(F);return Xm(ee.selectedToken,qe)}const Y=ee.selectedToken.probability,Ce=Y>.5?1:Y>.1?3:5;return Xm(ee.selectedToken,Ce)}),[u,v]);return K.useEffect(()=>{if(N||!I||u.length<=1||!p)return;const ee=setInterval(()=>{p((h+1)%u.length)},900);return()=>clearInterval(ee)},[I,h,u.length,p,N]),c.jsxs("div",{ref:O,className:"relative w-full h-full min-h-[480px] rounded-xl overflow-hidden bg-[#050714] flex flex-col",role:"region","aria-label":"Token Probability Distribution",tabIndex:0,children:[c.jsxs("div",{className:"flex items-center justify-between px-4 py-2.5 border-b border-white/5",children:[c.jsxs("div",{className:"flex items-center space-x-3",children:[c.jsx("span",{className:"h-2 w-2 rounded-full bg-blue-400 animate-pulse shadow-md"}),c.jsxs("div",{children:[c.jsx("h3",{className:"text-xs font-bold text-white tracking-tight",children:a}),c.jsx("p",{className:"text-[10px] text-blue-400/80 font-mono",children:l})]})]}),c.jsx("div",{className:"flex items-center space-x-2",children:c.jsxs("div",{className:"flex items-center space-x-1.5 bg-white/5 rounded-lg px-2 py-1",children:[c.jsx(Zh,{className:"h-3 w-3 text-slate-500"}),c.jsx("input",{type:"text",value:P,onChange:ee=>C(ee.target.value),placeholder:"Search tokens...",className:"bg-transparent text-xs text-white placeholder:text-gray-600 outline-none w-28 font-mono"})]})})]}),c.jsxs("div",{className:"flex items-center space-x-6 px-4 py-1.5 border-b border-white/5 text-[10px] font-mono text-gray-400",children:[c.jsxs("span",{children:[c.jsx(mg,{className:"inline h-3 w-3 text-blue-400 mr-1"}),"Top: ",c.jsx("strong",{className:"text-white",children:de?.token_str.trim()||"—"})," (",de?(de.probability*100).toFixed(1):0,"%)"]}),c.jsxs("span",{children:[c.jsx(cg,{className:"inline h-3 w-3 text-blue-400 mr-1"}),"Uncertainty: ",c.jsxs("strong",{className:"text-white",children:[q.toFixed(2)," bits"]})]}),c.jsxs("span",{children:[c.jsx(gc,{className:"inline h-3 w-3 text-blue-400 mr-1"}),"RAG: ",c.jsx("strong",{className:"text-white",children:t?`${oe} grounded`:"OFF"})]}),c.jsxs("span",{children:["Candidates: ",c.jsx("strong",{className:"text-white",children:s.filter(ee=>!ee.isFiltered).length})," / ",s.length]})]}),c.jsxs("div",{className:"flex-1 relative overflow-hidden",children:[c.jsx(lT,{modelId:M,latestLogits:E,params:e,ragTokenIds:t?s.filter(ee=>ee.is_rag_grounded).map(ee=>ee.token_id):[],isThinking:x,candidates:s,heightMode:U}),c.jsxs("div",{className:"absolute top-4 left-4 z-10 flex items-center space-x-2",children:[c.jsxs("div",{className:"flex bg-black/60 backdrop-blur-md rounded-lg border border-white/10 p-0.5 pointer-events-auto shadow-lg",children:[c.jsx("button",{onClick:()=>T("linear"),className:`px-2.5 py-1 text-[9px] font-mono font-bold rounded-md transition-all ${U==="linear"?"bg-blue-500/20 text-blue-300 border border-blue-500/30 shadow":"text-gray-400 hover:text-white hover:bg-white/5 border border-transparent"}`,children:"Standard View"}),c.jsx("button",{onClick:()=>T("log"),className:`px-2.5 py-1 text-[9px] font-mono font-bold rounded-md transition-all ${U==="log"?"bg-blue-500/20 text-blue-300 border border-blue-500/30 shadow":"text-gray-400 hover:text-white hover:bg-white/5 border border-transparent"}`,children:"Enhanced 3D"}),c.jsx("button",{onClick:()=>T("logit"),className:`px-2.5 py-1 text-[9px] font-mono font-bold rounded-md transition-all ${U==="logit"?"bg-blue-500/20 text-blue-300 border border-blue-500/30 shadow":"text-gray-400 hover:text-white hover:bg-white/5 border border-transparent"}`,children:"Raw Data"})]}),c.jsxs("button",{type:"button",onClick:re,title:H?"Exit Full Screen":"Go Full Screen",className:"flex items-center space-x-1 px-2 py-1 text-[9px] font-mono font-bold rounded-lg bg-black/60 hover:bg-black/80 backdrop-blur-md border border-white/10 text-gray-400 hover:text-white transition-all shadow-lg pointer-events-auto",children:[H?c.jsx(hg,{className:"h-3 w-3"}):c.jsx(x_,{className:"h-3 w-3"}),c.jsx("span",{children:H?"Exit Zen":"Zen Mode"})]})]}),c.jsxs("div",{className:"absolute top-4 right-4 w-64 bg-black/40 backdrop-blur-md rounded-lg border border-white/10 overflow-hidden pointer-events-none",children:[c.jsx("div",{className:"px-3 py-1.5 bg-white/5 border-b border-white/10",children:c.jsx("span",{className:"text-[10px] font-bold text-gray-300 uppercase tracking-wider",children:"Most Likely Next Words"})}),c.jsx("div",{className:"p-2 space-y-1",children:s.slice(0,10).map((ee,ce)=>{const F=Math.max(.3,1-ce*.07);return c.jsxs("div",{className:"flex items-center justify-between",style:{opacity:F},children:[c.jsx("span",{className:"text-[10px] font-mono text-slate-100 font-medium truncate mr-2",children:ee.token_str.trim()||"—"}),c.jsxs("span",{className:"text-[9px] font-mono text-slate-400",children:[(ee.probability*100).toFixed(1),"%"]})]},ce)})})]})]}),c.jsxs("div",{className:"flex items-center space-x-4 px-4 py-2 border-t border-white/5",children:[c.jsx(xo,{color:go.winner,label:"Winner"}),c.jsx(xo,{color:go.rag_grounded,label:"RAG Grounded"}),c.jsx(xo,{color:go.candidate,label:"Candidate"}),c.jsx(xo,{color:go.fringe,label:"Fringe"}),c.jsx(xo,{color:go.filtered,label:"Filtered"})]}),u.length>0&&p&&c.jsxs("div",{className:"border-t border-white/5 px-4 py-2 flex items-center space-x-3",children:[c.jsx("button",{onClick:z,className:"h-7 w-7 rounded-full bg-white/5 flex items-center justify-center text-gray-300 hover:text-blue-400 transition-colors",children:I?c.jsx(y_,{className:"h-3.5 w-3.5"}):c.jsx(Kh,{className:"h-3.5 w-3.5"})}),c.jsx("button",{onClick:()=>p(Math.max(0,h-1)),disabled:h===0,className:"text-gray-500 hover:text-white disabled:opacity-30 transition-colors",children:c.jsx(t_,{className:"h-4 w-4"})}),c.jsx("div",{className:"flex-1 flex items-center space-x-0.5 overflow-x-auto scrollbar-none",children:u.map((ee,ce)=>{const Y=Z[ce]?.perplexityColor||"#333";return c.jsx("button",{onClick:()=>p(ce),className:`flex-shrink-0 h-5 px-1.5 rounded text-[9px] font-mono transition-all ${ce===h?"ring-1 ring-blue-500 scale-110 text-white":"text-gray-500 hover:text-white"}`,style:{backgroundColor:Y},children:ee.selectedToken.token_str.trim().slice(0,6)},ce)})}),c.jsx("button",{onClick:()=>p(Math.min(u.length-1,h+1)),disabled:h===u.length-1,className:"text-gray-500 hover:text-white disabled:opacity-30 transition-colors",children:c.jsx(n_,{className:"h-4 w-4"})}),c.jsxs("span",{className:"text-[9px] text-gray-600 font-mono",children:[h+1,"/",u.length]})]})]})},cT=({leftCandidates:s,rightCandidates:e,leftParams:t,rightParams:r,leftTitle:a="Universe A (Primary Config)",leftSubtitle:l=`T = ${t.temperature.toFixed(2)} • Top-K = ${t.topK}`,rightTitle:u="Universe B (A/B Duel Config)",rightSubtitle:h=`T = ${r.temperature.toFixed(2)} • Top-K = ${r.topK}`,leftRagEnabled:p=!1,rightRagEnabled:f=!1,onSelectToken:g,onUpdateRightTemp:b,isByoeMode:v=!1,leftIsThinking:S=!1})=>{const M=K.useMemo(()=>{if(s.length===0||e.length===0)return null;const E=s[0],x=e[0],_=E?.token_str.trim()===x?.token_str.trim(),N=new Set(s.slice(0,5).map(U=>U.token_str.trim())),P=new Set(e.slice(0,5).map(U=>U.token_str.trim()));let C=0;N.forEach(U=>{P.has(U)&&C++});const k=Math.round(C/5*100),D=Math.abs((E?.probability||0)-(x?.probability||0));return{sameTop:_,topAStr:E?.token_str.trim()||"N/A",topBStr:x?.token_str.trim()||"N/A",probA:Math.round((E?.probability||0)*100),probB:Math.round((x?.probability||0)*100),overlapPct:k,probDiffPct:Math.round(D*100)}},[s,e]);return c.jsxs("div",{className:"w-full h-full min-h-[500px] flex flex-col space-y-3",children:[c.jsxs("div",{className:"flex items-center justify-between rounded-xl bg-slate-950/90 border border-purple-500/30 px-4 py-2 shadow-lg",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx(pg,{className:"h-4 w-4 text-purple-400 animate-pulse"}),c.jsx("span",{className:"text-xs font-bold text-slate-100",children:"A/B Probability Duel"}),c.jsx("span",{className:"rounded-full bg-purple-500/20 px-2 py-0.5 text-[10px] font-mono text-purple-300 border border-purple-500/30",children:v?"Frontier vs. Local BYOE":"Dual Temperature Experiment"})]}),M&&c.jsxs("div",{className:"flex items-center space-x-3 text-[11px] font-mono",children:[c.jsxs("div",{className:"flex items-center space-x-1",children:[c.jsx("span",{className:"text-slate-400",children:"Top Match:"}),M.sameTop?c.jsxs("span",{className:"text-emerald-400 font-bold",children:['Identical ("',M.topAStr,'")']}):c.jsxs("span",{className:"text-amber-400 font-bold",children:['Divergent ("',M.topAStr,'" vs "',M.topBStr,'")']})]}),c.jsxs("div",{className:"hidden sm:flex items-center space-x-1",children:[c.jsx("span",{className:"text-slate-400",children:"Top-5 Overlap:"}),c.jsxs("span",{className:"text-blue-300 font-bold",children:[M.overlapPct,"%"]})]})]})]}),c.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4 flex-1 min-h-[440px]",children:[c.jsx("div",{className:"relative w-full h-full border border-blue-500/30 rounded-2xl overflow-hidden shadow-md",children:c.jsx(Lc,{candidates:s,params:t,ragEnabled:p,onSelectToken:g,title:a,subtitle:l,isThinking:S})}),c.jsxs("div",{className:"relative w-full h-full border border-slate-800 rounded-2xl overflow-hidden shadow-md",children:[c.jsx(Lc,{candidates:e,params:r,ragEnabled:f,onSelectToken:g,title:u,subtitle:h}),!v&&b&&c.jsxs("div",{className:"absolute bottom-3 right-3 z-30 flex items-center space-x-2 rounded-xl bg-slate-950/90 border border-purple-500/40 px-3 py-1.5 backdrop-blur-md shadow-xl",children:[c.jsx(Kr,{className:"h-3.5 w-3.5 text-amber-400"}),c.jsx("span",{className:"text-[10px] font-bold text-slate-300",children:"Temp B:"}),c.jsx("input",{type:"range",min:"0.05",max:"2.0",step:"0.05",value:r.temperature,onChange:E=>b(parseFloat(E.target.value)),className:"w-20 h-1 appearance-none bg-slate-800 rounded-full accent-purple-500"}),c.jsx("span",{className:"text-[10px] font-mono font-bold text-purple-300 w-8 text-right",children:r.temperature.toFixed(2)})]})]})]})]})},uT=()=>c.jsxs("div",{className:"mx-auto max-w-5xl space-y-10 py-6 px-4 sm:px-6",children:[c.jsxs("div",{className:"glass-panel rounded-3xl p-8 border border-slate-800 shadow-2xl relative overflow-hidden",children:[c.jsx("div",{className:"absolute -right-20 -top-20 h-64 w-64 rounded-full bg-blue-500/5 blur-3xl"}),c.jsx("div",{className:"absolute -left-20 -bottom-20 h-64 w-64 rounded-full bg-slate-900/10 blur-3xl"}),c.jsxs("div",{className:"relative z-10 space-y-4 max-w-3xl",children:[c.jsxs("div",{className:"inline-flex items-center space-x-2 rounded-full bg-blue-500/10 px-3 py-1 text-xs font-semibold text-blue-300 border border-blue-500/20",children:[c.jsx(ug,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:"LLM Mechanics Deep Dive"})]}),c.jsx("h2",{className:"text-3xl sm:text-4xl font-extrabold text-slate-100 tracking-tight leading-tight bg-gradient-to-r from-slate-100 via-slate-200 to-blue-300 bg-clip-text text-transparent",children:"Demystifying LLM Sampling: How Parameters Shape AI Token Cosmos"}),c.jsxs("p",{className:"text-sm sm:text-base text-slate-300 leading-relaxed",children:["Large Language Models are not sentient reasoning engines—they are hyper-dimensional ",c.jsx("strong",{children:"next-token probability predictors"}),". Understanding how logits are sampled turns everyday AI prompts into precise, predictable tools."]})]})]}),c.jsxs("section",{className:"glass-panel rounded-2xl p-6 sm:p-8 space-y-4 border border-slate-800",children:[c.jsxs("h3",{className:"text-xl font-bold text-blue-300 flex items-center space-x-2",children:[c.jsx(yo,{className:"h-5 w-5 text-blue-400"}),c.jsx("span",{children:"1. The Visual Metaphor: Logits & Softmax"})]}),c.jsxs("p",{className:"text-sm text-slate-300 leading-relaxed",children:["At every step of text generation, the neural network evaluates its entire vocabulary (often 32,000 to 128,000 candidate tokens). It outputs an unnormalized vector of raw numbers called ",c.jsx("strong",{children:"logits ($z_i$)"}),"."]}),c.jsxs("div",{className:"rounded-xl bg-slate-950 p-4 border border-slate-800 font-mono text-xs text-slate-200 overflow-x-auto",children:[c.jsx("p",{className:"text-slate-400 mb-2",children:"// Softmax transformation converting unnormalized raw logits into normalized percentages:"}),c.jsx("p",{className:"text-amber-300",children:"P(x_i) = exp((z_i - z_max) / T) / Σ exp((z_j - z_max) / T)"})]}),c.jsx("p",{className:"text-sm text-slate-300 leading-relaxed",children:"High logits (>10) become glowing center supergiants in the Token Cosmos. Low logits (<0) form dim outer asteroid belts. The sampling parameters act as cosmic filters that shape which stars are eligible to be chosen."})]}),c.jsxs("section",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:[c.jsxs("div",{className:"glass-panel rounded-2xl p-6 border border-slate-800 space-y-3",children:[c.jsxs("div",{className:"flex items-center space-x-2 text-blue-400 font-bold",children:[c.jsx(Kr,{className:"h-5 w-5"}),c.jsx("h4",{children:"Temperature ($T$) — The Cosmic Heat"})]}),c.jsxs("p",{className:"text-xs text-slate-300 leading-relaxed",children:["Temperature scales logits prior to softmax. At ",c.jsx("strong",{children:"T = 0.1"}),", logits become sharp peaks, creating a deterministic, cold focus on top facts. At ",c.jsx("strong",{children:"T = 1.5"}),", probability mass flattens across candidate tokens, introducing wild creative entropy."]})]}),c.jsxs("div",{className:"glass-panel rounded-2xl p-6 border border-slate-800 space-y-3",children:[c.jsxs("div",{className:"flex items-center space-x-2 text-blue-400 font-bold",children:[c.jsx(ga,{className:"h-5 w-5"}),c.jsx("h4",{children:"Top-K & Top-P (Nucleus) Filtering"})]}),c.jsxs("p",{className:"text-xs text-slate-300 leading-relaxed",children:[c.jsx("strong",{children:"Top-K"})," truncates candidate tokens strictly by rank index $k$. ",c.jsx("strong",{children:"Top-P"})," (Nucleus sampling) dynamically selects the smallest candidate pool whose cumulative sum reaches percentage $p$ (e.g. 90%), adapting naturally to uncertain prompts."]})]})]}),c.jsxs("section",{className:"glass-panel rounded-2xl p-6 sm:p-8 space-y-6 border border-slate-800 shadow-2xl",children:[c.jsx("div",{className:"flex items-center justify-between",children:c.jsxs("div",{className:"space-y-1",children:[c.jsxs("h3",{className:"text-xl font-bold text-blue-300 flex items-center space-x-2",children:[c.jsx(Qh,{className:"h-5 w-5 text-blue-400"}),c.jsx("span",{children:"Power User Cheat Sheet: Troubleshooting Guide"})]}),c.jsx("p",{className:"text-xs text-slate-400",children:"Quick-reference lookup table mapping common daily AI prompts and failure modes to exact parameter adjustments."})]})}),c.jsx("div",{className:"overflow-x-auto rounded-xl border border-slate-800",children:c.jsxs("table",{className:"w-full text-left text-xs",children:[c.jsx("thead",{className:"bg-slate-950 text-slate-300 font-semibold uppercase tracking-wider border-b border-slate-800",children:c.jsxs("tr",{children:[c.jsx("th",{className:"px-4 py-3",children:"Common AI Frustration"}),c.jsx("th",{className:"px-4 py-3",children:"Root Cause"}),c.jsx("th",{className:"px-4 py-3",children:"Recommended Parameter Fix"}),c.jsx("th",{className:"px-4 py-3",children:"Expected Result"})]})}),c.jsxs("tbody",{className:"divide-y divide-slate-800/60 bg-slate-900/60 text-slate-300 font-mono",children:[c.jsxs("tr",{className:"hover:bg-slate-900/90 transition-colors",children:[c.jsx("td",{className:"px-4 py-3 font-semibold text-rose-300",children:'"Stop repeating words or looping"'}),c.jsx("td",{className:"px-4 py-3 text-slate-400",children:"Zero context penalty allowing tokens to re-occur infinitely"}),c.jsxs("td",{className:"px-4 py-3 text-blue-400",children:["Frequency Penalty: ",c.jsx("span",{className:"font-bold text-white",children:"0.5"}),c.jsx("br",{}),"Presence Penalty: ",c.jsx("span",{className:"font-bold text-white",children:"0.3"})]}),c.jsx("td",{className:"px-4 py-3 text-slate-300",children:"Penalizes previously seen tokens; forces vocabulary evolution."})]}),c.jsxs("tr",{className:"hover:bg-slate-900/90 transition-colors",children:[c.jsx("td",{className:"px-4 py-3 font-semibold text-amber-300",children:'"Stop hallucinating facts"'}),c.jsx("td",{className:"px-4 py-3 text-slate-400",children:"High temperature picking outer low-probability noise tokens"}),c.jsxs("td",{className:"px-4 py-3 text-blue-400",children:["RAG Fact Anchor: ",c.jsx("span",{className:"font-bold text-white",children:"ON"}),c.jsx("br",{}),"Temperature: ",c.jsx("span",{className:"font-bold text-white",children:"0.1"})," • Top-K: ",c.jsx("span",{className:"font-bold text-white",children:"5"})]}),c.jsx("td",{className:"px-4 py-3 text-slate-300",children:"Strictly anchors logits to retrieved factual context."})]}),c.jsxs("tr",{className:"hover:bg-slate-900/90 transition-colors",children:[c.jsx("td",{className:"px-4 py-3 font-semibold text-purple-300",children:`"Stop saying overuse words ('Delve')"`}),c.jsx("td",{className:"px-4 py-3 text-slate-400",children:"High baseline frequency logit bias in model weights"}),c.jsxs("td",{className:"px-4 py-3 text-blue-400",children:["Logit Bias: ",c.jsx("span",{className:"font-bold text-white font-mono",children:"'Delve': -100"})]}),c.jsx("td",{className:"px-4 py-3 text-slate-300",children:"Black-hole zeroing of logit mass; completely bans target token."})]}),c.jsxs("tr",{className:"hover:bg-slate-900/90 transition-colors",children:[c.jsx("td",{className:"px-4 py-3 font-semibold text-sky-300",children:'"Boost creative metaphors / stories"'}),c.jsx("td",{className:"px-4 py-3 text-slate-400",children:"Low temperature restricting choices to generic common paths"}),c.jsxs("td",{className:"px-4 py-3 text-blue-400",children:["Temperature: ",c.jsx("span",{className:"font-bold text-white",children:"1.3"}),c.jsx("br",{}),"Top-P: ",c.jsx("span",{className:"font-bold text-white",children:"0.95"})]}),c.jsx("td",{className:"px-4 py-3 text-slate-300",children:"Expands nucleus shield; unlocks surprising imaginative tokens."})]}),c.jsxs("tr",{className:"hover:bg-slate-900/90 transition-colors",children:[c.jsx("td",{className:"px-4 py-3 font-semibold text-emerald-300",children:'"Enforce technical domain terms"'}),c.jsx("td",{className:"px-4 py-3 text-slate-400",children:"Model preferring casual everyday synonyms over technical terms"}),c.jsxs("td",{className:"px-4 py-3 text-blue-400",children:["Logit Bias: ",c.jsx("span",{className:"font-bold text-white font-mono",children:"'quantum': +5.0"}),c.jsx("br",{}),"Min-P: ",c.jsx("span",{className:"font-bold text-white",children:"0.1"})]}),c.jsx("td",{className:"px-4 py-3 text-slate-300",children:"Magnetically pulls probability mass to specific technical terms."})]})]})]})})]})]}),dT=({params:s,setParams:e,prompt:t,setPrompt:r,ragContext:a,setRagContext:l,ragEnabled:u,setRagEnabled:h,topCandidateStr:p="Paris",topCandidateProb:f=.85,activeInteractionNotice:g=null})=>{const[b,v]=K.useState(!1),[S,M]=K.useState(""),[E,x]=K.useState(!1),[_,N]=K.useState(!0),[P,C]=K.useState(!1),[k,D]=K.useState({x:24,y:180}),[U,T]=K.useState(!1),I=K.useRef({x:0,y:0}),z=K.useRef({x:24,y:180}),O=K.useRef(null),[H,fe]=K.useState([{id:"welcome-1",sender:"navigator",text:"Greetings, Explorer! I am your free-floating Navigator guide. You can drag my console anywhere on the screen! Whenever you touch a slider, toggle a preset, or click any control, I will explain what it is, why it exists, and how it impacts AI probabilities.",timestamp:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}]);K.useEffect(()=>{const we=()=>{window.innerWidth<640&&!b&&D({x:window.innerWidth-60,y:window.innerHeight-60})};return we(),window.addEventListener("resize",we),()=>window.removeEventListener("resize",we)},[b]),K.useEffect(()=>{b&&window.innerWidth<640&&D({x:16,y:16})},[b]);const re=()=>{O.current?.scrollIntoView({behavior:"smooth"})};K.useEffect(()=>{b&&re()},[H,b]);const q=K.useCallback(we=>{if(_||typeof window>"u"||!("speechSynthesis"in window))return;window.speechSynthesis.cancel();const ie=new SpeechSynthesisUtterance(we),ve=window.speechSynthesis.getVoices().find(te=>te.name.includes("Google")||te.name.includes("Samantha")||te.name.includes("Zira")||te.name.includes("Natural")||te.lang.startsWith("en"));ve&&(ie.voice=ve),ie.rate=1,ie.pitch=1.1,ie.onstart=()=>C(!0),ie.onend=()=>C(!1),ie.onerror=()=>C(!1),window.speechSynthesis.speak(ie)},[_]);K.useEffect(()=>{_&&typeof window<"u"&&"speechSynthesis"in window&&(window.speechSynthesis.cancel(),C(!1))},[_]);const de=K.useRef(0);K.useEffect(()=>{if(!g||g.timestamp<=de.current)return;de.current=g.timestamp;const we=`${g.feature.toUpperCase()}

• WHAT IT IS: ${g.whatItIs}
• WHY IT EXISTS: ${g.whyItIs}
• HOW IT IMPACTS: ${g.impact}
• GUIDANCE: ${g.guidance}`,ie={id:`notice-${Date.now()}`,sender:"navigator",text:we,timestamp:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}),badge:g.feature};fe(ve=>[...ve,ie]);const xe=`${g.feature}. ${g.impact} ${g.guidance}`;q(xe)},[g,q]);const oe=we=>{T(!0),I.current={x:we.clientX,y:we.clientY},z.current={...k}};K.useEffect(()=>{const we=xe=>{if(!U)return;const ve=xe.clientX-I.current.x,te=xe.clientY-I.current.y,Se=b?Math.min(400,window.innerWidth-32):window.innerWidth<640?48:180,Qe=b?Math.min(540,window.innerHeight-32):48,Ft=Math.max(10,Math.min(window.innerWidth-Se-10,z.current.x+ve)),ut=Math.max(10,Math.min(window.innerHeight-Qe-10,z.current.y+te));D({x:Ft,y:ut})},ie=()=>{T(!1)};return U&&(window.addEventListener("mousemove",we),window.addEventListener("mouseup",ie)),()=>{window.removeEventListener("mousemove",we),window.removeEventListener("mouseup",ie)}},[U,b]);const Z=()=>({prompt:t,temperature:s.temperature,topK:s.topK,topP:s.topP,minP:s.minP,frequencyPenalty:s.frequencyPenalty,presencePenalty:s.presencePenalty,ragEnabled:u,logitBiases:s.logitBiases,topCandidateStr:p,topCandidateProb:`${(f*100).toFixed(1)}%`}),ee=we=>{const ie=we.toLowerCase(),xe=Z();return ie.includes("hallucinat")||ie.includes("heat")||ie.includes("wild")?{text:`Look at the canvas! At Temperature ${xe.temperature.toFixed(2)}, candidate probabilities flatten out. Low-probability outer asteroids glow brighter, causing the model to guess wildly. Lower Temperature to below 0.3 to restore factual focus!`,badge:"Heat Entropy Warning"}:ie.includes("truth")||ie.includes("fact")||ie.includes("rag")?{text:`When RAG Grounding is ${xe.ragEnabled?"ON":"OFF"}, retrieved factual context anchors logits. Grounded tokens get pulled to the center supergiant by cyan laser beams, forcing the LLM to stay tethered to facts!`,badge:"RAG Tether Active"}:ie.includes("ban")||ie.includes("delve")||ie.includes("black hole")||ie.includes("bias")?{text:"Applying a -100 Logit Bias creates a mathematical Black Hole! Target words implode into red cross icons on the outer fringe, making it impossible for the AI to select them.",badge:"Logit Bias Black Hole"}:ie.includes("repeat")||ie.includes("loop")||ie.includes("exhaust")?{text:`Frequency Penalty (${xe.frequencyPenalty.toFixed(2)}) acts as an Exhaustion Meter! Words that have already appeared in the sentence context physically dim in opacity, forcing the model to pick fresh vocabulary.`,badge:"Exhaustion Meter"}:{text:`You're currently evaluating prompt "${xe.prompt.slice(0,30)}..." with Temperature ${xe.temperature.toFixed(2)} and Top-K ${xe.topK}. The top predicted next token is "${xe.topCandidateStr}" (${xe.topCandidateProb}). Try adjusting the Cosmic Heat slider or toggling RAG to see how the starfield shifts!`,badge:"Cosmos State Analysis"}},ce=we=>{const ie=we||S.trim();if(!ie)return;const xe={id:`user-${Date.now()}`,sender:"user",text:ie,timestamp:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})};fe(ve=>[...ve,xe]),we||M(""),x(!0),setTimeout(()=>{const ve=ee(ie),te={id:`nav-${Date.now()}`,sender:"navigator",text:ve.text,timestamp:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}),badge:ve.badge};fe(Se=>[...Se,te]),x(!1),q(ve.text)},400)},F=()=>{e(we=>({...we,temperature:2,topK:50})),h(!1),ce("Show me how an AI hallucinates!")},Y=()=>{e(we=>({...we,temperature:.1,topK:5})),h(!0),a.trim()||l("Paris is the capital of France. The Eiffel Tower is located on the Champ de Mars in Paris."),ce("How do I force the AI to tell the truth?")},Ce=()=>{e(we=>({...we,logitBiases:{...we.logitBiases,delve:-100,delves:-100}})),ce('How do I ban annoying buzzwords like "delve"?')},qe=()=>{e(we=>({...we,frequencyPenalty:1.2,presencePenalty:.5})),ce("How do I fix repetitive text and looping?")};return c.jsx("div",{style:{position:"fixed",left:`${k.x}px`,top:`${k.y}px`,zIndex:50},className:"font-sans select-none",children:b?c.jsxs("div",{className:"flex h-[calc(100vh-32px)] w-[calc(100vw-32px)] max-h-[540px] flex-col overflow-hidden rounded-xl border border-white/10 bg-[#0A0A0A] shadow-2xl sm:h-[540px] sm:w-[400px]",children:[c.jsxs("div",{onMouseDown:oe,className:"flex items-center justify-between border-b border-slate-800 bg-slate-950 px-4 py-3 cursor-grab active:cursor-grabbing select-none",children:[c.jsxs("div",{className:"flex items-center space-x-2.5",children:[c.jsx(Gm,{className:"h-4 w-4 text-slate-500"}),c.jsx("div",{className:`relative flex h-8 w-8 items-center justify-center rounded-xl bg-blue-600 p-0.5 ${P?"shadow-md ring-2 ring-blue-500":""}`,children:c.jsx("div",{className:"flex h-full w-full items-center justify-center rounded-[10px] bg-slate-950",children:c.jsx(xc,{className:"h-4 w-4 text-blue-400"})})}),c.jsxs("div",{children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx("h3",{className:"text-sm font-bold text-slate-100",children:"The Navigator"}),P&&c.jsxs("span",{className:"flex items-center space-x-1 rounded-full bg-blue-500/10 px-2 py-0.5 text-[9px] font-mono font-bold text-blue-300 border border-blue-500/20",children:[c.jsx(Qv,{className:"h-3 w-3 animate-pulse text-blue-400"}),c.jsx("span",{children:"Speaking"})]})]}),c.jsxs("p",{className:"text-[10px] text-blue-400 font-mono flex items-center space-x-1",children:[c.jsx("span",{className:"h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"}),c.jsx("span",{children:"Free-Floating Mobility • Real-time AI"})]})]})]}),c.jsxs("div",{className:"flex items-center space-x-1",children:[c.jsx("button",{onClick:()=>N(!_),"aria-label":_?"Unmute Web Speech API voice assistant":"Mute voice assistant",className:`p-1.5 rounded-lg transition-colors ${_?"bg-slate-900 text-slate-400 border border-slate-800 hover:text-white":"bg-blue-500/10 text-blue-300 border border-blue-500/30 shadow-md"}`,title:_?"Unmute Voice Assistant (Web Speech API)":"Mute Voice Assistant",children:_?c.jsx(P_,{className:"h-4 w-4 text-slate-500"}):c.jsx(R_,{className:"h-4 w-4 text-blue-400 animate-pulse"})}),c.jsx("button",{onClick:()=>v(!1),"aria-label":"Minimize The Navigator guide",className:"p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800",children:c.jsx(hg,{className:"h-4 w-4"})})]})]}),c.jsxs("div",{className:"flex items-center justify-between bg-slate-900/90 px-4 py-1.5 border-b border-slate-800 text-[10px] font-mono text-slate-300",children:[c.jsxs("span",{children:["Temp: ",c.jsx("strong",{className:"text-blue-400",children:s.temperature.toFixed(2)})]}),c.jsxs("span",{children:["Top-K: ",c.jsx("strong",{className:"text-blue-400",children:s.topK})]}),c.jsxs("span",{children:["RAG: ",c.jsx("strong",{className:u?"text-blue-400":"text-slate-400",children:u?"ON":"OFF"})]}),c.jsxs("span",{children:["Voice: ",c.jsx("strong",{className:_?"text-slate-500":"text-blue-300",children:_?"MUTED":"ON"})]})]}),c.jsxs("div",{className:"flex-1 overflow-y-auto p-4 space-y-3.5 bg-slate-950/40 select-text",children:[H.map(we=>c.jsxs("div",{className:`flex flex-col ${we.sender==="user"?"items-end":"items-start"}`,children:[we.badge&&c.jsx("span",{className:"mb-1 rounded-full bg-blue-500/10 px-2 py-0.5 text-[9px] font-mono font-bold text-blue-300 border border-blue-500/20",children:we.badge}),c.jsx("div",{className:`max-w-[90%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed whitespace-pre-wrap ${we.sender==="user"?"bg-blue-600 text-white font-medium rounded-br-none":"bg-slate-900/90 border border-slate-800 text-slate-200 rounded-bl-none shadow-md"}`,children:we.text}),c.jsx("span",{className:"mt-1 text-[9px] font-mono text-slate-500 px-1",children:we.timestamp})]},we.id)),E&&c.jsxs("div",{className:"flex items-center space-x-1.5 bg-slate-900 border border-slate-800 p-2 rounded-2xl rounded-bl-none w-16",children:[c.jsx("span",{className:"h-1.5 w-1.5 rounded-full bg-blue-400 animate-bounce"}),c.jsx("span",{className:"h-1.5 w-1.5 rounded-full bg-blue-400 animate-bounce delay-100"}),c.jsx("span",{className:"h-1.5 w-1.5 rounded-full bg-blue-400 animate-bounce delay-200"})]}),c.jsx("div",{ref:O})]}),c.jsxs("div",{className:"border-t border-slate-800 bg-slate-950/80 p-2 space-y-1.5",children:[c.jsx("span",{className:"block text-[10px] font-bold uppercase tracking-wider text-blue-400 px-1",children:"Interactive Tour Stops (Action Callbacks)"}),c.jsxs("div",{className:"flex flex-wrap gap-1",children:[c.jsxs("button",{onClick:F,"aria-label":"Tour Stop: Show me how an AI hallucinates",className:"flex items-center space-x-1 rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-[10px] text-slate-300 hover:bg-slate-800 transition-colors",children:[c.jsx(Kr,{className:"h-3 w-3 text-slate-400"}),c.jsx("span",{children:"1. Hallucination Demo"})]}),c.jsxs("button",{onClick:Y,"aria-label":"Tour Stop: Force AI to tell the truth with RAG",className:"flex items-center space-x-1 rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-[10px] text-slate-300 hover:bg-slate-800 transition-colors",children:[c.jsx(gc,{className:"h-3 w-3 text-slate-400"}),c.jsx("span",{children:"2. RAG Fact Anchor"})]}),c.jsxs("button",{onClick:Ce,"aria-label":"Tour Stop: Ban annoying words with Black Hole Logit Bias",className:"flex items-center space-x-1 rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-[10px] text-slate-300 hover:bg-slate-800 transition-colors",children:[c.jsx(Jv,{className:"h-3 w-3 text-slate-400"}),c.jsx("span",{children:"3. Black Hole Ban"})]}),c.jsxs("button",{onClick:qe,"aria-label":"Tour Stop: Fix word repetition with Exhaustion Meter",className:"flex items-center space-x-1 rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-[10px] text-slate-300 hover:bg-slate-800 transition-colors",children:[c.jsx(E_,{className:"h-3 w-3 text-slate-400"}),c.jsx("span",{children:"4. Fix Repetition"})]})]})]}),c.jsxs("div",{className:"flex items-center space-x-2 border-t border-slate-800 bg-slate-950 p-3 select-text",children:[c.jsx("input",{type:"text","aria-label":"Ask The Navigator guide a question",value:S,onChange:we=>M(we.target.value),onKeyDown:we=>we.key==="Enter"&&ce(),placeholder:"Ask The Navigator about the dashboard...",className:"flex-1 rounded-xl bg-slate-900 border border-slate-800 px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:border-blue-500 focus:outline-none"}),c.jsx("button",{onClick:()=>ce(),"aria-label":"Send message to The Navigator",className:"rounded-xl bg-blue-600 p-2 text-white font-bold hover:bg-blue-700 transition-colors",children:c.jsx(S_,{className:"h-3.5 w-3.5"})})]})]}):c.jsxs("button",{onClick:()=>v(!0),onMouseDown:oe,"aria-label":"Open The Navigator Tourist Guide Chatbot (Draggable)",className:"group flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-[#0A0A0A] p-0 shadow-lg transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] hover:-translate-y-[1px] hover:border-white/20 transform-gpu cursor-grab active:cursor-grabbing sm:h-auto sm:w-auto sm:justify-start sm:space-x-2 sm:rounded-xl sm:px-3.5 sm:py-2",children:[c.jsx(Gm,{className:"hidden h-3.5 w-3.5 text-gray-400 opacity-60 group-hover:opacity-100 sm:block"}),c.jsx("div",{className:"flex h-6 w-6 items-center justify-center rounded-lg bg-white/10 text-white border border-white/20",children:c.jsx(xc,{className:"h-3.5 w-3.5"})}),c.jsxs("div",{className:"hidden text-left sm:block",children:[c.jsx("span",{className:"block text-xs font-bold text-white tracking-tight group-hover:text-gray-200",children:"The Navigator"}),c.jsx("span",{className:"block text-[10px] text-gray-400 font-mono",children:P?"🔊 Speaking...":"Draggable Guide"})]})]})})},hT=({isOpen:s,onClose:e,onSave:t,provider:r,customUrl:a,customApiKey:l,modelName:u})=>{const[h,p]=K.useState(r),[f,g]=K.useState(a),[b,v]=K.useState(l),[S,M]=K.useState(u),[E,x]=K.useState(!1);if(K.useEffect(()=>{p(r),g(a),v(l),M(u)},[r,a,l,u,s]),!s)return null;const _=C=>{p(C),C==="openai"?(g("https://api.openai.com/v1"),S||M("gpt-4o")):C==="custom"&&!f?(g("http://localhost:1234/v1"),S||M("local-model")):C==="default"&&(g(""),v(""),M("Cloud Run candidate demo"))},N=()=>{t(h,f.trim(),b.trim(),S.trim()),x(!0),setTimeout(()=>{x(!1),e()},800)},P=()=>{p("default"),g(""),v(""),M("Cloud Run candidate demo"),t("default","","","Cloud Run candidate demo"),x(!0),setTimeout(()=>{x(!1),e()},800)};return c.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-200",children:c.jsxs("div",{className:"w-full max-w-md rounded-2xl glass-panel border border-slate-800 shadow-2xl p-6 space-y-5 bg-slate-950/90",children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-slate-800 pb-3",children:[c.jsxs("div",{className:"flex items-center space-x-2.5",children:[c.jsx("div",{className:"flex h-9 w-9 items-center justify-center rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20",children:c.jsx(fg,{className:"h-5 w-5 animate-spin-slow"})}),c.jsxs("div",{children:[c.jsx("h3",{className:"text-base font-bold text-slate-100",children:"Engine Configuration (BYOE)"}),c.jsx("p",{className:"text-xs text-slate-400",children:"Bring Your Own API Key or Local Engine"})]})]}),c.jsx("button",{onClick:e,"aria-label":"Close settings modal",className:"p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800",children:c.jsx(_c,{className:"h-4 w-4"})})]}),c.jsxs("div",{className:"flex items-start space-x-2.5 rounded-xl bg-slate-900 p-3 border border-slate-800 text-xs text-slate-300",children:[c.jsx(Qh,{className:"h-4 w-4 text-slate-400 shrink-0 mt-0.5"}),c.jsxs("p",{className:"leading-relaxed",children:["API Keys and Custom URLs are stored ",c.jsx("strong",{children:"100% locally in your browser (localStorage)"}),". They bypass our backend and are never sent to our servers."]})]}),c.jsxs("div",{className:"space-y-4",children:[c.jsxs("div",{children:[c.jsxs("label",{htmlFor:"provider-select",className:"block text-xs font-semibold text-slate-200 mb-1.5 flex items-center space-x-1.5",children:[c.jsx(dg,{className:"h-3.5 w-3.5 text-blue-400"}),c.jsx("span",{children:"Select AI Provider Engine"})]}),c.jsxs("select",{id:"provider-select","aria-label":"Select AI Provider Engine",value:h,onChange:C=>_(C.target.value),className:"w-full rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-slate-200 font-semibold focus:border-blue-500 focus:outline-none",children:[c.jsx("option",{value:"default",children:"Default (Cloud Run candidate demo)"}),c.jsx("option",{value:"openai",children:"OpenAI (GPT-4o / GPT-3.5)"}),c.jsx("option",{value:"custom",children:"Custom / Local (vLLM / LM Studio / Ollama)"})]})]}),h!=="default"&&c.jsxs("div",{children:[c.jsx("label",{htmlFor:"model-name-input",className:"block text-xs font-semibold text-slate-200 mb-1.5",children:"Model Name String"}),c.jsx("input",{id:"model-name-input",type:"text","aria-label":"Model Name String",value:S,onChange:C=>M(C.target.value),placeholder:"e.g. gpt-4o, gemini-1.5-pro, local-model",className:"w-full rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:border-blue-500 focus:outline-none font-mono"})]}),(h==="custom"||h==="openai")&&c.jsxs("div",{children:[c.jsxs("label",{htmlFor:"custom-url-input",className:"block text-xs font-semibold text-slate-200 mb-1.5 flex items-center space-x-1.5",children:[c.jsx(M_,{className:"h-3.5 w-3.5 text-blue-400"}),c.jsx("span",{children:"Base API Endpoint URL"})]}),c.jsx("input",{id:"custom-url-input",type:"text","aria-label":"Base API Endpoint URL",value:f,onChange:C=>g(C.target.value),placeholder:"e.g. https://api.openai.com/v1 or http://localhost:1234/v1",className:"w-full rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:border-blue-500 focus:outline-none font-mono"}),c.jsxs("p",{className:"text-[11px] text-slate-400 mt-1",children:["Must support ",c.jsx("code",{className:"font-mono text-blue-400",children:"logprobs: true"})," to render token probability distribution."]})]}),h!=="default"&&c.jsxs("div",{children:[c.jsxs("label",{htmlFor:"custom-key-input",className:"block text-xs font-semibold text-slate-200 mb-1.5 flex items-center space-x-1.5",children:[c.jsx(p_,{className:"h-3.5 w-3.5 text-blue-400"}),c.jsx("span",{children:"API Key (Stored in local browser storage)"})]}),c.jsx("input",{id:"custom-key-input",type:"password","aria-label":"Custom API Key",value:b,onChange:C=>v(C.target.value),placeholder:"sk-...",className:"w-full rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:border-blue-500 focus:outline-none font-mono"})]})]}),c.jsxs("div",{className:"flex items-center justify-between pt-2 border-t border-slate-800",children:[c.jsxs("button",{onClick:P,type:"button","aria-label":"Reset engine configuration to default Cloud Run server",className:"flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-medium text-slate-400 hover:text-white hover:border-slate-700",children:[c.jsx(b_,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:"Reset Default"})]}),c.jsx("button",{onClick:N,type:"button","aria-label":"Save engine configuration",className:"flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-xs font-bold text-white shadow-md transition-colors",children:E?c.jsxs(c.Fragment,{children:[c.jsx(r_,{className:"h-4 w-4 text-emerald-300"}),c.jsx("span",{children:"Saved!"})]}):c.jsx("span",{children:"Save Configuration"})})]})]})})},fT=({isOpen:s,onClose:e,params:t,prompt:r,systemPrompt:a,ragContext:l,ragEnabled:u,modelName:h,provider:p,isReasoningModel:f=!1})=>{const[g,b]=K.useState("openai"),[v,S]=K.useState(!1);if(!s)return null;const E=`# Production OpenAI Python SDK Setup
# Generated by "The Token Cosmos"

from openai import OpenAI

client = OpenAI()

response = client.chat.completions.create(
    model="${f?"o3-mini":h||"gpt-4o"}",
    messages=[
${a.trim()?`        {"role": "system", "content": "${a.replace(/"/g,'\\"')}"},
`:""}${u&&l.trim()?`        {"role": "user", "content": "Retrieved Context: ${l.replace(/"/g,'\\"')}\\n\\nQuestion: ${r.replace(/"/g,'\\"')}"}`:`        {"role": "user", "content": "${r.replace(/"/g,'\\"')}"}`}
    ],
${f?`    max_completion_tokens=${t.maxThinkingTokens||2048}, # Acts as thinking budget + output`:`    temperature=${t.temperature},
    top_p=${t.topP},
    frequency_penalty=${t.frequencyPenalty},
    presence_penalty=${t.presencePenalty},
${t.stopSequences.length>0?`    stop=${JSON.stringify(t.stopSequences)},
`:""}${Object.keys(t.logitBiases).length>0?`    logit_bias=${JSON.stringify(t.logitBiases)},
`:""}    logprobs=True,
    top_logprobs=20,`}
)

print(response.choices[0].message.content)
`,x=`# Production Anthropic Python SDK Setup
# Generated by "The Token Cosmos"

import anthropic

client = anthropic.Anthropic()

response = client.messages.create(
    model="${f?"claude-3-7-sonnet-20250219":"claude-3-5-sonnet-20241022"}",
    max_tokens=${f?2e4:4096},
${a.trim()?`    system="${a.replace(/"/g,'\\"')}",
`:""}${f?`    thinking={
        "type": "enabled",
        "budget_tokens": ${t.maxThinkingTokens||2048}
    },
`:`    temperature=${t.temperature},
`}    messages=[
${u&&l.trim()?`        {"role": "user", "content": "Context: ${l.replace(/"/g,'\\"')}\\n\\nQuestion: ${r.replace(/"/g,'\\"')}"}`:`        {"role": "user", "content": "${r.replace(/"/g,'\\"')}"}`}
    ]
)

print(response.content[0].text)
`,_=`# Production Gemini Python SDK Setup
# Generated by "The Token Cosmos"

from google import genai
from google.genai import types

client = genai.Client()

${u&&l.trim()?`prompt_text = "Context: ${l.replace(/"/g,'\\"')}\\n\\nQuestion: ${r.replace(/"/g,'\\"')}"`:`prompt_text = "${r.replace(/"/g,'\\"')}"`}

response = client.models.generate_content(
    model='${f?"gemini-2.5-pro":"gemini-2.5-flash"}',
    contents=prompt_text,
    config=types.GenerateContentConfig(
${a.trim()?`        system_instruction="${a.replace(/"/g,'\\"')}",
`:""}${f?`        thinking_config=types.ThinkingConfig(
            thinking_budget_tokens=${t.maxThinkingTokens||2048}
        ),`:`        temperature=${t.temperature},
        top_p=${t.topP},
        top_k=${t.topK},`}
    )
)

print(response.text)
`,N=()=>{switch(g){case"openai":return E;case"anthropic":return x;case"gemini":return _}},P=()=>{navigator.clipboard.writeText(N()),S(!0),setTimeout(()=>S(!1),2e3)};return c.jsx("div",{className:"w-full h-full flex items-start justify-center animate-in fade-in duration-200 select-text",children:c.jsxs("div",{className:"w-full max-w-3xl rounded-2xl border border-slate-800 bg-[#15151a] p-6 shadow-2xl space-y-4",children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-slate-800 pb-3",children:[c.jsxs("div",{className:"flex items-center space-x-2.5",children:[c.jsx("div",{className:"flex h-8 w-8 items-center justify-center rounded-xl bg-blue-600 p-0.5 shadow-md",children:c.jsx("div",{className:"flex h-full w-full items-center justify-center rounded-[10px] bg-slate-950",children:c.jsx($h,{className:"h-4 w-4 text-blue-400"})})}),c.jsxs("div",{children:[c.jsx("h3",{className:"text-base font-bold text-slate-100",children:"Export Production Sampling Code"}),c.jsx("p",{className:"text-xs text-slate-400 font-mono",children:"1-click runnable snippets matching your visualizer setup"})]})]}),c.jsx("button",{onClick:e,className:"rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white",children:c.jsx(_c,{className:"h-4 w-4"})})]}),c.jsxs("div",{className:"flex items-center justify-between",children:[c.jsxs("div",{className:"flex rounded-lg bg-slate-900 p-1 border border-slate-800 font-mono text-xs",children:[c.jsxs("button",{onClick:()=>b("openai"),className:`flex items-center space-x-1.5 rounded-md px-3 py-1 font-bold transition-all ${g==="openai"?"bg-blue-600 text-white shadow-md":"text-slate-400 hover:text-slate-200"}`,children:[c.jsx(c_,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:"OpenAI API"})]}),c.jsxs("button",{onClick:()=>b("anthropic"),className:`flex items-center space-x-1.5 rounded-md px-3 py-1 font-bold transition-all ${g==="anthropic"?"bg-blue-600 text-white shadow-md":"text-slate-400 hover:text-slate-200"}`,children:[c.jsx(m_,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:"Anthropic API"})]}),c.jsxs("button",{onClick:()=>b("gemini"),className:`flex items-center space-x-1.5 rounded-md px-3 py-1 font-bold transition-all ${g==="gemini"?"bg-blue-600 text-white shadow-md":"text-slate-400 hover:text-slate-200"}`,children:[c.jsx(A_,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:"Gemini API"})]})]}),c.jsxs("button",{onClick:P,className:"flex items-center space-x-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 px-3 py-1.5 text-xs font-bold text-white shadow-md transition-colors",children:[v?c.jsx(qh,{className:"h-3.5 w-3.5 text-emerald-300"}):c.jsx(o_,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:v?"Copied to Clipboard!":"Copy Snippet"})]})]}),c.jsx("div",{className:"relative rounded-xl bg-slate-900/90 border border-slate-800 p-4 max-h-[340px] overflow-y-auto font-mono text-xs leading-relaxed text-slate-200",children:c.jsx("pre",{children:N()})})]})})},pT=({state:s,isWebGPUAvailable:e,availableModels:t,onSelectModel:r})=>s.status==="ready"&&s.modelId||s.status==="generating"?null:c.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-[#050714]/90 backdrop-blur-lg",children:c.jsxs("div",{className:"w-full max-w-md mx-4",children:[c.jsxs("div",{className:"text-center mb-6",children:[c.jsx("div",{className:"inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-500/10 border border-blue-500/30 mb-4",children:c.jsx(dg,{className:"w-8 h-8 text-blue-400"})}),c.jsx("h2",{className:"text-xl font-bold text-white tracking-tight",children:"WebGPU Inference Engine"}),c.jsx("p",{className:"text-sm text-gray-400 mt-1 font-mono",children:"In-browser LLM for full logit extraction"})]}),e?c.jsxs(c.Fragment,{children:[(s.status==="downloading"||s.status==="loading")&&c.jsxs("div",{className:"rounded-xl bg-white/5 border border-white/10 p-5 mb-4",children:[c.jsxs("div",{className:"flex items-center space-x-3 mb-3",children:[s.status==="downloading"?c.jsx(l_,{className:"w-5 h-5 text-blue-400 animate-bounce"}):c.jsx(vc,{className:"w-5 h-5 text-blue-400 animate-spin"}),c.jsx("span",{className:"text-sm text-white font-mono",children:s.progressText})]}),c.jsx("div",{className:"w-full h-2 bg-gray-800 rounded-full overflow-hidden",children:c.jsx("div",{className:"h-full bg-blue-600 rounded-full transition-all duration-300 ease-out",style:{width:`${s.progress}%`}})}),c.jsxs("div",{className:"flex justify-between mt-2",children:[c.jsx("span",{className:"text-[10px] text-gray-500 font-mono",children:s.status==="downloading"?"Downloading weights":"Initializing WebGPU"}),c.jsxs("span",{className:"text-[10px] text-blue-400 font-mono font-bold",children:[s.progress,"%"]})]})]}),s.status==="error"&&c.jsx("div",{className:"rounded-xl bg-red-500/10 border border-red-500/30 p-4 mb-4",children:c.jsxs("div",{className:"flex items-start space-x-3",children:[c.jsx(Jd,{className:"w-5 h-5 text-red-400 mt-0.5 flex-shrink-0"}),c.jsxs("div",{children:[c.jsx("p",{className:"text-sm font-semibold text-red-300",children:"Engine Error"}),c.jsx("p",{className:"text-xs text-red-200/70 mt-1 font-mono break-all",children:s.error})]})]})}),(s.status==="idle"||s.status==="error")&&e&&c.jsxs("div",{className:"space-y-2",children:[c.jsx("p",{className:"text-xs text-gray-500 uppercase tracking-wider font-mono mb-3 text-center",children:"Select a model to load"}),t.map(a=>c.jsx("button",{onClick:()=>r(a.id),className:"w-full rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-blue-500/30 p-4 text-left transition-all duration-200 group",children:c.jsxs("div",{className:"flex items-center justify-between",children:[c.jsxs("div",{children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx("span",{className:"text-sm font-bold text-white group-hover:text-blue-400 transition-colors",children:a.label}),c.jsx("span",{className:"text-[9px] px-1.5 py-0.5 rounded-full font-mono font-bold uppercase tracking-wider bg-slate-800 text-slate-300 border border-slate-700",children:a.tier})]}),c.jsx("p",{className:"text-xs text-gray-500 mt-1",children:a.description})]}),c.jsxs("div",{className:"text-right flex-shrink-0",children:[c.jsx("div",{className:"text-xs text-gray-400 font-mono",children:a.size}),c.jsxs("div",{className:"text-[9px] text-gray-600 font-mono",children:[a.vocabSize.toLocaleString()," tokens"]})]})]})},a.id))]}),c.jsxs("div",{className:"mt-4 text-center",children:[c.jsx("button",{onClick:()=>r("__CLOUD_API__"),className:"text-xs text-gray-500 hover:text-gray-300 transition-colors font-mono underline underline-offset-4",children:"Continue with Cloud Run candidate API"}),c.jsx("button",{onClick:()=>r("__SAMPLE_DATA__"),className:"mt-2 block w-full text-xs text-gray-600 hover:text-gray-300 transition-colors font-mono underline underline-offset-4",children:"Use generated sample data instead"})]})]}):c.jsx("div",{className:"rounded-xl bg-red-500/10 border border-red-500/30 p-4 mb-4",children:c.jsxs("div",{className:"flex items-start space-x-3",children:[c.jsx(Jd,{className:"w-5 h-5 text-red-400 mt-0.5 flex-shrink-0"}),c.jsxs("div",{children:[c.jsx("p",{className:"text-sm font-semibold text-red-300",children:"WebGPU Unsupported"}),c.jsx("p",{className:"text-xs text-red-200/70 mt-1",children:"Your browser or device does not support WebGPU, which is strictly required for The Token Cosmos 3D Engine."}),c.jsx("a",{href:"https://caniuse.com/webgpu",target:"_blank",rel:"noreferrer",className:"inline-block mt-3 px-3 py-1 bg-red-500/20 text-red-300 text-[10px] rounded hover:bg-red-500/40 transition-colors",children:"Check Browser Requirements →"})]})]})})]})});function mT({params:s,setParams:e,prompt:t,setPrompt:r,systemPrompt:a,setSystemPrompt:l,ragContext:u,setRagContext:h,ragEnabled:p,setRagEnabled:f}){const g=K.useRef(!0);return K.useEffect(()=>{if(typeof window>"u")return;if(g.current){g.current=!1;return}const v=new URLSearchParams;s.temperature!==.7&&v.set("temp",s.temperature.toString()),s.topK!==40&&v.set("topk",s.topK.toString()),s.topP!==.9&&v.set("topp",s.topP.toString()),s.minP!==.02&&v.set("minp",s.minP.toString()),s.frequencyPenalty!==.1&&v.set("freq",s.frequencyPenalty.toString()),s.presencePenalty!==.1&&v.set("pres",s.presencePenalty.toString()),v.set("rag",p?"1":"0"),a.trim()&&v.set("sys",a.trim()),t.trim()&&v.set("prompt",t.trim()),u.trim()&&v.set("ragctx",u.trim());const S=`${window.location.pathname}?${v.toString()}${window.location.hash}`;window.history.replaceState(null,"",S)},[s,t,a,u,p]),K.useEffect(()=>{if(typeof window>"u")return;const v=new URLSearchParams(window.location.search),S=v.get("temp"),M=v.get("topk"),E=v.get("topp"),x=v.get("minp"),_=v.get("freq"),N=v.get("pres"),P=v.get("rag"),C=v.get("sys"),k=v.get("prompt"),D=v.get("ragctx");(S||M||E||x||_||N)&&e(U=>({...U,temperature:S?parseFloat(S):U.temperature,topK:M?parseInt(M,10):U.topK,topP:E?parseFloat(E):U.topP,minP:x?parseFloat(x):U.minP,frequencyPenalty:_?parseFloat(_):U.frequencyPenalty,presencePenalty:N?parseFloat(N):U.presencePenalty})),P!==null&&f(P==="1"),C&&l(C),k&&r(k),D&&h(D)},[]),{copySetupLink:K.useCallback(()=>{typeof window>"u"||navigator.clipboard.writeText(window.location.href)},[])}}const gT=[{id:"SmolLM2-135M-Instruct-q4f16_1-MLC",label:"SmolLM2 135M (q4f16)",size:"~180MB",vocabSize:49152,description:"Ultra-light local model for compatible WebGPU devices.",tier:"light"},{id:"SmolLM2-135M-Instruct-q0f16-MLC",label:"SmolLM2 135M (q0f16)",size:"~360MB",vocabSize:49152,description:"Ultra-light unquantized float16 variant from WebLLM catalog.",tier:"light"},{id:"Qwen2.5-0.5B-Instruct-q4f16_1-MLC",label:"Qwen2.5 0.5B",size:"~500MB",vocabSize:151936,description:"Deeper reasoning, larger vocabulary. Requires ~1GB VRAM.",tier:"standard"},{id:"Qwen2.5-1.5B-Instruct-q4f16_1-MLC",label:"Qwen2.5 1.5B",size:"~1.2GB",vocabSize:151936,description:"High-quality inference. Requires ~2GB VRAM.",tier:"power"}];function xT(){return typeof navigator>"u"?!1:"gpu"in navigator}function vT(){const s=K.useRef(null),e=K.useRef(xT()),[t,r]=K.useState({status:"idle",progress:0,progressText:"No model loaded",vramUsageMB:null,modelId:null,vocabSize:null,error:null}),[a,l]=K.useState(null),[u,h]=K.useState(null),[p,f]=K.useState([]),[g,b]=K.useState([]),[v,S]=K.useState(!1),[M,E]=K.useState(null),x=K.useRef(null);K.useEffect(()=>{if(!e.current){r(z=>({...z,status:"idle",progressText:"WebGPU not available — using sample data"}));return}const I=new Worker(new URL("/assets/WebGPUInferenceWorker-CAwLZvkD.js",import.meta.url),{type:"module"});return I.onmessage=z=>{const O=z.data;switch(O.type){case"STATUS":r(H=>({...H,status:O.status,progress:O.progress,progressText:O.text,error:O.status==="error"?O.text:H.error}));break;case"MODEL_LOADED":r(H=>({...H,status:"ready",modelId:O.modelId,vocabSize:O.vocabSize,error:null}));break;case"VOCAB_LOADED":x.current=O.vocabList;break;case"LOGITS_READY":{const H=new Float32Array(O.snapshot.rawLogitsBuffer);l(H),h({stepIndex:O.snapshot.stepIndex,rawLogits:H,tokenId:O.snapshot.tokenId,tokenStr:O.snapshot.tokenStr,prompt:O.snapshot.prompt,isThinking:O.snapshot.isThinking,timestamp:O.snapshot.timestamp,topCandidates:O.snapshot.topCandidates}),f(O.snapshot.topCandidates);break}case"TOKEN_GENERATED":b(H=>[...H,{tokenStr:O.tokenStr,stepIndex:O.stepIndex}]);break;case"LOOP_ABORTED":S(!0),E(O.message);break;case"GENERATION_COMPLETE":break;case"ERROR":r(H=>({...H,status:"error",error:O.message,progressText:O.message}));break}},I.onerror=z=>{r(O=>({...O,status:"error",error:`Worker error: ${z.message}`,progressText:`Worker error: ${z.message}`}))},s.current=I,()=>{I.terminate(),s.current=null}},[]);const _=K.useCallback(I=>{s.current?.postMessage(I)},[]),N=K.useCallback(I=>{l(null),h(null),f([]),b([]),S(!1),E(null),x.current=null,_({type:"LOAD_MODEL",modelId:I})},[_]),P=K.useCallback(I=>{b([]),S(!1),E(null),_({type:"GET_FULL_LOGITS",prompt:I})},[_]),C=K.useCallback((I,z,O,H)=>{b([]),S(!1),E(null),_({type:"GENERATE_STEP",prompt:I,maxTokens:z,maxThinkingTokens:O,systemPrompt:H})},[_]),k=K.useCallback(()=>{S(!1),E(null),_({type:"RESET_CHAT"})},[_]),D=K.useCallback(()=>{_({type:"ABORT"})},[_]),U=K.useCallback(()=>{l(null),h(null),f([]),b([]),S(!1),E(null),x.current=null,_({type:"UNLOAD"})},[_]),T=K.useCallback((I,z)=>{const O=[];for(let H=0;H<I.length;H++){const fe=I[H];if(!isFinite(fe)||fe<-1e6)continue;const re=x.current?.[H]??`Token #${H}`;O.push({token_id:H,token_str:re,raw_logit:fe,is_rag_grounded:z?.has(re.toLowerCase())??!1})}return O.sort((H,fe)=>fe.raw_logit-H.raw_logit),O.slice(0,200)},[]);return{state:t,isWebGPUAvailable:e.current,isModelLoaded:t.status==="ready"&&t.modelId!==null,availableModels:gT,loadModel:N,getLogits:P,generateSteps:C,resetChat:k,abort:D,unload:U,latestLogits:a,latestSnapshot:u,latestCandidates:p,generatedTokens:g,isLoopAborted:v,loopAbortedMessage:M,logitsToRawCandidates:T}}const ha=[{id:"lab-1-infinite-loop",title:"Lab 1: The Infinite Repetition Loop",subtitle:"Frequency Penalties & Min-P Cutoff vs. Greedy Traps",difficulty:"beginner",badge:"Loop Defense",conceptTaught:"Autoregressive Feedback Loops & Repetition Penalties",description:"The model is trapped in an infinite recursive loop repeating customer service boilerplate. Your goal is to break the loop and produce a natural, coherent response without causing the generation to collapse.",objective:"Adjust the Frequency Penalty (>= 0.4) and Min-P (>= 0.05) sliders to eliminate repeating 4-gram sequences.",brokenPrompt:"Please verify your account details. For your security, please verify your account number. To proceed, please verify your account number and confirm your details. Please verify your account",initialParams:{temperature:.3,topK:50,topP:1,minP:0,frequencyPenalty:0,presencePenalty:0},targetParamHints:["Increase Frequency Penalty to between 0.4 and 0.8","Set Min-P to at least 0.05 to prune low-probability echo tokens"],verificationRules:[{id:"rule-loop-broken",type:"no_repeat_ngrams",description:"Zero repetitive 4-gram sequences in output buffer",threshold:1},{id:"rule-penalty-set",type:"parameter_range",description:"Frequency Penalty set to >= 0.3",paramKey:"frequencyPenalty",minVal:.3}],hints:["When Frequency Penalty is 0.0, the model receives no mathematical penalty for selecting tokens it has already emitted.","Min-P dynamically cuts off tokens whose probability is less than a percentage of the top candidate.","Try setting Frequency Penalty to 0.6 and Min-P to 0.08, then click Generate."],solutionExplanation:"Autoregressive language models suffer from self-reinforcing probability loops when presence/frequency penalties are zero. Applying a frequency penalty reduces logits of repeated tokens, while Min-P eliminates stale tail tokens, forcing the model to select alternative semantic paths."},{id:"lab-2-rag-grounding",title:"Lab 2: The RAG Grounding Defect",subtitle:"Contextual Vector Grounding & Attention Alignment",difficulty:"intermediate",badge:"RAG Alignment",conceptTaught:"Retrieval Grounding vs. Pre-Training Hallucination",description:"The prompt asks for specific account limits from an internal policy document, but high temperature and uncalibrated sampling cause the model to ignore retrieved context and hallucinate incorrect figures.",objective:"Calibrate Temperature (<= 0.5) and Min-P (>= 0.08) so the model locks onto retrieved context with > 70% grounding overlap.",brokenPrompt:"According to the provided Tier 2 Verification Policy document, what is the exact maximum daily transaction limit for Tier 2 accounts, what is the wire processing fee, and what triggers a Tier 3 compliance review?",ragEnabled:!0,ragContext:`TIER 2 VERIFICATION POLICY:
- Daily Transaction Ceiling: Exactly $75,000 USD.
- Wire Processing Fee: 0.15% flat rate (discounted from standard 0.50%).
- Compliance Escalation: Any cumulative 24-hour volume exceeding $75,000 triggers an automated Tier 3 compliance review.`,initialParams:{temperature:1.3,topK:80,topP:.98,minP:0,frequencyPenalty:.1,presencePenalty:.1},targetParamHints:["Lower Temperature to between 0.2 and 0.5","Increase Min-P to >= 0.08 to filter out ungrounded speculative tokens"],verificationRules:[{id:"rule-grounding-ratio",type:"min_grounding_ratio",description:"Context Grounding overlap ratio >= 70%",threshold:.7},{id:"rule-temp-calibrated",type:"parameter_range",description:"Temperature calibrated to <= 0.6",paramKey:"temperature",maxVal:.6}],hints:["Watch the cyan grounding laser beams in the visualizer. At T = 1.3, they point to dim outer asteroids.","Lowering Temperature sharpens the probability peak around tokens directly mentioned in the RAG context.","Set Temperature to 0.3 and Min-P to 0.10 to achieve strong grounding alignment."],solutionExplanation:"High sampling temperature flattens token logits across the entire vocabulary, allowing pre-training parametric memory to overpower retrieved prompt context. Compressing temperature and raising Min-P forces the model to stay on the high-confidence semantic plateau provided by the RAG document."},{id:"lab-3-json-stability",title:"Lab 3: Structured JSON Stability",subtitle:"Shannon Entropy Compression at Syntax Junctions",difficulty:"intermediate",badge:"Structured Output",conceptTaught:"Perplexity, Shannon Entropy, & Deterministic Syntax",description:"An automated extraction pipeline is attempting to generate a valid JSON payload, but hyper-dispersed sampling entropy creates corrupted syntax, missing quotes, and invalid keys.",objective:"Compress entropy (avg < 0.6 bits at syntax boundaries) to guarantee valid JSON formatting.",brokenPrompt:'Extract the customer profile into valid JSON with keys "name", "status", and "creditScore": Customer Sarah Jenkins is currently active with an 810 credit score.',initialParams:{temperature:1.4,topK:100,topP:.99,minP:0,frequencyPenalty:0,presencePenalty:0},targetParamHints:["Lower Temperature to <= 0.3 (near-greedy)","Set Top-P to 0.85 or Min-P to 0.12"],verificationRules:[{id:"rule-max-entropy",type:"max_entropy",description:"Average Shannon Entropy <= 0.6 bits",threshold:.6},{id:"rule-temp-deterministic",type:"parameter_range",description:"Temperature set to <= 0.4",paramKey:"temperature",maxVal:.4}],hints:["Look at the Perplexity/Entropy indicator in the Flight Path. Red indicates high uncertainty.",'JSON syntax tokens ("{", ":", "}") require near-zero entropy to ensure reliable parsing.',"Try setting Temperature to 0.2 and Min-P to 0.15."],solutionExplanation:"Generating deterministic formats like JSON, YAML, or SQL requires extremely low entropy at syntax boundaries. Running near-greedy sampling ensures that grammar tokens are selected with near 100% confidence, preventing syntax errors in downstream software parsers."},{id:"lab-4-reasoning-xray",title:"Lab 4: The Cognitive Orbit X-Ray",subtitle:"Reasoning Monologue <think> Dynamics & Energy Contraction",difficulty:"advanced",badge:"Reasoning Dynamics",conceptTaught:"Chain-of-Thought Entropy Contraction & Monologue Decoupling",description:"Explore how modern reasoning models explore candidate logical pathways within <think> monologues before contracting their probability distribution into a high-confidence answer.",objective:"Observe the cognitive asteroid cloud during the thinking stream and confirm that final token emission achieves high confidence (> 85%).",brokenPrompt:"Solve this riddle step by step: A farmer has 17 sheep, and all but 9 die. How many sheep are left alive?",initialParams:{temperature:.6,topK:50,topP:.95,minP:.05,maxThinkingTokens:128},targetParamHints:["Keep Min-P between 0.05 and 0.10","Watch the transition from <think> asteroid cloud to Supergiant star at the answer"],verificationRules:[{id:"rule-thinking-contrast",type:"thinking_contrast",description:"Successful cognitive monologue parsing and high-confidence final answer"}],hints:["Notice that during the thinking phase, the canvas renders a diffuse outer cloud of cognitive asteroids.",'Once </think> is emitted, the distribution contracts into a single Supergiant star representing "9".',"Click Generate to observe the real-time reasoning transition."],solutionExplanation:"Reasoning models maintain high cognitive entropy while exploring candidate logical hypotheses inside <think> tags. Once the problem is solved internally, the probability manifold contracts into a steep potential well, emitting the final answer with decisive certainty."}],_T=({activeLab:s,onSelectLab:e,evaluation:t,params:r,onUpdateParams:a,onResetScenario:l,completedLabIds:u})=>{const[h,p]=K.useState(!1),[f,g]=K.useState(!1),b=ha.findIndex(S=>S.id===s.id),v=b<ha.length-1?ha[b+1]:null;return c.jsxs("div",{className:"bg-slate-900/90 border border-cyan-500/30 rounded-xl p-5 backdrop-blur-md shadow-2xl flex flex-col gap-4 text-white",children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-slate-700/60 pb-3",children:[c.jsxs("div",{className:"flex items-center gap-3",children:[c.jsx("span",{className:"px-2.5 py-1 text-xs font-bold rounded-full uppercase tracking-wider bg-cyan-500/20 text-cyan-300 border border-cyan-400/40",children:s.badge}),c.jsx("span",{className:`px-2 py-0.5 text-xs font-semibold rounded ${s.difficulty==="beginner"?"bg-emerald-500/20 text-emerald-300 border border-emerald-500/30":s.difficulty==="intermediate"?"bg-amber-500/20 text-amber-300 border border-amber-500/30":"bg-purple-500/20 text-purple-300 border border-purple-500/30"}`,children:s.difficulty})]}),c.jsx("select",{value:s.id,onChange:S=>{const M=ha.find(E=>E.id===S.target.value);M&&e(M)},className:"bg-slate-800 border border-slate-700 text-xs rounded-lg px-2.5 py-1.5 text-cyan-200 focus:outline-none focus:border-cyan-400 cursor-pointer",children:ha.map((S,M)=>c.jsxs("option",{value:S.id,children:[u.includes(S.id)?"✅ ":`${M+1}. `,S.title]},S.id))})]}),c.jsxs("div",{children:[c.jsx("h2",{className:"text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-indigo-200 to-purple-300",children:s.title}),c.jsx("p",{className:"text-xs text-slate-400 mt-0.5",children:s.subtitle})]}),c.jsxs("div",{className:"bg-slate-800/60 border border-slate-700/50 rounded-lg p-3.5 flex flex-col gap-2 text-xs",children:[c.jsxs("div",{children:[c.jsx("span",{className:"font-semibold text-cyan-300",children:"Concept: "}),c.jsx("span",{className:"text-slate-300",children:s.conceptTaught})]}),c.jsx("p",{className:"text-slate-300 leading-relaxed",children:s.description}),c.jsxs("div",{className:"bg-cyan-950/40 border border-cyan-500/30 rounded p-2 text-cyan-200",children:[c.jsx("span",{className:"font-bold text-cyan-400",children:"🎯 Objective: "}),s.objective]})]}),c.jsxs("div",{className:`p-3.5 rounded-lg border flex flex-col gap-2 transition-all duration-300 ${t.status==="passed"?"bg-emerald-950/50 border-emerald-500/60 text-emerald-200 shadow-lg shadow-emerald-900/20":t.status==="aborted"?"bg-red-950/50 border-red-500/60 text-red-200 shadow-lg shadow-red-900/20":t.status==="failed"?"bg-amber-950/40 border-amber-500/40 text-amber-200":t.status==="running"?"bg-blue-950/40 border-blue-500/40 text-blue-200 animate-pulse":"bg-slate-800/40 border-slate-700/40 text-slate-400"}`,children:[c.jsxs("div",{className:"flex items-center justify-between",children:[c.jsxs("span",{className:"font-bold text-xs uppercase tracking-wide flex items-center gap-1.5",children:[t.status==="passed"&&"🎉 STATUS: SOLVED",t.status==="aborted"&&"🛑 STATUS: LOOP HALTED",t.status==="failed"&&"⚠️ STATUS: INCOMPLETE",t.status==="running"&&"⚡ STATUS: EVALUATING...",t.status==="unattempted"&&"⏳ STATUS: READY TO ATTEMPT"]}),t.status==="passed"&&v&&c.jsx("button",{onClick:()=>e(v),className:"px-2.5 py-1 text-xs font-bold rounded bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors shadow",children:"Next Challenge ➔"})]}),c.jsx("p",{className:"text-xs leading-relaxed",children:t.feedback}),c.jsxs("div",{className:"mt-1 pt-2 border-t border-white/10 flex flex-col gap-1.5",children:[c.jsx("span",{className:"text-[11px] font-semibold text-slate-400 uppercase",children:"Verification Rules:"}),s.verificationRules.map(S=>{const M=t.passedRuleIds.includes(S.id);return c.jsxs("div",{className:"flex items-center gap-2 text-xs",children:[c.jsx("span",{children:M?"✅":"❌"}),c.jsx("span",{className:M?"text-emerald-300 font-medium":"text-slate-400",children:S.description})]},S.id)})]})]}),c.jsxs("div",{className:"flex flex-col gap-2",children:[c.jsxs("button",{onClick:()=>p(!h),className:"flex items-center justify-between text-xs text-cyan-400 hover:text-cyan-300 font-semibold py-1 focus:outline-none transition-colors",children:[c.jsxs("span",{children:["💡 Guided Hints & Parameter Targets (",s.hints.length,")"]}),c.jsx("span",{children:h?"▲ Hide":"▼ View Hints"})]}),h&&c.jsx("div",{className:"bg-slate-800/80 border border-slate-700/60 rounded-lg p-3 flex flex-col gap-2 text-xs text-slate-300 animate-fadeIn",children:c.jsx("ul",{className:"list-disc list-inside space-y-1 text-slate-300",children:s.hints.map((S,M)=>c.jsx("li",{children:S},M))})})]}),c.jsxs("div",{className:"flex items-center justify-between pt-2 border-t border-slate-700/60",children:[c.jsx("button",{onClick:l,className:"px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-600 transition-colors",children:"↺ Reset Lab State"}),c.jsx("button",{onClick:()=>g(!f),className:"px-3 py-1.5 rounded-lg text-xs font-semibold text-purple-300 bg-purple-950/40 hover:bg-purple-900/50 border border-purple-500/40 transition-colors",children:f?"Hide Explanation":"📖 Deep Explanation"})]}),f&&c.jsxs("div",{className:"bg-purple-950/30 border border-purple-500/30 rounded-lg p-3.5 text-xs text-purple-200 leading-relaxed flex flex-col gap-1.5 animate-fadeIn",children:[c.jsx("span",{className:"font-bold text-purple-300",children:"Why this happens in production:"}),c.jsx("p",{children:s.solutionExplanation})]})]})};function yT({scenario:s,params:e,flightSteps:t,outputText:r,ragContext:a="",isGenerating:l,isLoopAborted:u=!1}){return K.useMemo(()=>{if(!s)return{status:"unattempted",feedback:"Select a lab scenario to begin guided challenge.",passedRuleIds:[],failedRuleIds:[],metrics:{}};if(u)return{status:"aborted",feedback:"⚠️ Catastrophic loop detected by WebWorker. Generation halted to protect GPU memory.",passedRuleIds:[],failedRuleIds:s.verificationRules.map(E=>E.id),metrics:{isLoopAborted:!0}};if(l)return{status:"running",feedback:"Analyzing token distribution and sampling dynamics in real-time...",passedRuleIds:[],failedRuleIds:[],metrics:{tokensGenerated:t.length}};if(t.length===0&&!r.trim())return{status:"unattempted",feedback:"Configure parameters and click Generate to evaluate this scenario.",passedRuleIds:[],failedRuleIds:[],metrics:{}};const h=[],p=[];let f=0;const g=t.map(E=>E.selectedToken.token_str.trim().toLowerCase());if(g.length>=8)for(let E=0;E<=g.length-8;E++){const x=g.slice(E,E+4).join(" ");for(let _=E+4;_<=g.length-4;_++){const N=g.slice(_,_+4).join(" ");x.length>5&&x===N&&f++}}let b=0;if(a&&a.trim().length>0&&t.length>0){const E=new Set(a.toLowerCase().replace(/[^\w\s]/g,"").split(/\s+/).filter(_=>_.length>3));b=t.filter(_=>E.has(_.selectedToken.token_str.trim().toLowerCase())).length/t.length}let v=0,S=0;if(t.length>0){const E=t.map(x=>{const _=x.rawLogits.map(P=>Math.exp(P.raw_logit)).filter(P=>P>0),N=_.reduce((P,C)=>P+C,0);return N<=0?0:_.reduce((P,C)=>{const k=C/N;return P-k*Math.log2(k+1e-10)},0)}).filter(x=>!isNaN(x)&&isFinite(x));E.length>0&&(v=E.reduce((x,_)=>x+_,0)/E.length,S=Math.max(...E))}for(const E of s.verificationRules){let x=!1;switch(E.type){case"no_repeat_ngrams":x=f===0&&!u;break;case"min_grounding_ratio":x=b>=(E.threshold??.7);break;case"max_entropy":x=v<=(E.threshold??.8)&&t.length>=5;break;case"thinking_contrast":x=r.includes("</think>")||t.some(_=>!_.selectedToken.isHistorical);break;case"parameter_range":if(E.paramKey&&e[E.paramKey]!==void 0){const _=e[E.paramKey],N=E.minVal===void 0||_>=E.minVal,P=E.maxVal===void 0||_<=E.maxVal;x=N&&P}break}x?h.push(E.id):p.push(E.id)}const M=h.length===s.verificationRules.length&&p.length===0;return{status:M?"passed":"failed",feedback:M?"🎉 Lab Challenge Solved! Sampling parameters successfully calibrated.":`Criteria not met (${h.length}/${s.verificationRules.length} rules passed). Inspect hints and adjust sliders.`,passedRuleIds:h,failedRuleIds:p,metrics:{repeatCount:f,groundingRatio:Math.round(b*100),avgEntropy:Math.round(v*100)/100,maxEntropy:Math.round(S*100)/100,tokensGenerated:t.length,isLoopAborted:u}}},[s,e,t,r,a,l,u])}function ua(s,e,t){if(!e||!t.trim())return s.map(a=>({...a,is_rag_grounded:!1}));const r=new Set((t.toLowerCase().match(/[a-z0-9'-]+/g)||[]).filter(a=>a.length>2));return s.map(a=>{const u=(a.token_str.toLowerCase().match(/[a-z0-9'-]+/g)||[]).some(h=>h.length>2&&r.has(h));return{...a,is_rag_grounded:u}})}const bT=()=>{const[s,e]=K.useState("experiment"),[t,r]=K.useState(!1),[a,l]=K.useState(!1),[u,h]=K.useState(ha[0]),[p,f]=K.useState(()=>{try{return JSON.parse(localStorage.getItem("token_cosmos_completed_labs")||"[]")}catch{return[]}}),g=vT(),[b,v]=K.useState(!1),[S,M]=K.useState(!1),[E,x]=K.useState("Sample data"),[_,N]=K.useState(null),[P,C]=K.useState(null),[k,D]=K.useState(!1),[U,T]=K.useState(()=>{const j=localStorage.getItem("token_cosmos_provider");return j==="openai"||j==="custom"?j:"default"}),[I,z]=K.useState(()=>localStorage.getItem("token_cosmos_custom_url")||""),[O,H]=K.useState(()=>localStorage.getItem("token_cosmos_custom_key")||""),[fe,re]=K.useState(()=>localStorage.getItem("token_cosmos_model_name")||"Cloud Run candidate demo"),[q,de]=K.useState({temperature:.7,topK:40,topP:.9,minP:.02,frequencyPenalty:.1,presencePenalty:.1,stopSequences:[],logitBiases:{},maxThinkingTokens:2048}),[oe,Z]=K.useState({temperature:1.5,topK:50,topP:.95,minP:.01,frequencyPenalty:0,presencePenalty:0,stopSequences:[],logitBiases:{}}),[ee,ce]=K.useState(oc[0].prompt),[F,Y]=K.useState(""),[Ce,qe]=K.useState('{ "type": "object", "properties": { "answer": { "type": "string" } } }'),[we,ie]=K.useState(!1),[xe,ve]=K.useState(oc[0].ragContext),[te,Se]=K.useState(oc[0].ragEnabled),[Qe,Ft]=K.useState(!1),{copySetupLink:ut}=mT({params:q,setParams:de,prompt:ee,setPrompt:ce,systemPrompt:F,setSystemPrompt:Y,ragContext:xe,setRagContext:ve,ragEnabled:te,setRagEnabled:Se}),[Ct,it]=K.useState(Ys["capital-france"].baseline),[Je,Lt]=K.useState(Ys["capital-france"].rag);K.useEffect(()=>{if(g.latestLogits&&g.isModelLoaded){const j=g.logitsToRawCandidates(g.latestLogits);j.length>0&&(it(ua(j,!1,"")),Lt(ua(j,te,xe)),x(`Local WebGPU - ${g.state.modelId}`),N(null))}},[g.latestLogits,g.latestCandidates,g.isModelLoaded,g.logitsToRawCandidates,g.state.modelId,te,xe]),K.useEffect(()=>{g.state.error&&N(g.state.error)},[g.state.error]);const zt=j=>{if(j==="__SAMPLE_DATA__"){g.unload(),v(!0),M(!0),x("Sample data"),N(null);return}if(j==="__CLOUD_API__"){g.unload(),v(!1),M(!0),x("Cloud Run candidate API"),N(null);return}v(!1),M(!1),x(`Loading local WebGPU - ${j}`),N(null),g.loadModel(j)},[St,Dt]=K.useState([]),[wt,ct]=K.useState(0),[Q,et]=K.useState(!1),[ze,L]=K.useState(!1),w=(j,be,Re,_e)=>{T(j),z(be),H(Re),re(_e),localStorage.setItem("token_cosmos_provider",j),be?localStorage.setItem("token_cosmos_custom_url",be):localStorage.removeItem("token_cosmos_custom_url"),Re?localStorage.setItem("token_cosmos_custom_key",Re):localStorage.removeItem("token_cosmos_custom_key"),_e?localStorage.setItem("token_cosmos_model_name",_e):localStorage.removeItem("token_cosmos_model_name")},$=(j,be,Re,_e)=>{const Be=j.trim().toLowerCase(),je=Re&&be?be.split(/\s+/).filter(It=>It.length>3):[];let ht=[];_e&&(_e.toLowerCase().includes("sql")||_e.toLowerCase().includes("dba"))?ht=[" SELECT"," FROM"," WHERE"," JOIN"," GROUP"," BY"," ORDER"," LIMIT"," COUNT"," MAX"]:Be.includes("steak")?ht=[" medium-rare"," grill"," searing"," butter"," seasoning"," ribeye"," pan"," tender"," garlic"," salt"]:Be.includes("poem")||Be.includes("server")?ht=[" crash"," glowing"," silicon"," binary"," silent"," electric"," echo"," dark"," pulse"," memory"]:Be.includes("policy")||Be.includes("work")?ht=[" remote"," office"," Tuesday"," Thursday"," schedule"," hybrid"," Monday"," Friday"," hours"," team"]:(ht=j.split(/\s+/).filter(tn=>tn.length>2).map(tn=>` ${tn}`),ht.length<5&&ht.push(" optimal"," result"," answer"," analysis"," structure"," concept"));const Et=[],$t=[];for(let It=0;It<50;It++){const tn=It<ht.length?ht[It]:` candidate_${It+1}`,Cn=16-Math.log(It+1)*3.1+Math.sin(It*1.5)*.5;let Hn=!1,Rn=Cn;if(Re&&je.length>0){const br=tn.trim().toLowerCase();for(const zi of je)if(br.includes(zi.toLowerCase())||zi.toLowerCase().includes(br)){Hn=!0,Rn+=5.5;break}}Et.push({token_id:2e3+It,token_str:tn,raw_logit:Math.round(Cn*100)/100,is_rag_grounded:!1}),$t.push({token_id:3e3+It,token_str:tn,raw_logit:Math.round(Rn*100)/100,is_rag_grounded:Hn})}return Et.sort((It,tn)=>tn.raw_logit-It.raw_logit),$t.sort((It,tn)=>tn.raw_logit-It.raw_logit),{baseline:Et,rag:$t}},ae=async j=>{const be=j!==void 0?j:ee;j===void 0&&(Dt([]),ct(0)),Ft(!0),N(null);try{if(g.isModelLoaded){const Be=te&&xe.trim()?`Context: ${xe}

Question: ${be}`:be;g.availableModels.find(ht=>ht.id===g.state.modelId)?.isReasoning?g.generateSteps(Be,(q.maxThinkingTokens||2048)+1024,q.maxThinkingTokens,F):g.getLogits(Be),x(`Local WebGPU - ${g.state.modelId}`);return}if(U!=="default"){if(U==="openai"&&!O)throw new Error("An OpenAI API key is required for BYOE inference.");const Be=I||(U==="openai"?"https://api.openai.com/v1":"");if(!Be)throw new Error("A base URL is required for a custom OpenAI-compatible endpoint.");const je=Be.replace(/\/$/,""),ht=je.endsWith("/chat/completions")?je:`${je}/chat/completions`,Et={"Content-Type":"application/json"};O&&(Et.Authorization=`Bearer ${O}`);const $t=[];F.trim()&&$t.push({role:"system",content:F.trim()});let It=be;te&&xe.trim()&&(It=`Retrieved Context: ${xe}

User Question: ${be}`),$t.push({role:"user",content:It});const tn={model:fe||"gpt-4o",messages:$t,max_tokens:1,temperature:q.temperature,logprobs:!0,top_logprobs:20},Cn=await fetch(ht,{method:"POST",headers:Et,body:JSON.stringify(tn)});if(!Cn.ok)throw new Error(`BYOE endpoint returned ${Cn.status}.`);const Hn=await Cn.json(),Rn=B_(Hn,te?xe:void 0);if(Rn.length===0)throw new Error("BYOE endpoint returned no token logprobs. Choose an OpenAI-compatible endpoint with logprobs support.");it(ua(Rn,!1,"")),Lt(ua(Rn,te,xe)),x(`BYOE - ${fe||U}`);return}if(b){const Be=$(be,xe,te,F);it(Be.baseline),Lt(Be.rag),x("Sample data");return}const Re=new AbortController,_e=setTimeout(()=>Re.abort(),5e3);try{const Be=await fetch("/api/logits",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt:be,system_prompt:F||null,rag_context:te?xe:null,top_n:50}),signal:Re.signal}),je=Be.headers.get("content-type")||"";if(!Be.ok||!je.includes("application/json"))throw new Error(`Cloud Run candidate API is unavailable (${Be.status}).`);const ht=await Be.json();if(!Array.isArray(ht.candidates)||ht.candidates.length===0)throw new Error("Cloud Run candidate API returned no candidates.");it(ua(ht.candidates,!1,"")),Lt(ua(ht.candidates,te,xe)),x(`Cloud Run - ${ht.engine||"candidate API"}`)}finally{clearTimeout(_e)}}catch(Re){const _e=$(ee,xe,te,F);it(_e.baseline),Lt(_e.rag);const Be=Re instanceof Error?Re.message:"Unknown inference error";x("Sample data (fallback)"),N(`${Be} Showing generated sample candidates instead.`)}finally{Ft(!1)}},me=j=>{if(de(be=>({...be,...j.params})),ce(j.prompt),ve(j.ragContext),Se(j.ragEnabled),j.id==="factual-roboticist")it(Ys["capital-france"].baseline),Lt(Ys["capital-france"].rag);else if(j.id==="wild-storyteller")it(Ys["cybernetic-forest"].baseline),Lt(Ys["cybernetic-forest"].baseline);else{const be=$(j.prompt,j.ragContext,j.ragEnabled,F);it(be.baseline),Lt(be.rag)}},Me=K.useMemo(()=>St.slice(0,wt+1).map(j=>j.selectedToken.token_str),[St,wt]),Ne=te?Je:Ct,ue=K.useMemo(()=>{const j=ao(Ne,q,Me);return we&&Ce.trim()&&j.forEach(be=>{const Re=be.token_str.trim();(Re.includes("candidate_")||Re.includes("fringe_")||Re.includes("Washington"))&&(be.probability=0,be.isFiltered=!0,be.filterReason="Banned",be.color="#e11d48")}),j},[Ne,q,Me,we,Ce]),ye=K.useMemo(()=>ao(Ne,oe,Me),[Ne,oe,Me]);K.useMemo(()=>ao(Ct,q,Me),[Ct,q,Me]),K.useMemo(()=>ao(Je,q,Me),[Je,q,Me]);const Ee=K.useMemo(()=>St.map(j=>ao(j.rawLogits,j.params)),[St]);K.useEffect(()=>{ue.length>0&&(Dt(j=>j.length===0?[{stepIndex:0,selectedToken:ue[0],promptSnippet:ee,rawLogits:Ne,params:q,ragEnabled:te}]:j),ct(j=>St.length===0?0:j))},[Ct,Je,ue]);const He=async j=>{const be=ee+j.token_str;ce(be);const Re={stepIndex:St.length,selectedToken:j,promptSnippet:ee,rawLogits:Ne,params:q,ragEnabled:te},_e=[...St.slice(0,wt+1),Re];Dt(_e),ct(_e.length-1),C({feature:`Token Selection ("${j.token_str.trim()}")`,whatItIs:"Direct token selection on the starfield orbital canvas.",whyItIs:"Allows step-by-step interactive trajectory steering.",impact:`Appends "${j.token_str.trim()}" (${(j.probability*100).toFixed(1)}%) to flight constellation.`,guidance:"Click any orbiting candidate star to force the LLM down a specific sentence path!",timestamp:Date.now()}),await ae(be)};K.useEffect(()=>{let j;const be=Qe||g.state.status==="generating";return ze&&!be&&ue.length>0&&(j=setTimeout(()=>{const Re=ue.find(_e=>!_e.isFiltered)||ue[0];Re?He(Re):L(!1)},950)),()=>clearTimeout(j)},[ze,Qe,g.state.status,ue,He]);const Ie=()=>{ue.length!==0&&(et(!0),setTimeout(()=>{const j=ue.find(be=>!be.isFiltered)||ue[0];He(j),et(!1)},200))},ke=()=>{if(ue.length>0){const be={stepIndex:0,selectedToken:ue[0],promptSnippet:ee,rawLogits:Ne,params:q,ragEnabled:te};Dt([be]),ct(0)}},We=!S&&g.isWebGPUAvailable&&["idle","downloading","loading","error"].includes(g.state.status),Ze=Qe||g.state.status==="generating",at=yT({scenario:s==="labs"?u:null,params:q,flightSteps:St,outputText:St.map(j=>j.selectedToken.token_str).join(""),ragContext:te?xe:"",isGenerating:Ze,isLoopAborted:g.isLoopAborted});K.useEffect(()=>{at.status==="passed"&&u&&!p.includes(u.id)&&f(j=>{const be=[...j,u.id];return localStorage.setItem("token_cosmos_completed_labs",JSON.stringify(be)),be})},[at.status,u,p]);const G=j=>{h(j),ce(j.brokenPrompt),de(be=>({...be,...j.initialParams})),j.ragContext?(ve(j.ragContext),Se(!0)):Se(!1),g.resetChat(),Dt([]),ct(0)},Fe=()=>{G(u)};return c.jsxs("div",{className:"flex flex-col h-screen overflow-hidden bg-[#050714] text-gray-100 font-sans selection:bg-blue-500/30 selection:text-white select-text",children:[We&&c.jsx(pT,{state:g.state,isWebGPUAvailable:g.isWebGPUAvailable,availableModels:g.availableModels,onSelectModel:zt}),c.jsxs(c.Fragment,{children:[c.jsx(N_,{activeTab:s,setActiveTab:e,splitView:t,setSplitView:r,onOpenSettings:()=>D(!0),onCopySetupLink:ut,showNavigator:a,setShowNavigator:l}),c.jsx("main",{className:"flex-1 w-full max-w-[1600px] mx-auto p-4 sm:p-6 flex flex-col space-y-6 min-h-0 overflow-hidden",children:s==="labs"?c.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1 min-h-0 overflow-hidden",children:[c.jsxs("div",{className:"lg:col-span-5 xl:col-span-4 h-full min-h-0 overflow-y-auto pr-1 space-y-4",children:[c.jsx(_T,{activeLab:u,onSelectLab:G,evaluation:at,params:q,onUpdateParams:j=>de(be=>({...be,...j})),onResetScenario:Fe,completedLabIds:p}),c.jsx($m,{params:q,setParams:de,prompt:ee,setPrompt:ce,systemPrompt:F,setSystemPrompt:Y,jsonSchema:Ce,setJsonSchema:qe,jsonSchemaEnabled:we,setJsonSchemaEnabled:ie,ragContext:xe,setRagContext:ve,ragEnabled:te,setRagEnabled:Se,onApplyPreset:me,onLaunchPrompt:ae,onInteractFeature:j=>C(j),isFetchingLogits:Ze,rawLogits:Ne,isReasoningModel:g.availableModels.find(j=>j.id===g.state.modelId)?.isReasoning})]}),c.jsx("div",{className:"lg:col-span-7 xl:col-span-8 h-full min-h-0 overflow-hidden flex flex-col",children:c.jsx(Lc,{candidates:ue,params:q,ragEnabled:te,onSelectToken:He,title:`${u.title}`,subtitle:`Interactive Challenge • ${u.conceptTaught}`,steps:St,currentStepIndex:wt,onSelectStep:j=>ct(j),onGenerateNextStep:Ie,onResetTimeline:ke,isGenerating:Q,allCandidatesByStep:Ee,historyLength:Me.length,modelId:g.state.modelId,latestLogits:g.latestLogits,isThinking:g.latestSnapshot?.isThinking,isPlaying:ze,onTogglePlay:()=>L(!ze)})})]}):s==="experiment"?c.jsxs(c.Fragment,{children:[_&&c.jsx("div",{role:"status",className:"border border-amber-400/30 bg-amber-400/10 px-3 py-2 text-xs text-amber-100",children:_}),c.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1 min-h-0 overflow-hidden",children:[c.jsx("div",{className:"lg:col-span-4 xl:col-span-4 h-full min-h-0 overflow-hidden",children:c.jsx($m,{params:q,setParams:de,prompt:ee,setPrompt:ce,systemPrompt:F,setSystemPrompt:Y,jsonSchema:Ce,setJsonSchema:qe,jsonSchemaEnabled:we,setJsonSchemaEnabled:ie,ragContext:xe,setRagContext:ve,ragEnabled:te,setRagEnabled:Se,onApplyPreset:me,onLaunchPrompt:ae,onInteractFeature:j=>C(j),isFetchingLogits:Ze,rawLogits:Ne,isReasoningModel:g.availableModels.find(j=>j.id===g.state.modelId)?.isReasoning})}),c.jsx("div",{className:"lg:col-span-8 xl:col-span-8 h-full min-h-0 overflow-hidden flex flex-col",children:c.jsx("div",{className:"flex-1 min-h-0 overflow-hidden",children:t?c.jsx(cT,{leftCandidates:ue,rightCandidates:ye,leftParams:q,rightParams:oe,leftTitle:U!=="default"?`Universe A [${U.toUpperCase()}] (${fe})`:`Universe A (Temp = ${q.temperature.toFixed(2)})`,leftSubtitle:`Primary Sampling Config • Top-K ${q.topK}`,rightTitle:U!=="default"?`Universe B [${E}]`:`Universe B (Temp = ${oe.temperature.toFixed(2)})`,rightSubtitle:`Secondary A/B Config • Top-K ${oe.topK}`,leftRagEnabled:te,rightRagEnabled:te,onSelectToken:He,onUpdateRightTemp:j=>Z(be=>({...be,temperature:j})),isByoeMode:U!=="default",leftIsThinking:g.latestSnapshot?.isThinking}):c.jsx(Lc,{candidates:ue,params:q,ragEnabled:te,onSelectToken:He,title:"The Token Cosmos",subtitle:`${E} • 3D Topographic Terrain`,steps:St,currentStepIndex:wt,onSelectStep:j=>ct(j),onGenerateNextStep:Ie,onResetTimeline:ke,isGenerating:Q,allCandidatesByStep:Ee,historyLength:Me.length,modelId:g.state.modelId,latestLogits:g.latestLogits,isThinking:g.latestSnapshot?.isThinking,isPlaying:ze,onTogglePlay:()=>L(!ze)})})})]})]}):s==="learn"?c.jsx("div",{className:"flex-1 overflow-y-auto",children:c.jsx(uT,{})}):c.jsx("div",{className:"flex-1 max-w-4xl mx-auto w-full pt-8 min-h-0 overflow-hidden",children:c.jsx("div",{className:"bg-[#1c1c21] rounded-xl border border-white/10 p-6 shadow-2xl overflow-hidden relative h-full",children:c.jsx("div",{className:"absolute inset-0 overflow-y-auto p-2",children:c.jsx(fT,{isOpen:!0,onClose:()=>e("experiment"),params:q,prompt:ee,systemPrompt:F,ragContext:xe,ragEnabled:te,modelName:fe,provider:U,isReasoningModel:g.availableModels.find(j=>j.id===g.state.modelId)?.isReasoning})})})})}),a&&c.jsx(dT,{params:q,setParams:de,prompt:ee,setPrompt:ce,ragContext:xe,setRagContext:ve,ragEnabled:te,setRagEnabled:Se,topCandidateStr:ue[0]?.token_str?.trim()||"Paris",topCandidateProb:ue[0]?.probability||.85,activeInteractionNotice:P}),c.jsx(hT,{isOpen:k,onClose:()=>D(!1),onSave:w,provider:U,customUrl:I,customApiKey:O,modelName:fe})]})]})};$v.createRoot(document.getElementById("root")).render(c.jsx(jv.StrictMode,{children:c.jsx(bT,{})}));
