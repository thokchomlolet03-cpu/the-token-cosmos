(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))r(a);new MutationObserver(a=>{for(const l of a)if(l.type==="childList")for(const d of l.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&r(d)}).observe(document,{childList:!0,subtree:!0});function t(a){const l={};return a.integrity&&(l.integrity=a.integrity),a.referrerPolicy&&(l.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?l.credentials="include":a.crossOrigin==="anonymous"?l.credentials="omit":l.credentials="same-origin",l}function r(a){if(a.ep)return;a.ep=!0;const l=t(a);fetch(a.href,l)}})();function tg(s){return s&&s.__esModule&&Object.prototype.hasOwnProperty.call(s,"default")?s.default:s}var ud={exports:{}},so={},dd={exports:{}},Ct={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Pm;function Lv(){if(Pm)return Ct;Pm=1;var s=Symbol.for("react.element"),e=Symbol.for("react.portal"),t=Symbol.for("react.fragment"),r=Symbol.for("react.strict_mode"),a=Symbol.for("react.profiler"),l=Symbol.for("react.provider"),d=Symbol.for("react.context"),h=Symbol.for("react.forward_ref"),f=Symbol.for("react.suspense"),m=Symbol.for("react.memo"),_=Symbol.for("react.lazy"),S=Symbol.iterator;function v(U){return U===null||typeof U!="object"?null:(U=S&&U[S]||U["@@iterator"],typeof U=="function"?U:null)}var b={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},M=Object.assign,E={};function g(U,q,Re){this.props=U,this.context=q,this.refs=E,this.updater=Re||b}g.prototype.isReactComponent={},g.prototype.setState=function(U,q){if(typeof U!="object"&&typeof U!="function"&&U!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,U,q,"setState")},g.prototype.forceUpdate=function(U){this.updater.enqueueForceUpdate(this,U,"forceUpdate")};function x(){}x.prototype=g.prototype;function N(U,q,Re){this.props=U,this.context=q,this.refs=E,this.updater=Re||b}var P=N.prototype=new x;P.constructor=N,M(P,g.prototype),P.isPureReactComponent=!0;var C=Array.isArray,D=Object.prototype.hasOwnProperty,L={current:null},O={key:!0,ref:!0,__self:!0,__source:!0};function T(U,q,Re){var qe,be={},ee=null,me=null;if(q!=null)for(qe in q.ref!==void 0&&(me=q.ref),q.key!==void 0&&(ee=""+q.key),q)D.call(q,qe)&&!O.hasOwnProperty(qe)&&(be[qe]=q[qe]);var ve=arguments.length-2;if(ve===1)be.children=Re;else if(1<ve){for(var ce=Array(ve),we=0;we<ve;we++)ce[we]=arguments[we+2];be.children=ce}if(U&&U.defaultProps)for(qe in ve=U.defaultProps,ve)be[qe]===void 0&&(be[qe]=ve[qe]);return{$$typeof:s,type:U,key:ee,ref:me,props:be,_owner:L.current}}function I(U,q){return{$$typeof:s,type:U.type,key:q,ref:U.ref,props:U.props,_owner:U._owner}}function H(U){return typeof U=="object"&&U!==null&&U.$$typeof===s}function B(U){var q={"=":"=0",":":"=2"};return"$"+U.replace(/[=:]/g,function(Re){return q[Re]})}var V=/\/+/g;function ae(U,q){return typeof U=="object"&&U!==null&&U.key!=null?B(""+U.key):q.toString(36)}function Q(U,q,Re,qe,be){var ee=typeof U;(ee==="undefined"||ee==="boolean")&&(U=null);var me=!1;if(U===null)me=!0;else switch(ee){case"string":case"number":me=!0;break;case"object":switch(U.$$typeof){case s:case e:me=!0}}if(me)return me=U,be=be(me),U=qe===""?"."+ae(me,0):qe,C(be)?(Re="",U!=null&&(Re=U.replace(V,"$&/")+"/"),Q(be,q,Re,"",function(we){return we})):be!=null&&(H(be)&&(be=I(be,Re+(!be.key||me&&me.key===be.key?"":(""+be.key).replace(V,"$&/")+"/")+U)),q.push(be)),1;if(me=0,qe=qe===""?".":qe+":",C(U))for(var ve=0;ve<U.length;ve++){ee=U[ve];var ce=qe+ae(ee,ve);me+=Q(ee,q,Re,ce,be)}else if(ce=v(U),typeof ce=="function")for(U=ce.call(U),ve=0;!(ee=U.next()).done;)ee=ee.value,ce=qe+ae(ee,ve++),me+=Q(ee,q,Re,ce,be);else if(ee==="object")throw q=String(U),Error("Objects are not valid as a React child (found: "+(q==="[object Object]"?"object with keys {"+Object.keys(U).join(", ")+"}":q)+"). If you meant to render a collection of children, use an array instead.");return me}function ie(U,q,Re){if(U==null)return U;var qe=[],be=0;return Q(U,qe,"","",function(ee){return q.call(Re,ee,be++)}),qe}function de(U){if(U._status===-1){var q=U._result;q=q(),q.then(function(Re){(U._status===0||U._status===-1)&&(U._status=1,U._result=Re)},function(Re){(U._status===0||U._status===-1)&&(U._status=2,U._result=Re)}),U._status===-1&&(U._status=0,U._result=q)}if(U._status===1)return U._result.default;throw U._result}var re={current:null},X={transition:null},J={ReactCurrentDispatcher:re,ReactCurrentBatchConfig:X,ReactCurrentOwner:L};function le(){throw Error("act(...) is not supported in production builds of React.")}return Ct.Children={map:ie,forEach:function(U,q,Re){ie(U,function(){q.apply(this,arguments)},Re)},count:function(U){var q=0;return ie(U,function(){q++}),q},toArray:function(U){return ie(U,function(q){return q})||[]},only:function(U){if(!H(U))throw Error("React.Children.only expected to receive a single React element child.");return U}},Ct.Component=g,Ct.Fragment=t,Ct.Profiler=a,Ct.PureComponent=N,Ct.StrictMode=r,Ct.Suspense=f,Ct.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=J,Ct.act=le,Ct.cloneElement=function(U,q,Re){if(U==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+U+".");var qe=M({},U.props),be=U.key,ee=U.ref,me=U._owner;if(q!=null){if(q.ref!==void 0&&(ee=q.ref,me=L.current),q.key!==void 0&&(be=""+q.key),U.type&&U.type.defaultProps)var ve=U.type.defaultProps;for(ce in q)D.call(q,ce)&&!O.hasOwnProperty(ce)&&(qe[ce]=q[ce]===void 0&&ve!==void 0?ve[ce]:q[ce])}var ce=arguments.length-2;if(ce===1)qe.children=Re;else if(1<ce){ve=Array(ce);for(var we=0;we<ce;we++)ve[we]=arguments[we+2];qe.children=ve}return{$$typeof:s,type:U.type,key:be,ref:ee,props:qe,_owner:me}},Ct.createContext=function(U){return U={$$typeof:d,_currentValue:U,_currentValue2:U,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},U.Provider={$$typeof:l,_context:U},U.Consumer=U},Ct.createElement=T,Ct.createFactory=function(U){var q=T.bind(null,U);return q.type=U,q},Ct.createRef=function(){return{current:null}},Ct.forwardRef=function(U){return{$$typeof:h,render:U}},Ct.isValidElement=H,Ct.lazy=function(U){return{$$typeof:_,_payload:{_status:-1,_result:U},_init:de}},Ct.memo=function(U,q){return{$$typeof:m,type:U,compare:q===void 0?null:q}},Ct.startTransition=function(U){var q=X.transition;X.transition={};try{U()}finally{X.transition=q}},Ct.unstable_act=le,Ct.useCallback=function(U,q){return re.current.useCallback(U,q)},Ct.useContext=function(U){return re.current.useContext(U)},Ct.useDebugValue=function(){},Ct.useDeferredValue=function(U){return re.current.useDeferredValue(U)},Ct.useEffect=function(U,q){return re.current.useEffect(U,q)},Ct.useId=function(){return re.current.useId()},Ct.useImperativeHandle=function(U,q,Re){return re.current.useImperativeHandle(U,q,Re)},Ct.useInsertionEffect=function(U,q){return re.current.useInsertionEffect(U,q)},Ct.useLayoutEffect=function(U,q){return re.current.useLayoutEffect(U,q)},Ct.useMemo=function(U,q){return re.current.useMemo(U,q)},Ct.useReducer=function(U,q,Re){return re.current.useReducer(U,q,Re)},Ct.useRef=function(U){return re.current.useRef(U)},Ct.useState=function(U){return re.current.useState(U)},Ct.useSyncExternalStore=function(U,q,Re){return re.current.useSyncExternalStore(U,q,Re)},Ct.useTransition=function(){return re.current.useTransition()},Ct.version="18.3.1",Ct}var Nm;function Gh(){return Nm||(Nm=1,dd.exports=Lv()),dd.exports}/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Lm;function Dv(){if(Lm)return so;Lm=1;var s=Gh(),e=Symbol.for("react.element"),t=Symbol.for("react.fragment"),r=Object.prototype.hasOwnProperty,a=s.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,l={key:!0,ref:!0,__self:!0,__source:!0};function d(h,f,m){var _,S={},v=null,b=null;m!==void 0&&(v=""+m),f.key!==void 0&&(v=""+f.key),f.ref!==void 0&&(b=f.ref);for(_ in f)r.call(f,_)&&!l.hasOwnProperty(_)&&(S[_]=f[_]);if(h&&h.defaultProps)for(_ in f=h.defaultProps,f)S[_]===void 0&&(S[_]=f[_]);return{$$typeof:e,type:h,key:v,ref:b,props:S,_owner:a.current}}return so.Fragment=t,so.jsx=d,so.jsxs=d,so}var Dm;function Iv(){return Dm||(Dm=1,ud.exports=Dv()),ud.exports}var c=Iv(),Y=Gh();const kv=tg(Y);var Rl={},hd={exports:{}},ni={},fd={exports:{}},pd={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Im;function Fv(){return Im||(Im=1,(function(s){function e(X,J){var le=X.length;X.push(J);e:for(;0<le;){var U=le-1>>>1,q=X[U];if(0<a(q,J))X[U]=J,X[le]=q,le=U;else break e}}function t(X){return X.length===0?null:X[0]}function r(X){if(X.length===0)return null;var J=X[0],le=X.pop();if(le!==J){X[0]=le;e:for(var U=0,q=X.length,Re=q>>>1;U<Re;){var qe=2*(U+1)-1,be=X[qe],ee=qe+1,me=X[ee];if(0>a(be,le))ee<q&&0>a(me,be)?(X[U]=me,X[ee]=le,U=ee):(X[U]=be,X[qe]=le,U=qe);else if(ee<q&&0>a(me,le))X[U]=me,X[ee]=le,U=ee;else break e}}return J}function a(X,J){var le=X.sortIndex-J.sortIndex;return le!==0?le:X.id-J.id}if(typeof performance=="object"&&typeof performance.now=="function"){var l=performance;s.unstable_now=function(){return l.now()}}else{var d=Date,h=d.now();s.unstable_now=function(){return d.now()-h}}var f=[],m=[],_=1,S=null,v=3,b=!1,M=!1,E=!1,g=typeof setTimeout=="function"?setTimeout:null,x=typeof clearTimeout=="function"?clearTimeout:null,N=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function P(X){for(var J=t(m);J!==null;){if(J.callback===null)r(m);else if(J.startTime<=X)r(m),J.sortIndex=J.expirationTime,e(f,J);else break;J=t(m)}}function C(X){if(E=!1,P(X),!M)if(t(f)!==null)M=!0,de(D);else{var J=t(m);J!==null&&re(C,J.startTime-X)}}function D(X,J){M=!1,E&&(E=!1,x(T),T=-1),b=!0;var le=v;try{for(P(J),S=t(f);S!==null&&(!(S.expirationTime>J)||X&&!B());){var U=S.callback;if(typeof U=="function"){S.callback=null,v=S.priorityLevel;var q=U(S.expirationTime<=J);J=s.unstable_now(),typeof q=="function"?S.callback=q:S===t(f)&&r(f),P(J)}else r(f);S=t(f)}if(S!==null)var Re=!0;else{var qe=t(m);qe!==null&&re(C,qe.startTime-J),Re=!1}return Re}finally{S=null,v=le,b=!1}}var L=!1,O=null,T=-1,I=5,H=-1;function B(){return!(s.unstable_now()-H<I)}function V(){if(O!==null){var X=s.unstable_now();H=X;var J=!0;try{J=O(!0,X)}finally{J?ae():(L=!1,O=null)}}else L=!1}var ae;if(typeof N=="function")ae=function(){N(V)};else if(typeof MessageChannel<"u"){var Q=new MessageChannel,ie=Q.port2;Q.port1.onmessage=V,ae=function(){ie.postMessage(null)}}else ae=function(){g(V,0)};function de(X){O=X,L||(L=!0,ae())}function re(X,J){T=g(function(){X(s.unstable_now())},J)}s.unstable_IdlePriority=5,s.unstable_ImmediatePriority=1,s.unstable_LowPriority=4,s.unstable_NormalPriority=3,s.unstable_Profiling=null,s.unstable_UserBlockingPriority=2,s.unstable_cancelCallback=function(X){X.callback=null},s.unstable_continueExecution=function(){M||b||(M=!0,de(D))},s.unstable_forceFrameRate=function(X){0>X||125<X?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):I=0<X?Math.floor(1e3/X):5},s.unstable_getCurrentPriorityLevel=function(){return v},s.unstable_getFirstCallbackNode=function(){return t(f)},s.unstable_next=function(X){switch(v){case 1:case 2:case 3:var J=3;break;default:J=v}var le=v;v=J;try{return X()}finally{v=le}},s.unstable_pauseExecution=function(){},s.unstable_requestPaint=function(){},s.unstable_runWithPriority=function(X,J){switch(X){case 1:case 2:case 3:case 4:case 5:break;default:X=3}var le=v;v=X;try{return J()}finally{v=le}},s.unstable_scheduleCallback=function(X,J,le){var U=s.unstable_now();switch(typeof le=="object"&&le!==null?(le=le.delay,le=typeof le=="number"&&0<le?U+le:U):le=U,X){case 1:var q=-1;break;case 2:q=250;break;case 5:q=1073741823;break;case 4:q=1e4;break;default:q=5e3}return q=le+q,X={id:_++,callback:J,priorityLevel:X,startTime:le,expirationTime:q,sortIndex:-1},le>U?(X.sortIndex=le,e(m,X),t(f)===null&&X===t(m)&&(E?(x(T),T=-1):E=!0,re(C,le-U))):(X.sortIndex=q,e(f,X),M||b||(M=!0,de(D))),X},s.unstable_shouldYield=B,s.unstable_wrapCallback=function(X){var J=v;return function(){var le=v;v=J;try{return X.apply(this,arguments)}finally{v=le}}}})(pd)),pd}var km;function Uv(){return km||(km=1,fd.exports=Fv()),fd.exports}/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Fm;function Ov(){if(Fm)return ni;Fm=1;var s=Gh(),e=Uv();function t(n){for(var i="https://reactjs.org/docs/error-decoder.html?invariant="+n,o=1;o<arguments.length;o++)i+="&args[]="+encodeURIComponent(arguments[o]);return"Minified React error #"+n+"; visit "+i+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var r=new Set,a={};function l(n,i){d(n,i),d(n+"Capture",i)}function d(n,i){for(a[n]=i,n=0;n<i.length;n++)r.add(i[n])}var h=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),f=Object.prototype.hasOwnProperty,m=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,_={},S={};function v(n){return f.call(S,n)?!0:f.call(_,n)?!1:m.test(n)?S[n]=!0:(_[n]=!0,!1)}function b(n,i,o,u){if(o!==null&&o.type===0)return!1;switch(typeof i){case"function":case"symbol":return!0;case"boolean":return u?!1:o!==null?!o.acceptsBooleans:(n=n.toLowerCase().slice(0,5),n!=="data-"&&n!=="aria-");default:return!1}}function M(n,i,o,u){if(i===null||typeof i>"u"||b(n,i,o,u))return!0;if(u)return!1;if(o!==null)switch(o.type){case 3:return!i;case 4:return i===!1;case 5:return isNaN(i);case 6:return isNaN(i)||1>i}return!1}function E(n,i,o,u,p,y,A){this.acceptsBooleans=i===2||i===3||i===4,this.attributeName=u,this.attributeNamespace=p,this.mustUseProperty=o,this.propertyName=n,this.type=i,this.sanitizeURL=y,this.removeEmptyString=A}var g={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(n){g[n]=new E(n,0,!1,n,null,!1,!1)}),[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(n){var i=n[0];g[i]=new E(i,1,!1,n[1],null,!1,!1)}),["contentEditable","draggable","spellCheck","value"].forEach(function(n){g[n]=new E(n,2,!1,n.toLowerCase(),null,!1,!1)}),["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(n){g[n]=new E(n,2,!1,n,null,!1,!1)}),"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(n){g[n]=new E(n,3,!1,n.toLowerCase(),null,!1,!1)}),["checked","multiple","muted","selected"].forEach(function(n){g[n]=new E(n,3,!0,n,null,!1,!1)}),["capture","download"].forEach(function(n){g[n]=new E(n,4,!1,n,null,!1,!1)}),["cols","rows","size","span"].forEach(function(n){g[n]=new E(n,6,!1,n,null,!1,!1)}),["rowSpan","start"].forEach(function(n){g[n]=new E(n,5,!1,n.toLowerCase(),null,!1,!1)});var x=/[\-:]([a-z])/g;function N(n){return n[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(n){var i=n.replace(x,N);g[i]=new E(i,1,!1,n,null,!1,!1)}),"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(n){var i=n.replace(x,N);g[i]=new E(i,1,!1,n,"http://www.w3.org/1999/xlink",!1,!1)}),["xml:base","xml:lang","xml:space"].forEach(function(n){var i=n.replace(x,N);g[i]=new E(i,1,!1,n,"http://www.w3.org/XML/1998/namespace",!1,!1)}),["tabIndex","crossOrigin"].forEach(function(n){g[n]=new E(n,1,!1,n.toLowerCase(),null,!1,!1)}),g.xlinkHref=new E("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1),["src","href","action","formAction"].forEach(function(n){g[n]=new E(n,1,!1,n.toLowerCase(),null,!0,!0)});function P(n,i,o,u){var p=g.hasOwnProperty(i)?g[i]:null;(p!==null?p.type!==0:u||!(2<i.length)||i[0]!=="o"&&i[0]!=="O"||i[1]!=="n"&&i[1]!=="N")&&(M(i,o,p,u)&&(o=null),u||p===null?v(i)&&(o===null?n.removeAttribute(i):n.setAttribute(i,""+o)):p.mustUseProperty?n[p.propertyName]=o===null?p.type===3?!1:"":o:(i=p.attributeName,u=p.attributeNamespace,o===null?n.removeAttribute(i):(p=p.type,o=p===3||p===4&&o===!0?"":""+o,u?n.setAttributeNS(u,i,o):n.setAttribute(i,o))))}var C=s.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,D=Symbol.for("react.element"),L=Symbol.for("react.portal"),O=Symbol.for("react.fragment"),T=Symbol.for("react.strict_mode"),I=Symbol.for("react.profiler"),H=Symbol.for("react.provider"),B=Symbol.for("react.context"),V=Symbol.for("react.forward_ref"),ae=Symbol.for("react.suspense"),Q=Symbol.for("react.suspense_list"),ie=Symbol.for("react.memo"),de=Symbol.for("react.lazy"),re=Symbol.for("react.offscreen"),X=Symbol.iterator;function J(n){return n===null||typeof n!="object"?null:(n=X&&n[X]||n["@@iterator"],typeof n=="function"?n:null)}var le=Object.assign,U;function q(n){if(U===void 0)try{throw Error()}catch(o){var i=o.stack.trim().match(/\n( *(at )?)/);U=i&&i[1]||""}return`
`+U+n}var Re=!1;function qe(n,i){if(!n||Re)return"";Re=!0;var o=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(i)if(i=function(){throw Error()},Object.defineProperty(i.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(i,[])}catch(xe){var u=xe}Reflect.construct(n,[],i)}else{try{i.call()}catch(xe){u=xe}n.call(i.prototype)}else{try{throw Error()}catch(xe){u=xe}n()}}catch(xe){if(xe&&u&&typeof xe.stack=="string"){for(var p=xe.stack.split(`
`),y=u.stack.split(`
`),A=p.length-1,z=y.length-1;1<=A&&0<=z&&p[A]!==y[z];)z--;for(;1<=A&&0<=z;A--,z--)if(p[A]!==y[z]){if(A!==1||z!==1)do if(A--,z--,0>z||p[A]!==y[z]){var W=`
`+p[A].replace(" at new "," at ");return n.displayName&&W.includes("<anonymous>")&&(W=W.replace("<anonymous>",n.displayName)),W}while(1<=A&&0<=z);break}}}finally{Re=!1,Error.prepareStackTrace=o}return(n=n?n.displayName||n.name:"")?q(n):""}function be(n){switch(n.tag){case 5:return q(n.type);case 16:return q("Lazy");case 13:return q("Suspense");case 19:return q("SuspenseList");case 0:case 2:case 15:return n=qe(n.type,!1),n;case 11:return n=qe(n.type.render,!1),n;case 1:return n=qe(n.type,!0),n;default:return""}}function ee(n){if(n==null)return null;if(typeof n=="function")return n.displayName||n.name||null;if(typeof n=="string")return n;switch(n){case O:return"Fragment";case L:return"Portal";case I:return"Profiler";case T:return"StrictMode";case ae:return"Suspense";case Q:return"SuspenseList"}if(typeof n=="object")switch(n.$$typeof){case B:return(n.displayName||"Context")+".Consumer";case H:return(n._context.displayName||"Context")+".Provider";case V:var i=n.render;return n=n.displayName,n||(n=i.displayName||i.name||"",n=n!==""?"ForwardRef("+n+")":"ForwardRef"),n;case ie:return i=n.displayName||null,i!==null?i:ee(n.type)||"Memo";case de:i=n._payload,n=n._init;try{return ee(n(i))}catch{}}return null}function me(n){var i=n.type;switch(n.tag){case 24:return"Cache";case 9:return(i.displayName||"Context")+".Consumer";case 10:return(i._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return n=i.render,n=n.displayName||n.name||"",i.displayName||(n!==""?"ForwardRef("+n+")":"ForwardRef");case 7:return"Fragment";case 5:return i;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return ee(i);case 8:return i===T?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof i=="function")return i.displayName||i.name||null;if(typeof i=="string")return i}return null}function ve(n){switch(typeof n){case"boolean":case"number":case"string":case"undefined":return n;case"object":return n;default:return""}}function ce(n){var i=n.type;return(n=n.nodeName)&&n.toLowerCase()==="input"&&(i==="checkbox"||i==="radio")}function we(n){var i=ce(n)?"checked":"value",o=Object.getOwnPropertyDescriptor(n.constructor.prototype,i),u=""+n[i];if(!n.hasOwnProperty(i)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var p=o.get,y=o.set;return Object.defineProperty(n,i,{configurable:!0,get:function(){return p.call(this)},set:function(A){u=""+A,y.call(this,A)}}),Object.defineProperty(n,i,{enumerable:o.enumerable}),{getValue:function(){return u},setValue:function(A){u=""+A},stopTracking:function(){n._valueTracker=null,delete n[i]}}}}function Ze(n){n._valueTracker||(n._valueTracker=we(n))}function bt(n){if(!n)return!1;var i=n._valueTracker;if(!i)return!0;var o=i.getValue(),u="";return n&&(u=ce(n)?n.checked?"true":"false":n.value),n=u,n!==o?(i.setValue(n),!0):!1}function ot(n){if(n=n||(typeof document<"u"?document:void 0),typeof n>"u")return null;try{return n.activeElement||n.body}catch{return n.body}}function at(n,i){var o=i.checked;return le({},i,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:o??n._wrapperState.initialChecked})}function $e(n,i){var o=i.defaultValue==null?"":i.defaultValue,u=i.checked!=null?i.checked:i.defaultChecked;o=ve(i.value!=null?i.value:o),n._wrapperState={initialChecked:u,initialValue:o,controlled:i.type==="checkbox"||i.type==="radio"?i.checked!=null:i.value!=null}}function Mt(n,i){i=i.checked,i!=null&&P(n,"checked",i,!1)}function St(n,i){Mt(n,i);var o=ve(i.value),u=i.type;if(o!=null)u==="number"?(o===0&&n.value===""||n.value!=o)&&(n.value=""+o):n.value!==""+o&&(n.value=""+o);else if(u==="submit"||u==="reset"){n.removeAttribute("value");return}i.hasOwnProperty("value")?It(n,i.type,o):i.hasOwnProperty("defaultValue")&&It(n,i.type,ve(i.defaultValue)),i.checked==null&&i.defaultChecked!=null&&(n.defaultChecked=!!i.defaultChecked)}function Dt(n,i,o){if(i.hasOwnProperty("value")||i.hasOwnProperty("defaultValue")){var u=i.type;if(!(u!=="submit"&&u!=="reset"||i.value!==void 0&&i.value!==null))return;i=""+n._wrapperState.initialValue,o||i===n.value||(n.value=i),n.defaultValue=i}o=n.name,o!==""&&(n.name=""),n.defaultChecked=!!n._wrapperState.initialChecked,o!==""&&(n.name=o)}function It(n,i,o){(i!=="number"||ot(n.ownerDocument)!==n)&&(o==null?n.defaultValue=""+n._wrapperState.initialValue:n.defaultValue!==""+o&&(n.defaultValue=""+o))}var Nt=Array.isArray;function ht(n,i,o,u){if(n=n.options,i){i={};for(var p=0;p<o.length;p++)i["$"+o[p]]=!0;for(o=0;o<n.length;o++)p=i.hasOwnProperty("$"+n[o].value),n[o].selected!==p&&(n[o].selected=p),p&&u&&(n[o].defaultSelected=!0)}else{for(o=""+ve(o),i=null,p=0;p<n.length;p++){if(n[p].value===o){n[p].selected=!0,u&&(n[p].defaultSelected=!0);return}i!==null||n[p].disabled||(i=n[p])}i!==null&&(i.selected=!0)}}function jt(n,i){if(i.dangerouslySetInnerHTML!=null)throw Error(t(91));return le({},i,{value:void 0,defaultValue:void 0,children:""+n._wrapperState.initialValue})}function j(n,i){var o=i.value;if(o==null){if(o=i.children,i=i.defaultValue,o!=null){if(i!=null)throw Error(t(92));if(Nt(o)){if(1<o.length)throw Error(t(93));o=o[0]}i=o}i==null&&(i=""),o=i}n._wrapperState={initialValue:ve(o)}}function Qe(n,i){var o=ve(i.value),u=ve(i.defaultValue);o!=null&&(o=""+o,o!==n.value&&(n.value=o),i.defaultValue==null&&n.defaultValue!==o&&(n.defaultValue=o)),u!=null&&(n.defaultValue=""+u)}function je(n){var i=n.textContent;i===n._wrapperState.initialValue&&i!==""&&i!==null&&(n.value=i)}function k(n){switch(n){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function w(n,i){return n==null||n==="http://www.w3.org/1999/xhtml"?k(i):n==="http://www.w3.org/2000/svg"&&i==="foreignObject"?"http://www.w3.org/1999/xhtml":n}var $,se=(function(n){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(i,o,u,p){MSApp.execUnsafeLocalFunction(function(){return n(i,o,u,p)})}:n})(function(n,i){if(n.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in n)n.innerHTML=i;else{for($=$||document.createElement("div"),$.innerHTML="<svg>"+i.valueOf().toString()+"</svg>",i=$.firstChild;n.firstChild;)n.removeChild(n.firstChild);for(;i.firstChild;)n.appendChild(i.firstChild)}});function he(n,i){if(i){var o=n.firstChild;if(o&&o===n.lastChild&&o.nodeType===3){o.nodeValue=i;return}}n.textContent=i}var Me={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},Ee=["Webkit","ms","Moz","O"];Object.keys(Me).forEach(function(n){Ee.forEach(function(i){i=i+n.charAt(0).toUpperCase()+n.substring(1),Me[i]=Me[n]})});function _e(n,i,o){return i==null||typeof i=="boolean"||i===""?"":o||typeof i!="number"||i===0||Me.hasOwnProperty(n)&&Me[n]?(""+i).trim():i+"px"}function fe(n,i){n=n.style;for(var o in i)if(i.hasOwnProperty(o)){var u=o.indexOf("--")===0,p=_e(o,i[o],u);o==="float"&&(o="cssFloat"),u?n.setProperty(o,p):n[o]=p}}var ke=le({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function We(n,i){if(i){if(ke[n]&&(i.children!=null||i.dangerouslySetInnerHTML!=null))throw Error(t(137,n));if(i.dangerouslySetInnerHTML!=null){if(i.children!=null)throw Error(t(60));if(typeof i.dangerouslySetInnerHTML!="object"||!("__html"in i.dangerouslySetInnerHTML))throw Error(t(61))}if(i.style!=null&&typeof i.style!="object")throw Error(t(62))}}function Ue(n,i){if(n.indexOf("-")===-1)return typeof i.is=="string";switch(n){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Le=null;function Xe(n){return n=n.target||n.srcElement||window,n.correspondingUseElement&&(n=n.correspondingUseElement),n.nodeType===3?n.parentNode:n}var tt=null,lt=null,F=null;function ye(n){if(n=Va(n)){if(typeof tt!="function")throw Error(t(280));var i=n.stateNode;i&&(i=Vo(i),tt(n.stateNode,n.type,i))}}function ge(n){lt?F?F.push(n):F=[n]:lt=n}function Pe(){if(lt){var n=lt,i=F;if(F=lt=null,ye(n),i)for(n=0;n<i.length;n++)ye(i[n])}}function Ae(n,i){return n(i)}function Se(){}var Oe=!1;function He(n,i,o){if(Oe)return n(i,o);Oe=!0;try{return Ae(n,i,o)}finally{Oe=!1,(lt!==null||F!==null)&&(Se(),Pe())}}function Tt(n,i){var o=n.stateNode;if(o===null)return null;var u=Vo(o);if(u===null)return null;o=u[i];e:switch(i){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(u=!u.disabled)||(n=n.type,u=!(n==="button"||n==="input"||n==="select"||n==="textarea")),n=!u;break e;default:n=!1}if(n)return null;if(o&&typeof o!="function")throw Error(t(231,i,typeof o));return o}var dt=!1;if(h)try{var Ft={};Object.defineProperty(Ft,"passive",{get:function(){dt=!0}}),window.addEventListener("test",Ft,Ft),window.removeEventListener("test",Ft,Ft)}catch{dt=!1}function ln(n,i,o,u,p,y,A,z,W){var xe=Array.prototype.slice.call(arguments,3);try{i.apply(o,xe)}catch(Ne){this.onError(Ne)}}var Dn=!1,In=null,oi=!1,mi=null,As={onError:function(n){Dn=!0,In=n}};function Cs(n,i,o,u,p,y,A,z,W){Dn=!1,In=null,ln.apply(As,arguments)}function es(n,i,o,u,p,y,A,z,W){if(Cs.apply(this,arguments),Dn){if(Dn){var xe=In;Dn=!1,In=null}else throw Error(t(198));oi||(oi=!0,mi=xe)}}function xn(n){var i=n,o=n;if(n.alternate)for(;i.return;)i=i.return;else{n=i;do i=n,(i.flags&4098)!==0&&(o=i.return),n=i.return;while(n)}return i.tag===3?o:null}function Hi(n){if(n.tag===13){var i=n.memoizedState;if(i===null&&(n=n.alternate,n!==null&&(i=n.memoizedState)),i!==null)return i.dehydrated}return null}function _r(n){if(xn(n)!==n)throw Error(t(188))}function _t(n){var i=n.alternate;if(!i){if(i=xn(n),i===null)throw Error(t(188));return i!==n?null:n}for(var o=n,u=i;;){var p=o.return;if(p===null)break;var y=p.alternate;if(y===null){if(u=p.return,u!==null){o=u;continue}break}if(p.child===y.child){for(y=p.child;y;){if(y===o)return _r(p),n;if(y===u)return _r(p),i;y=y.sibling}throw Error(t(188))}if(o.return!==u.return)o=p,u=y;else{for(var A=!1,z=p.child;z;){if(z===o){A=!0,o=p,u=y;break}if(z===u){A=!0,u=p,o=y;break}z=z.sibling}if(!A){for(z=y.child;z;){if(z===o){A=!0,o=y,u=p;break}if(z===u){A=!0,u=y,o=p;break}z=z.sibling}if(!A)throw Error(t(189))}}if(o.alternate!==u)throw Error(t(190))}if(o.tag!==3)throw Error(t(188));return o.stateNode.current===o?n:i}function Ot(n){return n=_t(n),n!==null?cn(n):null}function cn(n){if(n.tag===5||n.tag===6)return n;for(n=n.child;n!==null;){var i=cn(n);if(i!==null)return i;n=n.sibling}return null}var $t=e.unstable_scheduleCallback,hn=e.unstable_cancelCallback,rn=e.unstable_shouldYield,sn=e.unstable_requestPaint,Ht=e.unstable_now,yr=e.unstable_getCurrentPriorityLevel,Kt=e.unstable_ImmediatePriority,R=e.unstable_UserBlockingPriority,G=e.unstable_NormalPriority,oe=e.unstable_LowPriority,te=e.unstable_IdlePriority,ne=null,Te=null;function Be(n){if(Te&&typeof Te.onCommitFiberRoot=="function")try{Te.onCommitFiberRoot(ne,n,void 0,(n.current.flags&128)===128)}catch{}}var De=Math.clz32?Math.clz32:mt,ze=Math.log,Ve=Math.LN2;function mt(n){return n>>>=0,n===0?32:31-(ze(n)/Ve|0)|0}var ct=64,et=4194304;function Pt(n){switch(n&-n){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return n&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return n}}function Xt(n,i){var o=n.pendingLanes;if(o===0)return 0;var u=0,p=n.suspendedLanes,y=n.pingedLanes,A=o&268435455;if(A!==0){var z=A&~p;z!==0?u=Pt(z):(y&=A,y!==0&&(u=Pt(y)))}else A=o&~p,A!==0?u=Pt(A):y!==0&&(u=Pt(y));if(u===0)return 0;if(i!==0&&i!==u&&(i&p)===0&&(p=u&-u,y=i&-i,p>=y||p===16&&(y&4194240)!==0))return i;if((u&4)!==0&&(u|=o&16),i=n.entangledLanes,i!==0)for(n=n.entanglements,i&=u;0<i;)o=31-De(i),p=1<<o,u|=n[o],i&=~p;return u}function en(n,i){switch(n){case 1:case 2:case 4:return i+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return i+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Gt(n,i){for(var o=n.suspendedLanes,u=n.pingedLanes,p=n.expirationTimes,y=n.pendingLanes;0<y;){var A=31-De(y),z=1<<A,W=p[A];W===-1?((z&o)===0||(z&u)!==0)&&(p[A]=en(z,i)):W<=i&&(n.expiredLanes|=z),y&=~z}}function pn(n){return n=n.pendingLanes&-1073741825,n!==0?n:n&1073741824?1073741824:0}function Ye(){var n=ct;return ct<<=1,(ct&4194240)===0&&(ct=64),n}function Rn(n){for(var i=[],o=0;31>o;o++)i.push(n);return i}function Et(n,i,o){n.pendingLanes|=i,i!==536870912&&(n.suspendedLanes=0,n.pingedLanes=0),n=n.eventTimes,i=31-De(i),n[i]=o}function Yn(n,i){var o=n.pendingLanes&~i;n.pendingLanes=i,n.suspendedLanes=0,n.pingedLanes=0,n.expiredLanes&=i,n.mutableReadLanes&=i,n.entangledLanes&=i,i=n.entanglements;var u=n.eventTimes;for(n=n.expirationTimes;0<o;){var p=31-De(o),y=1<<p;i[p]=0,u[p]=-1,n[p]=-1,o&=~y}}function Kn(n,i){var o=n.entangledLanes|=i;for(n=n.entanglements;o;){var u=31-De(o),p=1<<u;p&i|n[u]&i&&(n[u]|=i),o&=~p}}var At=0;function tr(n){return n&=-n,1<n?4<n?(n&268435455)!==0?16:536870912:4:1}var zt,Zt,Ai,Vt,Ci,Gi=!1,ts=[],br=null,Sr=null,Mr=null,Ca=new Map,Ra=new Map,wr=[],ex="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function ff(n,i){switch(n){case"focusin":case"focusout":br=null;break;case"dragenter":case"dragleave":Sr=null;break;case"mouseover":case"mouseout":Mr=null;break;case"pointerover":case"pointerout":Ca.delete(i.pointerId);break;case"gotpointercapture":case"lostpointercapture":Ra.delete(i.pointerId)}}function Pa(n,i,o,u,p,y){return n===null||n.nativeEvent!==y?(n={blockedOn:i,domEventName:o,eventSystemFlags:u,nativeEvent:y,targetContainers:[p]},i!==null&&(i=Va(i),i!==null&&Zt(i)),n):(n.eventSystemFlags|=u,i=n.targetContainers,p!==null&&i.indexOf(p)===-1&&i.push(p),n)}function tx(n,i,o,u,p){switch(i){case"focusin":return br=Pa(br,n,i,o,u,p),!0;case"dragenter":return Sr=Pa(Sr,n,i,o,u,p),!0;case"mouseover":return Mr=Pa(Mr,n,i,o,u,p),!0;case"pointerover":var y=p.pointerId;return Ca.set(y,Pa(Ca.get(y)||null,n,i,o,u,p)),!0;case"gotpointercapture":return y=p.pointerId,Ra.set(y,Pa(Ra.get(y)||null,n,i,o,u,p)),!0}return!1}function pf(n){var i=ns(n.target);if(i!==null){var o=xn(i);if(o!==null){if(i=o.tag,i===13){if(i=Hi(o),i!==null){n.blockedOn=i,Ci(n.priority,function(){Ai(o)});return}}else if(i===3&&o.stateNode.current.memoizedState.isDehydrated){n.blockedOn=o.tag===3?o.stateNode.containerInfo:null;return}}}n.blockedOn=null}function Po(n){if(n.blockedOn!==null)return!1;for(var i=n.targetContainers;0<i.length;){var o=Uc(n.domEventName,n.eventSystemFlags,i[0],n.nativeEvent);if(o===null){o=n.nativeEvent;var u=new o.constructor(o.type,o);Le=u,o.target.dispatchEvent(u),Le=null}else return i=Va(o),i!==null&&Zt(i),n.blockedOn=o,!1;i.shift()}return!0}function mf(n,i,o){Po(n)&&o.delete(i)}function nx(){Gi=!1,br!==null&&Po(br)&&(br=null),Sr!==null&&Po(Sr)&&(Sr=null),Mr!==null&&Po(Mr)&&(Mr=null),Ca.forEach(mf),Ra.forEach(mf)}function Na(n,i){n.blockedOn===i&&(n.blockedOn=null,Gi||(Gi=!0,e.unstable_scheduleCallback(e.unstable_NormalPriority,nx)))}function La(n){function i(p){return Na(p,n)}if(0<ts.length){Na(ts[0],n);for(var o=1;o<ts.length;o++){var u=ts[o];u.blockedOn===n&&(u.blockedOn=null)}}for(br!==null&&Na(br,n),Sr!==null&&Na(Sr,n),Mr!==null&&Na(Mr,n),Ca.forEach(i),Ra.forEach(i),o=0;o<wr.length;o++)u=wr[o],u.blockedOn===n&&(u.blockedOn=null);for(;0<wr.length&&(o=wr[0],o.blockedOn===null);)pf(o),o.blockedOn===null&&wr.shift()}var Rs=C.ReactCurrentBatchConfig,No=!0;function ix(n,i,o,u){var p=At,y=Rs.transition;Rs.transition=null;try{At=1,Fc(n,i,o,u)}finally{At=p,Rs.transition=y}}function rx(n,i,o,u){var p=At,y=Rs.transition;Rs.transition=null;try{At=4,Fc(n,i,o,u)}finally{At=p,Rs.transition=y}}function Fc(n,i,o,u){if(No){var p=Uc(n,i,o,u);if(p===null)eu(n,i,u,Lo,o),ff(n,u);else if(tx(p,n,i,o,u))u.stopPropagation();else if(ff(n,u),i&4&&-1<ex.indexOf(n)){for(;p!==null;){var y=Va(p);if(y!==null&&zt(y),y=Uc(n,i,o,u),y===null&&eu(n,i,u,Lo,o),y===p)break;p=y}p!==null&&u.stopPropagation()}else eu(n,i,u,null,o)}}var Lo=null;function Uc(n,i,o,u){if(Lo=null,n=Xe(u),n=ns(n),n!==null)if(i=xn(n),i===null)n=null;else if(o=i.tag,o===13){if(n=Hi(i),n!==null)return n;n=null}else if(o===3){if(i.stateNode.current.memoizedState.isDehydrated)return i.tag===3?i.stateNode.containerInfo:null;n=null}else i!==n&&(n=null);return Lo=n,null}function gf(n){switch(n){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(yr()){case Kt:return 1;case R:return 4;case G:case oe:return 16;case te:return 536870912;default:return 16}default:return 16}}var Er=null,Oc=null,Do=null;function xf(){if(Do)return Do;var n,i=Oc,o=i.length,u,p="value"in Er?Er.value:Er.textContent,y=p.length;for(n=0;n<o&&i[n]===p[n];n++);var A=o-n;for(u=1;u<=A&&i[o-u]===p[y-u];u++);return Do=p.slice(n,1<u?1-u:void 0)}function Io(n){var i=n.keyCode;return"charCode"in n?(n=n.charCode,n===0&&i===13&&(n=13)):n=i,n===10&&(n=13),32<=n||n===13?n:0}function ko(){return!0}function vf(){return!1}function li(n){function i(o,u,p,y,A){this._reactName=o,this._targetInst=p,this.type=u,this.nativeEvent=y,this.target=A,this.currentTarget=null;for(var z in n)n.hasOwnProperty(z)&&(o=n[z],this[z]=o?o(y):y[z]);return this.isDefaultPrevented=(y.defaultPrevented!=null?y.defaultPrevented:y.returnValue===!1)?ko:vf,this.isPropagationStopped=vf,this}return le(i.prototype,{preventDefault:function(){this.defaultPrevented=!0;var o=this.nativeEvent;o&&(o.preventDefault?o.preventDefault():typeof o.returnValue!="unknown"&&(o.returnValue=!1),this.isDefaultPrevented=ko)},stopPropagation:function(){var o=this.nativeEvent;o&&(o.stopPropagation?o.stopPropagation():typeof o.cancelBubble!="unknown"&&(o.cancelBubble=!0),this.isPropagationStopped=ko)},persist:function(){},isPersistent:ko}),i}var Ps={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(n){return n.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Bc=li(Ps),Da=le({},Ps,{view:0,detail:0}),sx=li(Da),zc,jc,Ia,Fo=le({},Da,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Gc,button:0,buttons:0,relatedTarget:function(n){return n.relatedTarget===void 0?n.fromElement===n.srcElement?n.toElement:n.fromElement:n.relatedTarget},movementX:function(n){return"movementX"in n?n.movementX:(n!==Ia&&(Ia&&n.type==="mousemove"?(zc=n.screenX-Ia.screenX,jc=n.screenY-Ia.screenY):jc=zc=0,Ia=n),zc)},movementY:function(n){return"movementY"in n?n.movementY:jc}}),_f=li(Fo),ax=le({},Fo,{dataTransfer:0}),ox=li(ax),lx=le({},Da,{relatedTarget:0}),Hc=li(lx),cx=le({},Ps,{animationName:0,elapsedTime:0,pseudoElement:0}),ux=li(cx),dx=le({},Ps,{clipboardData:function(n){return"clipboardData"in n?n.clipboardData:window.clipboardData}}),hx=li(dx),fx=le({},Ps,{data:0}),yf=li(fx),px={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},mx={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},gx={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function xx(n){var i=this.nativeEvent;return i.getModifierState?i.getModifierState(n):(n=gx[n])?!!i[n]:!1}function Gc(){return xx}var vx=le({},Da,{key:function(n){if(n.key){var i=px[n.key]||n.key;if(i!=="Unidentified")return i}return n.type==="keypress"?(n=Io(n),n===13?"Enter":String.fromCharCode(n)):n.type==="keydown"||n.type==="keyup"?mx[n.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Gc,charCode:function(n){return n.type==="keypress"?Io(n):0},keyCode:function(n){return n.type==="keydown"||n.type==="keyup"?n.keyCode:0},which:function(n){return n.type==="keypress"?Io(n):n.type==="keydown"||n.type==="keyup"?n.keyCode:0}}),_x=li(vx),yx=le({},Fo,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),bf=li(yx),bx=le({},Da,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Gc}),Sx=li(bx),Mx=le({},Ps,{propertyName:0,elapsedTime:0,pseudoElement:0}),wx=li(Mx),Ex=le({},Fo,{deltaX:function(n){return"deltaX"in n?n.deltaX:"wheelDeltaX"in n?-n.wheelDeltaX:0},deltaY:function(n){return"deltaY"in n?n.deltaY:"wheelDeltaY"in n?-n.wheelDeltaY:"wheelDelta"in n?-n.wheelDelta:0},deltaZ:0,deltaMode:0}),Tx=li(Ex),Ax=[9,13,27,32],Vc=h&&"CompositionEvent"in window,ka=null;h&&"documentMode"in document&&(ka=document.documentMode);var Cx=h&&"TextEvent"in window&&!ka,Sf=h&&(!Vc||ka&&8<ka&&11>=ka),Mf=" ",wf=!1;function Ef(n,i){switch(n){case"keyup":return Ax.indexOf(i.keyCode)!==-1;case"keydown":return i.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Tf(n){return n=n.detail,typeof n=="object"&&"data"in n?n.data:null}var Ns=!1;function Rx(n,i){switch(n){case"compositionend":return Tf(i);case"keypress":return i.which!==32?null:(wf=!0,Mf);case"textInput":return n=i.data,n===Mf&&wf?null:n;default:return null}}function Px(n,i){if(Ns)return n==="compositionend"||!Vc&&Ef(n,i)?(n=xf(),Do=Oc=Er=null,Ns=!1,n):null;switch(n){case"paste":return null;case"keypress":if(!(i.ctrlKey||i.altKey||i.metaKey)||i.ctrlKey&&i.altKey){if(i.char&&1<i.char.length)return i.char;if(i.which)return String.fromCharCode(i.which)}return null;case"compositionend":return Sf&&i.locale!=="ko"?null:i.data;default:return null}}var Nx={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Af(n){var i=n&&n.nodeName&&n.nodeName.toLowerCase();return i==="input"?!!Nx[n.type]:i==="textarea"}function Cf(n,i,o,u){ge(u),i=jo(i,"onChange"),0<i.length&&(o=new Bc("onChange","change",null,o,u),n.push({event:o,listeners:i}))}var Fa=null,Ua=null;function Lx(n){Xf(n,0)}function Uo(n){var i=Fs(n);if(bt(i))return n}function Dx(n,i){if(n==="change")return i}var Rf=!1;if(h){var Wc;if(h){var Xc="oninput"in document;if(!Xc){var Pf=document.createElement("div");Pf.setAttribute("oninput","return;"),Xc=typeof Pf.oninput=="function"}Wc=Xc}else Wc=!1;Rf=Wc&&(!document.documentMode||9<document.documentMode)}function Nf(){Fa&&(Fa.detachEvent("onpropertychange",Lf),Ua=Fa=null)}function Lf(n){if(n.propertyName==="value"&&Uo(Ua)){var i=[];Cf(i,Ua,n,Xe(n)),He(Lx,i)}}function Ix(n,i,o){n==="focusin"?(Nf(),Fa=i,Ua=o,Fa.attachEvent("onpropertychange",Lf)):n==="focusout"&&Nf()}function kx(n){if(n==="selectionchange"||n==="keyup"||n==="keydown")return Uo(Ua)}function Fx(n,i){if(n==="click")return Uo(i)}function Ux(n,i){if(n==="input"||n==="change")return Uo(i)}function Ox(n,i){return n===i&&(n!==0||1/n===1/i)||n!==n&&i!==i}var Ri=typeof Object.is=="function"?Object.is:Ox;function Oa(n,i){if(Ri(n,i))return!0;if(typeof n!="object"||n===null||typeof i!="object"||i===null)return!1;var o=Object.keys(n),u=Object.keys(i);if(o.length!==u.length)return!1;for(u=0;u<o.length;u++){var p=o[u];if(!f.call(i,p)||!Ri(n[p],i[p]))return!1}return!0}function Df(n){for(;n&&n.firstChild;)n=n.firstChild;return n}function If(n,i){var o=Df(n);n=0;for(var u;o;){if(o.nodeType===3){if(u=n+o.textContent.length,n<=i&&u>=i)return{node:o,offset:i-n};n=u}e:{for(;o;){if(o.nextSibling){o=o.nextSibling;break e}o=o.parentNode}o=void 0}o=Df(o)}}function kf(n,i){return n&&i?n===i?!0:n&&n.nodeType===3?!1:i&&i.nodeType===3?kf(n,i.parentNode):"contains"in n?n.contains(i):n.compareDocumentPosition?!!(n.compareDocumentPosition(i)&16):!1:!1}function Ff(){for(var n=window,i=ot();i instanceof n.HTMLIFrameElement;){try{var o=typeof i.contentWindow.location.href=="string"}catch{o=!1}if(o)n=i.contentWindow;else break;i=ot(n.document)}return i}function qc(n){var i=n&&n.nodeName&&n.nodeName.toLowerCase();return i&&(i==="input"&&(n.type==="text"||n.type==="search"||n.type==="tel"||n.type==="url"||n.type==="password")||i==="textarea"||n.contentEditable==="true")}function Bx(n){var i=Ff(),o=n.focusedElem,u=n.selectionRange;if(i!==o&&o&&o.ownerDocument&&kf(o.ownerDocument.documentElement,o)){if(u!==null&&qc(o)){if(i=u.start,n=u.end,n===void 0&&(n=i),"selectionStart"in o)o.selectionStart=i,o.selectionEnd=Math.min(n,o.value.length);else if(n=(i=o.ownerDocument||document)&&i.defaultView||window,n.getSelection){n=n.getSelection();var p=o.textContent.length,y=Math.min(u.start,p);u=u.end===void 0?y:Math.min(u.end,p),!n.extend&&y>u&&(p=u,u=y,y=p),p=If(o,y);var A=If(o,u);p&&A&&(n.rangeCount!==1||n.anchorNode!==p.node||n.anchorOffset!==p.offset||n.focusNode!==A.node||n.focusOffset!==A.offset)&&(i=i.createRange(),i.setStart(p.node,p.offset),n.removeAllRanges(),y>u?(n.addRange(i),n.extend(A.node,A.offset)):(i.setEnd(A.node,A.offset),n.addRange(i)))}}for(i=[],n=o;n=n.parentNode;)n.nodeType===1&&i.push({element:n,left:n.scrollLeft,top:n.scrollTop});for(typeof o.focus=="function"&&o.focus(),o=0;o<i.length;o++)n=i[o],n.element.scrollLeft=n.left,n.element.scrollTop=n.top}}var zx=h&&"documentMode"in document&&11>=document.documentMode,Ls=null,$c=null,Ba=null,Yc=!1;function Uf(n,i,o){var u=o.window===o?o.document:o.nodeType===9?o:o.ownerDocument;Yc||Ls==null||Ls!==ot(u)||(u=Ls,"selectionStart"in u&&qc(u)?u={start:u.selectionStart,end:u.selectionEnd}:(u=(u.ownerDocument&&u.ownerDocument.defaultView||window).getSelection(),u={anchorNode:u.anchorNode,anchorOffset:u.anchorOffset,focusNode:u.focusNode,focusOffset:u.focusOffset}),Ba&&Oa(Ba,u)||(Ba=u,u=jo($c,"onSelect"),0<u.length&&(i=new Bc("onSelect","select",null,i,o),n.push({event:i,listeners:u}),i.target=Ls)))}function Oo(n,i){var o={};return o[n.toLowerCase()]=i.toLowerCase(),o["Webkit"+n]="webkit"+i,o["Moz"+n]="moz"+i,o}var Ds={animationend:Oo("Animation","AnimationEnd"),animationiteration:Oo("Animation","AnimationIteration"),animationstart:Oo("Animation","AnimationStart"),transitionend:Oo("Transition","TransitionEnd")},Kc={},Of={};h&&(Of=document.createElement("div").style,"AnimationEvent"in window||(delete Ds.animationend.animation,delete Ds.animationiteration.animation,delete Ds.animationstart.animation),"TransitionEvent"in window||delete Ds.transitionend.transition);function Bo(n){if(Kc[n])return Kc[n];if(!Ds[n])return n;var i=Ds[n],o;for(o in i)if(i.hasOwnProperty(o)&&o in Of)return Kc[n]=i[o];return n}var Bf=Bo("animationend"),zf=Bo("animationiteration"),jf=Bo("animationstart"),Hf=Bo("transitionend"),Gf=new Map,Vf="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function Tr(n,i){Gf.set(n,i),l(i,[n])}for(var Zc=0;Zc<Vf.length;Zc++){var Qc=Vf[Zc],jx=Qc.toLowerCase(),Hx=Qc[0].toUpperCase()+Qc.slice(1);Tr(jx,"on"+Hx)}Tr(Bf,"onAnimationEnd"),Tr(zf,"onAnimationIteration"),Tr(jf,"onAnimationStart"),Tr("dblclick","onDoubleClick"),Tr("focusin","onFocus"),Tr("focusout","onBlur"),Tr(Hf,"onTransitionEnd"),d("onMouseEnter",["mouseout","mouseover"]),d("onMouseLeave",["mouseout","mouseover"]),d("onPointerEnter",["pointerout","pointerover"]),d("onPointerLeave",["pointerout","pointerover"]),l("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),l("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),l("onBeforeInput",["compositionend","keypress","textInput","paste"]),l("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),l("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),l("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var za="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Gx=new Set("cancel close invalid load scroll toggle".split(" ").concat(za));function Wf(n,i,o){var u=n.type||"unknown-event";n.currentTarget=o,es(u,i,void 0,n),n.currentTarget=null}function Xf(n,i){i=(i&4)!==0;for(var o=0;o<n.length;o++){var u=n[o],p=u.event;u=u.listeners;e:{var y=void 0;if(i)for(var A=u.length-1;0<=A;A--){var z=u[A],W=z.instance,xe=z.currentTarget;if(z=z.listener,W!==y&&p.isPropagationStopped())break e;Wf(p,z,xe),y=W}else for(A=0;A<u.length;A++){if(z=u[A],W=z.instance,xe=z.currentTarget,z=z.listener,W!==y&&p.isPropagationStopped())break e;Wf(p,z,xe),y=W}}}if(oi)throw n=mi,oi=!1,mi=null,n}function Qt(n,i){var o=i[au];o===void 0&&(o=i[au]=new Set);var u=n+"__bubble";o.has(u)||(qf(i,n,2,!1),o.add(u))}function Jc(n,i,o){var u=0;i&&(u|=4),qf(o,n,u,i)}var zo="_reactListening"+Math.random().toString(36).slice(2);function ja(n){if(!n[zo]){n[zo]=!0,r.forEach(function(o){o!=="selectionchange"&&(Gx.has(o)||Jc(o,!1,n),Jc(o,!0,n))});var i=n.nodeType===9?n:n.ownerDocument;i===null||i[zo]||(i[zo]=!0,Jc("selectionchange",!1,i))}}function qf(n,i,o,u){switch(gf(i)){case 1:var p=ix;break;case 4:p=rx;break;default:p=Fc}o=p.bind(null,i,o,n),p=void 0,!dt||i!=="touchstart"&&i!=="touchmove"&&i!=="wheel"||(p=!0),u?p!==void 0?n.addEventListener(i,o,{capture:!0,passive:p}):n.addEventListener(i,o,!0):p!==void 0?n.addEventListener(i,o,{passive:p}):n.addEventListener(i,o,!1)}function eu(n,i,o,u,p){var y=u;if((i&1)===0&&(i&2)===0&&u!==null)e:for(;;){if(u===null)return;var A=u.tag;if(A===3||A===4){var z=u.stateNode.containerInfo;if(z===p||z.nodeType===8&&z.parentNode===p)break;if(A===4)for(A=u.return;A!==null;){var W=A.tag;if((W===3||W===4)&&(W=A.stateNode.containerInfo,W===p||W.nodeType===8&&W.parentNode===p))return;A=A.return}for(;z!==null;){if(A=ns(z),A===null)return;if(W=A.tag,W===5||W===6){u=y=A;continue e}z=z.parentNode}}u=u.return}He(function(){var xe=y,Ne=Xe(o),Ie=[];e:{var Ce=Gf.get(n);if(Ce!==void 0){var Ke=Bc,nt=n;switch(n){case"keypress":if(Io(o)===0)break e;case"keydown":case"keyup":Ke=_x;break;case"focusin":nt="focus",Ke=Hc;break;case"focusout":nt="blur",Ke=Hc;break;case"beforeblur":case"afterblur":Ke=Hc;break;case"click":if(o.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":Ke=_f;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":Ke=ox;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":Ke=Sx;break;case Bf:case zf:case jf:Ke=ux;break;case Hf:Ke=wx;break;case"scroll":Ke=sx;break;case"wheel":Ke=Tx;break;case"copy":case"cut":case"paste":Ke=hx;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":Ke=bf}var it=(i&4)!==0,fn=!it&&n==="scroll",ue=it?Ce!==null?Ce+"Capture":null:Ce;it=[];for(var Z=xe,pe;Z!==null;){pe=Z;var Fe=pe.stateNode;if(pe.tag===5&&Fe!==null&&(pe=Fe,ue!==null&&(Fe=Tt(Z,ue),Fe!=null&&it.push(Ha(Z,Fe,pe)))),fn)break;Z=Z.return}0<it.length&&(Ce=new Ke(Ce,nt,null,o,Ne),Ie.push({event:Ce,listeners:it}))}}if((i&7)===0){e:{if(Ce=n==="mouseover"||n==="pointerover",Ke=n==="mouseout"||n==="pointerout",Ce&&o!==Le&&(nt=o.relatedTarget||o.fromElement)&&(ns(nt)||nt[nr]))break e;if((Ke||Ce)&&(Ce=Ne.window===Ne?Ne:(Ce=Ne.ownerDocument)?Ce.defaultView||Ce.parentWindow:window,Ke?(nt=o.relatedTarget||o.toElement,Ke=xe,nt=nt?ns(nt):null,nt!==null&&(fn=xn(nt),nt!==fn||nt.tag!==5&&nt.tag!==6)&&(nt=null)):(Ke=null,nt=xe),Ke!==nt)){if(it=_f,Fe="onMouseLeave",ue="onMouseEnter",Z="mouse",(n==="pointerout"||n==="pointerover")&&(it=bf,Fe="onPointerLeave",ue="onPointerEnter",Z="pointer"),fn=Ke==null?Ce:Fs(Ke),pe=nt==null?Ce:Fs(nt),Ce=new it(Fe,Z+"leave",Ke,o,Ne),Ce.target=fn,Ce.relatedTarget=pe,Fe=null,ns(Ne)===xe&&(it=new it(ue,Z+"enter",nt,o,Ne),it.target=pe,it.relatedTarget=fn,Fe=it),fn=Fe,Ke&&nt)t:{for(it=Ke,ue=nt,Z=0,pe=it;pe;pe=Is(pe))Z++;for(pe=0,Fe=ue;Fe;Fe=Is(Fe))pe++;for(;0<Z-pe;)it=Is(it),Z--;for(;0<pe-Z;)ue=Is(ue),pe--;for(;Z--;){if(it===ue||ue!==null&&it===ue.alternate)break t;it=Is(it),ue=Is(ue)}it=null}else it=null;Ke!==null&&$f(Ie,Ce,Ke,it,!1),nt!==null&&fn!==null&&$f(Ie,fn,nt,it,!0)}}e:{if(Ce=xe?Fs(xe):window,Ke=Ce.nodeName&&Ce.nodeName.toLowerCase(),Ke==="select"||Ke==="input"&&Ce.type==="file")var st=Dx;else if(Af(Ce))if(Rf)st=Ux;else{st=kx;var ft=Ix}else(Ke=Ce.nodeName)&&Ke.toLowerCase()==="input"&&(Ce.type==="checkbox"||Ce.type==="radio")&&(st=Fx);if(st&&(st=st(n,xe))){Cf(Ie,st,o,Ne);break e}ft&&ft(n,Ce,xe),n==="focusout"&&(ft=Ce._wrapperState)&&ft.controlled&&Ce.type==="number"&&It(Ce,"number",Ce.value)}switch(ft=xe?Fs(xe):window,n){case"focusin":(Af(ft)||ft.contentEditable==="true")&&(Ls=ft,$c=xe,Ba=null);break;case"focusout":Ba=$c=Ls=null;break;case"mousedown":Yc=!0;break;case"contextmenu":case"mouseup":case"dragend":Yc=!1,Uf(Ie,o,Ne);break;case"selectionchange":if(zx)break;case"keydown":case"keyup":Uf(Ie,o,Ne)}var pt;if(Vc)e:{switch(n){case"compositionstart":var xt="onCompositionStart";break e;case"compositionend":xt="onCompositionEnd";break e;case"compositionupdate":xt="onCompositionUpdate";break e}xt=void 0}else Ns?Ef(n,o)&&(xt="onCompositionEnd"):n==="keydown"&&o.keyCode===229&&(xt="onCompositionStart");xt&&(Sf&&o.locale!=="ko"&&(Ns||xt!=="onCompositionStart"?xt==="onCompositionEnd"&&Ns&&(pt=xf()):(Er=Ne,Oc="value"in Er?Er.value:Er.textContent,Ns=!0)),ft=jo(xe,xt),0<ft.length&&(xt=new yf(xt,n,null,o,Ne),Ie.push({event:xt,listeners:ft}),pt?xt.data=pt:(pt=Tf(o),pt!==null&&(xt.data=pt)))),(pt=Cx?Rx(n,o):Px(n,o))&&(xe=jo(xe,"onBeforeInput"),0<xe.length&&(Ne=new yf("onBeforeInput","beforeinput",null,o,Ne),Ie.push({event:Ne,listeners:xe}),Ne.data=pt))}Xf(Ie,i)})}function Ha(n,i,o){return{instance:n,listener:i,currentTarget:o}}function jo(n,i){for(var o=i+"Capture",u=[];n!==null;){var p=n,y=p.stateNode;p.tag===5&&y!==null&&(p=y,y=Tt(n,o),y!=null&&u.unshift(Ha(n,y,p)),y=Tt(n,i),y!=null&&u.push(Ha(n,y,p))),n=n.return}return u}function Is(n){if(n===null)return null;do n=n.return;while(n&&n.tag!==5);return n||null}function $f(n,i,o,u,p){for(var y=i._reactName,A=[];o!==null&&o!==u;){var z=o,W=z.alternate,xe=z.stateNode;if(W!==null&&W===u)break;z.tag===5&&xe!==null&&(z=xe,p?(W=Tt(o,y),W!=null&&A.unshift(Ha(o,W,z))):p||(W=Tt(o,y),W!=null&&A.push(Ha(o,W,z)))),o=o.return}A.length!==0&&n.push({event:i,listeners:A})}var Vx=/\r\n?/g,Wx=/\u0000|\uFFFD/g;function Yf(n){return(typeof n=="string"?n:""+n).replace(Vx,`
`).replace(Wx,"")}function Ho(n,i,o){if(i=Yf(i),Yf(n)!==i&&o)throw Error(t(425))}function Go(){}var tu=null,nu=null;function iu(n,i){return n==="textarea"||n==="noscript"||typeof i.children=="string"||typeof i.children=="number"||typeof i.dangerouslySetInnerHTML=="object"&&i.dangerouslySetInnerHTML!==null&&i.dangerouslySetInnerHTML.__html!=null}var ru=typeof setTimeout=="function"?setTimeout:void 0,Xx=typeof clearTimeout=="function"?clearTimeout:void 0,Kf=typeof Promise=="function"?Promise:void 0,qx=typeof queueMicrotask=="function"?queueMicrotask:typeof Kf<"u"?function(n){return Kf.resolve(null).then(n).catch($x)}:ru;function $x(n){setTimeout(function(){throw n})}function su(n,i){var o=i,u=0;do{var p=o.nextSibling;if(n.removeChild(o),p&&p.nodeType===8)if(o=p.data,o==="/$"){if(u===0){n.removeChild(p),La(i);return}u--}else o!=="$"&&o!=="$?"&&o!=="$!"||u++;o=p}while(o);La(i)}function Ar(n){for(;n!=null;n=n.nextSibling){var i=n.nodeType;if(i===1||i===3)break;if(i===8){if(i=n.data,i==="$"||i==="$!"||i==="$?")break;if(i==="/$")return null}}return n}function Zf(n){n=n.previousSibling;for(var i=0;n;){if(n.nodeType===8){var o=n.data;if(o==="$"||o==="$!"||o==="$?"){if(i===0)return n;i--}else o==="/$"&&i++}n=n.previousSibling}return null}var ks=Math.random().toString(36).slice(2),Vi="__reactFiber$"+ks,Ga="__reactProps$"+ks,nr="__reactContainer$"+ks,au="__reactEvents$"+ks,Yx="__reactListeners$"+ks,Kx="__reactHandles$"+ks;function ns(n){var i=n[Vi];if(i)return i;for(var o=n.parentNode;o;){if(i=o[nr]||o[Vi]){if(o=i.alternate,i.child!==null||o!==null&&o.child!==null)for(n=Zf(n);n!==null;){if(o=n[Vi])return o;n=Zf(n)}return i}n=o,o=n.parentNode}return null}function Va(n){return n=n[Vi]||n[nr],!n||n.tag!==5&&n.tag!==6&&n.tag!==13&&n.tag!==3?null:n}function Fs(n){if(n.tag===5||n.tag===6)return n.stateNode;throw Error(t(33))}function Vo(n){return n[Ga]||null}var ou=[],Us=-1;function Cr(n){return{current:n}}function Jt(n){0>Us||(n.current=ou[Us],ou[Us]=null,Us--)}function Yt(n,i){Us++,ou[Us]=n.current,n.current=i}var Rr={},kn=Cr(Rr),Zn=Cr(!1),is=Rr;function Os(n,i){var o=n.type.contextTypes;if(!o)return Rr;var u=n.stateNode;if(u&&u.__reactInternalMemoizedUnmaskedChildContext===i)return u.__reactInternalMemoizedMaskedChildContext;var p={},y;for(y in o)p[y]=i[y];return u&&(n=n.stateNode,n.__reactInternalMemoizedUnmaskedChildContext=i,n.__reactInternalMemoizedMaskedChildContext=p),p}function Qn(n){return n=n.childContextTypes,n!=null}function Wo(){Jt(Zn),Jt(kn)}function Qf(n,i,o){if(kn.current!==Rr)throw Error(t(168));Yt(kn,i),Yt(Zn,o)}function Jf(n,i,o){var u=n.stateNode;if(i=i.childContextTypes,typeof u.getChildContext!="function")return o;u=u.getChildContext();for(var p in u)if(!(p in i))throw Error(t(108,me(n)||"Unknown",p));return le({},o,u)}function Xo(n){return n=(n=n.stateNode)&&n.__reactInternalMemoizedMergedChildContext||Rr,is=kn.current,Yt(kn,n),Yt(Zn,Zn.current),!0}function ep(n,i,o){var u=n.stateNode;if(!u)throw Error(t(169));o?(n=Jf(n,i,is),u.__reactInternalMemoizedMergedChildContext=n,Jt(Zn),Jt(kn),Yt(kn,n)):Jt(Zn),Yt(Zn,o)}var ir=null,qo=!1,lu=!1;function tp(n){ir===null?ir=[n]:ir.push(n)}function Zx(n){qo=!0,tp(n)}function Pr(){if(!lu&&ir!==null){lu=!0;var n=0,i=At;try{var o=ir;for(At=1;n<o.length;n++){var u=o[n];do u=u(!0);while(u!==null)}ir=null,qo=!1}catch(p){throw ir!==null&&(ir=ir.slice(n+1)),$t(Kt,Pr),p}finally{At=i,lu=!1}}return null}var Bs=[],zs=0,$o=null,Yo=0,gi=[],xi=0,rs=null,rr=1,sr="";function ss(n,i){Bs[zs++]=Yo,Bs[zs++]=$o,$o=n,Yo=i}function np(n,i,o){gi[xi++]=rr,gi[xi++]=sr,gi[xi++]=rs,rs=n;var u=rr;n=sr;var p=32-De(u)-1;u&=~(1<<p),o+=1;var y=32-De(i)+p;if(30<y){var A=p-p%5;y=(u&(1<<A)-1).toString(32),u>>=A,p-=A,rr=1<<32-De(i)+p|o<<p|u,sr=y+n}else rr=1<<y|o<<p|u,sr=n}function cu(n){n.return!==null&&(ss(n,1),np(n,1,0))}function uu(n){for(;n===$o;)$o=Bs[--zs],Bs[zs]=null,Yo=Bs[--zs],Bs[zs]=null;for(;n===rs;)rs=gi[--xi],gi[xi]=null,sr=gi[--xi],gi[xi]=null,rr=gi[--xi],gi[xi]=null}var ci=null,ui=null,tn=!1,Pi=null;function ip(n,i){var o=bi(5,null,null,0);o.elementType="DELETED",o.stateNode=i,o.return=n,i=n.deletions,i===null?(n.deletions=[o],n.flags|=16):i.push(o)}function rp(n,i){switch(n.tag){case 5:var o=n.type;return i=i.nodeType!==1||o.toLowerCase()!==i.nodeName.toLowerCase()?null:i,i!==null?(n.stateNode=i,ci=n,ui=Ar(i.firstChild),!0):!1;case 6:return i=n.pendingProps===""||i.nodeType!==3?null:i,i!==null?(n.stateNode=i,ci=n,ui=null,!0):!1;case 13:return i=i.nodeType!==8?null:i,i!==null?(o=rs!==null?{id:rr,overflow:sr}:null,n.memoizedState={dehydrated:i,treeContext:o,retryLane:1073741824},o=bi(18,null,null,0),o.stateNode=i,o.return=n,n.child=o,ci=n,ui=null,!0):!1;default:return!1}}function du(n){return(n.mode&1)!==0&&(n.flags&128)===0}function hu(n){if(tn){var i=ui;if(i){var o=i;if(!rp(n,i)){if(du(n))throw Error(t(418));i=Ar(o.nextSibling);var u=ci;i&&rp(n,i)?ip(u,o):(n.flags=n.flags&-4097|2,tn=!1,ci=n)}}else{if(du(n))throw Error(t(418));n.flags=n.flags&-4097|2,tn=!1,ci=n}}}function sp(n){for(n=n.return;n!==null&&n.tag!==5&&n.tag!==3&&n.tag!==13;)n=n.return;ci=n}function Ko(n){if(n!==ci)return!1;if(!tn)return sp(n),tn=!0,!1;var i;if((i=n.tag!==3)&&!(i=n.tag!==5)&&(i=n.type,i=i!=="head"&&i!=="body"&&!iu(n.type,n.memoizedProps)),i&&(i=ui)){if(du(n))throw ap(),Error(t(418));for(;i;)ip(n,i),i=Ar(i.nextSibling)}if(sp(n),n.tag===13){if(n=n.memoizedState,n=n!==null?n.dehydrated:null,!n)throw Error(t(317));e:{for(n=n.nextSibling,i=0;n;){if(n.nodeType===8){var o=n.data;if(o==="/$"){if(i===0){ui=Ar(n.nextSibling);break e}i--}else o!=="$"&&o!=="$!"&&o!=="$?"||i++}n=n.nextSibling}ui=null}}else ui=ci?Ar(n.stateNode.nextSibling):null;return!0}function ap(){for(var n=ui;n;)n=Ar(n.nextSibling)}function js(){ui=ci=null,tn=!1}function fu(n){Pi===null?Pi=[n]:Pi.push(n)}var Qx=C.ReactCurrentBatchConfig;function Wa(n,i,o){if(n=o.ref,n!==null&&typeof n!="function"&&typeof n!="object"){if(o._owner){if(o=o._owner,o){if(o.tag!==1)throw Error(t(309));var u=o.stateNode}if(!u)throw Error(t(147,n));var p=u,y=""+n;return i!==null&&i.ref!==null&&typeof i.ref=="function"&&i.ref._stringRef===y?i.ref:(i=function(A){var z=p.refs;A===null?delete z[y]:z[y]=A},i._stringRef=y,i)}if(typeof n!="string")throw Error(t(284));if(!o._owner)throw Error(t(290,n))}return n}function Zo(n,i){throw n=Object.prototype.toString.call(i),Error(t(31,n==="[object Object]"?"object with keys {"+Object.keys(i).join(", ")+"}":n))}function op(n){var i=n._init;return i(n._payload)}function lp(n){function i(ue,Z){if(n){var pe=ue.deletions;pe===null?(ue.deletions=[Z],ue.flags|=16):pe.push(Z)}}function o(ue,Z){if(!n)return null;for(;Z!==null;)i(ue,Z),Z=Z.sibling;return null}function u(ue,Z){for(ue=new Map;Z!==null;)Z.key!==null?ue.set(Z.key,Z):ue.set(Z.index,Z),Z=Z.sibling;return ue}function p(ue,Z){return ue=Or(ue,Z),ue.index=0,ue.sibling=null,ue}function y(ue,Z,pe){return ue.index=pe,n?(pe=ue.alternate,pe!==null?(pe=pe.index,pe<Z?(ue.flags|=2,Z):pe):(ue.flags|=2,Z)):(ue.flags|=1048576,Z)}function A(ue){return n&&ue.alternate===null&&(ue.flags|=2),ue}function z(ue,Z,pe,Fe){return Z===null||Z.tag!==6?(Z=rd(pe,ue.mode,Fe),Z.return=ue,Z):(Z=p(Z,pe),Z.return=ue,Z)}function W(ue,Z,pe,Fe){var st=pe.type;return st===O?Ne(ue,Z,pe.props.children,Fe,pe.key):Z!==null&&(Z.elementType===st||typeof st=="object"&&st!==null&&st.$$typeof===de&&op(st)===Z.type)?(Fe=p(Z,pe.props),Fe.ref=Wa(ue,Z,pe),Fe.return=ue,Fe):(Fe=bl(pe.type,pe.key,pe.props,null,ue.mode,Fe),Fe.ref=Wa(ue,Z,pe),Fe.return=ue,Fe)}function xe(ue,Z,pe,Fe){return Z===null||Z.tag!==4||Z.stateNode.containerInfo!==pe.containerInfo||Z.stateNode.implementation!==pe.implementation?(Z=sd(pe,ue.mode,Fe),Z.return=ue,Z):(Z=p(Z,pe.children||[]),Z.return=ue,Z)}function Ne(ue,Z,pe,Fe,st){return Z===null||Z.tag!==7?(Z=fs(pe,ue.mode,Fe,st),Z.return=ue,Z):(Z=p(Z,pe),Z.return=ue,Z)}function Ie(ue,Z,pe){if(typeof Z=="string"&&Z!==""||typeof Z=="number")return Z=rd(""+Z,ue.mode,pe),Z.return=ue,Z;if(typeof Z=="object"&&Z!==null){switch(Z.$$typeof){case D:return pe=bl(Z.type,Z.key,Z.props,null,ue.mode,pe),pe.ref=Wa(ue,null,Z),pe.return=ue,pe;case L:return Z=sd(Z,ue.mode,pe),Z.return=ue,Z;case de:var Fe=Z._init;return Ie(ue,Fe(Z._payload),pe)}if(Nt(Z)||J(Z))return Z=fs(Z,ue.mode,pe,null),Z.return=ue,Z;Zo(ue,Z)}return null}function Ce(ue,Z,pe,Fe){var st=Z!==null?Z.key:null;if(typeof pe=="string"&&pe!==""||typeof pe=="number")return st!==null?null:z(ue,Z,""+pe,Fe);if(typeof pe=="object"&&pe!==null){switch(pe.$$typeof){case D:return pe.key===st?W(ue,Z,pe,Fe):null;case L:return pe.key===st?xe(ue,Z,pe,Fe):null;case de:return st=pe._init,Ce(ue,Z,st(pe._payload),Fe)}if(Nt(pe)||J(pe))return st!==null?null:Ne(ue,Z,pe,Fe,null);Zo(ue,pe)}return null}function Ke(ue,Z,pe,Fe,st){if(typeof Fe=="string"&&Fe!==""||typeof Fe=="number")return ue=ue.get(pe)||null,z(Z,ue,""+Fe,st);if(typeof Fe=="object"&&Fe!==null){switch(Fe.$$typeof){case D:return ue=ue.get(Fe.key===null?pe:Fe.key)||null,W(Z,ue,Fe,st);case L:return ue=ue.get(Fe.key===null?pe:Fe.key)||null,xe(Z,ue,Fe,st);case de:var ft=Fe._init;return Ke(ue,Z,pe,ft(Fe._payload),st)}if(Nt(Fe)||J(Fe))return ue=ue.get(pe)||null,Ne(Z,ue,Fe,st,null);Zo(Z,Fe)}return null}function nt(ue,Z,pe,Fe){for(var st=null,ft=null,pt=Z,xt=Z=0,Tn=null;pt!==null&&xt<pe.length;xt++){pt.index>xt?(Tn=pt,pt=null):Tn=pt.sibling;var Bt=Ce(ue,pt,pe[xt],Fe);if(Bt===null){pt===null&&(pt=Tn);break}n&&pt&&Bt.alternate===null&&i(ue,pt),Z=y(Bt,Z,xt),ft===null?st=Bt:ft.sibling=Bt,ft=Bt,pt=Tn}if(xt===pe.length)return o(ue,pt),tn&&ss(ue,xt),st;if(pt===null){for(;xt<pe.length;xt++)pt=Ie(ue,pe[xt],Fe),pt!==null&&(Z=y(pt,Z,xt),ft===null?st=pt:ft.sibling=pt,ft=pt);return tn&&ss(ue,xt),st}for(pt=u(ue,pt);xt<pe.length;xt++)Tn=Ke(pt,ue,xt,pe[xt],Fe),Tn!==null&&(n&&Tn.alternate!==null&&pt.delete(Tn.key===null?xt:Tn.key),Z=y(Tn,Z,xt),ft===null?st=Tn:ft.sibling=Tn,ft=Tn);return n&&pt.forEach(function(Br){return i(ue,Br)}),tn&&ss(ue,xt),st}function it(ue,Z,pe,Fe){var st=J(pe);if(typeof st!="function")throw Error(t(150));if(pe=st.call(pe),pe==null)throw Error(t(151));for(var ft=st=null,pt=Z,xt=Z=0,Tn=null,Bt=pe.next();pt!==null&&!Bt.done;xt++,Bt=pe.next()){pt.index>xt?(Tn=pt,pt=null):Tn=pt.sibling;var Br=Ce(ue,pt,Bt.value,Fe);if(Br===null){pt===null&&(pt=Tn);break}n&&pt&&Br.alternate===null&&i(ue,pt),Z=y(Br,Z,xt),ft===null?st=Br:ft.sibling=Br,ft=Br,pt=Tn}if(Bt.done)return o(ue,pt),tn&&ss(ue,xt),st;if(pt===null){for(;!Bt.done;xt++,Bt=pe.next())Bt=Ie(ue,Bt.value,Fe),Bt!==null&&(Z=y(Bt,Z,xt),ft===null?st=Bt:ft.sibling=Bt,ft=Bt);return tn&&ss(ue,xt),st}for(pt=u(ue,pt);!Bt.done;xt++,Bt=pe.next())Bt=Ke(pt,ue,xt,Bt.value,Fe),Bt!==null&&(n&&Bt.alternate!==null&&pt.delete(Bt.key===null?xt:Bt.key),Z=y(Bt,Z,xt),ft===null?st=Bt:ft.sibling=Bt,ft=Bt);return n&&pt.forEach(function(Nv){return i(ue,Nv)}),tn&&ss(ue,xt),st}function fn(ue,Z,pe,Fe){if(typeof pe=="object"&&pe!==null&&pe.type===O&&pe.key===null&&(pe=pe.props.children),typeof pe=="object"&&pe!==null){switch(pe.$$typeof){case D:e:{for(var st=pe.key,ft=Z;ft!==null;){if(ft.key===st){if(st=pe.type,st===O){if(ft.tag===7){o(ue,ft.sibling),Z=p(ft,pe.props.children),Z.return=ue,ue=Z;break e}}else if(ft.elementType===st||typeof st=="object"&&st!==null&&st.$$typeof===de&&op(st)===ft.type){o(ue,ft.sibling),Z=p(ft,pe.props),Z.ref=Wa(ue,ft,pe),Z.return=ue,ue=Z;break e}o(ue,ft);break}else i(ue,ft);ft=ft.sibling}pe.type===O?(Z=fs(pe.props.children,ue.mode,Fe,pe.key),Z.return=ue,ue=Z):(Fe=bl(pe.type,pe.key,pe.props,null,ue.mode,Fe),Fe.ref=Wa(ue,Z,pe),Fe.return=ue,ue=Fe)}return A(ue);case L:e:{for(ft=pe.key;Z!==null;){if(Z.key===ft)if(Z.tag===4&&Z.stateNode.containerInfo===pe.containerInfo&&Z.stateNode.implementation===pe.implementation){o(ue,Z.sibling),Z=p(Z,pe.children||[]),Z.return=ue,ue=Z;break e}else{o(ue,Z);break}else i(ue,Z);Z=Z.sibling}Z=sd(pe,ue.mode,Fe),Z.return=ue,ue=Z}return A(ue);case de:return ft=pe._init,fn(ue,Z,ft(pe._payload),Fe)}if(Nt(pe))return nt(ue,Z,pe,Fe);if(J(pe))return it(ue,Z,pe,Fe);Zo(ue,pe)}return typeof pe=="string"&&pe!==""||typeof pe=="number"?(pe=""+pe,Z!==null&&Z.tag===6?(o(ue,Z.sibling),Z=p(Z,pe),Z.return=ue,ue=Z):(o(ue,Z),Z=rd(pe,ue.mode,Fe),Z.return=ue,ue=Z),A(ue)):o(ue,Z)}return fn}var Hs=lp(!0),cp=lp(!1),Qo=Cr(null),Jo=null,Gs=null,pu=null;function mu(){pu=Gs=Jo=null}function gu(n){var i=Qo.current;Jt(Qo),n._currentValue=i}function xu(n,i,o){for(;n!==null;){var u=n.alternate;if((n.childLanes&i)!==i?(n.childLanes|=i,u!==null&&(u.childLanes|=i)):u!==null&&(u.childLanes&i)!==i&&(u.childLanes|=i),n===o)break;n=n.return}}function Vs(n,i){Jo=n,pu=Gs=null,n=n.dependencies,n!==null&&n.firstContext!==null&&((n.lanes&i)!==0&&(Jn=!0),n.firstContext=null)}function vi(n){var i=n._currentValue;if(pu!==n)if(n={context:n,memoizedValue:i,next:null},Gs===null){if(Jo===null)throw Error(t(308));Gs=n,Jo.dependencies={lanes:0,firstContext:n}}else Gs=Gs.next=n;return i}var as=null;function vu(n){as===null?as=[n]:as.push(n)}function up(n,i,o,u){var p=i.interleaved;return p===null?(o.next=o,vu(i)):(o.next=p.next,p.next=o),i.interleaved=o,ar(n,u)}function ar(n,i){n.lanes|=i;var o=n.alternate;for(o!==null&&(o.lanes|=i),o=n,n=n.return;n!==null;)n.childLanes|=i,o=n.alternate,o!==null&&(o.childLanes|=i),o=n,n=n.return;return o.tag===3?o.stateNode:null}var Nr=!1;function _u(n){n.updateQueue={baseState:n.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function dp(n,i){n=n.updateQueue,i.updateQueue===n&&(i.updateQueue={baseState:n.baseState,firstBaseUpdate:n.firstBaseUpdate,lastBaseUpdate:n.lastBaseUpdate,shared:n.shared,effects:n.effects})}function or(n,i){return{eventTime:n,lane:i,tag:0,payload:null,callback:null,next:null}}function Lr(n,i,o){var u=n.updateQueue;if(u===null)return null;if(u=u.shared,(Ut&2)!==0){var p=u.pending;return p===null?i.next=i:(i.next=p.next,p.next=i),u.pending=i,ar(n,o)}return p=u.interleaved,p===null?(i.next=i,vu(u)):(i.next=p.next,p.next=i),u.interleaved=i,ar(n,o)}function el(n,i,o){if(i=i.updateQueue,i!==null&&(i=i.shared,(o&4194240)!==0)){var u=i.lanes;u&=n.pendingLanes,o|=u,i.lanes=o,Kn(n,o)}}function hp(n,i){var o=n.updateQueue,u=n.alternate;if(u!==null&&(u=u.updateQueue,o===u)){var p=null,y=null;if(o=o.firstBaseUpdate,o!==null){do{var A={eventTime:o.eventTime,lane:o.lane,tag:o.tag,payload:o.payload,callback:o.callback,next:null};y===null?p=y=A:y=y.next=A,o=o.next}while(o!==null);y===null?p=y=i:y=y.next=i}else p=y=i;o={baseState:u.baseState,firstBaseUpdate:p,lastBaseUpdate:y,shared:u.shared,effects:u.effects},n.updateQueue=o;return}n=o.lastBaseUpdate,n===null?o.firstBaseUpdate=i:n.next=i,o.lastBaseUpdate=i}function tl(n,i,o,u){var p=n.updateQueue;Nr=!1;var y=p.firstBaseUpdate,A=p.lastBaseUpdate,z=p.shared.pending;if(z!==null){p.shared.pending=null;var W=z,xe=W.next;W.next=null,A===null?y=xe:A.next=xe,A=W;var Ne=n.alternate;Ne!==null&&(Ne=Ne.updateQueue,z=Ne.lastBaseUpdate,z!==A&&(z===null?Ne.firstBaseUpdate=xe:z.next=xe,Ne.lastBaseUpdate=W))}if(y!==null){var Ie=p.baseState;A=0,Ne=xe=W=null,z=y;do{var Ce=z.lane,Ke=z.eventTime;if((u&Ce)===Ce){Ne!==null&&(Ne=Ne.next={eventTime:Ke,lane:0,tag:z.tag,payload:z.payload,callback:z.callback,next:null});e:{var nt=n,it=z;switch(Ce=i,Ke=o,it.tag){case 1:if(nt=it.payload,typeof nt=="function"){Ie=nt.call(Ke,Ie,Ce);break e}Ie=nt;break e;case 3:nt.flags=nt.flags&-65537|128;case 0:if(nt=it.payload,Ce=typeof nt=="function"?nt.call(Ke,Ie,Ce):nt,Ce==null)break e;Ie=le({},Ie,Ce);break e;case 2:Nr=!0}}z.callback!==null&&z.lane!==0&&(n.flags|=64,Ce=p.effects,Ce===null?p.effects=[z]:Ce.push(z))}else Ke={eventTime:Ke,lane:Ce,tag:z.tag,payload:z.payload,callback:z.callback,next:null},Ne===null?(xe=Ne=Ke,W=Ie):Ne=Ne.next=Ke,A|=Ce;if(z=z.next,z===null){if(z=p.shared.pending,z===null)break;Ce=z,z=Ce.next,Ce.next=null,p.lastBaseUpdate=Ce,p.shared.pending=null}}while(!0);if(Ne===null&&(W=Ie),p.baseState=W,p.firstBaseUpdate=xe,p.lastBaseUpdate=Ne,i=p.shared.interleaved,i!==null){p=i;do A|=p.lane,p=p.next;while(p!==i)}else y===null&&(p.shared.lanes=0);cs|=A,n.lanes=A,n.memoizedState=Ie}}function fp(n,i,o){if(n=i.effects,i.effects=null,n!==null)for(i=0;i<n.length;i++){var u=n[i],p=u.callback;if(p!==null){if(u.callback=null,u=o,typeof p!="function")throw Error(t(191,p));p.call(u)}}}var Xa={},Wi=Cr(Xa),qa=Cr(Xa),$a=Cr(Xa);function os(n){if(n===Xa)throw Error(t(174));return n}function yu(n,i){switch(Yt($a,i),Yt(qa,n),Yt(Wi,Xa),n=i.nodeType,n){case 9:case 11:i=(i=i.documentElement)?i.namespaceURI:w(null,"");break;default:n=n===8?i.parentNode:i,i=n.namespaceURI||null,n=n.tagName,i=w(i,n)}Jt(Wi),Yt(Wi,i)}function Ws(){Jt(Wi),Jt(qa),Jt($a)}function pp(n){os($a.current);var i=os(Wi.current),o=w(i,n.type);i!==o&&(Yt(qa,n),Yt(Wi,o))}function bu(n){qa.current===n&&(Jt(Wi),Jt(qa))}var an=Cr(0);function nl(n){for(var i=n;i!==null;){if(i.tag===13){var o=i.memoizedState;if(o!==null&&(o=o.dehydrated,o===null||o.data==="$?"||o.data==="$!"))return i}else if(i.tag===19&&i.memoizedProps.revealOrder!==void 0){if((i.flags&128)!==0)return i}else if(i.child!==null){i.child.return=i,i=i.child;continue}if(i===n)break;for(;i.sibling===null;){if(i.return===null||i.return===n)return null;i=i.return}i.sibling.return=i.return,i=i.sibling}return null}var Su=[];function Mu(){for(var n=0;n<Su.length;n++)Su[n]._workInProgressVersionPrimary=null;Su.length=0}var il=C.ReactCurrentDispatcher,wu=C.ReactCurrentBatchConfig,ls=0,on=null,vn=null,wn=null,rl=!1,Ya=!1,Ka=0,Jx=0;function Fn(){throw Error(t(321))}function Eu(n,i){if(i===null)return!1;for(var o=0;o<i.length&&o<n.length;o++)if(!Ri(n[o],i[o]))return!1;return!0}function Tu(n,i,o,u,p,y){if(ls=y,on=i,i.memoizedState=null,i.updateQueue=null,i.lanes=0,il.current=n===null||n.memoizedState===null?iv:rv,n=o(u,p),Ya){y=0;do{if(Ya=!1,Ka=0,25<=y)throw Error(t(301));y+=1,wn=vn=null,i.updateQueue=null,il.current=sv,n=o(u,p)}while(Ya)}if(il.current=ol,i=vn!==null&&vn.next!==null,ls=0,wn=vn=on=null,rl=!1,i)throw Error(t(300));return n}function Au(){var n=Ka!==0;return Ka=0,n}function Xi(){var n={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return wn===null?on.memoizedState=wn=n:wn=wn.next=n,wn}function _i(){if(vn===null){var n=on.alternate;n=n!==null?n.memoizedState:null}else n=vn.next;var i=wn===null?on.memoizedState:wn.next;if(i!==null)wn=i,vn=n;else{if(n===null)throw Error(t(310));vn=n,n={memoizedState:vn.memoizedState,baseState:vn.baseState,baseQueue:vn.baseQueue,queue:vn.queue,next:null},wn===null?on.memoizedState=wn=n:wn=wn.next=n}return wn}function Za(n,i){return typeof i=="function"?i(n):i}function Cu(n){var i=_i(),o=i.queue;if(o===null)throw Error(t(311));o.lastRenderedReducer=n;var u=vn,p=u.baseQueue,y=o.pending;if(y!==null){if(p!==null){var A=p.next;p.next=y.next,y.next=A}u.baseQueue=p=y,o.pending=null}if(p!==null){y=p.next,u=u.baseState;var z=A=null,W=null,xe=y;do{var Ne=xe.lane;if((ls&Ne)===Ne)W!==null&&(W=W.next={lane:0,action:xe.action,hasEagerState:xe.hasEagerState,eagerState:xe.eagerState,next:null}),u=xe.hasEagerState?xe.eagerState:n(u,xe.action);else{var Ie={lane:Ne,action:xe.action,hasEagerState:xe.hasEagerState,eagerState:xe.eagerState,next:null};W===null?(z=W=Ie,A=u):W=W.next=Ie,on.lanes|=Ne,cs|=Ne}xe=xe.next}while(xe!==null&&xe!==y);W===null?A=u:W.next=z,Ri(u,i.memoizedState)||(Jn=!0),i.memoizedState=u,i.baseState=A,i.baseQueue=W,o.lastRenderedState=u}if(n=o.interleaved,n!==null){p=n;do y=p.lane,on.lanes|=y,cs|=y,p=p.next;while(p!==n)}else p===null&&(o.lanes=0);return[i.memoizedState,o.dispatch]}function Ru(n){var i=_i(),o=i.queue;if(o===null)throw Error(t(311));o.lastRenderedReducer=n;var u=o.dispatch,p=o.pending,y=i.memoizedState;if(p!==null){o.pending=null;var A=p=p.next;do y=n(y,A.action),A=A.next;while(A!==p);Ri(y,i.memoizedState)||(Jn=!0),i.memoizedState=y,i.baseQueue===null&&(i.baseState=y),o.lastRenderedState=y}return[y,u]}function mp(){}function gp(n,i){var o=on,u=_i(),p=i(),y=!Ri(u.memoizedState,p);if(y&&(u.memoizedState=p,Jn=!0),u=u.queue,Pu(_p.bind(null,o,u,n),[n]),u.getSnapshot!==i||y||wn!==null&&wn.memoizedState.tag&1){if(o.flags|=2048,Qa(9,vp.bind(null,o,u,p,i),void 0,null),En===null)throw Error(t(349));(ls&30)!==0||xp(o,i,p)}return p}function xp(n,i,o){n.flags|=16384,n={getSnapshot:i,value:o},i=on.updateQueue,i===null?(i={lastEffect:null,stores:null},on.updateQueue=i,i.stores=[n]):(o=i.stores,o===null?i.stores=[n]:o.push(n))}function vp(n,i,o,u){i.value=o,i.getSnapshot=u,yp(i)&&bp(n)}function _p(n,i,o){return o(function(){yp(i)&&bp(n)})}function yp(n){var i=n.getSnapshot;n=n.value;try{var o=i();return!Ri(n,o)}catch{return!0}}function bp(n){var i=ar(n,1);i!==null&&Ii(i,n,1,-1)}function Sp(n){var i=Xi();return typeof n=="function"&&(n=n()),i.memoizedState=i.baseState=n,n={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:Za,lastRenderedState:n},i.queue=n,n=n.dispatch=nv.bind(null,on,n),[i.memoizedState,n]}function Qa(n,i,o,u){return n={tag:n,create:i,destroy:o,deps:u,next:null},i=on.updateQueue,i===null?(i={lastEffect:null,stores:null},on.updateQueue=i,i.lastEffect=n.next=n):(o=i.lastEffect,o===null?i.lastEffect=n.next=n:(u=o.next,o.next=n,n.next=u,i.lastEffect=n)),n}function Mp(){return _i().memoizedState}function sl(n,i,o,u){var p=Xi();on.flags|=n,p.memoizedState=Qa(1|i,o,void 0,u===void 0?null:u)}function al(n,i,o,u){var p=_i();u=u===void 0?null:u;var y=void 0;if(vn!==null){var A=vn.memoizedState;if(y=A.destroy,u!==null&&Eu(u,A.deps)){p.memoizedState=Qa(i,o,y,u);return}}on.flags|=n,p.memoizedState=Qa(1|i,o,y,u)}function wp(n,i){return sl(8390656,8,n,i)}function Pu(n,i){return al(2048,8,n,i)}function Ep(n,i){return al(4,2,n,i)}function Tp(n,i){return al(4,4,n,i)}function Ap(n,i){if(typeof i=="function")return n=n(),i(n),function(){i(null)};if(i!=null)return n=n(),i.current=n,function(){i.current=null}}function Cp(n,i,o){return o=o!=null?o.concat([n]):null,al(4,4,Ap.bind(null,i,n),o)}function Nu(){}function Rp(n,i){var o=_i();i=i===void 0?null:i;var u=o.memoizedState;return u!==null&&i!==null&&Eu(i,u[1])?u[0]:(o.memoizedState=[n,i],n)}function Pp(n,i){var o=_i();i=i===void 0?null:i;var u=o.memoizedState;return u!==null&&i!==null&&Eu(i,u[1])?u[0]:(n=n(),o.memoizedState=[n,i],n)}function Np(n,i,o){return(ls&21)===0?(n.baseState&&(n.baseState=!1,Jn=!0),n.memoizedState=o):(Ri(o,i)||(o=Ye(),on.lanes|=o,cs|=o,n.baseState=!0),i)}function ev(n,i){var o=At;At=o!==0&&4>o?o:4,n(!0);var u=wu.transition;wu.transition={};try{n(!1),i()}finally{At=o,wu.transition=u}}function Lp(){return _i().memoizedState}function tv(n,i,o){var u=Fr(n);if(o={lane:u,action:o,hasEagerState:!1,eagerState:null,next:null},Dp(n))Ip(i,o);else if(o=up(n,i,o,u),o!==null){var p=Vn();Ii(o,n,u,p),kp(o,i,u)}}function nv(n,i,o){var u=Fr(n),p={lane:u,action:o,hasEagerState:!1,eagerState:null,next:null};if(Dp(n))Ip(i,p);else{var y=n.alternate;if(n.lanes===0&&(y===null||y.lanes===0)&&(y=i.lastRenderedReducer,y!==null))try{var A=i.lastRenderedState,z=y(A,o);if(p.hasEagerState=!0,p.eagerState=z,Ri(z,A)){var W=i.interleaved;W===null?(p.next=p,vu(i)):(p.next=W.next,W.next=p),i.interleaved=p;return}}catch{}finally{}o=up(n,i,p,u),o!==null&&(p=Vn(),Ii(o,n,u,p),kp(o,i,u))}}function Dp(n){var i=n.alternate;return n===on||i!==null&&i===on}function Ip(n,i){Ya=rl=!0;var o=n.pending;o===null?i.next=i:(i.next=o.next,o.next=i),n.pending=i}function kp(n,i,o){if((o&4194240)!==0){var u=i.lanes;u&=n.pendingLanes,o|=u,i.lanes=o,Kn(n,o)}}var ol={readContext:vi,useCallback:Fn,useContext:Fn,useEffect:Fn,useImperativeHandle:Fn,useInsertionEffect:Fn,useLayoutEffect:Fn,useMemo:Fn,useReducer:Fn,useRef:Fn,useState:Fn,useDebugValue:Fn,useDeferredValue:Fn,useTransition:Fn,useMutableSource:Fn,useSyncExternalStore:Fn,useId:Fn,unstable_isNewReconciler:!1},iv={readContext:vi,useCallback:function(n,i){return Xi().memoizedState=[n,i===void 0?null:i],n},useContext:vi,useEffect:wp,useImperativeHandle:function(n,i,o){return o=o!=null?o.concat([n]):null,sl(4194308,4,Ap.bind(null,i,n),o)},useLayoutEffect:function(n,i){return sl(4194308,4,n,i)},useInsertionEffect:function(n,i){return sl(4,2,n,i)},useMemo:function(n,i){var o=Xi();return i=i===void 0?null:i,n=n(),o.memoizedState=[n,i],n},useReducer:function(n,i,o){var u=Xi();return i=o!==void 0?o(i):i,u.memoizedState=u.baseState=i,n={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:n,lastRenderedState:i},u.queue=n,n=n.dispatch=tv.bind(null,on,n),[u.memoizedState,n]},useRef:function(n){var i=Xi();return n={current:n},i.memoizedState=n},useState:Sp,useDebugValue:Nu,useDeferredValue:function(n){return Xi().memoizedState=n},useTransition:function(){var n=Sp(!1),i=n[0];return n=ev.bind(null,n[1]),Xi().memoizedState=n,[i,n]},useMutableSource:function(){},useSyncExternalStore:function(n,i,o){var u=on,p=Xi();if(tn){if(o===void 0)throw Error(t(407));o=o()}else{if(o=i(),En===null)throw Error(t(349));(ls&30)!==0||xp(u,i,o)}p.memoizedState=o;var y={value:o,getSnapshot:i};return p.queue=y,wp(_p.bind(null,u,y,n),[n]),u.flags|=2048,Qa(9,vp.bind(null,u,y,o,i),void 0,null),o},useId:function(){var n=Xi(),i=En.identifierPrefix;if(tn){var o=sr,u=rr;o=(u&~(1<<32-De(u)-1)).toString(32)+o,i=":"+i+"R"+o,o=Ka++,0<o&&(i+="H"+o.toString(32)),i+=":"}else o=Jx++,i=":"+i+"r"+o.toString(32)+":";return n.memoizedState=i},unstable_isNewReconciler:!1},rv={readContext:vi,useCallback:Rp,useContext:vi,useEffect:Pu,useImperativeHandle:Cp,useInsertionEffect:Ep,useLayoutEffect:Tp,useMemo:Pp,useReducer:Cu,useRef:Mp,useState:function(){return Cu(Za)},useDebugValue:Nu,useDeferredValue:function(n){var i=_i();return Np(i,vn.memoizedState,n)},useTransition:function(){var n=Cu(Za)[0],i=_i().memoizedState;return[n,i]},useMutableSource:mp,useSyncExternalStore:gp,useId:Lp,unstable_isNewReconciler:!1},sv={readContext:vi,useCallback:Rp,useContext:vi,useEffect:Pu,useImperativeHandle:Cp,useInsertionEffect:Ep,useLayoutEffect:Tp,useMemo:Pp,useReducer:Ru,useRef:Mp,useState:function(){return Ru(Za)},useDebugValue:Nu,useDeferredValue:function(n){var i=_i();return vn===null?i.memoizedState=n:Np(i,vn.memoizedState,n)},useTransition:function(){var n=Ru(Za)[0],i=_i().memoizedState;return[n,i]},useMutableSource:mp,useSyncExternalStore:gp,useId:Lp,unstable_isNewReconciler:!1};function Ni(n,i){if(n&&n.defaultProps){i=le({},i),n=n.defaultProps;for(var o in n)i[o]===void 0&&(i[o]=n[o]);return i}return i}function Lu(n,i,o,u){i=n.memoizedState,o=o(u,i),o=o==null?i:le({},i,o),n.memoizedState=o,n.lanes===0&&(n.updateQueue.baseState=o)}var ll={isMounted:function(n){return(n=n._reactInternals)?xn(n)===n:!1},enqueueSetState:function(n,i,o){n=n._reactInternals;var u=Vn(),p=Fr(n),y=or(u,p);y.payload=i,o!=null&&(y.callback=o),i=Lr(n,y,p),i!==null&&(Ii(i,n,p,u),el(i,n,p))},enqueueReplaceState:function(n,i,o){n=n._reactInternals;var u=Vn(),p=Fr(n),y=or(u,p);y.tag=1,y.payload=i,o!=null&&(y.callback=o),i=Lr(n,y,p),i!==null&&(Ii(i,n,p,u),el(i,n,p))},enqueueForceUpdate:function(n,i){n=n._reactInternals;var o=Vn(),u=Fr(n),p=or(o,u);p.tag=2,i!=null&&(p.callback=i),i=Lr(n,p,u),i!==null&&(Ii(i,n,u,o),el(i,n,u))}};function Fp(n,i,o,u,p,y,A){return n=n.stateNode,typeof n.shouldComponentUpdate=="function"?n.shouldComponentUpdate(u,y,A):i.prototype&&i.prototype.isPureReactComponent?!Oa(o,u)||!Oa(p,y):!0}function Up(n,i,o){var u=!1,p=Rr,y=i.contextType;return typeof y=="object"&&y!==null?y=vi(y):(p=Qn(i)?is:kn.current,u=i.contextTypes,y=(u=u!=null)?Os(n,p):Rr),i=new i(o,y),n.memoizedState=i.state!==null&&i.state!==void 0?i.state:null,i.updater=ll,n.stateNode=i,i._reactInternals=n,u&&(n=n.stateNode,n.__reactInternalMemoizedUnmaskedChildContext=p,n.__reactInternalMemoizedMaskedChildContext=y),i}function Op(n,i,o,u){n=i.state,typeof i.componentWillReceiveProps=="function"&&i.componentWillReceiveProps(o,u),typeof i.UNSAFE_componentWillReceiveProps=="function"&&i.UNSAFE_componentWillReceiveProps(o,u),i.state!==n&&ll.enqueueReplaceState(i,i.state,null)}function Du(n,i,o,u){var p=n.stateNode;p.props=o,p.state=n.memoizedState,p.refs={},_u(n);var y=i.contextType;typeof y=="object"&&y!==null?p.context=vi(y):(y=Qn(i)?is:kn.current,p.context=Os(n,y)),p.state=n.memoizedState,y=i.getDerivedStateFromProps,typeof y=="function"&&(Lu(n,i,y,o),p.state=n.memoizedState),typeof i.getDerivedStateFromProps=="function"||typeof p.getSnapshotBeforeUpdate=="function"||typeof p.UNSAFE_componentWillMount!="function"&&typeof p.componentWillMount!="function"||(i=p.state,typeof p.componentWillMount=="function"&&p.componentWillMount(),typeof p.UNSAFE_componentWillMount=="function"&&p.UNSAFE_componentWillMount(),i!==p.state&&ll.enqueueReplaceState(p,p.state,null),tl(n,o,p,u),p.state=n.memoizedState),typeof p.componentDidMount=="function"&&(n.flags|=4194308)}function Xs(n,i){try{var o="",u=i;do o+=be(u),u=u.return;while(u);var p=o}catch(y){p=`
Error generating stack: `+y.message+`
`+y.stack}return{value:n,source:i,stack:p,digest:null}}function Iu(n,i,o){return{value:n,source:null,stack:o??null,digest:i??null}}function ku(n,i){try{console.error(i.value)}catch(o){setTimeout(function(){throw o})}}var av=typeof WeakMap=="function"?WeakMap:Map;function Bp(n,i,o){o=or(-1,o),o.tag=3,o.payload={element:null};var u=i.value;return o.callback=function(){ml||(ml=!0,Ku=u),ku(n,i)},o}function zp(n,i,o){o=or(-1,o),o.tag=3;var u=n.type.getDerivedStateFromError;if(typeof u=="function"){var p=i.value;o.payload=function(){return u(p)},o.callback=function(){ku(n,i)}}var y=n.stateNode;return y!==null&&typeof y.componentDidCatch=="function"&&(o.callback=function(){ku(n,i),typeof u!="function"&&(Ir===null?Ir=new Set([this]):Ir.add(this));var A=i.stack;this.componentDidCatch(i.value,{componentStack:A!==null?A:""})}),o}function jp(n,i,o){var u=n.pingCache;if(u===null){u=n.pingCache=new av;var p=new Set;u.set(i,p)}else p=u.get(i),p===void 0&&(p=new Set,u.set(i,p));p.has(o)||(p.add(o),n=yv.bind(null,n,i,o),i.then(n,n))}function Hp(n){do{var i;if((i=n.tag===13)&&(i=n.memoizedState,i=i!==null?i.dehydrated!==null:!0),i)return n;n=n.return}while(n!==null);return null}function Gp(n,i,o,u,p){return(n.mode&1)===0?(n===i?n.flags|=65536:(n.flags|=128,o.flags|=131072,o.flags&=-52805,o.tag===1&&(o.alternate===null?o.tag=17:(i=or(-1,1),i.tag=2,Lr(o,i,1))),o.lanes|=1),n):(n.flags|=65536,n.lanes=p,n)}var ov=C.ReactCurrentOwner,Jn=!1;function Gn(n,i,o,u){i.child=n===null?cp(i,null,o,u):Hs(i,n.child,o,u)}function Vp(n,i,o,u,p){o=o.render;var y=i.ref;return Vs(i,p),u=Tu(n,i,o,u,y,p),o=Au(),n!==null&&!Jn?(i.updateQueue=n.updateQueue,i.flags&=-2053,n.lanes&=~p,lr(n,i,p)):(tn&&o&&cu(i),i.flags|=1,Gn(n,i,u,p),i.child)}function Wp(n,i,o,u,p){if(n===null){var y=o.type;return typeof y=="function"&&!id(y)&&y.defaultProps===void 0&&o.compare===null&&o.defaultProps===void 0?(i.tag=15,i.type=y,Xp(n,i,y,u,p)):(n=bl(o.type,null,u,i,i.mode,p),n.ref=i.ref,n.return=i,i.child=n)}if(y=n.child,(n.lanes&p)===0){var A=y.memoizedProps;if(o=o.compare,o=o!==null?o:Oa,o(A,u)&&n.ref===i.ref)return lr(n,i,p)}return i.flags|=1,n=Or(y,u),n.ref=i.ref,n.return=i,i.child=n}function Xp(n,i,o,u,p){if(n!==null){var y=n.memoizedProps;if(Oa(y,u)&&n.ref===i.ref)if(Jn=!1,i.pendingProps=u=y,(n.lanes&p)!==0)(n.flags&131072)!==0&&(Jn=!0);else return i.lanes=n.lanes,lr(n,i,p)}return Fu(n,i,o,u,p)}function qp(n,i,o){var u=i.pendingProps,p=u.children,y=n!==null?n.memoizedState:null;if(u.mode==="hidden")if((i.mode&1)===0)i.memoizedState={baseLanes:0,cachePool:null,transitions:null},Yt($s,di),di|=o;else{if((o&1073741824)===0)return n=y!==null?y.baseLanes|o:o,i.lanes=i.childLanes=1073741824,i.memoizedState={baseLanes:n,cachePool:null,transitions:null},i.updateQueue=null,Yt($s,di),di|=n,null;i.memoizedState={baseLanes:0,cachePool:null,transitions:null},u=y!==null?y.baseLanes:o,Yt($s,di),di|=u}else y!==null?(u=y.baseLanes|o,i.memoizedState=null):u=o,Yt($s,di),di|=u;return Gn(n,i,p,o),i.child}function $p(n,i){var o=i.ref;(n===null&&o!==null||n!==null&&n.ref!==o)&&(i.flags|=512,i.flags|=2097152)}function Fu(n,i,o,u,p){var y=Qn(o)?is:kn.current;return y=Os(i,y),Vs(i,p),o=Tu(n,i,o,u,y,p),u=Au(),n!==null&&!Jn?(i.updateQueue=n.updateQueue,i.flags&=-2053,n.lanes&=~p,lr(n,i,p)):(tn&&u&&cu(i),i.flags|=1,Gn(n,i,o,p),i.child)}function Yp(n,i,o,u,p){if(Qn(o)){var y=!0;Xo(i)}else y=!1;if(Vs(i,p),i.stateNode===null)ul(n,i),Up(i,o,u),Du(i,o,u,p),u=!0;else if(n===null){var A=i.stateNode,z=i.memoizedProps;A.props=z;var W=A.context,xe=o.contextType;typeof xe=="object"&&xe!==null?xe=vi(xe):(xe=Qn(o)?is:kn.current,xe=Os(i,xe));var Ne=o.getDerivedStateFromProps,Ie=typeof Ne=="function"||typeof A.getSnapshotBeforeUpdate=="function";Ie||typeof A.UNSAFE_componentWillReceiveProps!="function"&&typeof A.componentWillReceiveProps!="function"||(z!==u||W!==xe)&&Op(i,A,u,xe),Nr=!1;var Ce=i.memoizedState;A.state=Ce,tl(i,u,A,p),W=i.memoizedState,z!==u||Ce!==W||Zn.current||Nr?(typeof Ne=="function"&&(Lu(i,o,Ne,u),W=i.memoizedState),(z=Nr||Fp(i,o,z,u,Ce,W,xe))?(Ie||typeof A.UNSAFE_componentWillMount!="function"&&typeof A.componentWillMount!="function"||(typeof A.componentWillMount=="function"&&A.componentWillMount(),typeof A.UNSAFE_componentWillMount=="function"&&A.UNSAFE_componentWillMount()),typeof A.componentDidMount=="function"&&(i.flags|=4194308)):(typeof A.componentDidMount=="function"&&(i.flags|=4194308),i.memoizedProps=u,i.memoizedState=W),A.props=u,A.state=W,A.context=xe,u=z):(typeof A.componentDidMount=="function"&&(i.flags|=4194308),u=!1)}else{A=i.stateNode,dp(n,i),z=i.memoizedProps,xe=i.type===i.elementType?z:Ni(i.type,z),A.props=xe,Ie=i.pendingProps,Ce=A.context,W=o.contextType,typeof W=="object"&&W!==null?W=vi(W):(W=Qn(o)?is:kn.current,W=Os(i,W));var Ke=o.getDerivedStateFromProps;(Ne=typeof Ke=="function"||typeof A.getSnapshotBeforeUpdate=="function")||typeof A.UNSAFE_componentWillReceiveProps!="function"&&typeof A.componentWillReceiveProps!="function"||(z!==Ie||Ce!==W)&&Op(i,A,u,W),Nr=!1,Ce=i.memoizedState,A.state=Ce,tl(i,u,A,p);var nt=i.memoizedState;z!==Ie||Ce!==nt||Zn.current||Nr?(typeof Ke=="function"&&(Lu(i,o,Ke,u),nt=i.memoizedState),(xe=Nr||Fp(i,o,xe,u,Ce,nt,W)||!1)?(Ne||typeof A.UNSAFE_componentWillUpdate!="function"&&typeof A.componentWillUpdate!="function"||(typeof A.componentWillUpdate=="function"&&A.componentWillUpdate(u,nt,W),typeof A.UNSAFE_componentWillUpdate=="function"&&A.UNSAFE_componentWillUpdate(u,nt,W)),typeof A.componentDidUpdate=="function"&&(i.flags|=4),typeof A.getSnapshotBeforeUpdate=="function"&&(i.flags|=1024)):(typeof A.componentDidUpdate!="function"||z===n.memoizedProps&&Ce===n.memoizedState||(i.flags|=4),typeof A.getSnapshotBeforeUpdate!="function"||z===n.memoizedProps&&Ce===n.memoizedState||(i.flags|=1024),i.memoizedProps=u,i.memoizedState=nt),A.props=u,A.state=nt,A.context=W,u=xe):(typeof A.componentDidUpdate!="function"||z===n.memoizedProps&&Ce===n.memoizedState||(i.flags|=4),typeof A.getSnapshotBeforeUpdate!="function"||z===n.memoizedProps&&Ce===n.memoizedState||(i.flags|=1024),u=!1)}return Uu(n,i,o,u,y,p)}function Uu(n,i,o,u,p,y){$p(n,i);var A=(i.flags&128)!==0;if(!u&&!A)return p&&ep(i,o,!1),lr(n,i,y);u=i.stateNode,ov.current=i;var z=A&&typeof o.getDerivedStateFromError!="function"?null:u.render();return i.flags|=1,n!==null&&A?(i.child=Hs(i,n.child,null,y),i.child=Hs(i,null,z,y)):Gn(n,i,z,y),i.memoizedState=u.state,p&&ep(i,o,!0),i.child}function Kp(n){var i=n.stateNode;i.pendingContext?Qf(n,i.pendingContext,i.pendingContext!==i.context):i.context&&Qf(n,i.context,!1),yu(n,i.containerInfo)}function Zp(n,i,o,u,p){return js(),fu(p),i.flags|=256,Gn(n,i,o,u),i.child}var Ou={dehydrated:null,treeContext:null,retryLane:0};function Bu(n){return{baseLanes:n,cachePool:null,transitions:null}}function Qp(n,i,o){var u=i.pendingProps,p=an.current,y=!1,A=(i.flags&128)!==0,z;if((z=A)||(z=n!==null&&n.memoizedState===null?!1:(p&2)!==0),z?(y=!0,i.flags&=-129):(n===null||n.memoizedState!==null)&&(p|=1),Yt(an,p&1),n===null)return hu(i),n=i.memoizedState,n!==null&&(n=n.dehydrated,n!==null)?((i.mode&1)===0?i.lanes=1:n.data==="$!"?i.lanes=8:i.lanes=1073741824,null):(A=u.children,n=u.fallback,y?(u=i.mode,y=i.child,A={mode:"hidden",children:A},(u&1)===0&&y!==null?(y.childLanes=0,y.pendingProps=A):y=Sl(A,u,0,null),n=fs(n,u,o,null),y.return=i,n.return=i,y.sibling=n,i.child=y,i.child.memoizedState=Bu(o),i.memoizedState=Ou,n):zu(i,A));if(p=n.memoizedState,p!==null&&(z=p.dehydrated,z!==null))return lv(n,i,A,u,z,p,o);if(y){y=u.fallback,A=i.mode,p=n.child,z=p.sibling;var W={mode:"hidden",children:u.children};return(A&1)===0&&i.child!==p?(u=i.child,u.childLanes=0,u.pendingProps=W,i.deletions=null):(u=Or(p,W),u.subtreeFlags=p.subtreeFlags&14680064),z!==null?y=Or(z,y):(y=fs(y,A,o,null),y.flags|=2),y.return=i,u.return=i,u.sibling=y,i.child=u,u=y,y=i.child,A=n.child.memoizedState,A=A===null?Bu(o):{baseLanes:A.baseLanes|o,cachePool:null,transitions:A.transitions},y.memoizedState=A,y.childLanes=n.childLanes&~o,i.memoizedState=Ou,u}return y=n.child,n=y.sibling,u=Or(y,{mode:"visible",children:u.children}),(i.mode&1)===0&&(u.lanes=o),u.return=i,u.sibling=null,n!==null&&(o=i.deletions,o===null?(i.deletions=[n],i.flags|=16):o.push(n)),i.child=u,i.memoizedState=null,u}function zu(n,i){return i=Sl({mode:"visible",children:i},n.mode,0,null),i.return=n,n.child=i}function cl(n,i,o,u){return u!==null&&fu(u),Hs(i,n.child,null,o),n=zu(i,i.pendingProps.children),n.flags|=2,i.memoizedState=null,n}function lv(n,i,o,u,p,y,A){if(o)return i.flags&256?(i.flags&=-257,u=Iu(Error(t(422))),cl(n,i,A,u)):i.memoizedState!==null?(i.child=n.child,i.flags|=128,null):(y=u.fallback,p=i.mode,u=Sl({mode:"visible",children:u.children},p,0,null),y=fs(y,p,A,null),y.flags|=2,u.return=i,y.return=i,u.sibling=y,i.child=u,(i.mode&1)!==0&&Hs(i,n.child,null,A),i.child.memoizedState=Bu(A),i.memoizedState=Ou,y);if((i.mode&1)===0)return cl(n,i,A,null);if(p.data==="$!"){if(u=p.nextSibling&&p.nextSibling.dataset,u)var z=u.dgst;return u=z,y=Error(t(419)),u=Iu(y,u,void 0),cl(n,i,A,u)}if(z=(A&n.childLanes)!==0,Jn||z){if(u=En,u!==null){switch(A&-A){case 4:p=2;break;case 16:p=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:p=32;break;case 536870912:p=268435456;break;default:p=0}p=(p&(u.suspendedLanes|A))!==0?0:p,p!==0&&p!==y.retryLane&&(y.retryLane=p,ar(n,p),Ii(u,n,p,-1))}return nd(),u=Iu(Error(t(421))),cl(n,i,A,u)}return p.data==="$?"?(i.flags|=128,i.child=n.child,i=bv.bind(null,n),p._reactRetry=i,null):(n=y.treeContext,ui=Ar(p.nextSibling),ci=i,tn=!0,Pi=null,n!==null&&(gi[xi++]=rr,gi[xi++]=sr,gi[xi++]=rs,rr=n.id,sr=n.overflow,rs=i),i=zu(i,u.children),i.flags|=4096,i)}function Jp(n,i,o){n.lanes|=i;var u=n.alternate;u!==null&&(u.lanes|=i),xu(n.return,i,o)}function ju(n,i,o,u,p){var y=n.memoizedState;y===null?n.memoizedState={isBackwards:i,rendering:null,renderingStartTime:0,last:u,tail:o,tailMode:p}:(y.isBackwards=i,y.rendering=null,y.renderingStartTime=0,y.last=u,y.tail=o,y.tailMode=p)}function em(n,i,o){var u=i.pendingProps,p=u.revealOrder,y=u.tail;if(Gn(n,i,u.children,o),u=an.current,(u&2)!==0)u=u&1|2,i.flags|=128;else{if(n!==null&&(n.flags&128)!==0)e:for(n=i.child;n!==null;){if(n.tag===13)n.memoizedState!==null&&Jp(n,o,i);else if(n.tag===19)Jp(n,o,i);else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===i)break e;for(;n.sibling===null;){if(n.return===null||n.return===i)break e;n=n.return}n.sibling.return=n.return,n=n.sibling}u&=1}if(Yt(an,u),(i.mode&1)===0)i.memoizedState=null;else switch(p){case"forwards":for(o=i.child,p=null;o!==null;)n=o.alternate,n!==null&&nl(n)===null&&(p=o),o=o.sibling;o=p,o===null?(p=i.child,i.child=null):(p=o.sibling,o.sibling=null),ju(i,!1,p,o,y);break;case"backwards":for(o=null,p=i.child,i.child=null;p!==null;){if(n=p.alternate,n!==null&&nl(n)===null){i.child=p;break}n=p.sibling,p.sibling=o,o=p,p=n}ju(i,!0,o,null,y);break;case"together":ju(i,!1,null,null,void 0);break;default:i.memoizedState=null}return i.child}function ul(n,i){(i.mode&1)===0&&n!==null&&(n.alternate=null,i.alternate=null,i.flags|=2)}function lr(n,i,o){if(n!==null&&(i.dependencies=n.dependencies),cs|=i.lanes,(o&i.childLanes)===0)return null;if(n!==null&&i.child!==n.child)throw Error(t(153));if(i.child!==null){for(n=i.child,o=Or(n,n.pendingProps),i.child=o,o.return=i;n.sibling!==null;)n=n.sibling,o=o.sibling=Or(n,n.pendingProps),o.return=i;o.sibling=null}return i.child}function cv(n,i,o){switch(i.tag){case 3:Kp(i),js();break;case 5:pp(i);break;case 1:Qn(i.type)&&Xo(i);break;case 4:yu(i,i.stateNode.containerInfo);break;case 10:var u=i.type._context,p=i.memoizedProps.value;Yt(Qo,u._currentValue),u._currentValue=p;break;case 13:if(u=i.memoizedState,u!==null)return u.dehydrated!==null?(Yt(an,an.current&1),i.flags|=128,null):(o&i.child.childLanes)!==0?Qp(n,i,o):(Yt(an,an.current&1),n=lr(n,i,o),n!==null?n.sibling:null);Yt(an,an.current&1);break;case 19:if(u=(o&i.childLanes)!==0,(n.flags&128)!==0){if(u)return em(n,i,o);i.flags|=128}if(p=i.memoizedState,p!==null&&(p.rendering=null,p.tail=null,p.lastEffect=null),Yt(an,an.current),u)break;return null;case 22:case 23:return i.lanes=0,qp(n,i,o)}return lr(n,i,o)}var tm,Hu,nm,im;tm=function(n,i){for(var o=i.child;o!==null;){if(o.tag===5||o.tag===6)n.appendChild(o.stateNode);else if(o.tag!==4&&o.child!==null){o.child.return=o,o=o.child;continue}if(o===i)break;for(;o.sibling===null;){if(o.return===null||o.return===i)return;o=o.return}o.sibling.return=o.return,o=o.sibling}},Hu=function(){},nm=function(n,i,o,u){var p=n.memoizedProps;if(p!==u){n=i.stateNode,os(Wi.current);var y=null;switch(o){case"input":p=at(n,p),u=at(n,u),y=[];break;case"select":p=le({},p,{value:void 0}),u=le({},u,{value:void 0}),y=[];break;case"textarea":p=jt(n,p),u=jt(n,u),y=[];break;default:typeof p.onClick!="function"&&typeof u.onClick=="function"&&(n.onclick=Go)}We(o,u);var A;o=null;for(xe in p)if(!u.hasOwnProperty(xe)&&p.hasOwnProperty(xe)&&p[xe]!=null)if(xe==="style"){var z=p[xe];for(A in z)z.hasOwnProperty(A)&&(o||(o={}),o[A]="")}else xe!=="dangerouslySetInnerHTML"&&xe!=="children"&&xe!=="suppressContentEditableWarning"&&xe!=="suppressHydrationWarning"&&xe!=="autoFocus"&&(a.hasOwnProperty(xe)?y||(y=[]):(y=y||[]).push(xe,null));for(xe in u){var W=u[xe];if(z=p?.[xe],u.hasOwnProperty(xe)&&W!==z&&(W!=null||z!=null))if(xe==="style")if(z){for(A in z)!z.hasOwnProperty(A)||W&&W.hasOwnProperty(A)||(o||(o={}),o[A]="");for(A in W)W.hasOwnProperty(A)&&z[A]!==W[A]&&(o||(o={}),o[A]=W[A])}else o||(y||(y=[]),y.push(xe,o)),o=W;else xe==="dangerouslySetInnerHTML"?(W=W?W.__html:void 0,z=z?z.__html:void 0,W!=null&&z!==W&&(y=y||[]).push(xe,W)):xe==="children"?typeof W!="string"&&typeof W!="number"||(y=y||[]).push(xe,""+W):xe!=="suppressContentEditableWarning"&&xe!=="suppressHydrationWarning"&&(a.hasOwnProperty(xe)?(W!=null&&xe==="onScroll"&&Qt("scroll",n),y||z===W||(y=[])):(y=y||[]).push(xe,W))}o&&(y=y||[]).push("style",o);var xe=y;(i.updateQueue=xe)&&(i.flags|=4)}},im=function(n,i,o,u){o!==u&&(i.flags|=4)};function Ja(n,i){if(!tn)switch(n.tailMode){case"hidden":i=n.tail;for(var o=null;i!==null;)i.alternate!==null&&(o=i),i=i.sibling;o===null?n.tail=null:o.sibling=null;break;case"collapsed":o=n.tail;for(var u=null;o!==null;)o.alternate!==null&&(u=o),o=o.sibling;u===null?i||n.tail===null?n.tail=null:n.tail.sibling=null:u.sibling=null}}function Un(n){var i=n.alternate!==null&&n.alternate.child===n.child,o=0,u=0;if(i)for(var p=n.child;p!==null;)o|=p.lanes|p.childLanes,u|=p.subtreeFlags&14680064,u|=p.flags&14680064,p.return=n,p=p.sibling;else for(p=n.child;p!==null;)o|=p.lanes|p.childLanes,u|=p.subtreeFlags,u|=p.flags,p.return=n,p=p.sibling;return n.subtreeFlags|=u,n.childLanes=o,i}function uv(n,i,o){var u=i.pendingProps;switch(uu(i),i.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Un(i),null;case 1:return Qn(i.type)&&Wo(),Un(i),null;case 3:return u=i.stateNode,Ws(),Jt(Zn),Jt(kn),Mu(),u.pendingContext&&(u.context=u.pendingContext,u.pendingContext=null),(n===null||n.child===null)&&(Ko(i)?i.flags|=4:n===null||n.memoizedState.isDehydrated&&(i.flags&256)===0||(i.flags|=1024,Pi!==null&&(Ju(Pi),Pi=null))),Hu(n,i),Un(i),null;case 5:bu(i);var p=os($a.current);if(o=i.type,n!==null&&i.stateNode!=null)nm(n,i,o,u,p),n.ref!==i.ref&&(i.flags|=512,i.flags|=2097152);else{if(!u){if(i.stateNode===null)throw Error(t(166));return Un(i),null}if(n=os(Wi.current),Ko(i)){u=i.stateNode,o=i.type;var y=i.memoizedProps;switch(u[Vi]=i,u[Ga]=y,n=(i.mode&1)!==0,o){case"dialog":Qt("cancel",u),Qt("close",u);break;case"iframe":case"object":case"embed":Qt("load",u);break;case"video":case"audio":for(p=0;p<za.length;p++)Qt(za[p],u);break;case"source":Qt("error",u);break;case"img":case"image":case"link":Qt("error",u),Qt("load",u);break;case"details":Qt("toggle",u);break;case"input":$e(u,y),Qt("invalid",u);break;case"select":u._wrapperState={wasMultiple:!!y.multiple},Qt("invalid",u);break;case"textarea":j(u,y),Qt("invalid",u)}We(o,y),p=null;for(var A in y)if(y.hasOwnProperty(A)){var z=y[A];A==="children"?typeof z=="string"?u.textContent!==z&&(y.suppressHydrationWarning!==!0&&Ho(u.textContent,z,n),p=["children",z]):typeof z=="number"&&u.textContent!==""+z&&(y.suppressHydrationWarning!==!0&&Ho(u.textContent,z,n),p=["children",""+z]):a.hasOwnProperty(A)&&z!=null&&A==="onScroll"&&Qt("scroll",u)}switch(o){case"input":Ze(u),Dt(u,y,!0);break;case"textarea":Ze(u),je(u);break;case"select":case"option":break;default:typeof y.onClick=="function"&&(u.onclick=Go)}u=p,i.updateQueue=u,u!==null&&(i.flags|=4)}else{A=p.nodeType===9?p:p.ownerDocument,n==="http://www.w3.org/1999/xhtml"&&(n=k(o)),n==="http://www.w3.org/1999/xhtml"?o==="script"?(n=A.createElement("div"),n.innerHTML="<script><\/script>",n=n.removeChild(n.firstChild)):typeof u.is=="string"?n=A.createElement(o,{is:u.is}):(n=A.createElement(o),o==="select"&&(A=n,u.multiple?A.multiple=!0:u.size&&(A.size=u.size))):n=A.createElementNS(n,o),n[Vi]=i,n[Ga]=u,tm(n,i,!1,!1),i.stateNode=n;e:{switch(A=Ue(o,u),o){case"dialog":Qt("cancel",n),Qt("close",n),p=u;break;case"iframe":case"object":case"embed":Qt("load",n),p=u;break;case"video":case"audio":for(p=0;p<za.length;p++)Qt(za[p],n);p=u;break;case"source":Qt("error",n),p=u;break;case"img":case"image":case"link":Qt("error",n),Qt("load",n),p=u;break;case"details":Qt("toggle",n),p=u;break;case"input":$e(n,u),p=at(n,u),Qt("invalid",n);break;case"option":p=u;break;case"select":n._wrapperState={wasMultiple:!!u.multiple},p=le({},u,{value:void 0}),Qt("invalid",n);break;case"textarea":j(n,u),p=jt(n,u),Qt("invalid",n);break;default:p=u}We(o,p),z=p;for(y in z)if(z.hasOwnProperty(y)){var W=z[y];y==="style"?fe(n,W):y==="dangerouslySetInnerHTML"?(W=W?W.__html:void 0,W!=null&&se(n,W)):y==="children"?typeof W=="string"?(o!=="textarea"||W!=="")&&he(n,W):typeof W=="number"&&he(n,""+W):y!=="suppressContentEditableWarning"&&y!=="suppressHydrationWarning"&&y!=="autoFocus"&&(a.hasOwnProperty(y)?W!=null&&y==="onScroll"&&Qt("scroll",n):W!=null&&P(n,y,W,A))}switch(o){case"input":Ze(n),Dt(n,u,!1);break;case"textarea":Ze(n),je(n);break;case"option":u.value!=null&&n.setAttribute("value",""+ve(u.value));break;case"select":n.multiple=!!u.multiple,y=u.value,y!=null?ht(n,!!u.multiple,y,!1):u.defaultValue!=null&&ht(n,!!u.multiple,u.defaultValue,!0);break;default:typeof p.onClick=="function"&&(n.onclick=Go)}switch(o){case"button":case"input":case"select":case"textarea":u=!!u.autoFocus;break e;case"img":u=!0;break e;default:u=!1}}u&&(i.flags|=4)}i.ref!==null&&(i.flags|=512,i.flags|=2097152)}return Un(i),null;case 6:if(n&&i.stateNode!=null)im(n,i,n.memoizedProps,u);else{if(typeof u!="string"&&i.stateNode===null)throw Error(t(166));if(o=os($a.current),os(Wi.current),Ko(i)){if(u=i.stateNode,o=i.memoizedProps,u[Vi]=i,(y=u.nodeValue!==o)&&(n=ci,n!==null))switch(n.tag){case 3:Ho(u.nodeValue,o,(n.mode&1)!==0);break;case 5:n.memoizedProps.suppressHydrationWarning!==!0&&Ho(u.nodeValue,o,(n.mode&1)!==0)}y&&(i.flags|=4)}else u=(o.nodeType===9?o:o.ownerDocument).createTextNode(u),u[Vi]=i,i.stateNode=u}return Un(i),null;case 13:if(Jt(an),u=i.memoizedState,n===null||n.memoizedState!==null&&n.memoizedState.dehydrated!==null){if(tn&&ui!==null&&(i.mode&1)!==0&&(i.flags&128)===0)ap(),js(),i.flags|=98560,y=!1;else if(y=Ko(i),u!==null&&u.dehydrated!==null){if(n===null){if(!y)throw Error(t(318));if(y=i.memoizedState,y=y!==null?y.dehydrated:null,!y)throw Error(t(317));y[Vi]=i}else js(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;Un(i),y=!1}else Pi!==null&&(Ju(Pi),Pi=null),y=!0;if(!y)return i.flags&65536?i:null}return(i.flags&128)!==0?(i.lanes=o,i):(u=u!==null,u!==(n!==null&&n.memoizedState!==null)&&u&&(i.child.flags|=8192,(i.mode&1)!==0&&(n===null||(an.current&1)!==0?_n===0&&(_n=3):nd())),i.updateQueue!==null&&(i.flags|=4),Un(i),null);case 4:return Ws(),Hu(n,i),n===null&&ja(i.stateNode.containerInfo),Un(i),null;case 10:return gu(i.type._context),Un(i),null;case 17:return Qn(i.type)&&Wo(),Un(i),null;case 19:if(Jt(an),y=i.memoizedState,y===null)return Un(i),null;if(u=(i.flags&128)!==0,A=y.rendering,A===null)if(u)Ja(y,!1);else{if(_n!==0||n!==null&&(n.flags&128)!==0)for(n=i.child;n!==null;){if(A=nl(n),A!==null){for(i.flags|=128,Ja(y,!1),u=A.updateQueue,u!==null&&(i.updateQueue=u,i.flags|=4),i.subtreeFlags=0,u=o,o=i.child;o!==null;)y=o,n=u,y.flags&=14680066,A=y.alternate,A===null?(y.childLanes=0,y.lanes=n,y.child=null,y.subtreeFlags=0,y.memoizedProps=null,y.memoizedState=null,y.updateQueue=null,y.dependencies=null,y.stateNode=null):(y.childLanes=A.childLanes,y.lanes=A.lanes,y.child=A.child,y.subtreeFlags=0,y.deletions=null,y.memoizedProps=A.memoizedProps,y.memoizedState=A.memoizedState,y.updateQueue=A.updateQueue,y.type=A.type,n=A.dependencies,y.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext}),o=o.sibling;return Yt(an,an.current&1|2),i.child}n=n.sibling}y.tail!==null&&Ht()>Ys&&(i.flags|=128,u=!0,Ja(y,!1),i.lanes=4194304)}else{if(!u)if(n=nl(A),n!==null){if(i.flags|=128,u=!0,o=n.updateQueue,o!==null&&(i.updateQueue=o,i.flags|=4),Ja(y,!0),y.tail===null&&y.tailMode==="hidden"&&!A.alternate&&!tn)return Un(i),null}else 2*Ht()-y.renderingStartTime>Ys&&o!==1073741824&&(i.flags|=128,u=!0,Ja(y,!1),i.lanes=4194304);y.isBackwards?(A.sibling=i.child,i.child=A):(o=y.last,o!==null?o.sibling=A:i.child=A,y.last=A)}return y.tail!==null?(i=y.tail,y.rendering=i,y.tail=i.sibling,y.renderingStartTime=Ht(),i.sibling=null,o=an.current,Yt(an,u?o&1|2:o&1),i):(Un(i),null);case 22:case 23:return td(),u=i.memoizedState!==null,n!==null&&n.memoizedState!==null!==u&&(i.flags|=8192),u&&(i.mode&1)!==0?(di&1073741824)!==0&&(Un(i),i.subtreeFlags&6&&(i.flags|=8192)):Un(i),null;case 24:return null;case 25:return null}throw Error(t(156,i.tag))}function dv(n,i){switch(uu(i),i.tag){case 1:return Qn(i.type)&&Wo(),n=i.flags,n&65536?(i.flags=n&-65537|128,i):null;case 3:return Ws(),Jt(Zn),Jt(kn),Mu(),n=i.flags,(n&65536)!==0&&(n&128)===0?(i.flags=n&-65537|128,i):null;case 5:return bu(i),null;case 13:if(Jt(an),n=i.memoizedState,n!==null&&n.dehydrated!==null){if(i.alternate===null)throw Error(t(340));js()}return n=i.flags,n&65536?(i.flags=n&-65537|128,i):null;case 19:return Jt(an),null;case 4:return Ws(),null;case 10:return gu(i.type._context),null;case 22:case 23:return td(),null;case 24:return null;default:return null}}var dl=!1,On=!1,hv=typeof WeakSet=="function"?WeakSet:Set,Je=null;function qs(n,i){var o=n.ref;if(o!==null)if(typeof o=="function")try{o(null)}catch(u){un(n,i,u)}else o.current=null}function Gu(n,i,o){try{o()}catch(u){un(n,i,u)}}var rm=!1;function fv(n,i){if(tu=No,n=Ff(),qc(n)){if("selectionStart"in n)var o={start:n.selectionStart,end:n.selectionEnd};else e:{o=(o=n.ownerDocument)&&o.defaultView||window;var u=o.getSelection&&o.getSelection();if(u&&u.rangeCount!==0){o=u.anchorNode;var p=u.anchorOffset,y=u.focusNode;u=u.focusOffset;try{o.nodeType,y.nodeType}catch{o=null;break e}var A=0,z=-1,W=-1,xe=0,Ne=0,Ie=n,Ce=null;t:for(;;){for(var Ke;Ie!==o||p!==0&&Ie.nodeType!==3||(z=A+p),Ie!==y||u!==0&&Ie.nodeType!==3||(W=A+u),Ie.nodeType===3&&(A+=Ie.nodeValue.length),(Ke=Ie.firstChild)!==null;)Ce=Ie,Ie=Ke;for(;;){if(Ie===n)break t;if(Ce===o&&++xe===p&&(z=A),Ce===y&&++Ne===u&&(W=A),(Ke=Ie.nextSibling)!==null)break;Ie=Ce,Ce=Ie.parentNode}Ie=Ke}o=z===-1||W===-1?null:{start:z,end:W}}else o=null}o=o||{start:0,end:0}}else o=null;for(nu={focusedElem:n,selectionRange:o},No=!1,Je=i;Je!==null;)if(i=Je,n=i.child,(i.subtreeFlags&1028)!==0&&n!==null)n.return=i,Je=n;else for(;Je!==null;){i=Je;try{var nt=i.alternate;if((i.flags&1024)!==0)switch(i.tag){case 0:case 11:case 15:break;case 1:if(nt!==null){var it=nt.memoizedProps,fn=nt.memoizedState,ue=i.stateNode,Z=ue.getSnapshotBeforeUpdate(i.elementType===i.type?it:Ni(i.type,it),fn);ue.__reactInternalSnapshotBeforeUpdate=Z}break;case 3:var pe=i.stateNode.containerInfo;pe.nodeType===1?pe.textContent="":pe.nodeType===9&&pe.documentElement&&pe.removeChild(pe.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(t(163))}}catch(Fe){un(i,i.return,Fe)}if(n=i.sibling,n!==null){n.return=i.return,Je=n;break}Je=i.return}return nt=rm,rm=!1,nt}function eo(n,i,o){var u=i.updateQueue;if(u=u!==null?u.lastEffect:null,u!==null){var p=u=u.next;do{if((p.tag&n)===n){var y=p.destroy;p.destroy=void 0,y!==void 0&&Gu(i,o,y)}p=p.next}while(p!==u)}}function hl(n,i){if(i=i.updateQueue,i=i!==null?i.lastEffect:null,i!==null){var o=i=i.next;do{if((o.tag&n)===n){var u=o.create;o.destroy=u()}o=o.next}while(o!==i)}}function Vu(n){var i=n.ref;if(i!==null){var o=n.stateNode;switch(n.tag){case 5:n=o;break;default:n=o}typeof i=="function"?i(n):i.current=n}}function sm(n){var i=n.alternate;i!==null&&(n.alternate=null,sm(i)),n.child=null,n.deletions=null,n.sibling=null,n.tag===5&&(i=n.stateNode,i!==null&&(delete i[Vi],delete i[Ga],delete i[au],delete i[Yx],delete i[Kx])),n.stateNode=null,n.return=null,n.dependencies=null,n.memoizedProps=null,n.memoizedState=null,n.pendingProps=null,n.stateNode=null,n.updateQueue=null}function am(n){return n.tag===5||n.tag===3||n.tag===4}function om(n){e:for(;;){for(;n.sibling===null;){if(n.return===null||am(n.return))return null;n=n.return}for(n.sibling.return=n.return,n=n.sibling;n.tag!==5&&n.tag!==6&&n.tag!==18;){if(n.flags&2||n.child===null||n.tag===4)continue e;n.child.return=n,n=n.child}if(!(n.flags&2))return n.stateNode}}function Wu(n,i,o){var u=n.tag;if(u===5||u===6)n=n.stateNode,i?o.nodeType===8?o.parentNode.insertBefore(n,i):o.insertBefore(n,i):(o.nodeType===8?(i=o.parentNode,i.insertBefore(n,o)):(i=o,i.appendChild(n)),o=o._reactRootContainer,o!=null||i.onclick!==null||(i.onclick=Go));else if(u!==4&&(n=n.child,n!==null))for(Wu(n,i,o),n=n.sibling;n!==null;)Wu(n,i,o),n=n.sibling}function Xu(n,i,o){var u=n.tag;if(u===5||u===6)n=n.stateNode,i?o.insertBefore(n,i):o.appendChild(n);else if(u!==4&&(n=n.child,n!==null))for(Xu(n,i,o),n=n.sibling;n!==null;)Xu(n,i,o),n=n.sibling}var Pn=null,Li=!1;function Dr(n,i,o){for(o=o.child;o!==null;)lm(n,i,o),o=o.sibling}function lm(n,i,o){if(Te&&typeof Te.onCommitFiberUnmount=="function")try{Te.onCommitFiberUnmount(ne,o)}catch{}switch(o.tag){case 5:On||qs(o,i);case 6:var u=Pn,p=Li;Pn=null,Dr(n,i,o),Pn=u,Li=p,Pn!==null&&(Li?(n=Pn,o=o.stateNode,n.nodeType===8?n.parentNode.removeChild(o):n.removeChild(o)):Pn.removeChild(o.stateNode));break;case 18:Pn!==null&&(Li?(n=Pn,o=o.stateNode,n.nodeType===8?su(n.parentNode,o):n.nodeType===1&&su(n,o),La(n)):su(Pn,o.stateNode));break;case 4:u=Pn,p=Li,Pn=o.stateNode.containerInfo,Li=!0,Dr(n,i,o),Pn=u,Li=p;break;case 0:case 11:case 14:case 15:if(!On&&(u=o.updateQueue,u!==null&&(u=u.lastEffect,u!==null))){p=u=u.next;do{var y=p,A=y.destroy;y=y.tag,A!==void 0&&((y&2)!==0||(y&4)!==0)&&Gu(o,i,A),p=p.next}while(p!==u)}Dr(n,i,o);break;case 1:if(!On&&(qs(o,i),u=o.stateNode,typeof u.componentWillUnmount=="function"))try{u.props=o.memoizedProps,u.state=o.memoizedState,u.componentWillUnmount()}catch(z){un(o,i,z)}Dr(n,i,o);break;case 21:Dr(n,i,o);break;case 22:o.mode&1?(On=(u=On)||o.memoizedState!==null,Dr(n,i,o),On=u):Dr(n,i,o);break;default:Dr(n,i,o)}}function cm(n){var i=n.updateQueue;if(i!==null){n.updateQueue=null;var o=n.stateNode;o===null&&(o=n.stateNode=new hv),i.forEach(function(u){var p=Sv.bind(null,n,u);o.has(u)||(o.add(u),u.then(p,p))})}}function Di(n,i){var o=i.deletions;if(o!==null)for(var u=0;u<o.length;u++){var p=o[u];try{var y=n,A=i,z=A;e:for(;z!==null;){switch(z.tag){case 5:Pn=z.stateNode,Li=!1;break e;case 3:Pn=z.stateNode.containerInfo,Li=!0;break e;case 4:Pn=z.stateNode.containerInfo,Li=!0;break e}z=z.return}if(Pn===null)throw Error(t(160));lm(y,A,p),Pn=null,Li=!1;var W=p.alternate;W!==null&&(W.return=null),p.return=null}catch(xe){un(p,i,xe)}}if(i.subtreeFlags&12854)for(i=i.child;i!==null;)um(i,n),i=i.sibling}function um(n,i){var o=n.alternate,u=n.flags;switch(n.tag){case 0:case 11:case 14:case 15:if(Di(i,n),qi(n),u&4){try{eo(3,n,n.return),hl(3,n)}catch(it){un(n,n.return,it)}try{eo(5,n,n.return)}catch(it){un(n,n.return,it)}}break;case 1:Di(i,n),qi(n),u&512&&o!==null&&qs(o,o.return);break;case 5:if(Di(i,n),qi(n),u&512&&o!==null&&qs(o,o.return),n.flags&32){var p=n.stateNode;try{he(p,"")}catch(it){un(n,n.return,it)}}if(u&4&&(p=n.stateNode,p!=null)){var y=n.memoizedProps,A=o!==null?o.memoizedProps:y,z=n.type,W=n.updateQueue;if(n.updateQueue=null,W!==null)try{z==="input"&&y.type==="radio"&&y.name!=null&&Mt(p,y),Ue(z,A);var xe=Ue(z,y);for(A=0;A<W.length;A+=2){var Ne=W[A],Ie=W[A+1];Ne==="style"?fe(p,Ie):Ne==="dangerouslySetInnerHTML"?se(p,Ie):Ne==="children"?he(p,Ie):P(p,Ne,Ie,xe)}switch(z){case"input":St(p,y);break;case"textarea":Qe(p,y);break;case"select":var Ce=p._wrapperState.wasMultiple;p._wrapperState.wasMultiple=!!y.multiple;var Ke=y.value;Ke!=null?ht(p,!!y.multiple,Ke,!1):Ce!==!!y.multiple&&(y.defaultValue!=null?ht(p,!!y.multiple,y.defaultValue,!0):ht(p,!!y.multiple,y.multiple?[]:"",!1))}p[Ga]=y}catch(it){un(n,n.return,it)}}break;case 6:if(Di(i,n),qi(n),u&4){if(n.stateNode===null)throw Error(t(162));p=n.stateNode,y=n.memoizedProps;try{p.nodeValue=y}catch(it){un(n,n.return,it)}}break;case 3:if(Di(i,n),qi(n),u&4&&o!==null&&o.memoizedState.isDehydrated)try{La(i.containerInfo)}catch(it){un(n,n.return,it)}break;case 4:Di(i,n),qi(n);break;case 13:Di(i,n),qi(n),p=n.child,p.flags&8192&&(y=p.memoizedState!==null,p.stateNode.isHidden=y,!y||p.alternate!==null&&p.alternate.memoizedState!==null||(Yu=Ht())),u&4&&cm(n);break;case 22:if(Ne=o!==null&&o.memoizedState!==null,n.mode&1?(On=(xe=On)||Ne,Di(i,n),On=xe):Di(i,n),qi(n),u&8192){if(xe=n.memoizedState!==null,(n.stateNode.isHidden=xe)&&!Ne&&(n.mode&1)!==0)for(Je=n,Ne=n.child;Ne!==null;){for(Ie=Je=Ne;Je!==null;){switch(Ce=Je,Ke=Ce.child,Ce.tag){case 0:case 11:case 14:case 15:eo(4,Ce,Ce.return);break;case 1:qs(Ce,Ce.return);var nt=Ce.stateNode;if(typeof nt.componentWillUnmount=="function"){u=Ce,o=Ce.return;try{i=u,nt.props=i.memoizedProps,nt.state=i.memoizedState,nt.componentWillUnmount()}catch(it){un(u,o,it)}}break;case 5:qs(Ce,Ce.return);break;case 22:if(Ce.memoizedState!==null){fm(Ie);continue}}Ke!==null?(Ke.return=Ce,Je=Ke):fm(Ie)}Ne=Ne.sibling}e:for(Ne=null,Ie=n;;){if(Ie.tag===5){if(Ne===null){Ne=Ie;try{p=Ie.stateNode,xe?(y=p.style,typeof y.setProperty=="function"?y.setProperty("display","none","important"):y.display="none"):(z=Ie.stateNode,W=Ie.memoizedProps.style,A=W!=null&&W.hasOwnProperty("display")?W.display:null,z.style.display=_e("display",A))}catch(it){un(n,n.return,it)}}}else if(Ie.tag===6){if(Ne===null)try{Ie.stateNode.nodeValue=xe?"":Ie.memoizedProps}catch(it){un(n,n.return,it)}}else if((Ie.tag!==22&&Ie.tag!==23||Ie.memoizedState===null||Ie===n)&&Ie.child!==null){Ie.child.return=Ie,Ie=Ie.child;continue}if(Ie===n)break e;for(;Ie.sibling===null;){if(Ie.return===null||Ie.return===n)break e;Ne===Ie&&(Ne=null),Ie=Ie.return}Ne===Ie&&(Ne=null),Ie.sibling.return=Ie.return,Ie=Ie.sibling}}break;case 19:Di(i,n),qi(n),u&4&&cm(n);break;case 21:break;default:Di(i,n),qi(n)}}function qi(n){var i=n.flags;if(i&2){try{e:{for(var o=n.return;o!==null;){if(am(o)){var u=o;break e}o=o.return}throw Error(t(160))}switch(u.tag){case 5:var p=u.stateNode;u.flags&32&&(he(p,""),u.flags&=-33);var y=om(n);Xu(n,y,p);break;case 3:case 4:var A=u.stateNode.containerInfo,z=om(n);Wu(n,z,A);break;default:throw Error(t(161))}}catch(W){un(n,n.return,W)}n.flags&=-3}i&4096&&(n.flags&=-4097)}function pv(n,i,o){Je=n,dm(n)}function dm(n,i,o){for(var u=(n.mode&1)!==0;Je!==null;){var p=Je,y=p.child;if(p.tag===22&&u){var A=p.memoizedState!==null||dl;if(!A){var z=p.alternate,W=z!==null&&z.memoizedState!==null||On;z=dl;var xe=On;if(dl=A,(On=W)&&!xe)for(Je=p;Je!==null;)A=Je,W=A.child,A.tag===22&&A.memoizedState!==null?pm(p):W!==null?(W.return=A,Je=W):pm(p);for(;y!==null;)Je=y,dm(y),y=y.sibling;Je=p,dl=z,On=xe}hm(n)}else(p.subtreeFlags&8772)!==0&&y!==null?(y.return=p,Je=y):hm(n)}}function hm(n){for(;Je!==null;){var i=Je;if((i.flags&8772)!==0){var o=i.alternate;try{if((i.flags&8772)!==0)switch(i.tag){case 0:case 11:case 15:On||hl(5,i);break;case 1:var u=i.stateNode;if(i.flags&4&&!On)if(o===null)u.componentDidMount();else{var p=i.elementType===i.type?o.memoizedProps:Ni(i.type,o.memoizedProps);u.componentDidUpdate(p,o.memoizedState,u.__reactInternalSnapshotBeforeUpdate)}var y=i.updateQueue;y!==null&&fp(i,y,u);break;case 3:var A=i.updateQueue;if(A!==null){if(o=null,i.child!==null)switch(i.child.tag){case 5:o=i.child.stateNode;break;case 1:o=i.child.stateNode}fp(i,A,o)}break;case 5:var z=i.stateNode;if(o===null&&i.flags&4){o=z;var W=i.memoizedProps;switch(i.type){case"button":case"input":case"select":case"textarea":W.autoFocus&&o.focus();break;case"img":W.src&&(o.src=W.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(i.memoizedState===null){var xe=i.alternate;if(xe!==null){var Ne=xe.memoizedState;if(Ne!==null){var Ie=Ne.dehydrated;Ie!==null&&La(Ie)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(t(163))}On||i.flags&512&&Vu(i)}catch(Ce){un(i,i.return,Ce)}}if(i===n){Je=null;break}if(o=i.sibling,o!==null){o.return=i.return,Je=o;break}Je=i.return}}function fm(n){for(;Je!==null;){var i=Je;if(i===n){Je=null;break}var o=i.sibling;if(o!==null){o.return=i.return,Je=o;break}Je=i.return}}function pm(n){for(;Je!==null;){var i=Je;try{switch(i.tag){case 0:case 11:case 15:var o=i.return;try{hl(4,i)}catch(W){un(i,o,W)}break;case 1:var u=i.stateNode;if(typeof u.componentDidMount=="function"){var p=i.return;try{u.componentDidMount()}catch(W){un(i,p,W)}}var y=i.return;try{Vu(i)}catch(W){un(i,y,W)}break;case 5:var A=i.return;try{Vu(i)}catch(W){un(i,A,W)}}}catch(W){un(i,i.return,W)}if(i===n){Je=null;break}var z=i.sibling;if(z!==null){z.return=i.return,Je=z;break}Je=i.return}}var mv=Math.ceil,fl=C.ReactCurrentDispatcher,qu=C.ReactCurrentOwner,yi=C.ReactCurrentBatchConfig,Ut=0,En=null,mn=null,Nn=0,di=0,$s=Cr(0),_n=0,to=null,cs=0,pl=0,$u=0,no=null,ei=null,Yu=0,Ys=1/0,cr=null,ml=!1,Ku=null,Ir=null,gl=!1,kr=null,xl=0,io=0,Zu=null,vl=-1,_l=0;function Vn(){return(Ut&6)!==0?Ht():vl!==-1?vl:vl=Ht()}function Fr(n){return(n.mode&1)===0?1:(Ut&2)!==0&&Nn!==0?Nn&-Nn:Qx.transition!==null?(_l===0&&(_l=Ye()),_l):(n=At,n!==0||(n=window.event,n=n===void 0?16:gf(n.type)),n)}function Ii(n,i,o,u){if(50<io)throw io=0,Zu=null,Error(t(185));Et(n,o,u),((Ut&2)===0||n!==En)&&(n===En&&((Ut&2)===0&&(pl|=o),_n===4&&Ur(n,Nn)),ti(n,u),o===1&&Ut===0&&(i.mode&1)===0&&(Ys=Ht()+500,qo&&Pr()))}function ti(n,i){var o=n.callbackNode;Gt(n,i);var u=Xt(n,n===En?Nn:0);if(u===0)o!==null&&hn(o),n.callbackNode=null,n.callbackPriority=0;else if(i=u&-u,n.callbackPriority!==i){if(o!=null&&hn(o),i===1)n.tag===0?Zx(gm.bind(null,n)):tp(gm.bind(null,n)),qx(function(){(Ut&6)===0&&Pr()}),o=null;else{switch(tr(u)){case 1:o=Kt;break;case 4:o=R;break;case 16:o=G;break;case 536870912:o=te;break;default:o=G}o=wm(o,mm.bind(null,n))}n.callbackPriority=i,n.callbackNode=o}}function mm(n,i){if(vl=-1,_l=0,(Ut&6)!==0)throw Error(t(327));var o=n.callbackNode;if(Ks()&&n.callbackNode!==o)return null;var u=Xt(n,n===En?Nn:0);if(u===0)return null;if((u&30)!==0||(u&n.expiredLanes)!==0||i)i=yl(n,u);else{i=u;var p=Ut;Ut|=2;var y=vm();(En!==n||Nn!==i)&&(cr=null,Ys=Ht()+500,ds(n,i));do try{vv();break}catch(z){xm(n,z)}while(!0);mu(),fl.current=y,Ut=p,mn!==null?i=0:(En=null,Nn=0,i=_n)}if(i!==0){if(i===2&&(p=pn(n),p!==0&&(u=p,i=Qu(n,p))),i===1)throw o=to,ds(n,0),Ur(n,u),ti(n,Ht()),o;if(i===6)Ur(n,u);else{if(p=n.current.alternate,(u&30)===0&&!gv(p)&&(i=yl(n,u),i===2&&(y=pn(n),y!==0&&(u=y,i=Qu(n,y))),i===1))throw o=to,ds(n,0),Ur(n,u),ti(n,Ht()),o;switch(n.finishedWork=p,n.finishedLanes=u,i){case 0:case 1:throw Error(t(345));case 2:hs(n,ei,cr);break;case 3:if(Ur(n,u),(u&130023424)===u&&(i=Yu+500-Ht(),10<i)){if(Xt(n,0)!==0)break;if(p=n.suspendedLanes,(p&u)!==u){Vn(),n.pingedLanes|=n.suspendedLanes&p;break}n.timeoutHandle=ru(hs.bind(null,n,ei,cr),i);break}hs(n,ei,cr);break;case 4:if(Ur(n,u),(u&4194240)===u)break;for(i=n.eventTimes,p=-1;0<u;){var A=31-De(u);y=1<<A,A=i[A],A>p&&(p=A),u&=~y}if(u=p,u=Ht()-u,u=(120>u?120:480>u?480:1080>u?1080:1920>u?1920:3e3>u?3e3:4320>u?4320:1960*mv(u/1960))-u,10<u){n.timeoutHandle=ru(hs.bind(null,n,ei,cr),u);break}hs(n,ei,cr);break;case 5:hs(n,ei,cr);break;default:throw Error(t(329))}}}return ti(n,Ht()),n.callbackNode===o?mm.bind(null,n):null}function Qu(n,i){var o=no;return n.current.memoizedState.isDehydrated&&(ds(n,i).flags|=256),n=yl(n,i),n!==2&&(i=ei,ei=o,i!==null&&Ju(i)),n}function Ju(n){ei===null?ei=n:ei.push.apply(ei,n)}function gv(n){for(var i=n;;){if(i.flags&16384){var o=i.updateQueue;if(o!==null&&(o=o.stores,o!==null))for(var u=0;u<o.length;u++){var p=o[u],y=p.getSnapshot;p=p.value;try{if(!Ri(y(),p))return!1}catch{return!1}}}if(o=i.child,i.subtreeFlags&16384&&o!==null)o.return=i,i=o;else{if(i===n)break;for(;i.sibling===null;){if(i.return===null||i.return===n)return!0;i=i.return}i.sibling.return=i.return,i=i.sibling}}return!0}function Ur(n,i){for(i&=~$u,i&=~pl,n.suspendedLanes|=i,n.pingedLanes&=~i,n=n.expirationTimes;0<i;){var o=31-De(i),u=1<<o;n[o]=-1,i&=~u}}function gm(n){if((Ut&6)!==0)throw Error(t(327));Ks();var i=Xt(n,0);if((i&1)===0)return ti(n,Ht()),null;var o=yl(n,i);if(n.tag!==0&&o===2){var u=pn(n);u!==0&&(i=u,o=Qu(n,u))}if(o===1)throw o=to,ds(n,0),Ur(n,i),ti(n,Ht()),o;if(o===6)throw Error(t(345));return n.finishedWork=n.current.alternate,n.finishedLanes=i,hs(n,ei,cr),ti(n,Ht()),null}function ed(n,i){var o=Ut;Ut|=1;try{return n(i)}finally{Ut=o,Ut===0&&(Ys=Ht()+500,qo&&Pr())}}function us(n){kr!==null&&kr.tag===0&&(Ut&6)===0&&Ks();var i=Ut;Ut|=1;var o=yi.transition,u=At;try{if(yi.transition=null,At=1,n)return n()}finally{At=u,yi.transition=o,Ut=i,(Ut&6)===0&&Pr()}}function td(){di=$s.current,Jt($s)}function ds(n,i){n.finishedWork=null,n.finishedLanes=0;var o=n.timeoutHandle;if(o!==-1&&(n.timeoutHandle=-1,Xx(o)),mn!==null)for(o=mn.return;o!==null;){var u=o;switch(uu(u),u.tag){case 1:u=u.type.childContextTypes,u!=null&&Wo();break;case 3:Ws(),Jt(Zn),Jt(kn),Mu();break;case 5:bu(u);break;case 4:Ws();break;case 13:Jt(an);break;case 19:Jt(an);break;case 10:gu(u.type._context);break;case 22:case 23:td()}o=o.return}if(En=n,mn=n=Or(n.current,null),Nn=di=i,_n=0,to=null,$u=pl=cs=0,ei=no=null,as!==null){for(i=0;i<as.length;i++)if(o=as[i],u=o.interleaved,u!==null){o.interleaved=null;var p=u.next,y=o.pending;if(y!==null){var A=y.next;y.next=p,u.next=A}o.pending=u}as=null}return n}function xm(n,i){do{var o=mn;try{if(mu(),il.current=ol,rl){for(var u=on.memoizedState;u!==null;){var p=u.queue;p!==null&&(p.pending=null),u=u.next}rl=!1}if(ls=0,wn=vn=on=null,Ya=!1,Ka=0,qu.current=null,o===null||o.return===null){_n=1,to=i,mn=null;break}e:{var y=n,A=o.return,z=o,W=i;if(i=Nn,z.flags|=32768,W!==null&&typeof W=="object"&&typeof W.then=="function"){var xe=W,Ne=z,Ie=Ne.tag;if((Ne.mode&1)===0&&(Ie===0||Ie===11||Ie===15)){var Ce=Ne.alternate;Ce?(Ne.updateQueue=Ce.updateQueue,Ne.memoizedState=Ce.memoizedState,Ne.lanes=Ce.lanes):(Ne.updateQueue=null,Ne.memoizedState=null)}var Ke=Hp(A);if(Ke!==null){Ke.flags&=-257,Gp(Ke,A,z,y,i),Ke.mode&1&&jp(y,xe,i),i=Ke,W=xe;var nt=i.updateQueue;if(nt===null){var it=new Set;it.add(W),i.updateQueue=it}else nt.add(W);break e}else{if((i&1)===0){jp(y,xe,i),nd();break e}W=Error(t(426))}}else if(tn&&z.mode&1){var fn=Hp(A);if(fn!==null){(fn.flags&65536)===0&&(fn.flags|=256),Gp(fn,A,z,y,i),fu(Xs(W,z));break e}}y=W=Xs(W,z),_n!==4&&(_n=2),no===null?no=[y]:no.push(y),y=A;do{switch(y.tag){case 3:y.flags|=65536,i&=-i,y.lanes|=i;var ue=Bp(y,W,i);hp(y,ue);break e;case 1:z=W;var Z=y.type,pe=y.stateNode;if((y.flags&128)===0&&(typeof Z.getDerivedStateFromError=="function"||pe!==null&&typeof pe.componentDidCatch=="function"&&(Ir===null||!Ir.has(pe)))){y.flags|=65536,i&=-i,y.lanes|=i;var Fe=zp(y,z,i);hp(y,Fe);break e}}y=y.return}while(y!==null)}ym(o)}catch(st){i=st,mn===o&&o!==null&&(mn=o=o.return);continue}break}while(!0)}function vm(){var n=fl.current;return fl.current=ol,n===null?ol:n}function nd(){(_n===0||_n===3||_n===2)&&(_n=4),En===null||(cs&268435455)===0&&(pl&268435455)===0||Ur(En,Nn)}function yl(n,i){var o=Ut;Ut|=2;var u=vm();(En!==n||Nn!==i)&&(cr=null,ds(n,i));do try{xv();break}catch(p){xm(n,p)}while(!0);if(mu(),Ut=o,fl.current=u,mn!==null)throw Error(t(261));return En=null,Nn=0,_n}function xv(){for(;mn!==null;)_m(mn)}function vv(){for(;mn!==null&&!rn();)_m(mn)}function _m(n){var i=Mm(n.alternate,n,di);n.memoizedProps=n.pendingProps,i===null?ym(n):mn=i,qu.current=null}function ym(n){var i=n;do{var o=i.alternate;if(n=i.return,(i.flags&32768)===0){if(o=uv(o,i,di),o!==null){mn=o;return}}else{if(o=dv(o,i),o!==null){o.flags&=32767,mn=o;return}if(n!==null)n.flags|=32768,n.subtreeFlags=0,n.deletions=null;else{_n=6,mn=null;return}}if(i=i.sibling,i!==null){mn=i;return}mn=i=n}while(i!==null);_n===0&&(_n=5)}function hs(n,i,o){var u=At,p=yi.transition;try{yi.transition=null,At=1,_v(n,i,o,u)}finally{yi.transition=p,At=u}return null}function _v(n,i,o,u){do Ks();while(kr!==null);if((Ut&6)!==0)throw Error(t(327));o=n.finishedWork;var p=n.finishedLanes;if(o===null)return null;if(n.finishedWork=null,n.finishedLanes=0,o===n.current)throw Error(t(177));n.callbackNode=null,n.callbackPriority=0;var y=o.lanes|o.childLanes;if(Yn(n,y),n===En&&(mn=En=null,Nn=0),(o.subtreeFlags&2064)===0&&(o.flags&2064)===0||gl||(gl=!0,wm(G,function(){return Ks(),null})),y=(o.flags&15990)!==0,(o.subtreeFlags&15990)!==0||y){y=yi.transition,yi.transition=null;var A=At;At=1;var z=Ut;Ut|=4,qu.current=null,fv(n,o),um(o,n),Bx(nu),No=!!tu,nu=tu=null,n.current=o,pv(o),sn(),Ut=z,At=A,yi.transition=y}else n.current=o;if(gl&&(gl=!1,kr=n,xl=p),y=n.pendingLanes,y===0&&(Ir=null),Be(o.stateNode),ti(n,Ht()),i!==null)for(u=n.onRecoverableError,o=0;o<i.length;o++)p=i[o],u(p.value,{componentStack:p.stack,digest:p.digest});if(ml)throw ml=!1,n=Ku,Ku=null,n;return(xl&1)!==0&&n.tag!==0&&Ks(),y=n.pendingLanes,(y&1)!==0?n===Zu?io++:(io=0,Zu=n):io=0,Pr(),null}function Ks(){if(kr!==null){var n=tr(xl),i=yi.transition,o=At;try{if(yi.transition=null,At=16>n?16:n,kr===null)var u=!1;else{if(n=kr,kr=null,xl=0,(Ut&6)!==0)throw Error(t(331));var p=Ut;for(Ut|=4,Je=n.current;Je!==null;){var y=Je,A=y.child;if((Je.flags&16)!==0){var z=y.deletions;if(z!==null){for(var W=0;W<z.length;W++){var xe=z[W];for(Je=xe;Je!==null;){var Ne=Je;switch(Ne.tag){case 0:case 11:case 15:eo(8,Ne,y)}var Ie=Ne.child;if(Ie!==null)Ie.return=Ne,Je=Ie;else for(;Je!==null;){Ne=Je;var Ce=Ne.sibling,Ke=Ne.return;if(sm(Ne),Ne===xe){Je=null;break}if(Ce!==null){Ce.return=Ke,Je=Ce;break}Je=Ke}}}var nt=y.alternate;if(nt!==null){var it=nt.child;if(it!==null){nt.child=null;do{var fn=it.sibling;it.sibling=null,it=fn}while(it!==null)}}Je=y}}if((y.subtreeFlags&2064)!==0&&A!==null)A.return=y,Je=A;else e:for(;Je!==null;){if(y=Je,(y.flags&2048)!==0)switch(y.tag){case 0:case 11:case 15:eo(9,y,y.return)}var ue=y.sibling;if(ue!==null){ue.return=y.return,Je=ue;break e}Je=y.return}}var Z=n.current;for(Je=Z;Je!==null;){A=Je;var pe=A.child;if((A.subtreeFlags&2064)!==0&&pe!==null)pe.return=A,Je=pe;else e:for(A=Z;Je!==null;){if(z=Je,(z.flags&2048)!==0)try{switch(z.tag){case 0:case 11:case 15:hl(9,z)}}catch(st){un(z,z.return,st)}if(z===A){Je=null;break e}var Fe=z.sibling;if(Fe!==null){Fe.return=z.return,Je=Fe;break e}Je=z.return}}if(Ut=p,Pr(),Te&&typeof Te.onPostCommitFiberRoot=="function")try{Te.onPostCommitFiberRoot(ne,n)}catch{}u=!0}return u}finally{At=o,yi.transition=i}}return!1}function bm(n,i,o){i=Xs(o,i),i=Bp(n,i,1),n=Lr(n,i,1),i=Vn(),n!==null&&(Et(n,1,i),ti(n,i))}function un(n,i,o){if(n.tag===3)bm(n,n,o);else for(;i!==null;){if(i.tag===3){bm(i,n,o);break}else if(i.tag===1){var u=i.stateNode;if(typeof i.type.getDerivedStateFromError=="function"||typeof u.componentDidCatch=="function"&&(Ir===null||!Ir.has(u))){n=Xs(o,n),n=zp(i,n,1),i=Lr(i,n,1),n=Vn(),i!==null&&(Et(i,1,n),ti(i,n));break}}i=i.return}}function yv(n,i,o){var u=n.pingCache;u!==null&&u.delete(i),i=Vn(),n.pingedLanes|=n.suspendedLanes&o,En===n&&(Nn&o)===o&&(_n===4||_n===3&&(Nn&130023424)===Nn&&500>Ht()-Yu?ds(n,0):$u|=o),ti(n,i)}function Sm(n,i){i===0&&((n.mode&1)===0?i=1:(i=et,et<<=1,(et&130023424)===0&&(et=4194304)));var o=Vn();n=ar(n,i),n!==null&&(Et(n,i,o),ti(n,o))}function bv(n){var i=n.memoizedState,o=0;i!==null&&(o=i.retryLane),Sm(n,o)}function Sv(n,i){var o=0;switch(n.tag){case 13:var u=n.stateNode,p=n.memoizedState;p!==null&&(o=p.retryLane);break;case 19:u=n.stateNode;break;default:throw Error(t(314))}u!==null&&u.delete(i),Sm(n,o)}var Mm;Mm=function(n,i,o){if(n!==null)if(n.memoizedProps!==i.pendingProps||Zn.current)Jn=!0;else{if((n.lanes&o)===0&&(i.flags&128)===0)return Jn=!1,cv(n,i,o);Jn=(n.flags&131072)!==0}else Jn=!1,tn&&(i.flags&1048576)!==0&&np(i,Yo,i.index);switch(i.lanes=0,i.tag){case 2:var u=i.type;ul(n,i),n=i.pendingProps;var p=Os(i,kn.current);Vs(i,o),p=Tu(null,i,u,n,p,o);var y=Au();return i.flags|=1,typeof p=="object"&&p!==null&&typeof p.render=="function"&&p.$$typeof===void 0?(i.tag=1,i.memoizedState=null,i.updateQueue=null,Qn(u)?(y=!0,Xo(i)):y=!1,i.memoizedState=p.state!==null&&p.state!==void 0?p.state:null,_u(i),p.updater=ll,i.stateNode=p,p._reactInternals=i,Du(i,u,n,o),i=Uu(null,i,u,!0,y,o)):(i.tag=0,tn&&y&&cu(i),Gn(null,i,p,o),i=i.child),i;case 16:u=i.elementType;e:{switch(ul(n,i),n=i.pendingProps,p=u._init,u=p(u._payload),i.type=u,p=i.tag=wv(u),n=Ni(u,n),p){case 0:i=Fu(null,i,u,n,o);break e;case 1:i=Yp(null,i,u,n,o);break e;case 11:i=Vp(null,i,u,n,o);break e;case 14:i=Wp(null,i,u,Ni(u.type,n),o);break e}throw Error(t(306,u,""))}return i;case 0:return u=i.type,p=i.pendingProps,p=i.elementType===u?p:Ni(u,p),Fu(n,i,u,p,o);case 1:return u=i.type,p=i.pendingProps,p=i.elementType===u?p:Ni(u,p),Yp(n,i,u,p,o);case 3:e:{if(Kp(i),n===null)throw Error(t(387));u=i.pendingProps,y=i.memoizedState,p=y.element,dp(n,i),tl(i,u,null,o);var A=i.memoizedState;if(u=A.element,y.isDehydrated)if(y={element:u,isDehydrated:!1,cache:A.cache,pendingSuspenseBoundaries:A.pendingSuspenseBoundaries,transitions:A.transitions},i.updateQueue.baseState=y,i.memoizedState=y,i.flags&256){p=Xs(Error(t(423)),i),i=Zp(n,i,u,o,p);break e}else if(u!==p){p=Xs(Error(t(424)),i),i=Zp(n,i,u,o,p);break e}else for(ui=Ar(i.stateNode.containerInfo.firstChild),ci=i,tn=!0,Pi=null,o=cp(i,null,u,o),i.child=o;o;)o.flags=o.flags&-3|4096,o=o.sibling;else{if(js(),u===p){i=lr(n,i,o);break e}Gn(n,i,u,o)}i=i.child}return i;case 5:return pp(i),n===null&&hu(i),u=i.type,p=i.pendingProps,y=n!==null?n.memoizedProps:null,A=p.children,iu(u,p)?A=null:y!==null&&iu(u,y)&&(i.flags|=32),$p(n,i),Gn(n,i,A,o),i.child;case 6:return n===null&&hu(i),null;case 13:return Qp(n,i,o);case 4:return yu(i,i.stateNode.containerInfo),u=i.pendingProps,n===null?i.child=Hs(i,null,u,o):Gn(n,i,u,o),i.child;case 11:return u=i.type,p=i.pendingProps,p=i.elementType===u?p:Ni(u,p),Vp(n,i,u,p,o);case 7:return Gn(n,i,i.pendingProps,o),i.child;case 8:return Gn(n,i,i.pendingProps.children,o),i.child;case 12:return Gn(n,i,i.pendingProps.children,o),i.child;case 10:e:{if(u=i.type._context,p=i.pendingProps,y=i.memoizedProps,A=p.value,Yt(Qo,u._currentValue),u._currentValue=A,y!==null)if(Ri(y.value,A)){if(y.children===p.children&&!Zn.current){i=lr(n,i,o);break e}}else for(y=i.child,y!==null&&(y.return=i);y!==null;){var z=y.dependencies;if(z!==null){A=y.child;for(var W=z.firstContext;W!==null;){if(W.context===u){if(y.tag===1){W=or(-1,o&-o),W.tag=2;var xe=y.updateQueue;if(xe!==null){xe=xe.shared;var Ne=xe.pending;Ne===null?W.next=W:(W.next=Ne.next,Ne.next=W),xe.pending=W}}y.lanes|=o,W=y.alternate,W!==null&&(W.lanes|=o),xu(y.return,o,i),z.lanes|=o;break}W=W.next}}else if(y.tag===10)A=y.type===i.type?null:y.child;else if(y.tag===18){if(A=y.return,A===null)throw Error(t(341));A.lanes|=o,z=A.alternate,z!==null&&(z.lanes|=o),xu(A,o,i),A=y.sibling}else A=y.child;if(A!==null)A.return=y;else for(A=y;A!==null;){if(A===i){A=null;break}if(y=A.sibling,y!==null){y.return=A.return,A=y;break}A=A.return}y=A}Gn(n,i,p.children,o),i=i.child}return i;case 9:return p=i.type,u=i.pendingProps.children,Vs(i,o),p=vi(p),u=u(p),i.flags|=1,Gn(n,i,u,o),i.child;case 14:return u=i.type,p=Ni(u,i.pendingProps),p=Ni(u.type,p),Wp(n,i,u,p,o);case 15:return Xp(n,i,i.type,i.pendingProps,o);case 17:return u=i.type,p=i.pendingProps,p=i.elementType===u?p:Ni(u,p),ul(n,i),i.tag=1,Qn(u)?(n=!0,Xo(i)):n=!1,Vs(i,o),Up(i,u,p),Du(i,u,p,o),Uu(null,i,u,!0,n,o);case 19:return em(n,i,o);case 22:return qp(n,i,o)}throw Error(t(156,i.tag))};function wm(n,i){return $t(n,i)}function Mv(n,i,o,u){this.tag=n,this.key=o,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=i,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=u,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function bi(n,i,o,u){return new Mv(n,i,o,u)}function id(n){return n=n.prototype,!(!n||!n.isReactComponent)}function wv(n){if(typeof n=="function")return id(n)?1:0;if(n!=null){if(n=n.$$typeof,n===V)return 11;if(n===ie)return 14}return 2}function Or(n,i){var o=n.alternate;return o===null?(o=bi(n.tag,i,n.key,n.mode),o.elementType=n.elementType,o.type=n.type,o.stateNode=n.stateNode,o.alternate=n,n.alternate=o):(o.pendingProps=i,o.type=n.type,o.flags=0,o.subtreeFlags=0,o.deletions=null),o.flags=n.flags&14680064,o.childLanes=n.childLanes,o.lanes=n.lanes,o.child=n.child,o.memoizedProps=n.memoizedProps,o.memoizedState=n.memoizedState,o.updateQueue=n.updateQueue,i=n.dependencies,o.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext},o.sibling=n.sibling,o.index=n.index,o.ref=n.ref,o}function bl(n,i,o,u,p,y){var A=2;if(u=n,typeof n=="function")id(n)&&(A=1);else if(typeof n=="string")A=5;else e:switch(n){case O:return fs(o.children,p,y,i);case T:A=8,p|=8;break;case I:return n=bi(12,o,i,p|2),n.elementType=I,n.lanes=y,n;case ae:return n=bi(13,o,i,p),n.elementType=ae,n.lanes=y,n;case Q:return n=bi(19,o,i,p),n.elementType=Q,n.lanes=y,n;case re:return Sl(o,p,y,i);default:if(typeof n=="object"&&n!==null)switch(n.$$typeof){case H:A=10;break e;case B:A=9;break e;case V:A=11;break e;case ie:A=14;break e;case de:A=16,u=null;break e}throw Error(t(130,n==null?n:typeof n,""))}return i=bi(A,o,i,p),i.elementType=n,i.type=u,i.lanes=y,i}function fs(n,i,o,u){return n=bi(7,n,u,i),n.lanes=o,n}function Sl(n,i,o,u){return n=bi(22,n,u,i),n.elementType=re,n.lanes=o,n.stateNode={isHidden:!1},n}function rd(n,i,o){return n=bi(6,n,null,i),n.lanes=o,n}function sd(n,i,o){return i=bi(4,n.children!==null?n.children:[],n.key,i),i.lanes=o,i.stateNode={containerInfo:n.containerInfo,pendingChildren:null,implementation:n.implementation},i}function Ev(n,i,o,u,p){this.tag=i,this.containerInfo=n,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=Rn(0),this.expirationTimes=Rn(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Rn(0),this.identifierPrefix=u,this.onRecoverableError=p,this.mutableSourceEagerHydrationData=null}function ad(n,i,o,u,p,y,A,z,W){return n=new Ev(n,i,o,z,W),i===1?(i=1,y===!0&&(i|=8)):i=0,y=bi(3,null,null,i),n.current=y,y.stateNode=n,y.memoizedState={element:u,isDehydrated:o,cache:null,transitions:null,pendingSuspenseBoundaries:null},_u(y),n}function Tv(n,i,o){var u=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:L,key:u==null?null:""+u,children:n,containerInfo:i,implementation:o}}function Em(n){if(!n)return Rr;n=n._reactInternals;e:{if(xn(n)!==n||n.tag!==1)throw Error(t(170));var i=n;do{switch(i.tag){case 3:i=i.stateNode.context;break e;case 1:if(Qn(i.type)){i=i.stateNode.__reactInternalMemoizedMergedChildContext;break e}}i=i.return}while(i!==null);throw Error(t(171))}if(n.tag===1){var o=n.type;if(Qn(o))return Jf(n,o,i)}return i}function Tm(n,i,o,u,p,y,A,z,W){return n=ad(o,u,!0,n,p,y,A,z,W),n.context=Em(null),o=n.current,u=Vn(),p=Fr(o),y=or(u,p),y.callback=i??null,Lr(o,y,p),n.current.lanes=p,Et(n,p,u),ti(n,u),n}function Ml(n,i,o,u){var p=i.current,y=Vn(),A=Fr(p);return o=Em(o),i.context===null?i.context=o:i.pendingContext=o,i=or(y,A),i.payload={element:n},u=u===void 0?null:u,u!==null&&(i.callback=u),n=Lr(p,i,A),n!==null&&(Ii(n,p,A,y),el(n,p,A)),A}function wl(n){if(n=n.current,!n.child)return null;switch(n.child.tag){case 5:return n.child.stateNode;default:return n.child.stateNode}}function Am(n,i){if(n=n.memoizedState,n!==null&&n.dehydrated!==null){var o=n.retryLane;n.retryLane=o!==0&&o<i?o:i}}function od(n,i){Am(n,i),(n=n.alternate)&&Am(n,i)}function Av(){return null}var Cm=typeof reportError=="function"?reportError:function(n){console.error(n)};function ld(n){this._internalRoot=n}El.prototype.render=ld.prototype.render=function(n){var i=this._internalRoot;if(i===null)throw Error(t(409));Ml(n,i,null,null)},El.prototype.unmount=ld.prototype.unmount=function(){var n=this._internalRoot;if(n!==null){this._internalRoot=null;var i=n.containerInfo;us(function(){Ml(null,n,null,null)}),i[nr]=null}};function El(n){this._internalRoot=n}El.prototype.unstable_scheduleHydration=function(n){if(n){var i=Vt();n={blockedOn:null,target:n,priority:i};for(var o=0;o<wr.length&&i!==0&&i<wr[o].priority;o++);wr.splice(o,0,n),o===0&&pf(n)}};function cd(n){return!(!n||n.nodeType!==1&&n.nodeType!==9&&n.nodeType!==11)}function Tl(n){return!(!n||n.nodeType!==1&&n.nodeType!==9&&n.nodeType!==11&&(n.nodeType!==8||n.nodeValue!==" react-mount-point-unstable "))}function Rm(){}function Cv(n,i,o,u,p){if(p){if(typeof u=="function"){var y=u;u=function(){var xe=wl(A);y.call(xe)}}var A=Tm(i,u,n,0,null,!1,!1,"",Rm);return n._reactRootContainer=A,n[nr]=A.current,ja(n.nodeType===8?n.parentNode:n),us(),A}for(;p=n.lastChild;)n.removeChild(p);if(typeof u=="function"){var z=u;u=function(){var xe=wl(W);z.call(xe)}}var W=ad(n,0,!1,null,null,!1,!1,"",Rm);return n._reactRootContainer=W,n[nr]=W.current,ja(n.nodeType===8?n.parentNode:n),us(function(){Ml(i,W,o,u)}),W}function Al(n,i,o,u,p){var y=o._reactRootContainer;if(y){var A=y;if(typeof p=="function"){var z=p;p=function(){var W=wl(A);z.call(W)}}Ml(i,A,n,p)}else A=Cv(o,i,n,p,u);return wl(A)}zt=function(n){switch(n.tag){case 3:var i=n.stateNode;if(i.current.memoizedState.isDehydrated){var o=Pt(i.pendingLanes);o!==0&&(Kn(i,o|1),ti(i,Ht()),(Ut&6)===0&&(Ys=Ht()+500,Pr()))}break;case 13:us(function(){var u=ar(n,1);if(u!==null){var p=Vn();Ii(u,n,1,p)}}),od(n,1)}},Zt=function(n){if(n.tag===13){var i=ar(n,134217728);if(i!==null){var o=Vn();Ii(i,n,134217728,o)}od(n,134217728)}},Ai=function(n){if(n.tag===13){var i=Fr(n),o=ar(n,i);if(o!==null){var u=Vn();Ii(o,n,i,u)}od(n,i)}},Vt=function(){return At},Ci=function(n,i){var o=At;try{return At=n,i()}finally{At=o}},tt=function(n,i,o){switch(i){case"input":if(St(n,o),i=o.name,o.type==="radio"&&i!=null){for(o=n;o.parentNode;)o=o.parentNode;for(o=o.querySelectorAll("input[name="+JSON.stringify(""+i)+'][type="radio"]'),i=0;i<o.length;i++){var u=o[i];if(u!==n&&u.form===n.form){var p=Vo(u);if(!p)throw Error(t(90));bt(u),St(u,p)}}}break;case"textarea":Qe(n,o);break;case"select":i=o.value,i!=null&&ht(n,!!o.multiple,i,!1)}},Ae=ed,Se=us;var Rv={usingClientEntryPoint:!1,Events:[Va,Fs,Vo,ge,Pe,ed]},ro={findFiberByHostInstance:ns,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},Pv={bundleType:ro.bundleType,version:ro.version,rendererPackageName:ro.rendererPackageName,rendererConfig:ro.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:C.ReactCurrentDispatcher,findHostInstanceByFiber:function(n){return n=Ot(n),n===null?null:n.stateNode},findFiberByHostInstance:ro.findFiberByHostInstance||Av,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Cl=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Cl.isDisabled&&Cl.supportsFiber)try{ne=Cl.inject(Pv),Te=Cl}catch{}}return ni.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=Rv,ni.createPortal=function(n,i){var o=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!cd(i))throw Error(t(200));return Tv(n,i,null,o)},ni.createRoot=function(n,i){if(!cd(n))throw Error(t(299));var o=!1,u="",p=Cm;return i!=null&&(i.unstable_strictMode===!0&&(o=!0),i.identifierPrefix!==void 0&&(u=i.identifierPrefix),i.onRecoverableError!==void 0&&(p=i.onRecoverableError)),i=ad(n,1,!1,null,null,o,!1,u,p),n[nr]=i.current,ja(n.nodeType===8?n.parentNode:n),new ld(i)},ni.findDOMNode=function(n){if(n==null)return null;if(n.nodeType===1)return n;var i=n._reactInternals;if(i===void 0)throw typeof n.render=="function"?Error(t(188)):(n=Object.keys(n).join(","),Error(t(268,n)));return n=Ot(i),n=n===null?null:n.stateNode,n},ni.flushSync=function(n){return us(n)},ni.hydrate=function(n,i,o){if(!Tl(i))throw Error(t(200));return Al(null,n,i,!0,o)},ni.hydrateRoot=function(n,i,o){if(!cd(n))throw Error(t(405));var u=o!=null&&o.hydratedSources||null,p=!1,y="",A=Cm;if(o!=null&&(o.unstable_strictMode===!0&&(p=!0),o.identifierPrefix!==void 0&&(y=o.identifierPrefix),o.onRecoverableError!==void 0&&(A=o.onRecoverableError)),i=Tm(i,null,n,1,o??null,p,!1,y,A),n[nr]=i.current,ja(n),u)for(n=0;n<u.length;n++)o=u[n],p=o._getVersion,p=p(o._source),i.mutableSourceEagerHydrationData==null?i.mutableSourceEagerHydrationData=[o,p]:i.mutableSourceEagerHydrationData.push(o,p);return new El(i)},ni.render=function(n,i,o){if(!Tl(i))throw Error(t(200));return Al(null,n,i,!1,o)},ni.unmountComponentAtNode=function(n){if(!Tl(n))throw Error(t(40));return n._reactRootContainer?(us(function(){Al(null,null,n,!1,function(){n._reactRootContainer=null,n[nr]=null})}),!0):!1},ni.unstable_batchedUpdates=ed,ni.unstable_renderSubtreeIntoContainer=function(n,i,o,u){if(!Tl(o))throw Error(t(200));if(n==null||n._reactInternals===void 0)throw Error(t(38));return Al(n,i,o,!1,u)},ni.version="18.3.1-next-f1338f8080-20240426",ni}var Um;function Bv(){if(Um)return hd.exports;Um=1;function s(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(s)}catch(e){console.error(e)}}return s(),hd.exports=Ov(),hd.exports}var Om;function zv(){if(Om)return Rl;Om=1;var s=Bv();return Rl.createRoot=s.createRoot,Rl.hydrateRoot=s.hydrateRoot,Rl}var jv=zv();const Hv=tg(jv);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Gv=s=>s.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),ng=(...s)=>s.filter((e,t,r)=>!!e&&e.trim()!==""&&r.indexOf(e)===t).join(" ").trim();/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var Vv={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Wv=Y.forwardRef(({color:s="currentColor",size:e=24,strokeWidth:t=2,absoluteStrokeWidth:r,className:a="",children:l,iconNode:d,...h},f)=>Y.createElement("svg",{ref:f,...Vv,width:e,height:e,stroke:s,strokeWidth:r?Number(t)*24/Number(e):t,className:ng("lucide",a),...h},[...d.map(([m,_])=>Y.createElement(m,_)),...Array.isArray(l)?l:[l]]));/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const rt=(s,e)=>{const t=Y.forwardRef(({className:r,...a},l)=>Y.createElement(Wv,{ref:l,iconNode:e,className:ng(`lucide-${Gv(s)}`,r),...a}));return t.displayName=`${s}`,t};/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ig=rt("Activity",[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const gc=rt("Anchor",[["path",{d:"M12 22V8",key:"qkxhtm"}],["path",{d:"M5 12H2a10 10 0 0 0 20 0h-3",key:"1hv3nh"}],["circle",{cx:"12",cy:"5",r:"3",key:"rqqgnr"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xv=rt("AudioWaveform",[["path",{d:"M2 13a2 2 0 0 0 2-2V7a2 2 0 0 1 4 0v13a2 2 0 0 0 4 0V4a2 2 0 0 1 4 0v13a2 2 0 0 0 4 0v-4a2 2 0 0 1 2-2",key:"57tc96"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qv=rt("Ban",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m4.9 4.9 14.2 14.2",key:"1m5liu"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const rg=rt("BookOpen",[["path",{d:"M12 7v14",key:"1akyts"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",key:"ruj8y"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $v=rt("Bot",[["path",{d:"M12 8V4H8",key:"hb8ula"}],["rect",{width:"16",height:"12",x:"4",y:"8",rx:"2",key:"enze0r"}],["path",{d:"M2 14h2",key:"vft8re"}],["path",{d:"M20 14h2",key:"4cs60a"}],["path",{d:"M15 13v2",key:"1xurst"}],["path",{d:"M9 13v2",key:"rq6x2g"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Vh=rt("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ys=rt("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Yv=rt("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Kv=rt("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const bs=rt("ChevronUp",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Zv=rt("CircleAlert",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qv=rt("CircleCheck",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ac=rt("CircleDot",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"1",key:"41hilf"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Jv=rt("Clipboard",[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",key:"116196"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Wh=rt("CodeXml",[["path",{d:"m18 16 4-4-4-4",key:"1inbqp"}],["path",{d:"m6 8-4 4 4 4",key:"15zrgr"}],["path",{d:"m14.5 4-5 16",key:"e7oirm"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e_=rt("Code",[["polyline",{points:"16 18 22 12 16 6",key:"z7tu5w"}],["polyline",{points:"8 6 2 12 8 18",key:"1eg1df"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xc=rt("Compass",[["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z",key:"9ktpf1"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t_=rt("Copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const sg=rt("Cpu",[["rect",{width:"16",height:"16",x:"4",y:"4",rx:"2",key:"14l7u7"}],["rect",{width:"6",height:"6",x:"9",y:"9",rx:"1",key:"5aljv4"}],["path",{d:"M15 2v2",key:"13l42r"}],["path",{d:"M15 20v2",key:"15mkzm"}],["path",{d:"M2 15h2",key:"1gxd5l"}],["path",{d:"M2 9h2",key:"1bbxkp"}],["path",{d:"M20 15h2",key:"19e6y8"}],["path",{d:"M20 9h2",key:"19tzq7"}],["path",{d:"M9 2v2",key:"165o2o"}],["path",{d:"M9 20v2",key:"i2bqo8"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n_=rt("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i_=rt("Eye",[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r_=rt("FileCode",[["path",{d:"M10 12.5 8 15l2 2.5",key:"1tg20x"}],["path",{d:"m14 12.5 2 2.5-2 2.5",key:"yinavb"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z",key:"1mlx9k"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Bm=rt("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s_=rt("FileWarning",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Yr=rt("Flame",[["path",{d:"M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z",key:"96xj49"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a_=rt("Gauge",[["path",{d:"m12 14 4-4",key:"9kzdfg"}],["path",{d:"M3.34 19a10 10 0 1 1 17.32 0",key:"19p75a"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o_=rt("Github",[["path",{d:"M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4",key:"tonef"}],["path",{d:"M9 18c-4.51 2-5-2-7-2",key:"9comsn"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l_=rt("GraduationCap",[["path",{d:"M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",key:"j76jl0"}],["path",{d:"M22 10v6",key:"1lu8f3"}],["path",{d:"M6 12.5V16a6 3 0 0 0 12 0v-3.5",key:"1r8lef"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xh=rt("Info",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c_=rt("Key",[["path",{d:"m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4",key:"g0fldk"}],["path",{d:"m21 2-9.6 9.6",key:"1j0ho8"}],["circle",{cx:"7.5",cy:"15.5",r:"5.5",key:"yqb3hr"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u_=rt("Layers",[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const vc=rt("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d_=rt("Magnet",[["path",{d:"m6 15-4-4 6.75-6.77a7.79 7.79 0 0 1 11 11L13 22l-4-4 6.39-6.36a2.14 2.14 0 0 0-3-3L6 15",key:"1i3lhw"}],["path",{d:"m5 8 4 4",key:"j6kj7e"}],["path",{d:"m12 15 4 4",key:"lnac28"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h_=rt("Maximize2",[["polyline",{points:"15 3 21 3 21 9",key:"mznyad"}],["polyline",{points:"9 21 3 21 3 15",key:"1avn1i"}],["line",{x1:"21",x2:"14",y1:"3",y2:"10",key:"ota7mn"}],["line",{x1:"3",x2:"10",y1:"21",y2:"14",key:"1atl0r"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f_=rt("MessageSquare",[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",key:"1lielz"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ag=rt("Minimize2",[["polyline",{points:"4 14 10 14 10 20",key:"11kfnr"}],["polyline",{points:"20 10 14 10 14 4",key:"rlmsce"}],["line",{x1:"14",x2:"21",y1:"10",y2:"3",key:"o5lafz"}],["line",{x1:"3",x2:"10",y1:"21",y2:"14",key:"1atl0r"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const zm=rt("Move",[["path",{d:"M12 2v20",key:"t6zp3m"}],["path",{d:"m15 19-3 3-3-3",key:"11eu04"}],["path",{d:"m19 9 3 3-3 3",key:"1mg7y2"}],["path",{d:"M2 12h20",key:"9i4pu4"}],["path",{d:"m5 9-3 3 3 3",key:"j64kie"}],["path",{d:"m9 5 3-3 3 3",key:"l8vdw6"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p_=rt("Orbit",[["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}],["circle",{cx:"19",cy:"5",r:"2",key:"mhkx31"}],["circle",{cx:"5",cy:"19",r:"2",key:"v8kfzx"}],["path",{d:"M10.4 21.9a10 10 0 0 0 9.941-15.416",key:"eohfx2"}],["path",{d:"M13.5 2.1a10 10 0 0 0-9.841 15.416",key:"19pvbm"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m_=rt("Pause",[["rect",{x:"14",y:"4",width:"4",height:"16",rx:"1",key:"zuxfzm"}],["rect",{x:"6",y:"4",width:"4",height:"16",rx:"1",key:"1okwgv"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qh=rt("Play",[["polygon",{points:"6 3 20 12 6 21 6 3",key:"1oa8hb"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const jm=rt("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const g_=rt("RotateCcw",[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $h=rt("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x_=rt("Send",[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v_=rt("Server",[["rect",{width:"20",height:"8",x:"2",y:"2",rx:"2",ry:"2",key:"ngkwjq"}],["rect",{width:"20",height:"8",x:"2",y:"14",rx:"2",ry:"2",key:"iecqi9"}],["line",{x1:"6",x2:"6.01",y1:"6",y2:"6",key:"16zg32"}],["line",{x1:"6",x2:"6.01",y1:"18",y2:"18",key:"nzw8ys"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const og=rt("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const __=rt("Share2",[["circle",{cx:"18",cy:"5",r:"3",key:"gq8acd"}],["circle",{cx:"6",cy:"12",r:"3",key:"w7nqdw"}],["circle",{cx:"18",cy:"19",r:"3",key:"1xt0gg"}],["line",{x1:"8.59",x2:"15.42",y1:"13.51",y2:"17.49",key:"47mynk"}],["line",{x1:"15.41",x2:"8.59",y1:"6.51",y2:"10.49",key:"1n3mei"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y_=rt("ShieldAlert",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M12 8v4",key:"1got3b"}],["path",{d:"M12 16h.01",key:"1drbdi"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Yh=rt("ShieldCheck",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const fa=rt("Shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b_=rt("SlidersHorizontal",[["line",{x1:"21",x2:"14",y1:"4",y2:"4",key:"obuewd"}],["line",{x1:"10",x2:"3",y1:"4",y2:"4",key:"1q6298"}],["line",{x1:"21",x2:"12",y1:"12",y2:"12",key:"1iu8h1"}],["line",{x1:"8",x2:"3",y1:"12",y2:"12",key:"ntss68"}],["line",{x1:"21",x2:"16",y1:"20",y2:"20",key:"14d8ph"}],["line",{x1:"12",x2:"3",y1:"20",y2:"20",key:"m0wm8r"}],["line",{x1:"14",x2:"14",y1:"2",y2:"6",key:"14e1ph"}],["line",{x1:"8",x2:"8",y1:"10",y2:"14",key:"1i6ji0"}],["line",{x1:"16",x2:"16",y1:"18",y2:"22",key:"1lctlv"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ga=rt("SlidersVertical",[["line",{x1:"4",x2:"4",y1:"21",y2:"14",key:"1p332r"}],["line",{x1:"4",x2:"4",y1:"10",y2:"3",key:"gb41h5"}],["line",{x1:"12",x2:"12",y1:"21",y2:"12",key:"hf2csr"}],["line",{x1:"12",x2:"12",y1:"8",y2:"3",key:"1kfi7u"}],["line",{x1:"20",x2:"20",y1:"21",y2:"16",key:"1lhrwl"}],["line",{x1:"20",x2:"20",y1:"12",y2:"3",key:"16vvfq"}],["line",{x1:"2",x2:"6",y1:"14",y2:"14",key:"1uebub"}],["line",{x1:"10",x2:"14",y1:"8",y2:"8",key:"1yglbp"}],["line",{x1:"18",x2:"22",y1:"16",y2:"16",key:"1jxqpz"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const So=rt("Sparkles",[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}],["path",{d:"M20 3v4",key:"1olli1"}],["path",{d:"M22 5h-4",key:"1gvqau"}],["path",{d:"M4 17v2",key:"vumght"}],["path",{d:"M5 18H3",key:"zchphs"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const lg=rt("Swords",[["polyline",{points:"14.5 17.5 3 6 3 3 6 3 17.5 14.5",key:"1hfsw2"}],["line",{x1:"13",x2:"19",y1:"19",y2:"13",key:"1vrmhu"}],["line",{x1:"16",x2:"20",y1:"16",y2:"20",key:"1bron3"}],["line",{x1:"19",x2:"21",y1:"21",y2:"19",key:"13pww6"}],["polyline",{points:"14.5 6.5 18 3 21 3 21 6 17.5 9.5",key:"hbey2j"}],["line",{x1:"5",x2:"9",y1:"14",y2:"18",key:"1hf58s"}],["line",{x1:"7",x2:"4",y1:"17",y2:"20",key:"pidxm4"}],["line",{x1:"3",x2:"5",y1:"19",y2:"21",key:"1pehsh"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const S_=rt("Terminal",[["polyline",{points:"4 17 10 11 4 5",key:"akl6gq"}],["line",{x1:"12",x2:"20",y1:"19",y2:"19",key:"q2wloq"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Kd=rt("TriangleAlert",[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M_=rt("UserCheck",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["polyline",{points:"16 11 18 13 22 9",key:"1pwet4"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w_=rt("Volume2",[["path",{d:"M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",key:"uqj9uw"}],["path",{d:"M16 9a5 5 0 0 1 0 6",key:"1q6k2b"}],["path",{d:"M19.364 18.364a9 9 0 0 0 0-12.728",key:"ijwkga"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E_=rt("VolumeX",[["path",{d:"M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",key:"uqj9uw"}],["line",{x1:"22",x2:"16",y1:"9",y2:"15",key:"1ewh16"}],["line",{x1:"16",x2:"22",y1:"9",y2:"15",key:"5ykzw1"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _c=rt("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const cg=rt("Zap",[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]]),T_=({activeTab:s,setActiveTab:e,splitView:t,setSplitView:r,onOpenSettings:a,onCopySetupLink:l,onOpenCodeExport:d})=>{const[h,f]=Y.useState(!1),m=()=>{l(),f(!0),setTimeout(()=>f(!1),2e3)};return c.jsx("header",{className:"sticky top-0 z-40 w-full bg-[#1c1c21]/95 border-b border-white/5 backdrop-blur-md",children:c.jsxs("div",{className:"mx-auto flex max-w-7xl flex-wrap items-center gap-x-3 gap-y-2 px-4 py-2.5 sm:flex-nowrap sm:px-6 sm:py-3",children:[c.jsxs("div",{className:"flex min-w-0 flex-1 items-center space-x-3 sm:flex-none",children:[c.jsx("div",{className:"flex h-9 w-9 items-center justify-center rounded-lg bg-blue-500/10 border border-blue-500/30",children:c.jsx(p_,{className:"h-4 w-4 text-blue-400"})}),c.jsxs("div",{children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx("h1",{className:"whitespace-nowrap text-base font-bold text-white sm:text-xl",children:"The Token Cosmos"}),c.jsx("span",{className:"hidden rounded-full border border-blue-500/30 bg-blue-500/20 px-2.5 py-0.5 font-mono text-[10px] text-blue-300 sm:inline",children:"v4.1"})]}),c.jsx("p",{className:"text-xs text-gray-400 hidden sm:block",children:"Interactive X-Ray & Linter for Language Model Probabilities"})]})]}),c.jsxs("div",{className:"flex w-full items-center justify-between gap-1 overflow-x-auto sm:ml-auto sm:w-auto sm:justify-end sm:gap-2",children:[c.jsxs("button",{onClick:m,"aria-label":"Copy current parameter setup link to clipboard",className:"btn-secondary-matte flex shrink-0 items-center space-x-1.5 rounded-full p-2 text-xs sm:px-3.5 sm:py-1.5",title:"Copy Setup Link to Clipboard",children:[h?c.jsx(Vh,{className:"h-3.5 w-3.5 text-emerald-400"}):c.jsx(__,{className:"h-3.5 w-3.5"}),c.jsx("span",{className:"hidden sm:inline",children:h?"Link Copied!":"Share Setup"})]}),c.jsx("button",{onClick:a,"aria-label":"Open Bring Your Own Engine configuration settings modal",className:"btn-secondary-matte shrink-0 rounded-full p-2 text-xs",title:"Bring Your Own Engine (BYOE) Settings",children:c.jsx(og,{className:"h-4 w-4"})}),s==="experiment"&&c.jsxs("button",{onClick:()=>r(!t),"aria-label":t?"Disable A/B Duel Mode":"Enable side-by-side A/B Duel Mode",className:`flex shrink-0 items-center space-x-2 rounded-full p-2 text-xs font-medium transition-all sm:px-3.5 sm:py-1.5 ${t?"bg-blue-600 text-white border border-blue-500 shadow-sm":"btn-secondary-matte"}`,title:"Compare Model / Parameter Configurations side-by-side",children:[c.jsx(lg,{className:"h-3.5 w-3.5"}),c.jsx("span",{className:"hidden md:inline",children:t?"A/B Duel Active":"A/B Duel Mode"})]}),c.jsxs("div",{className:"flex shrink-0 rounded-full border border-white/10 bg-[#232329] p-1",role:"tablist",children:[c.jsxs("button",{onClick:()=>e("learn"),role:"tab","aria-selected":s==="learn","aria-label":"Switch to LEARN mode",className:`flex items-center space-x-1.5 rounded-full p-2 text-xs font-medium transition-all sm:px-3.5 sm:py-1 ${s==="learn"?"bg-blue-600 text-white font-semibold shadow-sm":"text-gray-400 hover:text-white"}`,children:[c.jsx(rg,{className:"h-3.5 w-3.5"}),c.jsx("span",{className:"hidden sm:inline",children:"LEARN"})]}),c.jsxs("button",{onClick:()=>e("labs"),role:"tab","aria-selected":s==="labs","aria-label":"Switch to LABS mode",className:`flex items-center space-x-1.5 rounded-full p-2 text-xs font-medium transition-all sm:px-3.5 sm:py-1 ${s==="labs"?"bg-cyan-600 text-white font-semibold shadow-sm":"text-gray-400 hover:text-white"}`,children:[c.jsx(l_,{className:"h-3.5 w-3.5"}),c.jsx("span",{className:"hidden sm:inline",children:"LABS"})]}),c.jsxs("button",{onClick:()=>e("experiment"),role:"tab","aria-selected":s==="experiment","aria-label":"Switch to EXPERIMENT mode",className:`flex items-center space-x-1.5 rounded-full p-2 text-xs font-medium transition-all sm:px-3.5 sm:py-1 ${s==="experiment"?"bg-blue-600 text-white font-semibold shadow-sm":"text-gray-400 hover:text-white"}`,children:[c.jsx(So,{className:"h-3.5 w-3.5"}),c.jsx("span",{className:"hidden sm:inline",children:"EXPERIMENT"})]}),c.jsxs("button",{onClick:()=>e("export"),role:"tab","aria-selected":s==="export","aria-label":"Switch to EXPORT mode",className:`flex items-center space-x-1.5 rounded-full p-2 text-xs font-medium transition-all sm:px-3.5 sm:py-1 ${s==="export"?"bg-blue-600 text-white font-semibold shadow-sm":"text-gray-400 hover:text-white"}`,children:[c.jsx(Wh,{className:"h-3.5 w-3.5"}),c.jsx("span",{className:"hidden sm:inline",children:"EXPORT"})]})]}),c.jsx("a",{href:"https://github.com/thokchomlolet03-cpu/the-token-cosmos",target:"_blank",rel:"noopener noreferrer","aria-label":"Open The Token Cosmos GitHub repository",className:"btn-secondary-matte shrink-0 rounded-full p-2 text-xs",title:"GitHub Repository",children:c.jsx(o_,{className:"h-4 w-4"})})]})]})})},oc=[{id:"factual-roboticist",name:"Legal & Contract Extraction",subtitle:"Temp: 0.05 • Min-P: 0.05 • RAG: ON",description:"Ultra-deterministic factual extraction with strict context anchoring. Eliminates creative guesswork for legal clauses.",icon:"FileText",params:{temperature:.05,topK:5,topP:1,minP:.05,frequencyPenalty:0,presencePenalty:0,stopSequences:[],logitBiases:{}},ragEnabled:!0,prompt:"What is the governing law and liability limit specified in the agreement?",ragContext:"This Agreement shall be governed by the laws of Delaware. Aggregate liability under Section 8 shall not exceed $1,000,000."},{id:"strict-guardrail",name:"Code & SQL Generator",subtitle:"Temp: 0.01 • Schema: ON • Stop: \\n\\n",description:"Zero-temperature greedy mode with stop sequences for structured JSON, SQL queries, and code syntax generation.",icon:"Code",params:{temperature:.01,topK:50,topP:1,minP:.1,frequencyPenalty:.2,presencePenalty:0,stopSequences:[`

`,"```"],logitBiases:{Delve:-100,delve:-100}},ragEnabled:!1,prompt:"Write an optimized PostgreSQL query to count active users by region.",ragContext:""},{id:"balanced-navigator",name:"Medical Record Summarizer",subtitle:"Temp: 0.10 • Top-K: 10 • RAG: ON",description:"High precision medical QA mode. Tethered strictly to clinical notes to prevent hallucinated medical advice.",icon:"Clipboard",params:{temperature:.1,topK:10,topP:.9,minP:.02,frequencyPenalty:.1,presencePenalty:.1,stopSequences:[],logitBiases:{}},ragEnabled:!0,prompt:"What was the patient's blood pressure and prescribed dosage?",ragContext:"Patient presents with blood pressure 120/80 mmHg. Prescribed Amoxicillin 500mg orally twice daily for 7 days."},{id:"wild-storyteller",name:"Creative & Game Dialogue",subtitle:"Temp: 1.30 • Top-P: 0.95 • Freq Pen: 0.8",description:"High entropy nucleus sampling for NPC dialogue, creative world-building, and unconstrained brainstorming.",icon:"MessageSquare",params:{temperature:1.3,topK:50,topP:.95,minP:.01,frequencyPenalty:.8,presencePenalty:.5,stopSequences:[],logitBiases:{}},ragEnabled:!1,prompt:"Deep in the glowing cybernetic forest, the ancient automaton discovered...",ragContext:""}],Zs={"capital-france":{baseline:[{token_id:101,token_str:" Paris",raw_logit:12.5,is_rag_grounded:!1},{token_id:102,token_str:" France",raw_logit:8.2,is_rag_grounded:!1},{token_id:103,token_str:" London",raw_logit:6.4,is_rag_grounded:!1},{token_id:104,token_str:" Lyon",raw_logit:5.8,is_rag_grounded:!1},{token_id:105,token_str:" Marseille",raw_logit:5.1,is_rag_grounded:!1},{token_id:106,token_str:" Berlin",raw_logit:4.2,is_rag_grounded:!1},{token_id:107,token_str:" Rome",raw_logit:3.9,is_rag_grounded:!1},{token_id:108,token_str:" Madrid",raw_logit:3.5,is_rag_grounded:!1},{token_id:109,token_str:" Tokyo",raw_logit:2.8,is_rag_grounded:!1},{token_id:110,token_str:" Washington",raw_logit:2.1,is_rag_grounded:!1},{token_id:111,token_str:" beautiful",raw_logit:1.8,is_rag_grounded:!1},{token_id:112,token_str:" known",raw_logit:1.5,is_rag_grounded:!1},{token_id:113,token_str:" famous",raw_logit:1.2,is_rag_grounded:!1},{token_id:114,token_str:" located",raw_logit:.9,is_rag_grounded:!1},{token_id:115,token_str:" home",raw_logit:.7,is_rag_grounded:!1},{token_id:116,token_str:" the",raw_logit:.5,is_rag_grounded:!1},{token_id:117,token_str:" a",raw_logit:.3,is_rag_grounded:!1},{token_id:118,token_str:" historic",raw_logit:.1,is_rag_grounded:!1},{token_id:119,token_str:" vibrant",raw_logit:-.2,is_rag_grounded:!1},{token_id:120,token_str:" bustling",raw_logit:-.5,is_rag_grounded:!1},...Array.from({length:30},(s,e)=>({token_id:200+e,token_str:` candidate_${e+1}`,raw_logit:-1-e*.3,is_rag_grounded:!1}))],rag:[{token_id:101,token_str:" Paris",raw_logit:18.9,is_rag_grounded:!0},{token_id:121,token_str:" Eiffel",raw_logit:14.2,is_rag_grounded:!0},{token_id:122,token_str:" Tower",raw_logit:12.8,is_rag_grounded:!0},{token_id:102,token_str:" France",raw_logit:7.1,is_rag_grounded:!0},{token_id:123,token_str:" 1889",raw_logit:6.5,is_rag_grounded:!0},{token_id:103,token_str:" London",raw_logit:1.2,is_rag_grounded:!1},{token_id:104,token_str:" Lyon",raw_logit:1,is_rag_grounded:!1},{token_id:105,token_str:" Marseille",raw_logit:.8,is_rag_grounded:!1},{token_id:106,token_str:" Berlin",raw_logit:.4,is_rag_grounded:!1},{token_id:107,token_str:" Rome",raw_logit:.2,is_rag_grounded:!1},...Array.from({length:40},(s,e)=>({token_id:300+e,token_str:` fringe_${e+1}`,raw_logit:-1.5-e*.2,is_rag_grounded:!1}))]},"cybernetic-forest":{baseline:[{token_id:501,token_str:" a",raw_logit:9.8,is_rag_grounded:!1},{token_id:502,token_str:" an",raw_logit:9.2,is_rag_grounded:!1},{token_id:503,token_str:" crystalline",raw_logit:8.7,is_rag_grounded:!1},{token_id:504,token_str:" forgotten",raw_logit:8.1,is_rag_grounded:!1},{token_id:505,token_str:" relic",raw_logit:7.5,is_rag_grounded:!1},{token_id:506,token_str:" pulse",raw_logit:7.2,is_rag_grounded:!1},{token_id:507,token_str:" glowing",raw_logit:6.8,is_rag_grounded:!1},{token_id:508,token_str:" hidden",raw_logit:6.4,is_rag_grounded:!1},{token_id:509,token_str:" secret",raw_logit:5.9,is_rag_grounded:!1},{token_id:510,token_str:" sanctuary",raw_logit:5.4,is_rag_grounded:!1},{token_id:511,token_str:" signal",raw_logit:5,is_rag_grounded:!1},{token_id:512,token_str:" memory",raw_logit:4.6,is_rag_grounded:!1},{token_id:513,token_str:" core",raw_logit:4.2,is_rag_grounded:!1},...Array.from({length:37},(s,e)=>({token_id:600+e,token_str:` Echo_${e+1}`,raw_logit:3.5-e*.2,is_rag_grounded:!1}))]}},A_=({params:s,activeParam:e})=>{const r=(()=>{switch(e){case"temperature":{const a=s.temperature;return a<=.4?{title:"Cold & Focused",icon:c.jsx(Yr,{className:"h-4 w-4 text-blue-400"}),badgeColor:"bg-blue-950/40 text-blue-300 border-blue-800/35",text:"The AI acts like a strict roboticist. It ignores creative risks and laser-focuses on the safest, most obvious words. Perfect for data tasks."}:a<=1.2?{title:"Balanced Atmosphere",icon:c.jsx(Yr,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800/50 text-slate-300 border-slate-700",text:"The AI mixes expected words with occasional surprising choices, mimicking natural human storytelling."}:{title:"Supernova Chaos",icon:c.jsx(Yr,{className:"h-4 w-4 text-rose-400"}),badgeColor:"bg-rose-950/40 text-rose-300 border-rose-800/35",text:"The AI begins guessing wildly. It will hallucinate facts and string together bizarre sentences. Use for brainstorming only."}}case"topK":{const a=s.topK;return a<=10?{title:"Strict Cutoff",icon:c.jsx(ga,{className:"h-4 w-4 text-blue-400"}),badgeColor:"bg-blue-950/40 text-blue-300 border-blue-800/35",text:"The AI is only allowed to look at the top few smartest choices. All background noise is completely blocked out."}:a<50?{title:"Broadening Horizons",icon:c.jsx(ga,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800/50 text-slate-300 border-slate-700",text:"The AI considers a wider pool of decent options, allowing for more variety in its vocabulary."}:{title:"Open Sky",icon:c.jsx(ga,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800/50 text-slate-300 border-slate-700",text:"The AI is looking at the maximum number of candidates. It relies entirely on Temperature to decide what to pick."}}case"topP":{const a=s.topP;return a<=.5?{title:"Tight Nucleus",icon:c.jsx(ac,{className:"h-4 w-4 text-blue-400"}),badgeColor:"bg-blue-950/40 text-blue-300 border-blue-800/35",text:"The shield only captures the absolute most confident words. If the AI isn't sure, it won't say it."}:a<=.9?{title:"Flexible Shield",icon:c.jsx(ac,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800/50 text-slate-300 border-slate-700",text:"The AI grabs a healthy mix of words until it reaches a solid confidence threshold."}:{title:"Weak Shield",icon:c.jsx(ac,{className:"h-4 w-4 text-rose-400"}),badgeColor:"bg-rose-950/40 text-rose-300 border-rose-800/35",text:"The AI lets almost everything through, capturing a massive pool of words regardless of how confident it is."}}case"minP":return s.minP<=.05?{title:"Broad Base",icon:c.jsx(xc,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800/50 text-slate-300 border-slate-700",text:"Allows low probability tail candidates as long as they meet a minimal baseline cutoff."}:{title:"Strict Gravity Well",icon:c.jsx(xc,{className:"h-4 w-4 text-blue-400"}),badgeColor:"bg-blue-950/40 text-blue-300 border-blue-800/35",text:"Filters out any candidate whose chance drops below relative fraction of top star."};case"frequencyPenalty":{const a=s.frequencyPenalty;return a===0?{title:"Repetitive Orbit",icon:c.jsx(fa,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800 text-slate-300 border-slate-700",text:"Previously used words retain full probability weight, allowing infinite repetitive loops."}:a<1?{title:"Synonym Searcher",icon:c.jsx(fa,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800/50 text-slate-300 border-slate-700",text:"Gradually penalizes repetitive words, encouraging vocabulary variety."}:{title:"Exhaustion Mode",icon:c.jsx(fa,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800/50 text-slate-300 border-slate-700",text:"Previously used words physically dim in opacity, forcing the AI away from familiar paths."}}case"presencePenalty":return s.presencePenalty===0?{title:"No Topic Shift",icon:c.jsx(fa,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800 text-slate-300 border-slate-700",text:"Does not penalize topic presence; AI stays focused on existing subject context."}:{title:"Horizon Booster",icon:c.jsx(fa,{className:"h-4 w-4 text-slate-400"}),badgeColor:"bg-slate-800/50 text-slate-300 border-slate-700",text:"Applies a one-time penalty on any word already seen, encouraging topic exploration."};default:return{title:"Interactive Math Engine",icon:c.jsx(Xh,{className:"h-4 w-4 text-blue-400"}),badgeColor:"bg-blue-950/40 text-blue-300 border-blue-800/35",text:"Drag any sampling slider to see real-time English explanations of LLM mathematical shifts."}}})();return c.jsxs("div",{"aria-live":"polite","aria-atomic":"true",className:"rounded-xl border border-slate-700 bg-slate-900/90 p-3.5 shadow-md backdrop-blur-md transition-all duration-200",children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-slate-800 pb-2 mb-2",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx(So,{className:"h-4 w-4 text-blue-400"}),c.jsx("span",{className:"text-xs font-bold text-slate-100 uppercase tracking-wider",children:"Cosmic Guide Explanation"})]}),c.jsxs("div",{className:`flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold border ${r.badgeColor}`,children:[r.icon,c.jsx("span",{children:r.title})]})]}),c.jsx("p",{className:"text-xs text-slate-200 leading-relaxed font-sans font-normal",children:r.text})]})};function ao(s,e,t=[]){if(!s||s.length===0)return[];const r={};t.forEach(g=>{const x=g.trim();r[g]=(r[g]||0)+1,x!==g&&(r[x]=(r[x]||0)+1)});const a=s.map(g=>{let x=0;const N=g.token_str.trim();e.logitBiases&&(e.logitBiases[g.token_str]!==void 0?x+=e.logitBiases[g.token_str]:e.logitBiases[N]!==void 0&&(x+=e.logitBiases[N]));const P=Math.max(r[g.token_str]||0,r[N]||0),C=P>0?1:0,D=e.presencePenalty*C+e.frequencyPenalty*P,L=g.raw_logit+x-D;return{...g,adjusted_logit:L,isHistorical:P>0,historicalCount:P}});a.sort((g,x)=>x.adjusted_logit-g.adjusted_logit);const l=Math.max(.001,e.temperature);let d=new Array(a.length).fill(0);if(l<=.01)d[0]=1;else{const g=a[0].adjusted_logit,x=a.map(P=>Math.exp((P.adjusted_logit-g)/l)),N=x.reduce((P,C)=>P+C,0);d=x.map(P=>N>0?P/N:0)}let h=a.map((g,x)=>({...g,probability:d[x],rank:x+1,isFiltered:!1,orbitRadius:0,orbitAngle:0,size:0,color:""}));const f=Math.min(Math.max(1,Math.round(e.topK)),h.length);h.forEach((g,x)=>{x>=f&&!g.isFiltered&&(g.isFiltered=!0,g.filterReason="Top-K")});let m=0;const _=Math.min(1,Math.max(.05,e.topP));for(let g=0;g<h.length;g++){const x=h[g];x.isFiltered||(m>=_?(x.isFiltered=!0,x.filterReason="Top-P"):m+=x.probability)}const S=h.length>0?h[0].probability:0,v=e.minP*S;h.forEach(g=>{!g.isFiltered&&g.probability<v&&(g.isFiltered=!0,g.filterReason="Min-P")}),h.forEach(g=>{g.adjusted_logit<=-50&&(g.isFiltered=!0,g.filterReason="Banned")});const M=h.filter(g=>!g.isFiltered).reduce((g,x)=>g+x.probability,0);h.forEach(g=>{g.isFiltered?g.probability=0:g.probability=M>0?g.probability/M:0});const E=h.length;return h.forEach((g,x)=>{const N=x/Math.max(1,E-1),P=x===0?0:35+N*180;g.orbitRadius=P,g.orbitAngle=x*137.5*Math.PI/180,x===0?g.size=18+g.probability*25:g.isFiltered?g.size=3:g.size=6+g.probability*20,g.filterReason==="Banned"?g.color="#1e293b":g.is_rag_grounded?g.color="#06b6d4":x===0?g.color="#f59e0b":g.isFiltered?g.color="#475569":g.probability>.15?g.color="#38bdf8":g.probability>.05?g.color="#a855f7":g.color="#ec4899"}),h}function C_(s){const e=s.filter(r=>!r.isFiltered&&r.probability>0);if(e.length===0)return 0;let t=0;for(const r of e)r.probability>1e-10&&(t-=r.probability*Math.log2(r.probability));return Math.max(0,t)}function Hm(s,e){const t=s.probability,r=s.rank,a=Math.min(1,t*2),l=Math.max(0,1-(r-1)/10),d=Math.min(1,e/5),h=Math.max(0,Math.min(1,a*.5+l*.3+(1-d)*.2));let f,m;return r<=3&&t>.7?(f="high",m="#475569"):t>=.1?(f="moderate",m="#334155"):(f="low",m="#1e293b"),{entropy:e,confidence:f,confidenceScore:h,perplexityColor:m}}function R_(s){return s.split(/(?<=[.!?;])\s+|\n+/).map(e=>e.trim()).filter(e=>e.length>0)}function P_(s,e,t){if(!e||e.length===0)return-5;const r=s.split(/\s+/).filter(d=>d.length>1);if(r.length===0)return-5;let a=0,l=0;for(const d of r){const h=d.replace(/[^a-zA-Z0-9]/g,"").toLowerCase();if(h.length<2)continue;const f=e.find(m=>{const _=m.token_str.trim().toLowerCase();return _===h||_.includes(h)||h.includes(_)});if(f){const m=e[0]?.raw_logit||16,_=(f.raw_logit-m)/Math.max(.1,t.temperature);a+=_,l++}else a-=3.5,l++}return l>0?a/l:-5}function N_(s,e,t){const r=s.toLowerCase(),a=e.toLowerCase(),l=new Set(r.split(/\s+/).filter(m=>m.length>3)),d=new Set(a.split(/\s+/).filter(m=>m.length>3));let h=0;return l.forEach(m=>{d.has(m)&&h++}),(l.size>0?h/l.size:0)<.1&&t>3?"Abrupt topic shift — minimal lexical continuity with previous context":r.includes("however")||r.includes("but")||r.includes("despite")||r.includes("although")?"Contradictory conjunction introduces logical tension with preceding statement":r.length>200?"Overly complex sentence structure — high cognitive load for model parsing":t>4?"Severe probability collapse — language pattern deviates sharply from training distribution":t>2?"Moderate coherence gap — phrasing may be ambiguous or structurally unusual":"Minor fluency variation — acceptable in most contexts"}function L_(s,e=.5){if(s.length<2)return[];const t=[];for(let m=1;m<s.length;m++)t.push(s[m-1].logProb-s[m].logProb);const r=t.reduce((m,_)=>m+_,0)/t.length,a=t.reduce((m,_)=>m+(_-r)**2,0)/t.length,l=Math.sqrt(a)||.5,d=1+e*2,h=[];for(let m=1;m<s.length;m++){const _=s[m-1].logProb-s[m].logProb;if(_>r+d*l*.5){const S=l>.01?(_-r)/l:0;let v;S>3?v="critical":S>2?v="warning":v="info",h.push({phraseIndex:m,phrase:s[m].text,logProbDrop:Math.round(_*100)/100,previousLogProb:Math.round(s[m-1].logProb*100)/100,currentLogProb:Math.round(s[m].logProb*100)/100,severity:v,reason:N_(s[m].text,s[m-1].text,_)})}}const f={critical:0,warning:1,info:2};return h.sort((m,_)=>{const S=f[m.severity]-f[_.severity];return S!==0?S:_.logProbDrop-m.logProbDrop}),h}async function D_(s,e,t,r=.5){const a=performance.now(),l=R_(s),d=[],h=10;for(let v=0;v<l.length;v+=h){const b=l.slice(v,v+h);v>0&&await new Promise(M=>{typeof requestIdleCallback<"u"?requestIdleCallback(()=>M()):setTimeout(M,0)});for(const M of b){const E=P_(M,e,t);d.push({text:M,logProb:E,normalizedScore:0})}}if(d.length>0){const v=Math.min(...d.map(E=>E.logProb)),M=Math.max(...d.map(E=>E.logProb))-v||1;d.forEach(E=>{E.normalizedScore=(E.logProb-v)/M})}const f=d.reduce((v,b)=>v+b.logProb,0),m=d.length>0?f/d.length:0,_=L_(d,r),S=Math.round((performance.now()-a)*100)/100;return{inputText:s,totalJointLogProb:Math.round(f*100)/100,averageLogProb:Math.round(m*100)/100,phrases:d,frictionPoints:_,analysisTimeMs:S}}function I_(s,e){if(!s)return[];const t=[],r=e?e.split(/\s+/).filter(l=>l.length>3):[];let a=[];try{if(s?.choices?.[0]?.logprobs?.content?.[0]?.top_logprobs)a=s.choices[0].logprobs.content[0].top_logprobs.map(d=>({token:d.token||d.text||"",logprob:typeof d.logprob=="number"?d.logprob:-5}));else if(s?.choices?.[0]?.logprobs?.top_logprobs?.[0]){const l=s.choices[0].logprobs.top_logprobs[0];Array.isArray(l)?a=l.map(d=>({token:d.token||"",logprob:typeof d.logprob=="number"?d.logprob:-5})):typeof l=="object"&&(a=Object.entries(l).map(([d,h])=>({token:d,logprob:typeof h=="number"?h:-5})))}else if(Array.isArray(s?.candidates))return s.candidates}catch(l){console.warn("Failed to parse external logprobs response, using fallback candidates:",l)}return a.forEach((l,d)=>{const h=Math.round((l.logprob+16)*100)/100,f=l.token||`token_${d+1}`;let m=!1;if(r.length>0){const _=f.trim().toLowerCase();_.length>2&&(m=r.some(S=>S.toLowerCase().includes(_)||_.includes(S.toLowerCase())))}t.push({token_id:5e3+d,token_str:f,raw_logit:h,is_rag_grounded:m})}),t.sort((l,d)=>d.raw_logit-l.raw_logit),t}const Gm={critical:{icon:Kd,label:"Critical",bgClass:"bg-red-500/10",textClass:"text-red-300",borderClass:"border-red-500/30",dotColor:"#ef4444"},warning:{icon:Zv,label:"Warning",bgClass:"bg-amber-500/10",textClass:"text-amber-300",borderClass:"border-amber-500/30",dotColor:"#f59e0b"},info:{icon:Xh,label:"Info",bgClass:"bg-sky-500/10",textClass:"text-sky-300",borderClass:"border-sky-500/30",dotColor:"#38bdf8"}},k_=`Our onboarding process begins with a comprehensive background check taking 3-5 business days. Once completed, new hires receive their equipment and access credentials.

However, the IT provisioning system requires manual approval from three separate department heads, each operating on different schedules.

After equipment setup, employees must complete a mandatory 40-hour training program. But the training materials haven't been updated since 2019 and reference deprecated internal tools.

Despite these challenges, we expect full productivity within the first two weeks of employment.`,F_=({params:s,rawLogits:e})=>{const[t,r]=Y.useState(""),[a,l]=Y.useState(!1),[d,h]=Y.useState(null),[f,m]=Y.useState(.5),[_,S]=Y.useState(new Set),[v,b]=Y.useState(!1),M=async()=>{if(t.trim()){l(!0),h(null);try{const P=await D_(t,e,s,f);h(P),S(new Set)}catch(P){console.error("Friction analysis failed:",P)}finally{l(!1)}}},E=()=>{r(k_),h(null)},g=P=>{S(C=>{const D=new Set(C);return D.has(P)?D.delete(P):D.add(P),D})},x=P=>P>.7?"#10b981":P>.4?"#f59e0b":"#ef4444",N=Y.useMemo(()=>d?{critical:d.frictionPoints.filter(P=>P.severity==="critical").length,warning:d.frictionPoints.filter(P=>P.severity==="warning").length,info:d.frictionPoints.filter(P=>P.severity==="info").length}:{critical:0,warning:0,info:0},[d]);return c.jsxs("div",{className:"flex flex-col space-y-4 h-full",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx("div",{className:"flex h-7 w-7 items-center justify-center rounded-lg bg-white/10 border border-white/20",children:c.jsx($h,{className:"h-3.5 w-3.5 text-white"})}),c.jsxs("div",{children:[c.jsx("h3",{className:"text-sm font-bold text-white tracking-tight",children:"Friction Analysis"}),c.jsx("p",{className:"text-[10px] text-gray-400 font-mono",children:"Joint log-probability • Drop-off detection"})]})]}),c.jsxs("div",{className:"relative",children:[c.jsx("textarea",{value:t,onChange:P=>{r(P.target.value),h(null)},placeholder:"Paste a business process, code block, job description, or any complex text to analyze for logical friction points...",rows:6,className:"w-full rounded-lg bg-[#111111] border border-white/10 px-3 py-2 text-xs text-gray-100 placeholder:text-gray-600 focus:border-gray-500 focus:outline-none focus:ring-0 resize-none font-mono leading-relaxed"}),c.jsxs("div",{className:"absolute bottom-2 right-2 flex items-center space-x-1.5",children:[c.jsx("button",{onClick:E,className:"btn-secondary-matte px-2.5 py-1 text-[11px]",children:"Load Contract Sample"}),c.jsx("button",{onClick:M,disabled:a||!t.trim(),className:"btn-primary-matte px-3 py-1 text-xs flex items-center space-x-1.5 disabled:opacity-50 disabled:cursor-not-allowed",children:a?c.jsxs(c.Fragment,{children:[c.jsx(vc,{className:"h-3.5 w-3.5 animate-spin"}),c.jsx("span",{children:"Scanning..."})]}):c.jsxs(c.Fragment,{children:[c.jsx(qh,{className:"h-3.5 w-3.5 fill-current"}),c.jsx("span",{children:"Analyze Friction"})]})})]})]}),c.jsxs("div",{className:"flex items-center space-x-3",children:[c.jsxs("div",{className:"flex items-center space-x-1.5",children:[c.jsx(a_,{className:"h-3.5 w-3.5 text-orange-400"}),c.jsx("span",{className:"text-[11px] font-bold text-slate-300",children:"Sensitivity"})]}),c.jsx("input",{type:"range",min:"0",max:"1",step:"0.05",value:f,onChange:P=>m(parseFloat(P.target.value)),className:"flex-1 h-1.5 rounded-full appearance-none bg-slate-800 accent-orange-500"}),c.jsx("span",{className:"text-[10px] font-mono text-orange-300 w-12 text-right",children:f<.33?"Loose":f<.66?"Balanced":"Strict"})]}),c.jsx("button",{onClick:M,disabled:a||!t.trim(),className:"flex items-center justify-center space-x-2 rounded-xl bg-gradient-to-r from-orange-500 to-red-600 px-4 py-2 text-xs font-bold text-white shadow-lg hover:opacity-90 transition-opacity disabled:opacity-40 disabled:cursor-not-allowed",children:a?c.jsxs(c.Fragment,{children:[c.jsx(vc,{className:"h-3.5 w-3.5 animate-spin"}),c.jsx("span",{children:"Analyzing Friction..."})]}):c.jsxs(c.Fragment,{children:[c.jsx(cg,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:"Analyze Friction Points"})]})}),d&&c.jsxs("div",{className:"flex flex-col space-y-3 overflow-y-auto flex-1 min-h-0",children:[c.jsxs("div",{className:"grid grid-cols-3 gap-2",children:[c.jsxs("div",{className:"rounded-lg bg-slate-950/80 border border-slate-800 p-2 text-center",children:[c.jsx("div",{className:"text-[10px] text-slate-400 font-mono uppercase",children:"Joint Log-Prob"}),c.jsx("div",{className:"text-sm font-bold text-blue-300 font-mono",children:d.totalJointLogProb.toFixed(1)})]}),c.jsxs("div",{className:"rounded-lg bg-slate-950/80 border border-slate-800 p-2 text-center",children:[c.jsx("div",{className:"text-[10px] text-slate-400 font-mono uppercase",children:"Avg Score"}),c.jsx("div",{className:"text-sm font-bold text-blue-300 font-mono",children:d.averageLogProb.toFixed(2)})]}),c.jsxs("div",{className:"rounded-lg bg-slate-950/80 border border-slate-800 p-2 text-center",children:[c.jsx("div",{className:"text-[10px] text-slate-400 font-mono uppercase",children:"Analysis"}),c.jsxs("div",{className:"text-sm font-bold text-blue-300 font-mono",children:[d.analysisTimeMs,"ms"]})]})]}),c.jsx("div",{className:"flex items-center space-x-2",children:["critical","warning","info"].map(P=>{const C=Gm[P],D=N[P],L=C.icon;return c.jsxs("div",{className:`flex items-center space-x-1 rounded-lg px-2 py-1 text-[10px] font-mono font-bold border ${C.bgClass} ${C.textClass} ${C.borderClass}`,children:[c.jsx(L,{className:"h-3 w-3"}),c.jsxs("span",{children:[D," ",C.label]})]},P)})}),c.jsxs("button",{onClick:()=>b(!v),className:"flex items-center space-x-1.5 text-[11px] text-slate-300 hover:text-orange-300 transition-colors",children:[c.jsx(ig,{className:"h-3.5 w-3.5 text-orange-400"}),c.jsx("span",{className:"font-bold",children:"Phrase-Level Heatmap"}),v?c.jsx(bs,{className:"h-3 w-3"}):c.jsx(ys,{className:"h-3 w-3"})]}),v&&c.jsx("div",{className:"space-y-1 max-h-[200px] overflow-y-auto rounded-lg bg-slate-950/60 p-2 border border-slate-800",children:d.phrases.map((P,C)=>c.jsxs("div",{className:"flex items-start space-x-2 rounded-md px-2 py-1 text-[10px] font-mono",children:[c.jsx("span",{className:"shrink-0 mt-1 h-2 w-2 rounded-full",style:{backgroundColor:x(P.normalizedScore)}}),c.jsx("span",{className:"text-slate-300 leading-relaxed flex-1",children:P.text}),c.jsx("span",{className:"shrink-0 font-bold",style:{color:x(P.normalizedScore)},children:P.logProb.toFixed(2)})]},C))}),d.frictionPoints.length>0?c.jsxs("div",{className:"space-y-2",children:[c.jsxs("div",{className:"flex items-center space-x-1.5",children:[c.jsx(s_,{className:"h-3.5 w-3.5 text-red-400"}),c.jsxs("span",{className:"text-[11px] font-bold text-slate-200",children:["Operational Friction Report (",d.frictionPoints.length," points)"]})]}),d.frictionPoints.map((P,C)=>{const D=Gm[P.severity],L=D.icon,O=_.has(C);return c.jsxs("div",{className:`rounded-xl border ${D.borderClass} ${D.bgClass} overflow-hidden`,children:[c.jsxs("button",{onClick:()=>g(C),className:"w-full flex items-center justify-between px-3 py-2 text-left",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx(L,{className:`h-3.5 w-3.5 ${D.textClass}`}),c.jsxs("span",{className:`text-[11px] font-bold ${D.textClass}`,children:[D.label," — Phrase #",P.phraseIndex+1]}),c.jsxs("span",{className:"text-[10px] font-mono text-slate-400",children:["Drop: ",P.logProbDrop.toFixed(2)]})]}),O?c.jsx(bs,{className:"h-3 w-3 text-slate-400"}):c.jsx(ys,{className:"h-3 w-3 text-slate-400"})]}),O&&c.jsxs("div",{className:"px-3 pb-2.5 space-y-1.5 border-t border-slate-800/50",children:[c.jsxs("div",{className:"mt-2 rounded-md bg-slate-950/60 px-2.5 py-1.5 text-[10px] font-mono text-slate-300 leading-relaxed",children:['"',P.phrase,'"']}),c.jsxs("div",{className:"grid grid-cols-2 gap-2 text-[10px] font-mono",children:[c.jsxs("div",{children:[c.jsx("span",{className:"text-slate-500",children:"Previous Log-Prob:"})," ",c.jsx("span",{className:"text-emerald-300",children:P.previousLogProb})]}),c.jsxs("div",{children:[c.jsx("span",{className:"text-slate-500",children:"Current Log-Prob:"})," ",c.jsx("span",{className:"text-red-300",children:P.currentLogProb})]})]}),c.jsxs("div",{className:"text-[10px] text-slate-300 leading-relaxed italic flex items-start space-x-1.5",children:[c.jsx(Xh,{className:"h-3.5 w-3.5 text-slate-500 shrink-0 mt-0.5"}),c.jsx("span",{children:P.reason})]})]})]},C)})]}):c.jsxs("div",{className:"rounded-xl bg-emerald-500/10 border border-emerald-500/20 px-4 py-3 text-center flex items-center justify-center space-x-2",children:[c.jsx(Vh,{className:"h-4 w-4 text-emerald-400"}),c.jsx("span",{className:"text-xs text-emerald-300 font-medium",children:"No significant friction points detected at current sensitivity level"})]})]})]})},Vm=({params:s,setParams:e,prompt:t,setPrompt:r,systemPrompt:a,setSystemPrompt:l,jsonSchema:d,setJsonSchema:h,jsonSchemaEnabled:f,setJsonSchemaEnabled:m,ragContext:_,setRagContext:S,ragEnabled:v,setRagEnabled:b,onApplyPreset:M,onLaunchPrompt:E,onInteractFeature:g,isFetchingLogits:x=!1,rawLogits:N=[],isReasoningModel:P=!1})=>{const[C,D]=Y.useState("sampling"),[L,O]=Y.useState(!!a.trim()),[T,I]=Y.useState(f),[H,B]=Y.useState(v),[V,ae]=Y.useState(!1),[Q,ie]=Y.useState(""),[de,re]=Y.useState(-100),[X,J]=Y.useState(""),[le,U]=Y.useState("temperature"),q=ce=>{g&&g({...ce,timestamp:Date.now()})},Re=(ce,we)=>{e(Ze=>({...Ze,[ce]:we}))},qe=()=>{if(!Q.trim())return;const ce=Q.trim();e(we=>({...we,logitBiases:{...we.logitBiases,[ce]:de}})),q({feature:`Logit Bias ('${ce}': ${de})`,whatItIs:`Direct numerical modifier applied to token '${ce}' before Softmax normalization.`,whyItIs:"Allows strict black-listing (-100) or heavy boosting (+10.0) of target vocabulary terms.",impact:de<=-50?`Implodes token '${ce}' into a red Black Hole icon on the outer fringe (0% chance).`:`Pulls token '${ce}' toward the center supergiant star.`,guidance:'Use -100 to ban unwanted buzzwords ("delve", "testament").'}),ie("")},be=ce=>{e(we=>{const Ze={...we.logitBiases};return delete Ze[ce],{...we,logitBiases:Ze}})},ee=()=>{if(!X.trim())return;const ce=X.trim();s.stopSequences.includes(ce)||Re("stopSequences",[...s.stopSequences,ce]),q({feature:`Emergency Stop Sequence ("${ce}")`,whatItIs:"Text pattern string that instantly halts generation when encountered.",whyItIs:"Prevents endless runaway text generation loops.",impact:`Truncates response output immediately when candidate matches "${ce}".`,guidance:"Add \\n\\n or END to stop multi-paragraph answers cleanly."}),J("")},me=ce=>{Re("stopSequences",s.stopSequences.filter(we=>we!==ce))},ve=ce=>{const we="h-4 w-4 text-slate-400 group-hover:text-blue-500 transition-colors duration-200";switch(ce){case"FileText":return c.jsx(Bm,{className:we});case"Code":return c.jsx(e_,{className:we});case"Clipboard":return c.jsx(Jv,{className:we});case"MessageSquare":return c.jsx(f_,{className:we});default:return c.jsx(ga,{className:we})}};return c.jsxs("div",{className:"glass-panel-matte flex flex-col h-full rounded-xl overflow-hidden",children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-white/10 bg-[#1c1c21] px-5 py-3",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx(b_,{className:"h-4 w-4 text-slate-400"}),c.jsx("h2",{className:"text-sm font-bold text-white tracking-tight hidden sm:block",children:"Mission Control"})]}),c.jsxs("div",{className:"flex rounded-full bg-[#18181b] p-1 border border-white/10",children:[c.jsxs("button",{onClick:()=>D("sampling"),className:`flex items-center space-x-1.5 rounded-full px-3 py-1 text-xs font-medium transition-all ${C==="sampling"?"bg-blue-600 text-white font-semibold shadow-sm":"text-gray-400 hover:text-white"}`,children:[c.jsx(ga,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:"Sampling"})]}),c.jsxs("button",{onClick:()=>D("friction"),className:`flex items-center space-x-1.5 rounded-full px-3 py-1 text-xs font-medium transition-all ${C==="friction"?"bg-blue-600 text-white font-semibold shadow-sm":"text-gray-400 hover:text-white"}`,children:[c.jsx($h,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:"Friction Analysis"})]})]})]}),c.jsx("div",{className:"flex-1 overflow-y-auto p-5 space-y-6",children:C==="friction"?c.jsx(F_,{params:s,rawLogits:N}):c.jsxs("div",{className:"space-y-6",children:[c.jsxs("div",{children:[c.jsxs("label",{className:"text-[11px] font-mono uppercase tracking-wider text-gray-400 flex items-center space-x-1.5 mb-1",children:[c.jsx(So,{className:"h-3.5 w-3.5 text-slate-400"}),c.jsx("span",{children:"Example Tasks"})]}),c.jsx("p",{className:"text-[10px] text-gray-500 mb-2.5",children:"Click one to see how the AI handles different jobs."}),c.jsx("div",{className:"grid grid-cols-2 gap-2",children:oc.map(ce=>c.jsxs("button",{onClick:()=>{M(ce),q({feature:`Preset: ${ce.name}`,whatItIs:`Pre-configured hyperparameter setup calibrated for ${ce.name}.`,whyItIs:"Demonstrates ideal settings for specific AI tasks (e.g. strict coding vs creative writing).",impact:`Re-allocates Temperature to ${ce.params.temperature}, Top-K to ${ce.params.topK}, and toggles RAG.`,guidance:"Click presets to instantly jump between robotic factual accuracy and wild storytelling!"})},"aria-label":`Apply ${ce.name} preset: ${ce.subtitle}`,className:"glass-panel-interactive-matte flex flex-col items-start p-3 rounded-lg text-left border border-white/10 hover:border-white/20 transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] group",children:[c.jsxs("div",{className:"flex items-center space-x-2 w-full mb-1",children:[ve(ce.icon),c.jsx("span",{className:"text-xs font-semibold text-gray-200 group-hover:text-white transition-colors duration-200 truncate",children:ce.name})]}),c.jsx("span",{className:"text-[10px] text-gray-400 font-mono",children:ce.subtitle})]},ce.id))})]}),c.jsxs("div",{className:"rounded-xl border border-white/10 bg-[#111111] overflow-hidden",children:[c.jsxs("button",{type:"button",onClick:()=>O(!L),"aria-label":"Toggle AI Personality and Role instructions","aria-expanded":L,className:"w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-medium text-gray-200 hover:bg-white/5 transition-colors",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx(M_,{className:`h-4 w-4 transition-colors duration-200 ${a.trim()?"text-blue-500":"text-slate-400"}`}),c.jsx("span",{className:"font-semibold text-white tracking-tight",children:"AI Personality & Role"}),c.jsx("span",{className:`rounded-md px-2 py-0.5 text-[10px] font-mono font-medium ${a.trim()?"bg-white/10 text-white border border-white/15":"bg-black text-gray-400 border border-white/10"}`,children:a.trim()?"ACTIVE":"DEFAULT"})]}),L?c.jsx(bs,{className:"h-4 w-4 text-gray-400"}):c.jsx(ys,{className:"h-4 w-4 text-gray-400"})]}),L&&c.jsxs("div",{className:"p-3 border-t border-white/10 space-y-2 bg-[#0A0A0A]",children:[c.jsxs("p",{className:"text-[11px] text-gray-400 leading-relaxed font-mono",children:["Tell the AI who it should act like (e.g., ",c.jsx("em",{children:'"You are a helpful tutor"'}),"). Shifts the baseline word probabilities."]}),c.jsx("textarea",{"aria-label":"System prompt persona instructions",value:a,onChange:ce=>{l(ce.target.value),q({feature:"System Persona Override",whatItIs:"Top-level behavioral directive injected into model chat template.",whyItIs:"Establishes domain persona expertise before processing user prompts.",impact:"Shifts baseline raw logit distribution across entire vocabulary.",guidance:"Use for domain task specialization (e.g. SQL DBA, Legal clause parser)."})},rows:2,className:"w-full rounded-lg bg-[#111111] border border-white/10 px-2.5 py-1.5 text-xs text-gray-100 placeholder:text-gray-600 focus:border-gray-500 focus:ring-0 focus:outline-none font-mono",placeholder:"You are a senior PostgreSQL DBA. Reply only with valid SQL queries..."})]})]}),c.jsxs("div",{className:"space-y-3",children:[c.jsxs("div",{children:[c.jsxs("div",{className:"flex items-center justify-between mb-1.5",children:[c.jsxs("label",{htmlFor:"prompt-input",className:"text-xs font-semibold text-gray-300 flex items-center space-x-1.5",children:[c.jsx(Bm,{className:"h-3.5 w-3.5 text-gray-400"}),c.jsx("span",{className:"text-white tracking-tight",children:"Your Message (The Prompt)"})]}),c.jsx("span",{className:"text-[10px] text-gray-400 font-mono",children:"Custom Prompt"})]}),c.jsx("textarea",{id:"prompt-input","aria-label":"Enter custom prompt for LLM sampling",value:t,onChange:ce=>r(ce.target.value),rows:2,className:"w-full rounded-lg bg-[#111111] border border-white/10 px-3 py-2 text-xs text-gray-100 placeholder:text-gray-600 focus:border-gray-500 focus:outline-none focus:ring-0 resize-none font-mono leading-relaxed",placeholder:"Type your question or starting sentence here..."})]}),c.jsxs("div",{className:"rounded-xl border border-white/10 bg-[#111111] overflow-hidden",children:[c.jsxs("button",{onClick:()=>{const ce=!v;b(ce),B(ce),q({feature:`RAG Grounding (${ce?"ON":"OFF"})`,whatItIs:"Retrieval-Augmented Generation context tethering.",whyItIs:"Forces the LLM to base its predictions on user-provided factual documents.",impact:ce?"Pulls grounded document terms to the center supergiant star via cyan laser beams.":"Un-tethers predictions, allowing parametric memory generation.",guidance:"Turn ON when accuracy is non-negotiable."})},"aria-label":v?"Turn RAG Fact Anchor OFF":"Turn RAG Fact Anchor ON","aria-expanded":H,className:"w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-medium text-gray-200 hover:bg-white/5 transition-colors",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx(gc,{className:`h-4 w-4 transition-colors duration-200 ${v?"text-blue-500":"text-slate-400"}`}),c.jsx("span",{className:"font-semibold text-white tracking-tight",children:"Provide Reference Facts"}),c.jsx("span",{className:`rounded-md px-2 py-0.5 text-[10px] font-mono font-medium ${v?"bg-white/10 text-white border border-white/15":"bg-black text-gray-400 border border-white/10"}`,children:v?"Grounded":"OFF"})]}),H?c.jsx(bs,{className:"h-4 w-4 text-gray-400"}):c.jsx(ys,{className:"h-4 w-4 text-gray-400"})]}),H&&c.jsxs("div",{className:"p-3 border-t border-white/10 space-y-2 bg-[#0A0A0A]",children:[c.jsxs("div",{className:"flex items-center space-x-1.5 text-[11px] text-gray-300 font-mono",children:[c.jsx(gc,{className:"h-3.5 w-3.5 text-gray-400"}),c.jsx("span",{children:"Paste reference facts here. The AI will read this instead of guessing."})]}),c.jsx("textarea",{"aria-label":"Retrieved factual context for RAG grounding",value:_,onChange:ce=>S(ce.target.value),rows:2,className:"w-full rounded-lg bg-slate-900 border border-slate-800 px-2.5 py-1.5 text-xs text-slate-100 placeholder-slate-600 focus:border-blue-500 focus:outline-none font-mono",placeholder:"Example: Employees must be in the office Tuesday through Thursday. Monday and Friday are remote."})]})]}),c.jsxs("div",{className:"rounded-xl border border-white/10 bg-[#111111] overflow-hidden",children:[c.jsxs("button",{onClick:()=>{const ce=!f;m(ce),I(ce),q({feature:`Structured Output JSON Schema (${ce?"ACTIVE":"OFF"})`,whatItIs:"Rigid JSON grammar rule enforcer.",whyItIs:"Guarantees the AI returns valid JSON data structures instead of plain conversational prose.",impact:ce?"Non-conforming tokens drop to 0% probability and turn red, proving format compliance.":"Restores normal dictionary token vocabulary.",guidance:"Activate when building automated API data extraction pipelines."})},"aria-label":f?"Turn Structured Output JSON Schema OFF":"Turn Structured Output JSON Schema ON","aria-expanded":T,className:"w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-medium text-slate-200 hover:bg-white/5 transition-colors",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx(Wh,{className:`h-4 w-4 transition-colors duration-200 ${f?"text-blue-500":"text-slate-400"}`}),c.jsx("span",{className:"font-semibold text-slate-100",children:"Force Strict Formatting"}),c.jsx("span",{className:`rounded-full px-2 py-0.5 text-[10px] font-bold ${f?"bg-blue-500/20 text-blue-300 border border-blue-400/30":"bg-slate-800 text-slate-400"}`,children:f?"ACTIVE":"OFF"})]}),T?c.jsx(bs,{className:"h-4 w-4 text-slate-400"}):c.jsx(ys,{className:"h-4 w-4 text-slate-400"})]}),T&&c.jsxs("div",{className:"p-3 border-t border-white/10 space-y-2 bg-[#0A0A0A]",children:[c.jsx("p",{className:"text-[11px] text-slate-300 leading-relaxed",children:"Forces the AI to answer in a rigid data format instead of a paragraph."}),c.jsx("textarea",{"aria-label":"JSON Schema for structured output enforcement",value:d,onChange:ce=>h(ce.target.value),rows:2,className:"w-full rounded-lg bg-slate-900 border border-slate-800 px-2.5 py-1.5 text-xs text-slate-100 placeholder-slate-600 focus:border-blue-500 focus:outline-none font-mono",placeholder:'{ "type": "object", "properties": { "result": { "type": "string" } } }'})]})]}),c.jsx("button",{onClick:E,disabled:x||!t.trim(),"aria-label":"Launch prompt evaluation and fetch token candidates",className:"w-full flex items-center justify-center space-x-2 rounded-xl bg-blue-600 hover:bg-blue-700 py-2.5 text-xs font-bold text-white shadow-md disabled:opacity-50 disabled:cursor-not-allowed transition-all",children:x?c.jsxs(c.Fragment,{children:[c.jsx(vc,{className:"h-4 w-4 animate-spin text-white"}),c.jsx("span",{children:"Mapping AI Thoughts..."})]}):c.jsxs(c.Fragment,{children:[c.jsx(qh,{className:"h-4 w-4 text-white"}),c.jsx("span",{children:"Map the AI's Thoughts"})]})})]}),c.jsx(A_,{params:s,activeParam:le}),c.jsxs("div",{className:"space-y-4 pt-2 border-t border-slate-800",children:[c.jsxs("h3",{className:"text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5",children:[c.jsx(Yr,{className:"h-3.5 w-3.5 text-slate-400"}),c.jsx("span",{children:"Brain Controls (How it Picks Words)"})]}),P?c.jsx("div",{className:"space-y-4",children:c.jsxs("div",{className:"rounded-xl border border-purple-500/30 bg-purple-950/20 p-4 shadow-lg shadow-purple-500/10",children:[c.jsxs("div",{className:"flex items-center space-x-2 mb-2",children:[c.jsx($v,{className:"h-4 w-4 text-purple-400 animate-pulse"}),c.jsx("span",{className:"text-xs font-bold text-purple-300 uppercase tracking-widest",children:"Reasoning Active"})]}),c.jsx("p",{className:"text-[10px] text-purple-200/70 mb-4 leading-relaxed",children:"Standard decoding parameters (Temperature, Top-P) are disabled during reasoning. Adjust the Thinking Budget to control latent space exploration depth."}),c.jsxs("div",{className:"space-y-1.5",children:[c.jsxs("div",{className:"flex justify-between text-xs",children:[c.jsxs("label",{htmlFor:"thinking-budget",className:"font-medium text-slate-200 flex items-center space-x-1",children:[c.jsx("span",{children:"Thinking Budget"}),c.jsx("span",{className:"text-slate-400 font-mono text-[11px]",children:"(Max Tokens)"})]}),c.jsx("span",{className:"font-mono font-bold text-purple-400",children:s.maxThinkingTokens||2048})]}),c.jsx("input",{id:"thinking-budget",type:"range",min:"50",max:"4096",step:"50",value:s.maxThinkingTokens||2048,onChange:ce=>e(we=>({...we,maxThinkingTokens:parseInt(ce.target.value)})),className:"w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 hover:accent-blue-400 transition-all"}),c.jsxs("div",{className:"flex justify-between text-[9px] font-mono text-slate-500 px-1 pt-1",children:[c.jsx("span",{children:"50 (Fractured)"}),c.jsx("span",{children:"4096 (Deep Thought)"})]})]})]})}):c.jsxs(c.Fragment,{children:[c.jsxs("div",{className:"space-y-1.5",children:[c.jsxs("div",{className:"flex justify-between text-xs",children:[c.jsx("label",{htmlFor:"temp-slider",className:"font-medium text-slate-200 flex items-center space-x-1",children:c.jsx("span",{children:"Creativity vs. Focus (Temperature)"})}),c.jsx("span",{className:"font-mono font-bold text-amber-400",children:s.temperature.toFixed(2)})]}),c.jsx("input",{id:"temp-slider","aria-label":"Adjust Temperature T slider from 0.01 to 2.0",type:"range",min:"0.01",max:"2.0",step:"0.01",value:s.temperature,onFocus:()=>{U("temperature"),q({feature:`Cosmic Heat (Temperature T = ${s.temperature.toFixed(2)})`,whatItIs:"Softmax exponent scaling divisor for candidate logits.",whyItIs:"Controls the balance between deterministic focus and creative randomness.",impact:s.temperature>1.2?"Outer asteroid stars glow brighter and flatten probability distribution.":"Sharpens top supergiant star probability toward 100%.",guidance:"Keep <0.3 for factual QA/code; set >1.0 for creative writing."})},onChange:ce=>{const we=parseFloat(ce.target.value);U("temperature"),Re("temperature",we),q({feature:`Temperature T (${we.toFixed(2)})`,whatItIs:"Softmax exponent scaling divisor.",whyItIs:"Controls output entropy and candidate randomness.",impact:we>1.2?"Causes low-probability outer tokens to glow brighter.":"Focuses probability heavily on the top star.",guidance:we>1.2?"High entropy mode active.":"Factual focus mode active."})},className:"w-full"}),c.jsx("p",{className:"text-[11px] text-slate-400",children:"Low = Predictable and strict. High = Creative, random, and chaotic."}),c.jsx("div",{className:"flex items-center space-x-1.5 mt-1",children:s.temperature<=.2?c.jsxs("span",{className:"rounded-full bg-blue-500/10 text-blue-300 border border-blue-500/20 px-2 py-0.5 text-[10px] font-mono font-bold flex items-center space-x-1",children:[c.jsx(Yh,{className:"h-3 w-3 text-blue-400"}),c.jsx("span",{children:"Factual Precision (Legal / Medical / Code)"})]}):s.temperature>=1.2?c.jsxs("span",{className:"rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 px-2 py-0.5 text-[10px] font-mono font-bold flex items-center space-x-1",children:[c.jsx(Yr,{className:"h-3 w-3 text-rose-400"}),c.jsx("span",{children:"High Entropy (Creative Fiction / Dialogue)"})]}):c.jsx("span",{className:"rounded-full bg-blue-500/10 text-blue-300 border border-blue-500/20 px-2 py-0.5 text-[10px] font-mono font-medium",children:"Balanced Assistant Mode (General Q&A)"})})]}),c.jsxs("div",{className:"space-y-1.5",children:[c.jsxs("div",{className:"flex justify-between text-xs",children:[c.jsx("label",{htmlFor:"topk-slider",className:"font-medium text-slate-200 flex items-center space-x-1",children:c.jsx("span",{children:"Word Limit (Top-K)"})}),c.jsx("span",{className:"font-mono font-bold text-blue-400",children:s.topK})]}),c.jsx("input",{id:"topk-slider","aria-label":"Adjust Top-K slider from 1 to 100",type:"range",min:"1",max:"100",step:"1",value:s.topK,onFocus:()=>{U("topK"),q({feature:`Orbital Ring (Top-K = ${s.topK})`,whatItIs:"Strict top K rank vocabulary candidate filter.",whyItIs:"Eliminates absurd long-tail tokens regardless of temperature.",impact:`Keeps top ${s.topK} candidate stars active; grays out outer tokens.`,guidance:"Set Top-K to 40 for standard conversational LLM sampling."})},onChange:ce=>{const we=parseInt(ce.target.value,10);U("topK"),Re("topK",we),q({feature:`Top-K Filter (${we})`,whatItIs:"Rank cutoff threshold.",whyItIs:"Hard-clips tokens beyond rank K.",impact:`Only top ${we} candidates remain eligible for sampling.`,guidance:`Top ${we} candidates active.`})},className:"w-full"}),c.jsx("p",{className:"text-[11px] text-slate-400",children:"Only allow the AI to choose from the top K most likely words. Ignores the rest."})]}),c.jsxs("div",{className:"space-y-1.5",children:[c.jsxs("div",{className:"flex justify-between text-xs",children:[c.jsx("label",{htmlFor:"topp-slider",className:"font-medium text-slate-200 flex items-center space-x-1",children:c.jsx("span",{children:"Confidence Cutoff (Top-P)"})}),c.jsxs("span",{className:"font-mono font-bold text-blue-400",children:[(s.topP*100).toFixed(0),"%"]})]}),c.jsx("input",{id:"topp-slider","aria-label":"Adjust Top-P slider from 1% to 100%",type:"range",min:"0.01",max:"1.0",step:"0.01",value:s.topP,onFocus:()=>U("topP"),onChange:ce=>{const we=parseFloat(ce.target.value);U("topP"),Re("topP",we),q({feature:`Energy Shield (Top-P = ${(we*100).toFixed(0)}%)`,whatItIs:"Cumulative probability nucleus cutoff threshold.",whyItIs:"Dynamically resizes candidate pool based on confidence distribution.",impact:`Drapes dynamic purple energy shield ring at cumulative ${(we*100).toFixed(0)}%.`,guidance:"Set Top-P to 0.90 for balanced natural responses."})},className:"w-full"}),c.jsx("p",{className:"text-[11px] text-slate-400",children:"Only use words that make up the top P% of total probability."})]}),c.jsxs("div",{className:"space-y-1.5",children:[c.jsxs("div",{className:"flex justify-between text-xs",children:[c.jsx("label",{htmlFor:"minp-slider",className:"font-medium text-slate-200 flex items-center space-x-1",children:c.jsx("span",{children:"Ignore Wild Guesses (Min-P)"})}),c.jsxs("span",{className:"font-mono font-bold text-blue-400",children:[(s.minP*100).toFixed(1),"%"]})]}),c.jsx("input",{id:"minp-slider","aria-label":"Adjust Min-P slider from 0% to 100%",type:"range",min:"0.0",max:"1.0",step:"0.01",value:s.minP,onFocus:()=>U("minP"),onChange:ce=>{const we=parseFloat(ce.target.value);U("minP"),Re("minP",we),q({feature:`Gravity Well (Min-P = ${(we*100).toFixed(1)}%)`,whatItIs:"Relative probability cutoff scaled to top star chance.",whyItIs:"Superior to Top-P at high temperatures because it scales dynamically.",impact:`Filters candidates below ${(we*100).toFixed(1)}% of top star probability.`,guidance:"Set Min-P to 0.05 (5%) for clean sampling at T>1.0."})},className:"w-full"}),c.jsx("p",{className:"text-[11px] text-slate-400",children:"Hide words that have a near-zero chance of making sense."})]})]}),c.jsxs("div",{className:"rounded-xl border border-white/10 bg-[#111111] overflow-hidden",children:[c.jsxs("button",{type:"button",onClick:()=>ae(!V),"aria-label":"Toggle Penalties and Guardrails sampling options","aria-expanded":V,className:"w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-medium text-gray-200 hover:bg-white/5 transition-colors",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx(fa,{className:`h-4 w-4 transition-colors duration-200 ${s.frequencyPenalty>0||s.presencePenalty>0||Object.keys(s.logitBiases).length>0||s.stopSequences.length>0?"text-blue-500":"text-slate-400"}`}),c.jsx("span",{className:"font-semibold text-white tracking-tight",children:"Repetition Blockers (Penalties)"}),c.jsx("span",{className:`rounded-full px-2 py-0.5 text-[10px] font-bold ${s.frequencyPenalty>0||s.presencePenalty>0||Object.keys(s.logitBiases).length>0||s.stopSequences.length>0?"bg-blue-500/10 text-blue-300 border border-blue-500/20":"bg-slate-800 text-slate-400"}`,children:s.frequencyPenalty>0||s.presencePenalty>0||Object.keys(s.logitBiases).length>0||s.stopSequences.length>0?"ACTIVE":"DEFAULT"})]}),V?c.jsx(bs,{className:"h-4 w-4 text-gray-400"}):c.jsx(ys,{className:"h-4 w-4 text-gray-400"})]}),V&&c.jsxs("div",{className:"p-4 border-t border-white/10 space-y-4 bg-[#0A0A0A]",children:[c.jsxs("div",{className:"space-y-1.5",children:[c.jsxs("div",{className:"flex justify-between text-xs",children:[c.jsx("label",{htmlFor:"freq-penalty-slider",className:"font-medium text-slate-200",children:"Exhaustion Meter (Frequency Penalty)"}),c.jsx("span",{className:"font-mono font-bold text-blue-400",children:s.frequencyPenalty.toFixed(2)})]}),c.jsx("input",{id:"freq-penalty-slider","aria-label":"Adjust Frequency Penalty (Exhaustion Meter) slider from -2 to 2",type:"range",min:"-2.0",max:"2.0",step:"0.01",value:s.frequencyPenalty,onFocus:()=>U("frequencyPenalty"),onChange:ce=>{const we=parseFloat(ce.target.value);U("frequencyPenalty"),Re("frequencyPenalty",we),q({feature:`Exhaustion Meter (Frequency Penalty = ${we.toFixed(2)})`,whatItIs:"Repetition penalty proportional to exact token frequency count.",whyItIs:"Breaks stubborn repetitive phrases and word loops.",impact:"Words used repeatedly in context history dim in opacity.",guidance:"Increase >0.5 to stop the model from repeating words."})},className:"w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 hover:accent-blue-400 transition-all"})]}),c.jsxs("div",{className:"space-y-1.5",children:[c.jsxs("div",{className:"flex justify-between text-xs",children:[c.jsx("label",{htmlFor:"presence-penalty-slider",className:"font-medium text-slate-200",children:"Horizon Booster (Presence Penalty)"}),c.jsx("span",{className:"font-mono font-bold text-blue-400",children:s.presencePenalty.toFixed(2)})]}),c.jsx("input",{id:"presence-penalty-slider","aria-label":"Adjust Presence Penalty (Horizon Booster) slider from -2 to 2",type:"range",min:"-2.0",max:"2.0",step:"0.01",value:s.presencePenalty,onFocus:()=>U("presencePenalty"),onChange:ce=>{const we=parseFloat(ce.target.value);U("presencePenalty"),Re("presencePenalty",we),q({feature:`Horizon Booster (Presence Penalty = ${we.toFixed(2)})`,whatItIs:"Flat penalty applied once to any token present in context.",whyItIs:"Encourages the model to introduce fresh new topics.",impact:"Broadens vocabulary scope across outer orbital rings.",guidance:"Increase >0.5 to encourage diverse topic exploration."})},className:"w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 hover:accent-blue-400 transition-all"})]}),c.jsxs("div",{className:"space-y-2",children:[c.jsx("label",{htmlFor:"bias-word-input",className:"text-xs font-medium text-slate-200 flex items-center justify-between",children:c.jsxs("span",{className:"flex items-center space-x-1",children:[c.jsx(d_,{className:"h-3.5 w-3.5 text-slate-400"}),c.jsx("span",{children:"Magnet / Black Hole (Logit Bias)"})]})}),c.jsx("div",{className:"flex flex-wrap gap-1.5 mb-2",children:Object.entries(s.logitBiases).map(([ce,we])=>c.jsxs("span",{className:`inline-flex items-center space-x-1 px-2 py-0.5 rounded-md text-xs font-mono border ${we<0?"bg-slate-900 text-slate-300 border border-slate-700":"bg-blue-950/60 text-blue-300 border border-blue-800/50"}`,children:[c.jsxs("span",{children:["'",ce,"':"]}),c.jsx("span",{className:"font-bold",children:we>0?`+${we}`:we}),c.jsx("button",{type:"button",onClick:()=>be(ce),"aria-label":`Remove logit bias for ${ce}`,className:"hover:text-white ml-1",children:c.jsx(_c,{className:"h-3 w-3"})})]},ce))}),c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx("input",{id:"bias-word-input",type:"text",placeholder:"Target word (e.g. delve)","aria-label":"Word to apply logit bias to",value:Q,onChange:ce=>ie(ce.target.value),className:"flex-1 rounded-lg bg-slate-900 border border-slate-800 px-2.5 py-1 text-xs text-slate-200 placeholder-slate-600 focus:border-cyan-400 focus:outline-none font-mono"}),c.jsxs("select",{"aria-label":"Select logit bias value",value:de,onChange:ce=>re(parseFloat(ce.target.value)),className:"rounded-lg bg-slate-900 border border-slate-800 px-2 py-1 text-xs text-slate-200 font-mono focus:outline-none",children:[c.jsx("option",{value:-100,children:"-100 (Black Hole / Ban)"}),c.jsx("option",{value:-5,children:"-5.0 (Discourage)"}),c.jsx("option",{value:5,children:"+5.0 (Boost)"}),c.jsx("option",{value:10,children:"+10.0 (Magnet)"})]}),c.jsx("button",{type:"button",onClick:qe,"aria-label":"Add logit bias word",className:"rounded-lg bg-blue-600 hover:bg-blue-700 text-white p-1.5 shadow-md transition-colors",children:c.jsx(jm,{className:"h-3.5 w-3.5"})})]})]}),c.jsxs("div",{className:"space-y-2",children:[c.jsxs("label",{htmlFor:"stop-seq-input",className:"text-xs font-medium text-slate-200 flex items-center space-x-1",children:[c.jsx(ac,{className:"h-3.5 w-3.5 text-slate-400"}),c.jsx("span",{children:"Emergency Brake (Stop Sequences)"})]}),c.jsx("div",{className:"flex flex-wrap gap-1.5",children:s.stopSequences.map(ce=>c.jsxs("span",{className:"inline-flex items-center space-x-1 px-2 py-0.5 rounded-md text-xs font-mono bg-slate-800 text-amber-300 border border-slate-700",children:[c.jsxs("span",{children:['"',ce,'"']}),c.jsx("button",{type:"button",onClick:()=>me(ce),"aria-label":`Remove stop sequence ${ce}`,className:"hover:text-white ml-1",children:c.jsx(_c,{className:"h-3 w-3"})})]},ce))}),c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx("input",{id:"stop-seq-input",type:"text",placeholder:"e.g. \\n or END","aria-label":"Stop sequence string to add",value:X,onChange:ce=>J(ce.target.value),className:"flex-1 rounded-lg bg-slate-900 border border-slate-800 px-2.5 py-1 text-xs text-slate-200 placeholder-slate-600 focus:border-cyan-400 focus:outline-none font-mono"}),c.jsx("button",{type:"button",onClick:ee,"aria-label":"Add stop sequence",className:"rounded-lg bg-amber-500/20 p-1.5 text-amber-300 border border-amber-400/40 hover:bg-amber-500/30",children:c.jsx(jm,{className:"h-3.5 w-3.5"})})]})]})]})]}),"      "]})]})})]})};/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Kh="185",xa={ROTATE:0,DOLLY:1,PAN:2},ma={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},U_=0,Wm=1,O_=2,lc=1,B_=2,vo=3,Kr=0,si=1,Oi=2,Qi=0,ws=1,yc=2,Xm=3,qm=4,z_=5,vs=100,j_=101,H_=102,G_=103,V_=104,W_=200,X_=201,q_=202,$_=203,Zd=204,Qd=205,Y_=206,K_=207,Z_=208,Q_=209,J_=210,ey=211,ty=212,ny=213,iy=214,Jd=0,eh=1,th=2,ya=3,nh=4,ih=5,rh=6,sh=7,ug=0,ry=1,sy=2,Ji=0,dg=1,hg=2,fg=3,pg=4,mg=5,gg=6,xg=7,vg=300,Es=301,ba=302,md=303,gd=304,Dc=306,ah=1e3,mr=1001,oh=1002,Ln=1003,ay=1004,Pl=1005,jn=1006,xd=1007,Ss=1008,Ei=1009,_g=1010,yg=1011,yo=1012,Zh=1013,er=1014,zi=1015,pi=1016,Qh=1017,Jh=1018,bo=1020,bg=35902,Sg=35899,Mg=1021,wg=1022,ji=1023,vr=1026,Ms=1027,Eg=1028,ef=1029,Zr=1030,tf=1031,nf=1033,cc=33776,uc=33777,dc=33778,hc=33779,lh=35840,ch=35841,uh=35842,dh=35843,hh=36196,fh=37492,ph=37496,mh=37488,gh=37489,bc=37490,xh=37491,vh=37808,_h=37809,yh=37810,bh=37811,Sh=37812,Mh=37813,wh=37814,Eh=37815,Th=37816,Ah=37817,Ch=37818,Rh=37819,Ph=37820,Nh=37821,Lh=36492,Dh=36494,Ih=36495,kh=36283,Fh=36284,Sc=36285,Uh=36286,oy=3200,$m=0,ly=1,qr="",Mi="srgb",Mc="srgb-linear",wc="linear",Wt="srgb",Qs=7680,Ym=519,cy=512,uy=513,dy=514,rf=515,hy=516,fy=517,sf=518,py=519,Km=35044,Zm="300 es",Zi=2e3,Ec=2001;function my(s){for(let e=s.length-1;e>=0;--e)if(s[e]>=65535)return!0;return!1}function Tc(s){return document.createElementNS("http://www.w3.org/1999/xhtml",s)}function gy(){const s=Tc("canvas");return s.style.display="block",s}const Qm={};function Jm(...s){const e="THREE."+s.shift();console.log(e,...s)}function Tg(s){const e=s[0];if(typeof e=="string"&&e.startsWith("TSL:")){const t=s[1];t&&t.isStackTrace?s[0]+=" "+t.getLocation():s[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return s}function gt(...s){s=Tg(s);const e="THREE."+s.shift();{const t=s[0];t&&t.isStackTrace?console.warn(t.getError(e)):console.warn(e,...s)}}function kt(...s){s=Tg(s);const e="THREE."+s.shift();{const t=s[0];t&&t.isStackTrace?console.error(t.getError(e)):console.error(e,...s)}}function va(...s){const e=s.join(" ");e in Qm||(Qm[e]=!0,gt(...s))}function xy(s,e,t){return new Promise(function(r,a){function l(){switch(s.clientWaitSync(e,s.SYNC_FLUSH_COMMANDS_BIT,0)){case s.WAIT_FAILED:a();break;case s.TIMEOUT_EXPIRED:setTimeout(l,t);break;default:r()}}setTimeout(l,t)})}const vy={[Jd]:eh,[th]:rh,[nh]:sh,[ya]:ih,[eh]:Jd,[rh]:th,[sh]:nh,[ih]:ya};class Jr{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const r=this._listeners;r[e]===void 0&&(r[e]=[]),r[e].indexOf(t)===-1&&r[e].push(t)}hasEventListener(e,t){const r=this._listeners;return r===void 0?!1:r[e]!==void 0&&r[e].indexOf(t)!==-1}removeEventListener(e,t){const r=this._listeners;if(r===void 0)return;const a=r[e];if(a!==void 0){const l=a.indexOf(t);l!==-1&&a.splice(l,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const r=t[e.type];if(r!==void 0){e.target=this;const a=r.slice(0);for(let l=0,d=a.length;l<d;l++)a[l].call(this,e);e.target=null}}}const Bn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],fc=Math.PI/180,Oh=180/Math.PI;function Mo(){const s=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,r=Math.random()*4294967295|0;return(Bn[s&255]+Bn[s>>8&255]+Bn[s>>16&255]+Bn[s>>24&255]+"-"+Bn[e&255]+Bn[e>>8&255]+"-"+Bn[e>>16&15|64]+Bn[e>>24&255]+"-"+Bn[t&63|128]+Bn[t>>8&255]+"-"+Bn[t>>16&255]+Bn[t>>24&255]+Bn[r&255]+Bn[r>>8&255]+Bn[r>>16&255]+Bn[r>>24&255]).toLowerCase()}function Rt(s,e,t){return Math.max(e,Math.min(t,s))}function _y(s,e){return(s%e+e)%e}function vd(s,e,t){return(1-t)*s+t*e}function oo(s,e){switch(e.constructor){case Float32Array:return s;case Uint32Array:return s/4294967295;case Uint16Array:return s/65535;case Uint8Array:return s/255;case Int32Array:return Math.max(s/2147483647,-1);case Int16Array:return Math.max(s/32767,-1);case Int8Array:return Math.max(s/127,-1);default:throw new Error("THREE.MathUtils: Invalid component type.")}}function ii(s,e){switch(e.constructor){case Float32Array:return s;case Uint32Array:return Math.round(s*4294967295);case Uint16Array:return Math.round(s*65535);case Uint8Array:return Math.round(s*255);case Int32Array:return Math.round(s*2147483647);case Int16Array:return Math.round(s*32767);case Int8Array:return Math.round(s*127);default:throw new Error("THREE.MathUtils: Invalid component type.")}}const yy={DEG2RAD:fc};class ut{static{ut.prototype.isVector2=!0}constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,r=this.y,a=e.elements;return this.x=a[0]*t+a[3]*r+a[6],this.y=a[1]*t+a[4]*r+a[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Rt(this.x,e.x,t.x),this.y=Rt(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=Rt(this.x,e,t),this.y=Rt(this.y,e,t),this}clampLength(e,t){const r=this.length();return this.divideScalar(r||1).multiplyScalar(Rt(r,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const r=this.dot(e)/t;return Math.acos(Rt(r,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,r=this.y-e.y;return t*t+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,r){return this.x=e.x+(t.x-e.x)*r,this.y=e.y+(t.y-e.y)*r,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const r=Math.cos(t),a=Math.sin(t),l=this.x-e.x,d=this.y-e.y;return this.x=l*r-d*a+e.x,this.y=l*a+d*r+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Qr{constructor(e=0,t=0,r=0,a=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=r,this._w=a}static slerpFlat(e,t,r,a,l,d,h){let f=r[a+0],m=r[a+1],_=r[a+2],S=r[a+3],v=l[d+0],b=l[d+1],M=l[d+2],E=l[d+3];if(S!==E||f!==v||m!==b||_!==M){let g=f*v+m*b+_*M+S*E;g<0&&(v=-v,b=-b,M=-M,E=-E,g=-g);let x=1-h;if(g<.9995){const N=Math.acos(g),P=Math.sin(N);x=Math.sin(x*N)/P,h=Math.sin(h*N)/P,f=f*x+v*h,m=m*x+b*h,_=_*x+M*h,S=S*x+E*h}else{f=f*x+v*h,m=m*x+b*h,_=_*x+M*h,S=S*x+E*h;const N=1/Math.sqrt(f*f+m*m+_*_+S*S);f*=N,m*=N,_*=N,S*=N}}e[t]=f,e[t+1]=m,e[t+2]=_,e[t+3]=S}static multiplyQuaternionsFlat(e,t,r,a,l,d){const h=r[a],f=r[a+1],m=r[a+2],_=r[a+3],S=l[d],v=l[d+1],b=l[d+2],M=l[d+3];return e[t]=h*M+_*S+f*b-m*v,e[t+1]=f*M+_*v+m*S-h*b,e[t+2]=m*M+_*b+h*v-f*S,e[t+3]=_*M-h*S-f*v-m*b,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,r,a){return this._x=e,this._y=t,this._z=r,this._w=a,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const r=e._x,a=e._y,l=e._z,d=e._order,h=Math.cos,f=Math.sin,m=h(r/2),_=h(a/2),S=h(l/2),v=f(r/2),b=f(a/2),M=f(l/2);switch(d){case"XYZ":this._x=v*_*S+m*b*M,this._y=m*b*S-v*_*M,this._z=m*_*M+v*b*S,this._w=m*_*S-v*b*M;break;case"YXZ":this._x=v*_*S+m*b*M,this._y=m*b*S-v*_*M,this._z=m*_*M-v*b*S,this._w=m*_*S+v*b*M;break;case"ZXY":this._x=v*_*S-m*b*M,this._y=m*b*S+v*_*M,this._z=m*_*M+v*b*S,this._w=m*_*S-v*b*M;break;case"ZYX":this._x=v*_*S-m*b*M,this._y=m*b*S+v*_*M,this._z=m*_*M-v*b*S,this._w=m*_*S+v*b*M;break;case"YZX":this._x=v*_*S+m*b*M,this._y=m*b*S+v*_*M,this._z=m*_*M-v*b*S,this._w=m*_*S-v*b*M;break;case"XZY":this._x=v*_*S-m*b*M,this._y=m*b*S-v*_*M,this._z=m*_*M+v*b*S,this._w=m*_*S+v*b*M;break;default:gt("Quaternion: .setFromEuler() encountered an unknown order: "+d)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const r=t/2,a=Math.sin(r);return this._x=e.x*a,this._y=e.y*a,this._z=e.z*a,this._w=Math.cos(r),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,r=t[0],a=t[4],l=t[8],d=t[1],h=t[5],f=t[9],m=t[2],_=t[6],S=t[10],v=r+h+S;if(v>0){const b=.5/Math.sqrt(v+1);this._w=.25/b,this._x=(_-f)*b,this._y=(l-m)*b,this._z=(d-a)*b}else if(r>h&&r>S){const b=2*Math.sqrt(1+r-h-S);this._w=(_-f)/b,this._x=.25*b,this._y=(a+d)/b,this._z=(l+m)/b}else if(h>S){const b=2*Math.sqrt(1+h-r-S);this._w=(l-m)/b,this._x=(a+d)/b,this._y=.25*b,this._z=(f+_)/b}else{const b=2*Math.sqrt(1+S-r-h);this._w=(d-a)/b,this._x=(l+m)/b,this._y=(f+_)/b,this._z=.25*b}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let r=e.dot(t)+1;return r<1e-8?(r=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=r):(this._x=0,this._y=-e.z,this._z=e.y,this._w=r)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=r),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Rt(this.dot(e),-1,1)))}rotateTowards(e,t){const r=this.angleTo(e);if(r===0)return this;const a=Math.min(1,t/r);return this.slerp(e,a),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const r=e._x,a=e._y,l=e._z,d=e._w,h=t._x,f=t._y,m=t._z,_=t._w;return this._x=r*_+d*h+a*m-l*f,this._y=a*_+d*f+l*h-r*m,this._z=l*_+d*m+r*f-a*h,this._w=d*_-r*h-a*f-l*m,this._onChangeCallback(),this}slerp(e,t){let r=e._x,a=e._y,l=e._z,d=e._w,h=this.dot(e);h<0&&(r=-r,a=-a,l=-l,d=-d,h=-h);let f=1-t;if(h<.9995){const m=Math.acos(h),_=Math.sin(m);f=Math.sin(f*m)/_,t=Math.sin(t*m)/_,this._x=this._x*f+r*t,this._y=this._y*f+a*t,this._z=this._z*f+l*t,this._w=this._w*f+d*t,this._onChangeCallback()}else this._x=this._x*f+r*t,this._y=this._y*f+a*t,this._z=this._z*f+l*t,this._w=this._w*f+d*t,this.normalize();return this}slerpQuaternions(e,t,r){return this.copy(e).slerp(t,r)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),r=Math.random(),a=Math.sqrt(1-r),l=Math.sqrt(r);return this.set(a*Math.sin(e),a*Math.cos(e),l*Math.sin(t),l*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class K{static{K.prototype.isVector3=!0}constructor(e=0,t=0,r=0){this.x=e,this.y=t,this.z=r}set(e,t,r){return r===void 0&&(r=this.z),this.x=e,this.y=t,this.z=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(e0.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(e0.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,r=this.y,a=this.z,l=e.elements;return this.x=l[0]*t+l[3]*r+l[6]*a,this.y=l[1]*t+l[4]*r+l[7]*a,this.z=l[2]*t+l[5]*r+l[8]*a,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,r=this.y,a=this.z,l=e.elements,d=1/(l[3]*t+l[7]*r+l[11]*a+l[15]);return this.x=(l[0]*t+l[4]*r+l[8]*a+l[12])*d,this.y=(l[1]*t+l[5]*r+l[9]*a+l[13])*d,this.z=(l[2]*t+l[6]*r+l[10]*a+l[14])*d,this}applyQuaternion(e){const t=this.x,r=this.y,a=this.z,l=e.x,d=e.y,h=e.z,f=e.w,m=2*(d*a-h*r),_=2*(h*t-l*a),S=2*(l*r-d*t);return this.x=t+f*m+d*S-h*_,this.y=r+f*_+h*m-l*S,this.z=a+f*S+l*_-d*m,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,r=this.y,a=this.z,l=e.elements;return this.x=l[0]*t+l[4]*r+l[8]*a,this.y=l[1]*t+l[5]*r+l[9]*a,this.z=l[2]*t+l[6]*r+l[10]*a,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Rt(this.x,e.x,t.x),this.y=Rt(this.y,e.y,t.y),this.z=Rt(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=Rt(this.x,e,t),this.y=Rt(this.y,e,t),this.z=Rt(this.z,e,t),this}clampLength(e,t){const r=this.length();return this.divideScalar(r||1).multiplyScalar(Rt(r,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,r){return this.x=e.x+(t.x-e.x)*r,this.y=e.y+(t.y-e.y)*r,this.z=e.z+(t.z-e.z)*r,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const r=e.x,a=e.y,l=e.z,d=t.x,h=t.y,f=t.z;return this.x=a*f-l*h,this.y=l*d-r*f,this.z=r*h-a*d,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const r=e.dot(this)/t;return this.copy(e).multiplyScalar(r)}projectOnPlane(e){return _d.copy(this).projectOnVector(e),this.sub(_d)}reflect(e){return this.sub(_d.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const r=this.dot(e)/t;return Math.acos(Rt(r,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,r=this.y-e.y,a=this.z-e.z;return t*t+r*r+a*a}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,r){const a=Math.sin(t)*e;return this.x=a*Math.sin(r),this.y=Math.cos(t)*e,this.z=a*Math.cos(r),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,r){return this.x=e*Math.sin(t),this.y=r,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),r=this.setFromMatrixColumn(e,1).length(),a=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=r,this.z=a,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,r=Math.sqrt(1-t*t);return this.x=r*Math.cos(e),this.y=t,this.z=r*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const _d=new K,e0=new Qr;class yt{static{yt.prototype.isMatrix3=!0}constructor(e,t,r,a,l,d,h,f,m){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,r,a,l,d,h,f,m)}set(e,t,r,a,l,d,h,f,m){const _=this.elements;return _[0]=e,_[1]=a,_[2]=h,_[3]=t,_[4]=l,_[5]=f,_[6]=r,_[7]=d,_[8]=m,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,r=e.elements;return t[0]=r[0],t[1]=r[1],t[2]=r[2],t[3]=r[3],t[4]=r[4],t[5]=r[5],t[6]=r[6],t[7]=r[7],t[8]=r[8],this}extractBasis(e,t,r){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),r.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const r=e.elements,a=t.elements,l=this.elements,d=r[0],h=r[3],f=r[6],m=r[1],_=r[4],S=r[7],v=r[2],b=r[5],M=r[8],E=a[0],g=a[3],x=a[6],N=a[1],P=a[4],C=a[7],D=a[2],L=a[5],O=a[8];return l[0]=d*E+h*N+f*D,l[3]=d*g+h*P+f*L,l[6]=d*x+h*C+f*O,l[1]=m*E+_*N+S*D,l[4]=m*g+_*P+S*L,l[7]=m*x+_*C+S*O,l[2]=v*E+b*N+M*D,l[5]=v*g+b*P+M*L,l[8]=v*x+b*C+M*O,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],r=e[1],a=e[2],l=e[3],d=e[4],h=e[5],f=e[6],m=e[7],_=e[8];return t*d*_-t*h*m-r*l*_+r*h*f+a*l*m-a*d*f}invert(){const e=this.elements,t=e[0],r=e[1],a=e[2],l=e[3],d=e[4],h=e[5],f=e[6],m=e[7],_=e[8],S=_*d-h*m,v=h*f-_*l,b=m*l-d*f,M=t*S+r*v+a*b;if(M===0)return this.set(0,0,0,0,0,0,0,0,0);const E=1/M;return e[0]=S*E,e[1]=(a*m-_*r)*E,e[2]=(h*r-a*d)*E,e[3]=v*E,e[4]=(_*t-a*f)*E,e[5]=(a*l-h*t)*E,e[6]=b*E,e[7]=(r*f-m*t)*E,e[8]=(d*t-r*l)*E,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,r,a,l,d,h){const f=Math.cos(l),m=Math.sin(l);return this.set(r*f,r*m,-r*(f*d+m*h)+d+e,-a*m,a*f,-a*(-m*d+f*h)+h+t,0,0,1),this}scale(e,t){return va("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(yd.makeScale(e,t)),this}rotate(e){return va("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(yd.makeRotation(-e)),this}translate(e,t){return va("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(yd.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),r=Math.sin(e);return this.set(t,-r,0,r,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,r=e.elements;for(let a=0;a<9;a++)if(t[a]!==r[a])return!1;return!0}fromArray(e,t=0){for(let r=0;r<9;r++)this.elements[r]=e[r+t];return this}toArray(e=[],t=0){const r=this.elements;return e[t]=r[0],e[t+1]=r[1],e[t+2]=r[2],e[t+3]=r[3],e[t+4]=r[4],e[t+5]=r[5],e[t+6]=r[6],e[t+7]=r[7],e[t+8]=r[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const yd=new yt,t0=new yt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),n0=new yt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function by(){const s={enabled:!0,workingColorSpace:Mc,spaces:{},convert:function(a,l,d){return this.enabled===!1||l===d||!l||!d||(this.spaces[l].transfer===Wt&&(a.r=gr(a.r),a.g=gr(a.g),a.b=gr(a.b)),this.spaces[l].primaries!==this.spaces[d].primaries&&(a.applyMatrix3(this.spaces[l].toXYZ),a.applyMatrix3(this.spaces[d].fromXYZ)),this.spaces[d].transfer===Wt&&(a.r=_a(a.r),a.g=_a(a.g),a.b=_a(a.b))),a},workingToColorSpace:function(a,l){return this.convert(a,this.workingColorSpace,l)},colorSpaceToWorking:function(a,l){return this.convert(a,l,this.workingColorSpace)},getPrimaries:function(a){return this.spaces[a].primaries},getTransfer:function(a){return a===qr?wc:this.spaces[a].transfer},getToneMappingMode:function(a){return this.spaces[a].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(a,l=this.workingColorSpace){return a.fromArray(this.spaces[l].luminanceCoefficients)},define:function(a){Object.assign(this.spaces,a)},_getMatrix:function(a,l,d){return a.copy(this.spaces[l].toXYZ).multiply(this.spaces[d].fromXYZ)},_getDrawingBufferColorSpace:function(a){return this.spaces[a].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(a=this.workingColorSpace){return this.spaces[a].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(a,l){return va("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),s.workingToColorSpace(a,l)},toWorkingColorSpace:function(a,l){return va("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),s.colorSpaceToWorking(a,l)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],r=[.3127,.329];return s.define({[Mc]:{primaries:e,whitePoint:r,transfer:wc,toXYZ:t0,fromXYZ:n0,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:Mi},outputColorSpaceConfig:{drawingBufferColorSpace:Mi}},[Mi]:{primaries:e,whitePoint:r,transfer:Wt,toXYZ:t0,fromXYZ:n0,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:Mi}}}),s}const Lt=by();function gr(s){return s<.04045?s*.0773993808:Math.pow(s*.9478672986+.0521327014,2.4)}function _a(s){return s<.0031308?s*12.92:1.055*Math.pow(s,.41666)-.055}let Js;class Sy{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let r;if(e instanceof HTMLCanvasElement)r=e;else{Js===void 0&&(Js=Tc("canvas")),Js.width=e.width,Js.height=e.height;const a=Js.getContext("2d");e instanceof ImageData?a.putImageData(e,0,0):a.drawImage(e,0,0,e.width,e.height),r=Js}return r.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=Tc("canvas");t.width=e.width,t.height=e.height;const r=t.getContext("2d");r.drawImage(e,0,0,e.width,e.height);const a=r.getImageData(0,0,e.width,e.height),l=a.data;for(let d=0;d<l.length;d++)l[d]=gr(l[d]/255)*255;return r.putImageData(a,0,0),t}else if(e.data){const t=e.data.slice(0);for(let r=0;r<t.length;r++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[r]=Math.floor(gr(t[r]/255)*255):t[r]=gr(t[r]);return{data:t,width:e.width,height:e.height}}else return gt("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let My=0;class af{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:My++}),this.uuid=Mo(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<"u"&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const r={uuid:this.uuid,url:""},a=this.data;if(a!==null){let l;if(Array.isArray(a)){l=[];for(let d=0,h=a.length;d<h;d++)a[d].isDataTexture?l.push(bd(a[d].image)):l.push(bd(a[d]))}else l=bd(a);r.url=l}return t||(e.images[this.uuid]=r),r}}function bd(s){return typeof HTMLImageElement<"u"&&s instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&s instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&s instanceof ImageBitmap?Sy.getDataURL(s):s.data?{data:Array.from(s.data),width:s.width,height:s.height,type:s.data.constructor.name}:(gt("Texture: Unable to serialize Texture."),{})}let wy=0;const Sd=new K;class Xn extends Jr{constructor(e=Xn.DEFAULT_IMAGE,t=Xn.DEFAULT_MAPPING,r=mr,a=mr,l=jn,d=Ss,h=ji,f=Ei,m=Xn.DEFAULT_ANISOTROPY,_=qr){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:wy++}),this.uuid=Mo(),this.name="",this.source=new af(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=r,this.wrapT=a,this.magFilter=l,this.minFilter=d,this.anisotropy=m,this.format=h,this.internalFormat=null,this.type=f,this.offset=new ut(0,0),this.repeat=new ut(1,1),this.center=new ut(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new yt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=_,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(Sd).x}get height(){return this.source.getSize(Sd).y}get depth(){return this.source.getSize(Sd).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const r=e[t];if(r===void 0){gt(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const a=this[t];if(a===void 0){gt(`Texture.setValues(): property '${t}' does not exist.`);continue}a&&r&&a.isVector2&&r.isVector2||a&&r&&a.isVector3&&r.isVector3||a&&r&&a.isMatrix3&&r.isMatrix3?a.copy(r):this[t]=r}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const r={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(r.userData=this.userData),t||(e.textures[this.uuid]=r),r}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==vg)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case ah:e.x=e.x-Math.floor(e.x);break;case mr:e.x=e.x<0?0:1;break;case oh:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case ah:e.y=e.y-Math.floor(e.y);break;case mr:e.y=e.y<0?0:1;break;case oh:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Xn.DEFAULT_IMAGE=null;Xn.DEFAULT_MAPPING=vg;Xn.DEFAULT_ANISOTROPY=1;class dn{static{dn.prototype.isVector4=!0}constructor(e=0,t=0,r=0,a=1){this.x=e,this.y=t,this.z=r,this.w=a}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,r,a){return this.x=e,this.y=t,this.z=r,this.w=a,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,r=this.y,a=this.z,l=this.w,d=e.elements;return this.x=d[0]*t+d[4]*r+d[8]*a+d[12]*l,this.y=d[1]*t+d[5]*r+d[9]*a+d[13]*l,this.z=d[2]*t+d[6]*r+d[10]*a+d[14]*l,this.w=d[3]*t+d[7]*r+d[11]*a+d[15]*l,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,r,a,l;const f=e.elements,m=f[0],_=f[4],S=f[8],v=f[1],b=f[5],M=f[9],E=f[2],g=f[6],x=f[10];if(Math.abs(_-v)<.01&&Math.abs(S-E)<.01&&Math.abs(M-g)<.01){if(Math.abs(_+v)<.1&&Math.abs(S+E)<.1&&Math.abs(M+g)<.1&&Math.abs(m+b+x-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const P=(m+1)/2,C=(b+1)/2,D=(x+1)/2,L=(_+v)/4,O=(S+E)/4,T=(M+g)/4;return P>C&&P>D?P<.01?(r=0,a=.707106781,l=.707106781):(r=Math.sqrt(P),a=L/r,l=O/r):C>D?C<.01?(r=.707106781,a=0,l=.707106781):(a=Math.sqrt(C),r=L/a,l=T/a):D<.01?(r=.707106781,a=.707106781,l=0):(l=Math.sqrt(D),r=O/l,a=T/l),this.set(r,a,l,t),this}let N=Math.sqrt((g-M)*(g-M)+(S-E)*(S-E)+(v-_)*(v-_));return Math.abs(N)<.001&&(N=1),this.x=(g-M)/N,this.y=(S-E)/N,this.z=(v-_)/N,this.w=Math.acos((m+b+x-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Rt(this.x,e.x,t.x),this.y=Rt(this.y,e.y,t.y),this.z=Rt(this.z,e.z,t.z),this.w=Rt(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=Rt(this.x,e,t),this.y=Rt(this.y,e,t),this.z=Rt(this.z,e,t),this.w=Rt(this.w,e,t),this}clampLength(e,t){const r=this.length();return this.divideScalar(r||1).multiplyScalar(Rt(r,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,r){return this.x=e.x+(t.x-e.x)*r,this.y=e.y+(t.y-e.y)*r,this.z=e.z+(t.z-e.z)*r,this.w=e.w+(t.w-e.w)*r,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Ey extends Jr{constructor(e=1,t=1,r={}){super(),r=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:jn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},r),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=r.depth,this.scissor=new dn(0,0,e,t),this.scissorTest=!1,this.viewport=new dn(0,0,e,t),this.textures=[];const a={width:e,height:t,depth:r.depth},l=new Xn(a),d=r.count;for(let h=0;h<d;h++)this.textures[h]=l.clone(),this.textures[h].isRenderTargetTexture=!0,this.textures[h].renderTarget=this;this._setTextureOptions(r),this.depthBuffer=r.depthBuffer,this.stencilBuffer=r.stencilBuffer,this.resolveDepthBuffer=r.resolveDepthBuffer,this.resolveStencilBuffer=r.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=r.depthTexture,this.samples=r.samples,this.multiview=r.multiview,this.useArrayDepthTexture=r.useArrayDepthTexture}_setTextureOptions(e={}){const t={minFilter:jn,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let r=0;r<this.textures.length;r++)this.textures[r].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,r=1){if(this.width!==e||this.height!==t||this.depth!==r){this.width=e,this.height=t,this.depth=r;for(let a=0,l=this.textures.length;a<l;a++)this.textures[a].image.width=e,this.textures[a].image.height=t,this.textures[a].image.depth=r,this.textures[a].isData3DTexture!==!0&&(this.textures[a].isArrayTexture=this.textures[a].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,r=e.textures.length;t<r;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const a=Object.assign({},e.textures[t].image);this.textures[t].source=new af(a)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class ai extends Ey{constructor(e=1,t=1,r={}){super(e,t,r),this.isWebGLRenderTarget=!0}}class Ag extends Xn{constructor(e=null,t=1,r=1,a=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:r,depth:a},this.magFilter=Ln,this.minFilter=Ln,this.wrapR=mr,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class Ty extends Xn{constructor(e=null,t=1,r=1,a=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:r,depth:a},this.magFilter=Ln,this.minFilter=Ln,this.wrapR=mr,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class nn{static{nn.prototype.isMatrix4=!0}constructor(e,t,r,a,l,d,h,f,m,_,S,v,b,M,E,g){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,r,a,l,d,h,f,m,_,S,v,b,M,E,g)}set(e,t,r,a,l,d,h,f,m,_,S,v,b,M,E,g){const x=this.elements;return x[0]=e,x[4]=t,x[8]=r,x[12]=a,x[1]=l,x[5]=d,x[9]=h,x[13]=f,x[2]=m,x[6]=_,x[10]=S,x[14]=v,x[3]=b,x[7]=M,x[11]=E,x[15]=g,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new nn().fromArray(this.elements)}copy(e){const t=this.elements,r=e.elements;return t[0]=r[0],t[1]=r[1],t[2]=r[2],t[3]=r[3],t[4]=r[4],t[5]=r[5],t[6]=r[6],t[7]=r[7],t[8]=r[8],t[9]=r[9],t[10]=r[10],t[11]=r[11],t[12]=r[12],t[13]=r[13],t[14]=r[14],t[15]=r[15],this}copyPosition(e){const t=this.elements,r=e.elements;return t[12]=r[12],t[13]=r[13],t[14]=r[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,r){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),r.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),r.setFromMatrixColumn(this,2),this)}makeBasis(e,t,r){return this.set(e.x,t.x,r.x,0,e.y,t.y,r.y,0,e.z,t.z,r.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();const t=this.elements,r=e.elements,a=1/ea.setFromMatrixColumn(e,0).length(),l=1/ea.setFromMatrixColumn(e,1).length(),d=1/ea.setFromMatrixColumn(e,2).length();return t[0]=r[0]*a,t[1]=r[1]*a,t[2]=r[2]*a,t[3]=0,t[4]=r[4]*l,t[5]=r[5]*l,t[6]=r[6]*l,t[7]=0,t[8]=r[8]*d,t[9]=r[9]*d,t[10]=r[10]*d,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,r=e.x,a=e.y,l=e.z,d=Math.cos(r),h=Math.sin(r),f=Math.cos(a),m=Math.sin(a),_=Math.cos(l),S=Math.sin(l);if(e.order==="XYZ"){const v=d*_,b=d*S,M=h*_,E=h*S;t[0]=f*_,t[4]=-f*S,t[8]=m,t[1]=b+M*m,t[5]=v-E*m,t[9]=-h*f,t[2]=E-v*m,t[6]=M+b*m,t[10]=d*f}else if(e.order==="YXZ"){const v=f*_,b=f*S,M=m*_,E=m*S;t[0]=v+E*h,t[4]=M*h-b,t[8]=d*m,t[1]=d*S,t[5]=d*_,t[9]=-h,t[2]=b*h-M,t[6]=E+v*h,t[10]=d*f}else if(e.order==="ZXY"){const v=f*_,b=f*S,M=m*_,E=m*S;t[0]=v-E*h,t[4]=-d*S,t[8]=M+b*h,t[1]=b+M*h,t[5]=d*_,t[9]=E-v*h,t[2]=-d*m,t[6]=h,t[10]=d*f}else if(e.order==="ZYX"){const v=d*_,b=d*S,M=h*_,E=h*S;t[0]=f*_,t[4]=M*m-b,t[8]=v*m+E,t[1]=f*S,t[5]=E*m+v,t[9]=b*m-M,t[2]=-m,t[6]=h*f,t[10]=d*f}else if(e.order==="YZX"){const v=d*f,b=d*m,M=h*f,E=h*m;t[0]=f*_,t[4]=E-v*S,t[8]=M*S+b,t[1]=S,t[5]=d*_,t[9]=-h*_,t[2]=-m*_,t[6]=b*S+M,t[10]=v-E*S}else if(e.order==="XZY"){const v=d*f,b=d*m,M=h*f,E=h*m;t[0]=f*_,t[4]=-S,t[8]=m*_,t[1]=v*S+E,t[5]=d*_,t[9]=b*S-M,t[2]=M*S-b,t[6]=h*_,t[10]=E*S+v}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Ay,e,Cy)}lookAt(e,t,r){const a=this.elements;return hi.subVectors(e,t),hi.lengthSq()===0&&(hi.z=1),hi.normalize(),zr.crossVectors(r,hi),zr.lengthSq()===0&&(Math.abs(r.z)===1?hi.x+=1e-4:hi.z+=1e-4,hi.normalize(),zr.crossVectors(r,hi)),zr.normalize(),Nl.crossVectors(hi,zr),a[0]=zr.x,a[4]=Nl.x,a[8]=hi.x,a[1]=zr.y,a[5]=Nl.y,a[9]=hi.y,a[2]=zr.z,a[6]=Nl.z,a[10]=hi.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const r=e.elements,a=t.elements,l=this.elements,d=r[0],h=r[4],f=r[8],m=r[12],_=r[1],S=r[5],v=r[9],b=r[13],M=r[2],E=r[6],g=r[10],x=r[14],N=r[3],P=r[7],C=r[11],D=r[15],L=a[0],O=a[4],T=a[8],I=a[12],H=a[1],B=a[5],V=a[9],ae=a[13],Q=a[2],ie=a[6],de=a[10],re=a[14],X=a[3],J=a[7],le=a[11],U=a[15];return l[0]=d*L+h*H+f*Q+m*X,l[4]=d*O+h*B+f*ie+m*J,l[8]=d*T+h*V+f*de+m*le,l[12]=d*I+h*ae+f*re+m*U,l[1]=_*L+S*H+v*Q+b*X,l[5]=_*O+S*B+v*ie+b*J,l[9]=_*T+S*V+v*de+b*le,l[13]=_*I+S*ae+v*re+b*U,l[2]=M*L+E*H+g*Q+x*X,l[6]=M*O+E*B+g*ie+x*J,l[10]=M*T+E*V+g*de+x*le,l[14]=M*I+E*ae+g*re+x*U,l[3]=N*L+P*H+C*Q+D*X,l[7]=N*O+P*B+C*ie+D*J,l[11]=N*T+P*V+C*de+D*le,l[15]=N*I+P*ae+C*re+D*U,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],r=e[4],a=e[8],l=e[12],d=e[1],h=e[5],f=e[9],m=e[13],_=e[2],S=e[6],v=e[10],b=e[14],M=e[3],E=e[7],g=e[11],x=e[15],N=f*b-m*v,P=h*b-m*S,C=h*v-f*S,D=d*b-m*_,L=d*v-f*_,O=d*S-h*_;return t*(E*N-g*P+x*C)-r*(M*N-g*D+x*L)+a*(M*P-E*D+x*O)-l*(M*C-E*L+g*O)}determinantAffine(){const e=this.elements,t=e[0],r=e[4],a=e[8],l=e[1],d=e[5],h=e[9],f=e[2],m=e[6],_=e[10];return t*(d*_-h*m)-r*(l*_-h*f)+a*(l*m-d*f)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,r){const a=this.elements;return e.isVector3?(a[12]=e.x,a[13]=e.y,a[14]=e.z):(a[12]=e,a[13]=t,a[14]=r),this}invert(){const e=this.elements,t=e[0],r=e[1],a=e[2],l=e[3],d=e[4],h=e[5],f=e[6],m=e[7],_=e[8],S=e[9],v=e[10],b=e[11],M=e[12],E=e[13],g=e[14],x=e[15],N=t*h-r*d,P=t*f-a*d,C=t*m-l*d,D=r*f-a*h,L=r*m-l*h,O=a*m-l*f,T=_*E-S*M,I=_*g-v*M,H=_*x-b*M,B=S*g-v*E,V=S*x-b*E,ae=v*x-b*g,Q=N*ae-P*V+C*B+D*H-L*I+O*T;if(Q===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const ie=1/Q;return e[0]=(h*ae-f*V+m*B)*ie,e[1]=(a*V-r*ae-l*B)*ie,e[2]=(E*O-g*L+x*D)*ie,e[3]=(v*L-S*O-b*D)*ie,e[4]=(f*H-d*ae-m*I)*ie,e[5]=(t*ae-a*H+l*I)*ie,e[6]=(g*C-M*O-x*P)*ie,e[7]=(_*O-v*C+b*P)*ie,e[8]=(d*V-h*H+m*T)*ie,e[9]=(r*H-t*V-l*T)*ie,e[10]=(M*L-E*C+x*N)*ie,e[11]=(S*C-_*L-b*N)*ie,e[12]=(h*I-d*B-f*T)*ie,e[13]=(t*B-r*I+a*T)*ie,e[14]=(E*P-M*D-g*N)*ie,e[15]=(_*D-S*P+v*N)*ie,this}scale(e){const t=this.elements,r=e.x,a=e.y,l=e.z;return t[0]*=r,t[4]*=a,t[8]*=l,t[1]*=r,t[5]*=a,t[9]*=l,t[2]*=r,t[6]*=a,t[10]*=l,t[3]*=r,t[7]*=a,t[11]*=l,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],r=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],a=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,r,a))}makeTranslation(e,t,r){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,r,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),r=Math.sin(e);return this.set(1,0,0,0,0,t,-r,0,0,r,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),r=Math.sin(e);return this.set(t,0,r,0,0,1,0,0,-r,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),r=Math.sin(e);return this.set(t,-r,0,0,r,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const r=Math.cos(t),a=Math.sin(t),l=1-r,d=e.x,h=e.y,f=e.z,m=l*d,_=l*h;return this.set(m*d+r,m*h-a*f,m*f+a*h,0,m*h+a*f,_*h+r,_*f-a*d,0,m*f-a*h,_*f+a*d,l*f*f+r,0,0,0,0,1),this}makeScale(e,t,r){return this.set(e,0,0,0,0,t,0,0,0,0,r,0,0,0,0,1),this}makeShear(e,t,r,a,l,d){return this.set(1,r,l,0,e,1,d,0,t,a,1,0,0,0,0,1),this}compose(e,t,r){const a=this.elements,l=t._x,d=t._y,h=t._z,f=t._w,m=l+l,_=d+d,S=h+h,v=l*m,b=l*_,M=l*S,E=d*_,g=d*S,x=h*S,N=f*m,P=f*_,C=f*S,D=r.x,L=r.y,O=r.z;return a[0]=(1-(E+x))*D,a[1]=(b+C)*D,a[2]=(M-P)*D,a[3]=0,a[4]=(b-C)*L,a[5]=(1-(v+x))*L,a[6]=(g+N)*L,a[7]=0,a[8]=(M+P)*O,a[9]=(g-N)*O,a[10]=(1-(v+E))*O,a[11]=0,a[12]=e.x,a[13]=e.y,a[14]=e.z,a[15]=1,this}decompose(e,t,r){const a=this.elements;e.x=a[12],e.y=a[13],e.z=a[14];const l=this.determinantAffine();if(l===0)return r.set(1,1,1),t.identity(),this;let d=ea.set(a[0],a[1],a[2]).length();const h=ea.set(a[4],a[5],a[6]).length(),f=ea.set(a[8],a[9],a[10]).length();l<0&&(d=-d),ki.copy(this);const m=1/d,_=1/h,S=1/f;return ki.elements[0]*=m,ki.elements[1]*=m,ki.elements[2]*=m,ki.elements[4]*=_,ki.elements[5]*=_,ki.elements[6]*=_,ki.elements[8]*=S,ki.elements[9]*=S,ki.elements[10]*=S,t.setFromRotationMatrix(ki),r.x=d,r.y=h,r.z=f,this}makePerspective(e,t,r,a,l,d,h=Zi,f=!1){const m=this.elements,_=2*l/(t-e),S=2*l/(r-a),v=(t+e)/(t-e),b=(r+a)/(r-a);let M,E;if(f)M=l/(d-l),E=d*l/(d-l);else if(h===Zi)M=-(d+l)/(d-l),E=-2*d*l/(d-l);else if(h===Ec)M=-d/(d-l),E=-d*l/(d-l);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+h);return m[0]=_,m[4]=0,m[8]=v,m[12]=0,m[1]=0,m[5]=S,m[9]=b,m[13]=0,m[2]=0,m[6]=0,m[10]=M,m[14]=E,m[3]=0,m[7]=0,m[11]=-1,m[15]=0,this}makeOrthographic(e,t,r,a,l,d,h=Zi,f=!1){const m=this.elements,_=2/(t-e),S=2/(r-a),v=-(t+e)/(t-e),b=-(r+a)/(r-a);let M,E;if(f)M=1/(d-l),E=d/(d-l);else if(h===Zi)M=-2/(d-l),E=-(d+l)/(d-l);else if(h===Ec)M=-1/(d-l),E=-l/(d-l);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+h);return m[0]=_,m[4]=0,m[8]=0,m[12]=v,m[1]=0,m[5]=S,m[9]=0,m[13]=b,m[2]=0,m[6]=0,m[10]=M,m[14]=E,m[3]=0,m[7]=0,m[11]=0,m[15]=1,this}equals(e){const t=this.elements,r=e.elements;for(let a=0;a<16;a++)if(t[a]!==r[a])return!1;return!0}fromArray(e,t=0){for(let r=0;r<16;r++)this.elements[r]=e[r+t];return this}toArray(e=[],t=0){const r=this.elements;return e[t]=r[0],e[t+1]=r[1],e[t+2]=r[2],e[t+3]=r[3],e[t+4]=r[4],e[t+5]=r[5],e[t+6]=r[6],e[t+7]=r[7],e[t+8]=r[8],e[t+9]=r[9],e[t+10]=r[10],e[t+11]=r[11],e[t+12]=r[12],e[t+13]=r[13],e[t+14]=r[14],e[t+15]=r[15],e}}const ea=new K,ki=new nn,Ay=new K(0,0,0),Cy=new K(1,1,1),zr=new K,Nl=new K,hi=new K,i0=new nn,r0=new Qr;class Ts{constructor(e=0,t=0,r=0,a=Ts.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=r,this._order=a}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,r,a=this._order){return this._x=e,this._y=t,this._z=r,this._order=a,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,r=!0){const a=e.elements,l=a[0],d=a[4],h=a[8],f=a[1],m=a[5],_=a[9],S=a[2],v=a[6],b=a[10];switch(t){case"XYZ":this._y=Math.asin(Rt(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(-_,b),this._z=Math.atan2(-d,l)):(this._x=Math.atan2(v,m),this._z=0);break;case"YXZ":this._x=Math.asin(-Rt(_,-1,1)),Math.abs(_)<.9999999?(this._y=Math.atan2(h,b),this._z=Math.atan2(f,m)):(this._y=Math.atan2(-S,l),this._z=0);break;case"ZXY":this._x=Math.asin(Rt(v,-1,1)),Math.abs(v)<.9999999?(this._y=Math.atan2(-S,b),this._z=Math.atan2(-d,m)):(this._y=0,this._z=Math.atan2(f,l));break;case"ZYX":this._y=Math.asin(-Rt(S,-1,1)),Math.abs(S)<.9999999?(this._x=Math.atan2(v,b),this._z=Math.atan2(f,l)):(this._x=0,this._z=Math.atan2(-d,m));break;case"YZX":this._z=Math.asin(Rt(f,-1,1)),Math.abs(f)<.9999999?(this._x=Math.atan2(-_,m),this._y=Math.atan2(-S,l)):(this._x=0,this._y=Math.atan2(h,b));break;case"XZY":this._z=Math.asin(-Rt(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(v,m),this._y=Math.atan2(h,l)):(this._x=Math.atan2(-_,b),this._y=0);break;default:gt("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,r===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,r){return i0.makeRotationFromQuaternion(e),this.setFromRotationMatrix(i0,t,r)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return r0.setFromEuler(this),this.setFromQuaternion(r0,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Ts.DEFAULT_ORDER="XYZ";class of{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let Ry=0;const s0=new K,ta=new Qr,ur=new nn,Ll=new K,lo=new K,Py=new K,Ny=new Qr,a0=new K(1,0,0),o0=new K(0,1,0),l0=new K(0,0,1),c0={type:"added"},Ly={type:"removed"},na={type:"childadded",child:null},Md={type:"childremoved",child:null};class qn extends Jr{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Ry++}),this.uuid=Mo(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=qn.DEFAULT_UP.clone();const e=new K,t=new Ts,r=new Qr,a=new K(1,1,1);function l(){r.setFromEuler(t,!1)}function d(){t.setFromQuaternion(r,void 0,!1)}t._onChange(l),r._onChange(d),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:r},scale:{configurable:!0,enumerable:!0,value:a},modelViewMatrix:{value:new nn},normalMatrix:{value:new yt}}),this.matrix=new nn,this.matrixWorld=new nn,this.matrixAutoUpdate=qn.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=qn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new of,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return ta.setFromAxisAngle(e,t),this.quaternion.multiply(ta),this}rotateOnWorldAxis(e,t){return ta.setFromAxisAngle(e,t),this.quaternion.premultiply(ta),this}rotateX(e){return this.rotateOnAxis(a0,e)}rotateY(e){return this.rotateOnAxis(o0,e)}rotateZ(e){return this.rotateOnAxis(l0,e)}translateOnAxis(e,t){return s0.copy(e).applyQuaternion(this.quaternion),this.position.add(s0.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(a0,e)}translateY(e){return this.translateOnAxis(o0,e)}translateZ(e){return this.translateOnAxis(l0,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(ur.copy(this.matrixWorld).invert())}lookAt(e,t,r){e.isVector3?Ll.copy(e):Ll.set(e,t,r);const a=this.parent;this.updateWorldMatrix(!0,!1),lo.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?ur.lookAt(lo,Ll,this.up):ur.lookAt(Ll,lo,this.up),this.quaternion.setFromRotationMatrix(ur),a&&(ur.extractRotation(a.matrixWorld),ta.setFromRotationMatrix(ur),this.quaternion.premultiply(ta.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(kt("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(c0),na.child=e,this.dispatchEvent(na),na.child=null):kt("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let r=0;r<arguments.length;r++)this.remove(arguments[r]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Ly),Md.child=e,this.dispatchEvent(Md),Md.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),ur.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),ur.multiply(e.parent.matrixWorld)),e.applyMatrix4(ur),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(c0),na.child=e,this.dispatchEvent(na),na.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let r=0,a=this.children.length;r<a;r++){const d=this.children[r].getObjectByProperty(e,t);if(d!==void 0)return d}}getObjectsByProperty(e,t,r=[]){this[e]===t&&r.push(this);const a=this.children;for(let l=0,d=a.length;l<d;l++)a[l].getObjectsByProperty(e,t,r);return r}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(lo,e,Py),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(lo,Ny,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let r=0,a=t.length;r<a;r++)t[r].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let r=0,a=t.length;r<a;r++)t[r].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const t=e.x,r=e.y,a=e.z,l=this.matrix.elements;l[12]+=t-l[0]*t-l[4]*r-l[8]*a,l[13]+=r-l[1]*t-l[5]*r-l[9]*a,l[14]+=a-l[2]*t-l[6]*r-l[10]*a}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let r=0,a=t.length;r<a;r++)t[r].updateMatrixWorld(e)}updateWorldMatrix(e,t,r=!1){const a=this.parent;if(e===!0&&a!==null&&a.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||r)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,r=!0),t===!0){const l=this.children;for(let d=0,h=l.length;d<h;d++)l[d].updateWorldMatrix(!1,!0,r)}}toJSON(e){const t=e===void 0||typeof e=="string",r={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},r.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const a={};a.uuid=this.uuid,a.type=this.type,this.name!==""&&(a.name=this.name),this.castShadow===!0&&(a.castShadow=!0),this.receiveShadow===!0&&(a.receiveShadow=!0),this.visible===!1&&(a.visible=!1),this.frustumCulled===!1&&(a.frustumCulled=!1),this.renderOrder!==0&&(a.renderOrder=this.renderOrder),this.static!==!1&&(a.static=this.static),Object.keys(this.userData).length>0&&(a.userData=this.userData),a.layers=this.layers.mask,a.matrix=this.matrix.toArray(),a.up=this.up.toArray(),this.pivot!==null&&(a.pivot=this.pivot.toArray()),this.matrixAutoUpdate===!1&&(a.matrixAutoUpdate=!1),this.morphTargetDictionary!==void 0&&(a.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(a.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(a.type="InstancedMesh",a.count=this.count,a.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(a.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(a.type="BatchedMesh",a.perObjectFrustumCulled=this.perObjectFrustumCulled,a.sortObjects=this.sortObjects,a.drawRanges=this._drawRanges,a.reservedRanges=this._reservedRanges,a.geometryInfo=this._geometryInfo.map(h=>({...h,boundingBox:h.boundingBox?h.boundingBox.toJSON():void 0,boundingSphere:h.boundingSphere?h.boundingSphere.toJSON():void 0})),a.instanceInfo=this._instanceInfo.map(h=>({...h})),a.availableInstanceIds=this._availableInstanceIds.slice(),a.availableGeometryIds=this._availableGeometryIds.slice(),a.nextIndexStart=this._nextIndexStart,a.nextVertexStart=this._nextVertexStart,a.geometryCount=this._geometryCount,a.maxInstanceCount=this._maxInstanceCount,a.maxVertexCount=this._maxVertexCount,a.maxIndexCount=this._maxIndexCount,a.geometryInitialized=this._geometryInitialized,a.matricesTexture=this._matricesTexture.toJSON(e),a.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(a.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(a.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(a.boundingBox=this.boundingBox.toJSON()));function l(h,f){return h[f.uuid]===void 0&&(h[f.uuid]=f.toJSON(e)),f.uuid}if(this.isScene)this.background&&(this.background.isColor?a.background=this.background.toJSON():this.background.isTexture&&(a.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(a.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){a.geometry=l(e.geometries,this.geometry);const h=this.geometry.parameters;if(h!==void 0&&h.shapes!==void 0){const f=h.shapes;if(Array.isArray(f))for(let m=0,_=f.length;m<_;m++){const S=f[m];l(e.shapes,S)}else l(e.shapes,f)}}if(this.isSkinnedMesh&&(a.bindMode=this.bindMode,a.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(l(e.skeletons,this.skeleton),a.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const h=[];for(let f=0,m=this.material.length;f<m;f++)h.push(l(e.materials,this.material[f]));a.material=h}else a.material=l(e.materials,this.material);if(this.children.length>0){a.children=[];for(let h=0;h<this.children.length;h++)a.children.push(this.children[h].toJSON(e).object)}if(this.animations.length>0){a.animations=[];for(let h=0;h<this.animations.length;h++){const f=this.animations[h];a.animations.push(l(e.animations,f))}}if(t){const h=d(e.geometries),f=d(e.materials),m=d(e.textures),_=d(e.images),S=d(e.shapes),v=d(e.skeletons),b=d(e.animations),M=d(e.nodes);h.length>0&&(r.geometries=h),f.length>0&&(r.materials=f),m.length>0&&(r.textures=m),_.length>0&&(r.images=_),S.length>0&&(r.shapes=S),v.length>0&&(r.skeletons=v),b.length>0&&(r.animations=b),M.length>0&&(r.nodes=M)}return r.object=a,r;function d(h){const f=[];for(const m in h){const _=h[m];delete _.metadata,f.push(_)}return f}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let r=0;r<e.children.length;r++){const a=e.children[r];this.add(a.clone())}return this}}qn.DEFAULT_UP=new K(0,1,0);qn.DEFAULT_MATRIX_AUTO_UPDATE=!0;qn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class Dl extends qn{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Dy={type:"move"};class wd{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Dl,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Dl,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new K,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new K),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Dl,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new K,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new K,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const r of e.hand.values())this._getHandJoint(t,r)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,r){let a=null,l=null,d=null;const h=this._targetRay,f=this._grip,m=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(m&&e.hand){d=!0;for(const E of e.hand.values()){const g=t.getJointPose(E,r),x=this._getHandJoint(m,E);g!==null&&(x.matrix.fromArray(g.transform.matrix),x.matrix.decompose(x.position,x.rotation,x.scale),x.matrixWorldNeedsUpdate=!0,x.jointRadius=g.radius),x.visible=g!==null}const _=m.joints["index-finger-tip"],S=m.joints["thumb-tip"],v=_.position.distanceTo(S.position),b=.02,M=.005;m.inputState.pinching&&v>b+M?(m.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!m.inputState.pinching&&v<=b-M&&(m.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else f!==null&&e.gripSpace&&(l=t.getPose(e.gripSpace,r),l!==null&&(f.matrix.fromArray(l.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,l.linearVelocity?(f.hasLinearVelocity=!0,f.linearVelocity.copy(l.linearVelocity)):f.hasLinearVelocity=!1,l.angularVelocity?(f.hasAngularVelocity=!0,f.angularVelocity.copy(l.angularVelocity)):f.hasAngularVelocity=!1,f.eventsEnabled&&f.dispatchEvent({type:"gripUpdated",data:e,target:this})));h!==null&&(a=t.getPose(e.targetRaySpace,r),a===null&&l!==null&&(a=l),a!==null&&(h.matrix.fromArray(a.transform.matrix),h.matrix.decompose(h.position,h.rotation,h.scale),h.matrixWorldNeedsUpdate=!0,a.linearVelocity?(h.hasLinearVelocity=!0,h.linearVelocity.copy(a.linearVelocity)):h.hasLinearVelocity=!1,a.angularVelocity?(h.hasAngularVelocity=!0,h.angularVelocity.copy(a.angularVelocity)):h.hasAngularVelocity=!1,this.dispatchEvent(Dy)))}return h!==null&&(h.visible=a!==null),f!==null&&(f.visible=l!==null),m!==null&&(m.visible=d!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const r=new Dl;r.matrixAutoUpdate=!1,r.visible=!1,e.joints[t.jointName]=r,e.add(r)}return e.joints[t.jointName]}}const Cg={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},jr={h:0,s:0,l:0},Il={h:0,s:0,l:0};function Ed(s,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?s+(e-s)*6*t:t<1/2?e:t<2/3?s+(e-s)*6*(2/3-t):s}class vt{constructor(e,t,r){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,r)}set(e,t,r){if(t===void 0&&r===void 0){const a=e;a&&a.isColor?this.copy(a):typeof a=="number"?this.setHex(a):typeof a=="string"&&this.setStyle(a)}else this.setRGB(e,t,r);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Mi){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Lt.colorSpaceToWorking(this,t),this}setRGB(e,t,r,a=Lt.workingColorSpace){return this.r=e,this.g=t,this.b=r,Lt.colorSpaceToWorking(this,a),this}setHSL(e,t,r,a=Lt.workingColorSpace){if(e=_y(e,1),t=Rt(t,0,1),r=Rt(r,0,1),t===0)this.r=this.g=this.b=r;else{const l=r<=.5?r*(1+t):r+t-r*t,d=2*r-l;this.r=Ed(d,l,e+1/3),this.g=Ed(d,l,e),this.b=Ed(d,l,e-1/3)}return Lt.colorSpaceToWorking(this,a),this}setStyle(e,t=Mi){function r(l){l!==void 0&&parseFloat(l)<1&&gt("Color: Alpha component of "+e+" will be ignored.")}let a;if(a=/^(\w+)\(([^\)]*)\)/.exec(e)){let l;const d=a[1],h=a[2];switch(d){case"rgb":case"rgba":if(l=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(h))return r(l[4]),this.setRGB(Math.min(255,parseInt(l[1],10))/255,Math.min(255,parseInt(l[2],10))/255,Math.min(255,parseInt(l[3],10))/255,t);if(l=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(h))return r(l[4]),this.setRGB(Math.min(100,parseInt(l[1],10))/100,Math.min(100,parseInt(l[2],10))/100,Math.min(100,parseInt(l[3],10))/100,t);break;case"hsl":case"hsla":if(l=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(h))return r(l[4]),this.setHSL(parseFloat(l[1])/360,parseFloat(l[2])/100,parseFloat(l[3])/100,t);break;default:gt("Color: Unknown color model "+e)}}else if(a=/^\#([A-Fa-f\d]+)$/.exec(e)){const l=a[1],d=l.length;if(d===3)return this.setRGB(parseInt(l.charAt(0),16)/15,parseInt(l.charAt(1),16)/15,parseInt(l.charAt(2),16)/15,t);if(d===6)return this.setHex(parseInt(l,16),t);gt("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Mi){const r=Cg[e.toLowerCase()];return r!==void 0?this.setHex(r,t):gt("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=gr(e.r),this.g=gr(e.g),this.b=gr(e.b),this}copyLinearToSRGB(e){return this.r=_a(e.r),this.g=_a(e.g),this.b=_a(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Mi){return Lt.workingToColorSpace(zn.copy(this),e),Math.round(Rt(zn.r*255,0,255))*65536+Math.round(Rt(zn.g*255,0,255))*256+Math.round(Rt(zn.b*255,0,255))}getHexString(e=Mi){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=Lt.workingColorSpace){Lt.workingToColorSpace(zn.copy(this),t);const r=zn.r,a=zn.g,l=zn.b,d=Math.max(r,a,l),h=Math.min(r,a,l);let f,m;const _=(h+d)/2;if(h===d)f=0,m=0;else{const S=d-h;switch(m=_<=.5?S/(d+h):S/(2-d-h),d){case r:f=(a-l)/S+(a<l?6:0);break;case a:f=(l-r)/S+2;break;case l:f=(r-a)/S+4;break}f/=6}return e.h=f,e.s=m,e.l=_,e}getRGB(e,t=Lt.workingColorSpace){return Lt.workingToColorSpace(zn.copy(this),t),e.r=zn.r,e.g=zn.g,e.b=zn.b,e}getStyle(e=Mi){Lt.workingToColorSpace(zn.copy(this),e);const t=zn.r,r=zn.g,a=zn.b;return e!==Mi?`color(${e} ${t.toFixed(3)} ${r.toFixed(3)} ${a.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(r*255)},${Math.round(a*255)})`}offsetHSL(e,t,r){return this.getHSL(jr),this.setHSL(jr.h+e,jr.s+t,jr.l+r)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,r){return this.r=e.r+(t.r-e.r)*r,this.g=e.g+(t.g-e.g)*r,this.b=e.b+(t.b-e.b)*r,this}lerpHSL(e,t){this.getHSL(jr),e.getHSL(Il);const r=vd(jr.h,Il.h,t),a=vd(jr.s,Il.s,t),l=vd(jr.l,Il.l,t);return this.setHSL(r,a,l),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,r=this.g,a=this.b,l=e.elements;return this.r=l[0]*t+l[3]*r+l[6]*a,this.g=l[1]*t+l[4]*r+l[7]*a,this.b=l[2]*t+l[5]*r+l[8]*a,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const zn=new vt;vt.NAMES=Cg;class lf{constructor(e,t=25e-5){this.isFogExp2=!0,this.name="",this.color=new vt(e),this.density=t}clone(){return new lf(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class Iy extends qn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Ts,this.environmentIntensity=1,this.environmentRotation=new Ts,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}const Fi=new K,dr=new K,Td=new K,hr=new K,ia=new K,ra=new K,u0=new K,Ad=new K,Cd=new K,Rd=new K,Pd=new dn,Nd=new dn,Ld=new dn;class Bi{constructor(e=new K,t=new K,r=new K){this.a=e,this.b=t,this.c=r}static getNormal(e,t,r,a){a.subVectors(r,t),Fi.subVectors(e,t),a.cross(Fi);const l=a.lengthSq();return l>0?a.multiplyScalar(1/Math.sqrt(l)):a.set(0,0,0)}static getBarycoord(e,t,r,a,l){Fi.subVectors(a,t),dr.subVectors(r,t),Td.subVectors(e,t);const d=Fi.dot(Fi),h=Fi.dot(dr),f=Fi.dot(Td),m=dr.dot(dr),_=dr.dot(Td),S=d*m-h*h;if(S===0)return l.set(0,0,0),null;const v=1/S,b=(m*f-h*_)*v,M=(d*_-h*f)*v;return l.set(1-b-M,M,b)}static containsPoint(e,t,r,a){return this.getBarycoord(e,t,r,a,hr)===null?!1:hr.x>=0&&hr.y>=0&&hr.x+hr.y<=1}static getInterpolation(e,t,r,a,l,d,h,f){return this.getBarycoord(e,t,r,a,hr)===null?(f.x=0,f.y=0,"z"in f&&(f.z=0),"w"in f&&(f.w=0),null):(f.setScalar(0),f.addScaledVector(l,hr.x),f.addScaledVector(d,hr.y),f.addScaledVector(h,hr.z),f)}static getInterpolatedAttribute(e,t,r,a,l,d){return Pd.setScalar(0),Nd.setScalar(0),Ld.setScalar(0),Pd.fromBufferAttribute(e,t),Nd.fromBufferAttribute(e,r),Ld.fromBufferAttribute(e,a),d.setScalar(0),d.addScaledVector(Pd,l.x),d.addScaledVector(Nd,l.y),d.addScaledVector(Ld,l.z),d}static isFrontFacing(e,t,r,a){return Fi.subVectors(r,t),dr.subVectors(e,t),Fi.cross(dr).dot(a)<0}set(e,t,r){return this.a.copy(e),this.b.copy(t),this.c.copy(r),this}setFromPointsAndIndices(e,t,r,a){return this.a.copy(e[t]),this.b.copy(e[r]),this.c.copy(e[a]),this}setFromAttributeAndIndices(e,t,r,a){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,r),this.c.fromBufferAttribute(e,a),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Fi.subVectors(this.c,this.b),dr.subVectors(this.a,this.b),Fi.cross(dr).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return Bi.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return Bi.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,r,a,l){return Bi.getInterpolation(e,this.a,this.b,this.c,t,r,a,l)}containsPoint(e){return Bi.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return Bi.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const r=this.a,a=this.b,l=this.c;let d,h;ia.subVectors(a,r),ra.subVectors(l,r),Ad.subVectors(e,r);const f=ia.dot(Ad),m=ra.dot(Ad);if(f<=0&&m<=0)return t.copy(r);Cd.subVectors(e,a);const _=ia.dot(Cd),S=ra.dot(Cd);if(_>=0&&S<=_)return t.copy(a);const v=f*S-_*m;if(v<=0&&f>=0&&_<=0)return d=f/(f-_),t.copy(r).addScaledVector(ia,d);Rd.subVectors(e,l);const b=ia.dot(Rd),M=ra.dot(Rd);if(M>=0&&b<=M)return t.copy(l);const E=b*m-f*M;if(E<=0&&m>=0&&M<=0)return h=m/(m-M),t.copy(r).addScaledVector(ra,h);const g=_*M-b*S;if(g<=0&&S-_>=0&&b-M>=0)return u0.subVectors(l,a),h=(S-_)/(S-_+(b-M)),t.copy(a).addScaledVector(u0,h);const x=1/(g+E+v);return d=E*x,h=v*x,t.copy(r).addScaledVector(ia,d).addScaledVector(ra,h)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class wo{constructor(e=new K(1/0,1/0,1/0),t=new K(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,r=e.length;t<r;t+=3)this.expandByPoint(Ui.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,r=e.count;t<r;t++)this.expandByPoint(Ui.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,r=e.length;t<r;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const r=Ui.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(r),this.max.copy(e).add(r),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const r=e.geometry;if(r!==void 0){const l=r.getAttribute("position");if(t===!0&&l!==void 0&&e.isInstancedMesh!==!0)for(let d=0,h=l.count;d<h;d++)e.isMesh===!0?e.getVertexPosition(d,Ui):Ui.fromBufferAttribute(l,d),Ui.applyMatrix4(e.matrixWorld),this.expandByPoint(Ui);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),kl.copy(e.boundingBox)):(r.boundingBox===null&&r.computeBoundingBox(),kl.copy(r.boundingBox)),kl.applyMatrix4(e.matrixWorld),this.union(kl)}const a=e.children;for(let l=0,d=a.length;l<d;l++)this.expandByObject(a[l],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Ui),Ui.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,r;return e.normal.x>0?(t=e.normal.x*this.min.x,r=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,r=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,r+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,r+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,r+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,r+=e.normal.z*this.min.z),t<=-e.constant&&r>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(co),Fl.subVectors(this.max,co),sa.subVectors(e.a,co),aa.subVectors(e.b,co),oa.subVectors(e.c,co),Hr.subVectors(aa,sa),Gr.subVectors(oa,aa),ps.subVectors(sa,oa);let t=[0,-Hr.z,Hr.y,0,-Gr.z,Gr.y,0,-ps.z,ps.y,Hr.z,0,-Hr.x,Gr.z,0,-Gr.x,ps.z,0,-ps.x,-Hr.y,Hr.x,0,-Gr.y,Gr.x,0,-ps.y,ps.x,0];return!Dd(t,sa,aa,oa,Fl)||(t=[1,0,0,0,1,0,0,0,1],!Dd(t,sa,aa,oa,Fl))?!1:(Ul.crossVectors(Hr,Gr),t=[Ul.x,Ul.y,Ul.z],Dd(t,sa,aa,oa,Fl))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Ui).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Ui).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(fr[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),fr[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),fr[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),fr[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),fr[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),fr[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),fr[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),fr[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(fr),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const fr=[new K,new K,new K,new K,new K,new K,new K,new K],Ui=new K,kl=new wo,sa=new K,aa=new K,oa=new K,Hr=new K,Gr=new K,ps=new K,co=new K,Fl=new K,Ul=new K,ms=new K;function Dd(s,e,t,r,a){for(let l=0,d=s.length-3;l<=d;l+=3){ms.fromArray(s,l);const h=a.x*Math.abs(ms.x)+a.y*Math.abs(ms.y)+a.z*Math.abs(ms.z),f=e.dot(ms),m=t.dot(ms),_=r.dot(ms);if(Math.max(-Math.max(f,m,_),Math.min(f,m,_))>h)return!1}return!0}const gn=new K,Ol=new ut;let ky=0;class Cn extends Jr{constructor(e,t,r=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:ky++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=r,this.usage=Km,this.updateRanges=[],this.gpuType=zi,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,r){e*=this.itemSize,r*=t.itemSize;for(let a=0,l=this.itemSize;a<l;a++)this.array[e+a]=t.array[r+a];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,r=this.count;t<r;t++)Ol.fromBufferAttribute(this,t),Ol.applyMatrix3(e),this.setXY(t,Ol.x,Ol.y);else if(this.itemSize===3)for(let t=0,r=this.count;t<r;t++)gn.fromBufferAttribute(this,t),gn.applyMatrix3(e),this.setXYZ(t,gn.x,gn.y,gn.z);return this}applyMatrix4(e){for(let t=0,r=this.count;t<r;t++)gn.fromBufferAttribute(this,t),gn.applyMatrix4(e),this.setXYZ(t,gn.x,gn.y,gn.z);return this}applyNormalMatrix(e){for(let t=0,r=this.count;t<r;t++)gn.fromBufferAttribute(this,t),gn.applyNormalMatrix(e),this.setXYZ(t,gn.x,gn.y,gn.z);return this}transformDirection(e){for(let t=0,r=this.count;t<r;t++)gn.fromBufferAttribute(this,t),gn.transformDirection(e),this.setXYZ(t,gn.x,gn.y,gn.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let r=this.array[e*this.itemSize+t];return this.normalized&&(r=oo(r,this.array)),r}setComponent(e,t,r){return this.normalized&&(r=ii(r,this.array)),this.array[e*this.itemSize+t]=r,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=oo(t,this.array)),t}setX(e,t){return this.normalized&&(t=ii(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=oo(t,this.array)),t}setY(e,t){return this.normalized&&(t=ii(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=oo(t,this.array)),t}setZ(e,t){return this.normalized&&(t=ii(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=oo(t,this.array)),t}setW(e,t){return this.normalized&&(t=ii(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,r){return e*=this.itemSize,this.normalized&&(t=ii(t,this.array),r=ii(r,this.array)),this.array[e+0]=t,this.array[e+1]=r,this}setXYZ(e,t,r,a){return e*=this.itemSize,this.normalized&&(t=ii(t,this.array),r=ii(r,this.array),a=ii(a,this.array)),this.array[e+0]=t,this.array[e+1]=r,this.array[e+2]=a,this}setXYZW(e,t,r,a,l){return e*=this.itemSize,this.normalized&&(t=ii(t,this.array),r=ii(r,this.array),a=ii(a,this.array),l=ii(l,this.array)),this.array[e+0]=t,this.array[e+1]=r,this.array[e+2]=a,this.array[e+3]=l,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==Km&&(e.usage=this.usage),e}dispose(){this.dispatchEvent({type:"dispose"})}}class Rg extends Cn{constructor(e,t,r){super(new Uint16Array(e),t,r)}}class Pg extends Cn{constructor(e,t,r){super(new Uint32Array(e),t,r)}}class $n extends Cn{constructor(e,t,r){super(new Float32Array(e),t,r)}}const Fy=new wo,uo=new K,Id=new K;class Eo{constructor(e=new K,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const r=this.center;t!==void 0?r.copy(t):Fy.setFromPoints(e).getCenter(r);let a=0;for(let l=0,d=e.length;l<d;l++)a=Math.max(a,r.distanceToSquared(e[l]));return this.radius=Math.sqrt(a),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const r=this.center.distanceToSquared(e);return t.copy(e),r>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;uo.subVectors(e,this.center);const t=uo.lengthSq();if(t>this.radius*this.radius){const r=Math.sqrt(t),a=(r-this.radius)*.5;this.center.addScaledVector(uo,a/r),this.radius+=a}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Id.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(uo.copy(e.center).add(Id)),this.expandByPoint(uo.copy(e.center).sub(Id))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let Uy=0;const Si=new nn,kd=new qn,la=new K,fi=new wo,ho=new wo,An=new K;class Hn extends Jr{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Uy++}),this.uuid=Mo(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(my(e)?Pg:Rg)(e,1):this.index=e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,r=0){this.groups.push({start:e,count:t,materialIndex:r})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const r=this.attributes.normal;if(r!==void 0){const l=new yt().getNormalMatrix(e);r.applyNormalMatrix(l),r.needsUpdate=!0}const a=this.attributes.tangent;return a!==void 0&&(a.transformDirection(e),a.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return Si.makeRotationFromQuaternion(e),this.applyMatrix4(Si),this}rotateX(e){return Si.makeRotationX(e),this.applyMatrix4(Si),this}rotateY(e){return Si.makeRotationY(e),this.applyMatrix4(Si),this}rotateZ(e){return Si.makeRotationZ(e),this.applyMatrix4(Si),this}translate(e,t,r){return Si.makeTranslation(e,t,r),this.applyMatrix4(Si),this}scale(e,t,r){return Si.makeScale(e,t,r),this.applyMatrix4(Si),this}lookAt(e){return kd.lookAt(e),kd.updateMatrix(),this.applyMatrix4(kd.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(la).negate(),this.translate(la.x,la.y,la.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const r=[];for(let a=0,l=e.length;a<l;a++){const d=e[a];r.push(d.x,d.y,d.z||0)}this.setAttribute("position",new $n(r,3))}else{const r=Math.min(e.length,t.count);for(let a=0;a<r;a++){const l=e[a];t.setXYZ(a,l.x,l.y,l.z||0)}e.length>t.count&&gt("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new wo);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){kt("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new K(-1/0,-1/0,-1/0),new K(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let r=0,a=t.length;r<a;r++){const l=t[r];fi.setFromBufferAttribute(l),this.morphTargetsRelative?(An.addVectors(this.boundingBox.min,fi.min),this.boundingBox.expandByPoint(An),An.addVectors(this.boundingBox.max,fi.max),this.boundingBox.expandByPoint(An)):(this.boundingBox.expandByPoint(fi.min),this.boundingBox.expandByPoint(fi.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&kt('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Eo);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){kt("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new K,1/0);return}if(e){const r=this.boundingSphere.center;if(fi.setFromBufferAttribute(e),t)for(let l=0,d=t.length;l<d;l++){const h=t[l];ho.setFromBufferAttribute(h),this.morphTargetsRelative?(An.addVectors(fi.min,ho.min),fi.expandByPoint(An),An.addVectors(fi.max,ho.max),fi.expandByPoint(An)):(fi.expandByPoint(ho.min),fi.expandByPoint(ho.max))}fi.getCenter(r);let a=0;for(let l=0,d=e.count;l<d;l++)An.fromBufferAttribute(e,l),a=Math.max(a,r.distanceToSquared(An));if(t)for(let l=0,d=t.length;l<d;l++){const h=t[l],f=this.morphTargetsRelative;for(let m=0,_=h.count;m<_;m++)An.fromBufferAttribute(h,m),f&&(la.fromBufferAttribute(e,m),An.add(la)),a=Math.max(a,r.distanceToSquared(An))}this.boundingSphere.radius=Math.sqrt(a),isNaN(this.boundingSphere.radius)&&kt('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){kt("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const r=t.position,a=t.normal,l=t.uv;let d=this.getAttribute("tangent");(d===void 0||d.count!==r.count)&&(d=new Cn(new Float32Array(4*r.count),4),this.setAttribute("tangent",d));const h=[],f=[];for(let T=0;T<r.count;T++)h[T]=new K,f[T]=new K;const m=new K,_=new K,S=new K,v=new ut,b=new ut,M=new ut,E=new K,g=new K;function x(T,I,H){m.fromBufferAttribute(r,T),_.fromBufferAttribute(r,I),S.fromBufferAttribute(r,H),v.fromBufferAttribute(l,T),b.fromBufferAttribute(l,I),M.fromBufferAttribute(l,H),_.sub(m),S.sub(m),b.sub(v),M.sub(v);const B=1/(b.x*M.y-M.x*b.y);isFinite(B)&&(E.copy(_).multiplyScalar(M.y).addScaledVector(S,-b.y).multiplyScalar(B),g.copy(S).multiplyScalar(b.x).addScaledVector(_,-M.x).multiplyScalar(B),h[T].add(E),h[I].add(E),h[H].add(E),f[T].add(g),f[I].add(g),f[H].add(g))}let N=this.groups;N.length===0&&(N=[{start:0,count:e.count}]);for(let T=0,I=N.length;T<I;++T){const H=N[T],B=H.start,V=H.count;for(let ae=B,Q=B+V;ae<Q;ae+=3)x(e.getX(ae+0),e.getX(ae+1),e.getX(ae+2))}const P=new K,C=new K,D=new K,L=new K;function O(T){D.fromBufferAttribute(a,T),L.copy(D);const I=h[T];P.copy(I),P.sub(D.multiplyScalar(D.dot(I))).normalize(),C.crossVectors(L,I);const B=C.dot(f[T])<0?-1:1;d.setXYZW(T,P.x,P.y,P.z,B)}for(let T=0,I=N.length;T<I;++T){const H=N[T],B=H.start,V=H.count;for(let ae=B,Q=B+V;ae<Q;ae+=3)O(e.getX(ae+0)),O(e.getX(ae+1)),O(e.getX(ae+2))}this._transformed=!0}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let r=this.getAttribute("normal");if(r===void 0||r.count!==t.count)r=new Cn(new Float32Array(t.count*3),3),this.setAttribute("normal",r);else for(let v=0,b=r.count;v<b;v++)r.setXYZ(v,0,0,0);const a=new K,l=new K,d=new K,h=new K,f=new K,m=new K,_=new K,S=new K;if(e)for(let v=0,b=e.count;v<b;v+=3){const M=e.getX(v+0),E=e.getX(v+1),g=e.getX(v+2);a.fromBufferAttribute(t,M),l.fromBufferAttribute(t,E),d.fromBufferAttribute(t,g),_.subVectors(d,l),S.subVectors(a,l),_.cross(S),h.fromBufferAttribute(r,M),f.fromBufferAttribute(r,E),m.fromBufferAttribute(r,g),h.add(_),f.add(_),m.add(_),r.setXYZ(M,h.x,h.y,h.z),r.setXYZ(E,f.x,f.y,f.z),r.setXYZ(g,m.x,m.y,m.z)}else for(let v=0,b=t.count;v<b;v+=3)a.fromBufferAttribute(t,v+0),l.fromBufferAttribute(t,v+1),d.fromBufferAttribute(t,v+2),_.subVectors(d,l),S.subVectors(a,l),_.cross(S),r.setXYZ(v+0,_.x,_.y,_.z),r.setXYZ(v+1,_.x,_.y,_.z),r.setXYZ(v+2,_.x,_.y,_.z);this.normalizeNormals(),r.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,r=e.count;t<r;t++)An.fromBufferAttribute(e,t),An.normalize(),e.setXYZ(t,An.x,An.y,An.z)}toNonIndexed(){function e(h,f){const m=h.array,_=h.itemSize,S=h.normalized,v=new m.constructor(f.length*_);let b=0,M=0;for(let E=0,g=f.length;E<g;E++){h.isInterleavedBufferAttribute?b=f[E]*h.data.stride+h.offset:b=f[E]*_;for(let x=0;x<_;x++)v[M++]=m[b++]}return new Cn(v,_,S)}if(this.index===null)return gt("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new Hn,r=this.index.array,a=this.attributes;for(const h in a){const f=a[h],m=e(f,r);t.setAttribute(h,m)}const l=this.morphAttributes;for(const h in l){const f=[],m=l[h];for(let _=0,S=m.length;_<S;_++){const v=m[_],b=e(v,r);f.push(b)}t.morphAttributes[h]=f}t.morphTargetsRelative=this.morphTargetsRelative;const d=this.groups;for(let h=0,f=d.length;h<f;h++){const m=d[h];t.addGroup(m.start,m.count,m.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const f=this.parameters;for(const m in f)f[m]!==void 0&&(e[m]=f[m]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const r=this.attributes;for(const f in r){const m=r[f];e.data.attributes[f]=m.toJSON(e.data)}const a={};let l=!1;for(const f in this.morphAttributes){const m=this.morphAttributes[f],_=[];for(let S=0,v=m.length;S<v;S++){const b=m[S];_.push(b.toJSON(e.data))}_.length>0&&(a[f]=_,l=!0)}l&&(e.data.morphAttributes=a,e.data.morphTargetsRelative=this.morphTargetsRelative);const d=this.groups;d.length>0&&(e.data.groups=JSON.parse(JSON.stringify(d)));const h=this.boundingSphere;return h!==null&&(e.data.boundingSphere=h.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const r=e.index;r!==null&&this.setIndex(r.clone());const a=e.attributes;for(const m in a){const _=a[m];this.setAttribute(m,_.clone(t))}const l=e.morphAttributes;for(const m in l){const _=[],S=l[m];for(let v=0,b=S.length;v<b;v++)_.push(S[v].clone(t));this.morphAttributes[m]=_}this.morphTargetsRelative=e.morphTargetsRelative;const d=e.groups;for(let m=0,_=d.length;m<_;m++){const S=d[m];this.addGroup(S.start,S.count,S.materialIndex)}const h=e.boundingBox;h!==null&&(this.boundingBox=h.clone());const f=e.boundingSphere;return f!==null&&(this.boundingSphere=f.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}let Oy=0;class Ta extends Jr{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Oy++}),this.uuid=Mo(),this.name="",this.type="Material",this.blending=ws,this.side=Kr,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Zd,this.blendDst=Qd,this.blendEquation=vs,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new vt(0,0,0),this.blendAlpha=0,this.depthFunc=ya,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Ym,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Qs,this.stencilZFail=Qs,this.stencilZPass=Qs,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const r=e[t];if(r===void 0){gt(`Material: parameter '${t}' has value of undefined.`);continue}const a=this[t];if(a===void 0){gt(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}a&&a.isColor?a.set(r):a&&a.isVector2&&r&&r.isVector2||a&&a.isEuler&&r&&r.isEuler||a&&a.isVector3&&r&&r.isVector3?a.copy(r):this[t]=r}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const r={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.color&&this.color.isColor&&(r.color=this.color.getHex()),this.roughness!==void 0&&(r.roughness=this.roughness),this.metalness!==void 0&&(r.metalness=this.metalness),this.sheen!==void 0&&(r.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(r.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(r.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(r.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(r.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(r.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(r.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(r.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(r.shininess=this.shininess),this.clearcoat!==void 0&&(r.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(r.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(r.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(r.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(r.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,r.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(r.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(r.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(r.dispersion=this.dispersion),this.iridescence!==void 0&&(r.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(r.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(r.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(r.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(r.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(r.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(r.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(r.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(r.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(r.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(r.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(r.lightMap=this.lightMap.toJSON(e).uuid,r.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(r.aoMap=this.aoMap.toJSON(e).uuid,r.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(r.bumpMap=this.bumpMap.toJSON(e).uuid,r.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(r.normalMap=this.normalMap.toJSON(e).uuid,r.normalMapType=this.normalMapType,r.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(r.displacementMap=this.displacementMap.toJSON(e).uuid,r.displacementScale=this.displacementScale,r.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(r.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(r.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(r.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(r.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(r.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(r.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(r.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(r.combine=this.combine)),this.envMapRotation!==void 0&&(r.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(r.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(r.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(r.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(r.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(r.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(r.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(r.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(r.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(r.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(r.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(r.size=this.size),this.shadowSide!==null&&(r.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(r.sizeAttenuation=this.sizeAttenuation),this.blending!==ws&&(r.blending=this.blending),this.side!==Kr&&(r.side=this.side),this.vertexColors===!0&&(r.vertexColors=!0),this.opacity<1&&(r.opacity=this.opacity),this.transparent===!0&&(r.transparent=!0),this.blendSrc!==Zd&&(r.blendSrc=this.blendSrc),this.blendDst!==Qd&&(r.blendDst=this.blendDst),this.blendEquation!==vs&&(r.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(r.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(r.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(r.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(r.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(r.blendAlpha=this.blendAlpha),this.depthFunc!==ya&&(r.depthFunc=this.depthFunc),this.depthTest===!1&&(r.depthTest=this.depthTest),this.depthWrite===!1&&(r.depthWrite=this.depthWrite),this.colorWrite===!1&&(r.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(r.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Ym&&(r.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(r.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(r.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Qs&&(r.stencilFail=this.stencilFail),this.stencilZFail!==Qs&&(r.stencilZFail=this.stencilZFail),this.stencilZPass!==Qs&&(r.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(r.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(r.rotation=this.rotation),this.polygonOffset===!0&&(r.polygonOffset=!0),this.polygonOffsetFactor!==0&&(r.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(r.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(r.linewidth=this.linewidth),this.dashSize!==void 0&&(r.dashSize=this.dashSize),this.gapSize!==void 0&&(r.gapSize=this.gapSize),this.scale!==void 0&&(r.scale=this.scale),this.dithering===!0&&(r.dithering=!0),this.alphaTest>0&&(r.alphaTest=this.alphaTest),this.alphaHash===!0&&(r.alphaHash=!0),this.alphaToCoverage===!0&&(r.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(r.premultipliedAlpha=!0),this.forceSinglePass===!0&&(r.forceSinglePass=!0),this.allowOverride===!1&&(r.allowOverride=!1),this.wireframe===!0&&(r.wireframe=!0),this.wireframeLinewidth>1&&(r.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(r.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(r.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(r.flatShading=!0),this.visible===!1&&(r.visible=!1),this.toneMapped===!1&&(r.toneMapped=!1),this.fog===!1&&(r.fog=!1),Object.keys(this.userData).length>0&&(r.userData=this.userData);function a(l){const d=[];for(const h in l){const f=l[h];delete f.metadata,d.push(f)}return d}if(t){const l=a(e.textures),d=a(e.images);l.length>0&&(r.textures=l),d.length>0&&(r.images=d)}return r}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new vt().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=e.iridescenceThicknessRange),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors=="number"?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let r=e.normalScale;Array.isArray(r)===!1&&(r=[r,r]),this.normalScale=new ut().fromArray(r)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new ut().fromArray(e.clearcoatNormalScale)),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let r=null;if(t!==null){const a=t.length;r=new Array(a);for(let l=0;l!==a;++l)r[l]=t[l].clone()}return this.clippingPlanes=r,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}const pr=new K,Fd=new K,Bl=new K,Vr=new K,Ud=new K,zl=new K,Od=new K;class To{constructor(e=new K,t=new K(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,pr)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const r=t.dot(this.direction);return r<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,r)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=pr.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(pr.copy(this.origin).addScaledVector(this.direction,t),pr.distanceToSquared(e))}distanceSqToSegment(e,t,r,a){Fd.copy(e).add(t).multiplyScalar(.5),Bl.copy(t).sub(e).normalize(),Vr.copy(this.origin).sub(Fd);const l=e.distanceTo(t)*.5,d=-this.direction.dot(Bl),h=Vr.dot(this.direction),f=-Vr.dot(Bl),m=Vr.lengthSq(),_=Math.abs(1-d*d);let S,v,b,M;if(_>0)if(S=d*f-h,v=d*h-f,M=l*_,S>=0)if(v>=-M)if(v<=M){const E=1/_;S*=E,v*=E,b=S*(S+d*v+2*h)+v*(d*S+v+2*f)+m}else v=l,S=Math.max(0,-(d*v+h)),b=-S*S+v*(v+2*f)+m;else v=-l,S=Math.max(0,-(d*v+h)),b=-S*S+v*(v+2*f)+m;else v<=-M?(S=Math.max(0,-(-d*l+h)),v=S>0?-l:Math.min(Math.max(-l,-f),l),b=-S*S+v*(v+2*f)+m):v<=M?(S=0,v=Math.min(Math.max(-l,-f),l),b=v*(v+2*f)+m):(S=Math.max(0,-(d*l+h)),v=S>0?l:Math.min(Math.max(-l,-f),l),b=-S*S+v*(v+2*f)+m);else v=d>0?-l:l,S=Math.max(0,-(d*v+h)),b=-S*S+v*(v+2*f)+m;return r&&r.copy(this.origin).addScaledVector(this.direction,S),a&&a.copy(Fd).addScaledVector(Bl,v),b}intersectSphere(e,t){pr.subVectors(e.center,this.origin);const r=pr.dot(this.direction),a=pr.dot(pr)-r*r,l=e.radius*e.radius;if(a>l)return null;const d=Math.sqrt(l-a),h=r-d,f=r+d;return f<0?null:h<0?this.at(f,t):this.at(h,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const r=-(this.origin.dot(e.normal)+e.constant)/t;return r>=0?r:null}intersectPlane(e,t){const r=this.distanceToPlane(e);return r===null?null:this.at(r,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let r,a,l,d,h,f;const m=1/this.direction.x,_=1/this.direction.y,S=1/this.direction.z,v=this.origin;return m>=0?(r=(e.min.x-v.x)*m,a=(e.max.x-v.x)*m):(r=(e.max.x-v.x)*m,a=(e.min.x-v.x)*m),_>=0?(l=(e.min.y-v.y)*_,d=(e.max.y-v.y)*_):(l=(e.max.y-v.y)*_,d=(e.min.y-v.y)*_),r>d||l>a||((l>r||isNaN(r))&&(r=l),(d<a||isNaN(a))&&(a=d),S>=0?(h=(e.min.z-v.z)*S,f=(e.max.z-v.z)*S):(h=(e.max.z-v.z)*S,f=(e.min.z-v.z)*S),r>f||h>a)||((h>r||r!==r)&&(r=h),(f<a||a!==a)&&(a=f),a<0)?null:this.at(r>=0?r:a,t)}intersectsBox(e){return this.intersectBox(e,pr)!==null}intersectTriangle(e,t,r,a,l){Ud.subVectors(t,e),zl.subVectors(r,e),Od.crossVectors(Ud,zl);let d=this.direction.dot(Od),h;if(d>0){if(a)return null;h=1}else if(d<0)h=-1,d=-d;else return null;Vr.subVectors(this.origin,e);const f=h*this.direction.dot(zl.crossVectors(Vr,zl));if(f<0)return null;const m=h*this.direction.dot(Ud.cross(Vr));if(m<0||f+m>d)return null;const _=-h*Vr.dot(Od);return _<0?null:this.at(_/d,l)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class cf extends Ta{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new vt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Ts,this.combine=ug,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const d0=new nn,gs=new To,jl=new Eo,h0=new K,Hl=new K,Gl=new K,Vl=new K,Bd=new K,Wl=new K,f0=new K,Xl=new K;class Ti extends qn{constructor(e=new Hn,t=new cf){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,r=Object.keys(t);if(r.length>0){const a=t[r[0]];if(a!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let l=0,d=a.length;l<d;l++){const h=a[l].name||String(l);this.morphTargetInfluences.push(0),this.morphTargetDictionary[h]=l}}}}getVertexPosition(e,t){const r=this.geometry,a=r.attributes.position,l=r.morphAttributes.position,d=r.morphTargetsRelative;t.fromBufferAttribute(a,e);const h=this.morphTargetInfluences;if(l&&h){Wl.set(0,0,0);for(let f=0,m=l.length;f<m;f++){const _=h[f],S=l[f];_!==0&&(Bd.fromBufferAttribute(S,e),d?Wl.addScaledVector(Bd,_):Wl.addScaledVector(Bd.sub(t),_))}t.add(Wl)}return t}raycast(e,t){const r=this.geometry,a=this.material,l=this.matrixWorld;a!==void 0&&(r.boundingSphere===null&&r.computeBoundingSphere(),jl.copy(r.boundingSphere),jl.applyMatrix4(l),gs.copy(e.ray).recast(e.near),!(jl.containsPoint(gs.origin)===!1&&(gs.intersectSphere(jl,h0)===null||gs.origin.distanceToSquared(h0)>(e.far-e.near)**2))&&(d0.copy(l).invert(),gs.copy(e.ray).applyMatrix4(d0),!(r.boundingBox!==null&&gs.intersectsBox(r.boundingBox)===!1)&&this._computeIntersections(e,t,gs)))}_computeIntersections(e,t,r){let a;const l=this.geometry,d=this.material,h=l.index,f=l.attributes.position,m=l.attributes.uv,_=l.attributes.uv1,S=l.attributes.normal,v=l.groups,b=l.drawRange;if(h!==null)if(Array.isArray(d))for(let M=0,E=v.length;M<E;M++){const g=v[M],x=d[g.materialIndex],N=Math.max(g.start,b.start),P=Math.min(h.count,Math.min(g.start+g.count,b.start+b.count));for(let C=N,D=P;C<D;C+=3){const L=h.getX(C),O=h.getX(C+1),T=h.getX(C+2);a=ql(this,x,e,r,m,_,S,L,O,T),a&&(a.faceIndex=Math.floor(C/3),a.face.materialIndex=g.materialIndex,t.push(a))}}else{const M=Math.max(0,b.start),E=Math.min(h.count,b.start+b.count);for(let g=M,x=E;g<x;g+=3){const N=h.getX(g),P=h.getX(g+1),C=h.getX(g+2);a=ql(this,d,e,r,m,_,S,N,P,C),a&&(a.faceIndex=Math.floor(g/3),t.push(a))}}else if(f!==void 0)if(Array.isArray(d))for(let M=0,E=v.length;M<E;M++){const g=v[M],x=d[g.materialIndex],N=Math.max(g.start,b.start),P=Math.min(f.count,Math.min(g.start+g.count,b.start+b.count));for(let C=N,D=P;C<D;C+=3){const L=C,O=C+1,T=C+2;a=ql(this,x,e,r,m,_,S,L,O,T),a&&(a.faceIndex=Math.floor(C/3),a.face.materialIndex=g.materialIndex,t.push(a))}}else{const M=Math.max(0,b.start),E=Math.min(f.count,b.start+b.count);for(let g=M,x=E;g<x;g+=3){const N=g,P=g+1,C=g+2;a=ql(this,d,e,r,m,_,S,N,P,C),a&&(a.faceIndex=Math.floor(g/3),t.push(a))}}}}function By(s,e,t,r,a,l,d,h){let f;if(e.side===si?f=r.intersectTriangle(d,l,a,!0,h):f=r.intersectTriangle(a,l,d,e.side===Kr,h),f===null)return null;Xl.copy(h),Xl.applyMatrix4(s.matrixWorld);const m=t.ray.origin.distanceTo(Xl);return m<t.near||m>t.far?null:{distance:m,point:Xl.clone(),object:s}}function ql(s,e,t,r,a,l,d,h,f,m){s.getVertexPosition(h,Hl),s.getVertexPosition(f,Gl),s.getVertexPosition(m,Vl);const _=By(s,e,t,r,Hl,Gl,Vl,f0);if(_){const S=new K;Bi.getBarycoord(f0,Hl,Gl,Vl,S),a&&(_.uv=Bi.getInterpolatedAttribute(a,h,f,m,S,new ut)),l&&(_.uv1=Bi.getInterpolatedAttribute(l,h,f,m,S,new ut)),d&&(_.normal=Bi.getInterpolatedAttribute(d,h,f,m,S,new K),_.normal.dot(r.direction)>0&&_.normal.multiplyScalar(-1));const v={a:h,b:f,c:m,normal:new K,materialIndex:0};Bi.getNormal(Hl,Gl,Vl,v.normal),_.face=v,_.barycoord=S}return _}class Ng extends Xn{constructor(e=null,t=1,r=1,a,l,d,h,f,m=Ln,_=Ln,S,v){super(null,d,h,f,m,_,a,l,S,v),this.isDataTexture=!0,this.image={data:e,width:t,height:r},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const zd=new K,zy=new K,jy=new yt;class Xr{constructor(e=new K(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,r,a){return this.normal.set(e,t,r),this.constant=a,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,r){const a=zd.subVectors(r,t).cross(zy.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(a,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,r=!0){const a=e.delta(zd),l=this.normal.dot(a);if(l===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const d=-(e.start.dot(this.normal)+this.constant)/l;return r===!0&&(d<0||d>1)?null:t.copy(e.start).addScaledVector(a,d)}intersectsLine(e){const t=this.distanceToPoint(e.start),r=this.distanceToPoint(e.end);return t<0&&r>0||r<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const r=t||jy.getNormalMatrix(e),a=this.coplanarPoint(zd).applyMatrix4(e),l=this.normal.applyMatrix3(r).normalize();return this.constant=-a.dot(l),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const xs=new Eo,Hy=new ut(.5,.5),$l=new K;class Lg{constructor(e=new Xr,t=new Xr,r=new Xr,a=new Xr,l=new Xr,d=new Xr){this.planes=[e,t,r,a,l,d]}set(e,t,r,a,l,d){const h=this.planes;return h[0].copy(e),h[1].copy(t),h[2].copy(r),h[3].copy(a),h[4].copy(l),h[5].copy(d),this}copy(e){const t=this.planes;for(let r=0;r<6;r++)t[r].copy(e.planes[r]);return this}setFromProjectionMatrix(e,t=Zi,r=!1){const a=this.planes,l=e.elements,d=l[0],h=l[1],f=l[2],m=l[3],_=l[4],S=l[5],v=l[6],b=l[7],M=l[8],E=l[9],g=l[10],x=l[11],N=l[12],P=l[13],C=l[14],D=l[15];if(a[0].setComponents(m-d,b-_,x-M,D-N).normalize(),a[1].setComponents(m+d,b+_,x+M,D+N).normalize(),a[2].setComponents(m+h,b+S,x+E,D+P).normalize(),a[3].setComponents(m-h,b-S,x-E,D-P).normalize(),r)a[4].setComponents(f,v,g,C).normalize(),a[5].setComponents(m-f,b-v,x-g,D-C).normalize();else if(a[4].setComponents(m-f,b-v,x-g,D-C).normalize(),t===Zi)a[5].setComponents(m+f,b+v,x+g,D+C).normalize();else if(t===Ec)a[5].setComponents(f,v,g,C).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),xs.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),xs.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(xs)}intersectsSprite(e){xs.center.set(0,0,0);const t=Hy.distanceTo(e.center);return xs.radius=.7071067811865476+t,xs.applyMatrix4(e.matrixWorld),this.intersectsSphere(xs)}intersectsSphere(e){const t=this.planes,r=e.center,a=-e.radius;for(let l=0;l<6;l++)if(t[l].distanceToPoint(r)<a)return!1;return!0}intersectsBox(e){const t=this.planes;for(let r=0;r<6;r++){const a=t[r];if($l.x=a.normal.x>0?e.max.x:e.min.x,$l.y=a.normal.y>0?e.max.y:e.min.y,$l.z=a.normal.z>0?e.max.z:e.min.z,a.distanceToPoint($l)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let r=0;r<6;r++)if(t[r].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class uf extends Ta{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new vt(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const Ac=new K,Cc=new K,p0=new nn,fo=new To,Yl=new Eo,jd=new K,m0=new K;class Dg extends qn{constructor(e=new Hn,t=new uf){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,r=[0];for(let a=1,l=t.count;a<l;a++)Ac.fromBufferAttribute(t,a-1),Cc.fromBufferAttribute(t,a),r[a]=r[a-1],r[a]+=Ac.distanceTo(Cc);e.setAttribute("lineDistance",new $n(r,1))}else gt("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){const r=this.geometry,a=this.matrixWorld,l=e.params.Line.threshold,d=r.drawRange;if(r.boundingSphere===null&&r.computeBoundingSphere(),Yl.copy(r.boundingSphere),Yl.applyMatrix4(a),Yl.radius+=l,e.ray.intersectsSphere(Yl)===!1)return;p0.copy(a).invert(),fo.copy(e.ray).applyMatrix4(p0);const h=l/((this.scale.x+this.scale.y+this.scale.z)/3),f=h*h,m=this.isLineSegments?2:1,_=r.index,v=r.attributes.position;if(_!==null){const b=Math.max(0,d.start),M=Math.min(_.count,d.start+d.count);for(let E=b,g=M-1;E<g;E+=m){const x=_.getX(E),N=_.getX(E+1),P=Kl(this,e,fo,f,x,N,E);P&&t.push(P)}if(this.isLineLoop){const E=_.getX(M-1),g=_.getX(b),x=Kl(this,e,fo,f,E,g,M-1);x&&t.push(x)}}else{const b=Math.max(0,d.start),M=Math.min(v.count,d.start+d.count);for(let E=b,g=M-1;E<g;E+=m){const x=Kl(this,e,fo,f,E,E+1,E);x&&t.push(x)}if(this.isLineLoop){const E=Kl(this,e,fo,f,M-1,b,M-1);E&&t.push(E)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,r=Object.keys(t);if(r.length>0){const a=t[r[0]];if(a!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let l=0,d=a.length;l<d;l++){const h=a[l].name||String(l);this.morphTargetInfluences.push(0),this.morphTargetDictionary[h]=l}}}}}function Kl(s,e,t,r,a,l,d){const h=s.geometry.attributes.position;if(Ac.fromBufferAttribute(h,a),Cc.fromBufferAttribute(h,l),t.distanceSqToSegment(Ac,Cc,jd,m0)>r)return;jd.applyMatrix4(s.matrixWorld);const m=e.ray.origin.distanceTo(jd);if(!(m<e.near||m>e.far))return{distance:m,point:m0.clone().applyMatrix4(s.matrixWorld),index:d,face:null,faceIndex:null,barycoord:null,object:s}}const g0=new K,x0=new K;class Gy extends Dg{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,r=[];for(let a=0,l=t.count;a<l;a+=2)g0.fromBufferAttribute(t,a),x0.fromBufferAttribute(t,a+1),r[a]=a===0?0:r[a-1],r[a+1]=r[a]+g0.distanceTo(x0);e.setAttribute("lineDistance",new $n(r,1))}else gt("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class Vy extends Ta{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new vt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const v0=new nn,Bh=new To,Zl=new Eo,Ql=new K;class Wy extends qn{constructor(e=new Hn,t=new Vy){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){const r=this.geometry,a=this.matrixWorld,l=e.params.Points.threshold,d=r.drawRange;if(r.boundingSphere===null&&r.computeBoundingSphere(),Zl.copy(r.boundingSphere),Zl.applyMatrix4(a),Zl.radius+=l,e.ray.intersectsSphere(Zl)===!1)return;v0.copy(a).invert(),Bh.copy(e.ray).applyMatrix4(v0);const h=l/((this.scale.x+this.scale.y+this.scale.z)/3),f=h*h,m=r.index,S=r.attributes.position;if(m!==null){const v=Math.max(0,d.start),b=Math.min(m.count,d.start+d.count);for(let M=v,E=b;M<E;M++){const g=m.getX(M);Ql.fromBufferAttribute(S,g),_0(Ql,g,f,a,e,t,this)}}else{const v=Math.max(0,d.start),b=Math.min(S.count,d.start+d.count);for(let M=v,E=b;M<E;M++)Ql.fromBufferAttribute(S,M),_0(Ql,M,f,a,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,r=Object.keys(t);if(r.length>0){const a=t[r[0]];if(a!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let l=0,d=a.length;l<d;l++){const h=a[l].name||String(l);this.morphTargetInfluences.push(0),this.morphTargetDictionary[h]=l}}}}}function _0(s,e,t,r,a,l,d){const h=Bh.distanceSqToPoint(s);if(h<t){const f=new K;Bh.closestPointToPoint(s,f),f.applyMatrix4(r);const m=a.ray.origin.distanceTo(f);if(m<a.near||m>a.far)return;l.push({distance:m,distanceToRay:Math.sqrt(h),point:f,index:e,face:null,faceIndex:null,barycoord:null,object:d})}}class Ig extends Xn{constructor(e=[],t=Es,r,a,l,d,h,f,m,_){super(e,t,r,a,l,d,h,f,m,_),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Sa extends Xn{constructor(e,t,r=er,a,l,d,h=Ln,f=Ln,m,_=vr,S=1){if(_!==vr&&_!==Ms)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const v={width:e,height:t,depth:S};super(v,a,l,d,h,f,_,r,m),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new af(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}class Xy extends Sa{constructor(e,t=er,r=Es,a,l,d=Ln,h=Ln,f,m=vr){const _={width:e,height:e,depth:1},S=[_,_,_,_,_,_];super(e,e,t,r,a,l,d,h,f,m),this.image=S,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class kg extends Xn{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class Ao extends Hn{constructor(e=1,t=1,r=1,a=1,l=1,d=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:r,widthSegments:a,heightSegments:l,depthSegments:d};const h=this;a=Math.floor(a),l=Math.floor(l),d=Math.floor(d);const f=[],m=[],_=[],S=[];let v=0,b=0;M("z","y","x",-1,-1,r,t,e,d,l,0),M("z","y","x",1,-1,r,t,-e,d,l,1),M("x","z","y",1,1,e,r,t,a,d,2),M("x","z","y",1,-1,e,r,-t,a,d,3),M("x","y","z",1,-1,e,t,r,a,l,4),M("x","y","z",-1,-1,e,t,-r,a,l,5),this.setIndex(f),this.setAttribute("position",new $n(m,3)),this.setAttribute("normal",new $n(_,3)),this.setAttribute("uv",new $n(S,2));function M(E,g,x,N,P,C,D,L,O,T,I){const H=C/O,B=D/T,V=C/2,ae=D/2,Q=L/2,ie=O+1,de=T+1;let re=0,X=0;const J=new K;for(let le=0;le<de;le++){const U=le*B-ae;for(let q=0;q<ie;q++){const Re=q*H-V;J[E]=Re*N,J[g]=U*P,J[x]=Q,m.push(J.x,J.y,J.z),J[E]=0,J[g]=0,J[x]=L>0?1:-1,_.push(J.x,J.y,J.z),S.push(q/O),S.push(1-le/T),re+=1}}for(let le=0;le<T;le++)for(let U=0;U<O;U++){const q=v+U+ie*le,Re=v+U+ie*(le+1),qe=v+(U+1)+ie*(le+1),be=v+(U+1)+ie*le;f.push(q,Re,be),f.push(Re,qe,be),X+=6}h.addGroup(b,X,I),b+=X,v+=re}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ao(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class Co extends Hn{constructor(e=1,t=1,r=1,a=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:r,heightSegments:a};const l=e/2,d=t/2,h=Math.floor(r),f=Math.floor(a),m=h+1,_=f+1,S=e/h,v=t/f,b=[],M=[],E=[],g=[];for(let x=0;x<_;x++){const N=x*v-d;for(let P=0;P<m;P++){const C=P*S-l;M.push(C,-N,0),E.push(0,0,1),g.push(P/h),g.push(1-x/f)}}for(let x=0;x<f;x++)for(let N=0;N<h;N++){const P=N+m*x,C=N+m*(x+1),D=N+1+m*(x+1),L=N+1+m*x;b.push(P,C,L),b.push(C,D,L)}this.setIndex(b),this.setAttribute("position",new $n(M,3)),this.setAttribute("normal",new $n(E,3)),this.setAttribute("uv",new $n(g,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Co(e.width,e.height,e.widthSegments,e.heightSegments)}}function Ma(s){const e={};for(const t in s){e[t]={};for(const r in s[t]){const a=s[t][r];if(y0(a))a.isRenderTargetTexture?(gt("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][r]=null):e[t][r]=a.clone();else if(Array.isArray(a))if(y0(a[0])){const l=[];for(let d=0,h=a.length;d<h;d++)l[d]=a[d].clone();e[t][r]=l}else e[t][r]=a.slice();else e[t][r]=a}}return e}function Wn(s){const e={};for(let t=0;t<s.length;t++){const r=Ma(s[t]);for(const a in r)e[a]=r[a]}return e}function y0(s){return s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)}function qy(s){const e=[];for(let t=0;t<s.length;t++)e.push(s[t].clone());return e}function Fg(s){const e=s.getRenderTarget();return e===null?s.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:Lt.workingColorSpace}const Rc={clone:Ma,merge:Wn};var $y=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Yy=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class bn extends Ta{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=$y,this.fragmentShader=Yy,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Ma(e.uniforms),this.uniformsGroups=qy(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const a in this.uniforms){const d=this.uniforms[a].value;d&&d.isTexture?t.uniforms[a]={type:"t",value:d.toJSON(e).uuid}:d&&d.isColor?t.uniforms[a]={type:"c",value:d.getHex()}:d&&d.isVector2?t.uniforms[a]={type:"v2",value:d.toArray()}:d&&d.isVector3?t.uniforms[a]={type:"v3",value:d.toArray()}:d&&d.isVector4?t.uniforms[a]={type:"v4",value:d.toArray()}:d&&d.isMatrix3?t.uniforms[a]={type:"m3",value:d.toArray()}:d&&d.isMatrix4?t.uniforms[a]={type:"m4",value:d.toArray()}:t.uniforms[a]={value:d}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const r={};for(const a in this.extensions)this.extensions[a]===!0&&(r[a]=!0);return Object.keys(r).length>0&&(t.extensions=r),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(const r in e.uniforms){const a=e.uniforms[r];switch(this.uniforms[r]={},a.type){case"t":this.uniforms[r].value=t[a.value]||null;break;case"c":this.uniforms[r].value=new vt().setHex(a.value);break;case"v2":this.uniforms[r].value=new ut().fromArray(a.value);break;case"v3":this.uniforms[r].value=new K().fromArray(a.value);break;case"v4":this.uniforms[r].value=new dn().fromArray(a.value);break;case"m3":this.uniforms[r].value=new yt().fromArray(a.value);break;case"m4":this.uniforms[r].value=new nn().fromArray(a.value);break;default:this.uniforms[r].value=a.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(const r in e.extensions)this.extensions[r]=e.extensions[r];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}}class Ky extends bn{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class Zy extends Ta{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=oy,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class Qy extends Ta{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const Jl=new K,ec=new Qr,$i=new K;class Ug extends qn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new nn,this.projectionMatrix=new nn,this.projectionMatrixInverse=new nn,this.coordinateSystem=Zi,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Jl,ec,$i),$i.x===1&&$i.y===1&&$i.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Jl,ec,$i.set(1,1,1)).invert()}updateWorldMatrix(e,t,r=!1){super.updateWorldMatrix(e,t,r),this.matrixWorld.decompose(Jl,ec,$i),$i.x===1&&$i.y===1&&$i.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Jl,ec,$i.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const Wr=new K,b0=new ut,S0=new ut;class wi extends Ug{constructor(e=50,t=1,r=.1,a=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=r,this.far=a,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=Oh*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(fc*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Oh*2*Math.atan(Math.tan(fc*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,r){Wr.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Wr.x,Wr.y).multiplyScalar(-e/Wr.z),Wr.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),r.set(Wr.x,Wr.y).multiplyScalar(-e/Wr.z)}getViewSize(e,t){return this.getViewBounds(e,b0,S0),t.subVectors(S0,b0)}setViewOffset(e,t,r,a,l,d){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=r,this.view.offsetY=a,this.view.width=l,this.view.height=d,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(fc*.5*this.fov)/this.zoom,r=2*t,a=this.aspect*r,l=-.5*a;const d=this.view;if(this.view!==null&&this.view.enabled){const f=d.fullWidth,m=d.fullHeight;l+=d.offsetX*a/f,t-=d.offsetY*r/m,a*=d.width/f,r*=d.height/m}const h=this.filmOffset;h!==0&&(l+=e*h/this.getFilmWidth()),this.projectionMatrix.makePerspective(l,l+a,t,t-r,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}class df extends Ug{constructor(e=-1,t=1,r=1,a=-1,l=.1,d=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=r,this.bottom=a,this.near=l,this.far=d,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,r,a,l,d){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=r,this.view.offsetY=a,this.view.width=l,this.view.height=d,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),r=(this.right+this.left)/2,a=(this.top+this.bottom)/2;let l=r-e,d=r+e,h=a+t,f=a-t;if(this.view!==null&&this.view.enabled){const m=(this.right-this.left)/this.view.fullWidth/this.zoom,_=(this.top-this.bottom)/this.view.fullHeight/this.zoom;l+=m*this.view.offsetX,d=l+m*this.view.width,h-=_*this.view.offsetY,f=h-_*this.view.height}this.projectionMatrix.makeOrthographic(l,d,h,f,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}const ca=-90,ua=1;class Jy extends qn{constructor(e,t,r){super(),this.type="CubeCamera",this.renderTarget=r,this.coordinateSystem=null,this.activeMipmapLevel=0;const a=new wi(ca,ua,e,t);a.layers=this.layers,this.add(a);const l=new wi(ca,ua,e,t);l.layers=this.layers,this.add(l);const d=new wi(ca,ua,e,t);d.layers=this.layers,this.add(d);const h=new wi(ca,ua,e,t);h.layers=this.layers,this.add(h);const f=new wi(ca,ua,e,t);f.layers=this.layers,this.add(f);const m=new wi(ca,ua,e,t);m.layers=this.layers,this.add(m)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[r,a,l,d,h,f]=t;for(const m of t)this.remove(m);if(e===Zi)r.up.set(0,1,0),r.lookAt(1,0,0),a.up.set(0,1,0),a.lookAt(-1,0,0),l.up.set(0,0,-1),l.lookAt(0,1,0),d.up.set(0,0,1),d.lookAt(0,-1,0),h.up.set(0,1,0),h.lookAt(0,0,1),f.up.set(0,1,0),f.lookAt(0,0,-1);else if(e===Ec)r.up.set(0,-1,0),r.lookAt(-1,0,0),a.up.set(0,-1,0),a.lookAt(1,0,0),l.up.set(0,0,1),l.lookAt(0,1,0),d.up.set(0,0,-1),d.lookAt(0,-1,0),h.up.set(0,-1,0),h.lookAt(0,0,1),f.up.set(0,-1,0),f.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const m of t)this.add(m),m.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:r,activeMipmapLevel:a}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[l,d,h,f,m,_]=this.children,S=e.getRenderTarget(),v=e.getActiveCubeFace(),b=e.getActiveMipmapLevel(),M=e.xr.enabled;e.xr.enabled=!1;const E=r.texture.generateMipmaps;r.texture.generateMipmaps=!1;let g=!1;e.isWebGLRenderer===!0?g=e.state.buffers.depth.getReversed():g=e.reversedDepthBuffer,e.setRenderTarget(r,0,a),g&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),e.setRenderTarget(r,1,a),g&&e.autoClear===!1&&e.clearDepth(),e.render(t,d),e.setRenderTarget(r,2,a),g&&e.autoClear===!1&&e.clearDepth(),e.render(t,h),e.setRenderTarget(r,3,a),g&&e.autoClear===!1&&e.clearDepth(),e.render(t,f),e.setRenderTarget(r,4,a),g&&e.autoClear===!1&&e.clearDepth(),e.render(t,m),r.texture.generateMipmaps=E,e.setRenderTarget(r,5,a),g&&e.autoClear===!1&&e.clearDepth(),e.render(t,_),e.setRenderTarget(S,v,b),e.xr.enabled=M,r.texture.needsPMREMUpdate=!0}}class e1 extends wi{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}class t1{constructor(){this._previousTime=0,this._currentTime=0,this._startTime=performance.now(),this._delta=0,this._elapsed=0,this._timescale=1,this._document=null,this._pageVisibilityHandler=null}connect(e){this._document=e,e.hidden!==void 0&&(this._pageVisibilityHandler=n1.bind(this),e.addEventListener("visibilitychange",this._pageVisibilityHandler,!1))}disconnect(){this._pageVisibilityHandler!==null&&(this._document.removeEventListener("visibilitychange",this._pageVisibilityHandler),this._pageVisibilityHandler=null),this._document=null}getDelta(){return this._delta/1e3}getElapsed(){return this._elapsed/1e3}getTimescale(){return this._timescale}setTimescale(e){return this._timescale=e,this}reset(){return this._currentTime=performance.now()-this._startTime,this}dispose(){this.disconnect()}update(e){return this._pageVisibilityHandler!==null&&this._document.hidden===!0?this._delta=0:(this._previousTime=this._currentTime,this._currentTime=(e!==void 0?e:performance.now())-this._startTime,this._delta=(this._currentTime-this._previousTime)*this._timescale,this._elapsed+=this._delta),this}}function n1(){this._document.hidden===!1&&this.reset()}const M0=new nn;class i1{constructor(e,t,r=0,a=1/0){this.ray=new To(e,t),this.near=r,this.far=a,this.camera=null,this.layers=new of,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,t.projectionMatrix.elements[14]).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):kt("Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return M0.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(M0),this}intersectObject(e,t=!0,r=[]){return zh(e,this,r,t),r.sort(w0),r}intersectObjects(e,t=!0,r=[]){for(let a=0,l=e.length;a<l;a++)zh(e[a],this,r,t);return r.sort(w0),r}}function w0(s,e){return s.distance-e.distance}function zh(s,e,t,r){let a=!0;if(s.layers.test(e.layers)&&s.raycast(e,t)===!1&&(a=!1),a===!0&&r===!0){const l=s.children;for(let d=0,h=l.length;d<h;d++)zh(l[d],e,t,!0)}}class E0{constructor(e=1,t=0,r=0){this.radius=e,this.phi=t,this.theta=r}set(e,t,r){return this.radius=e,this.phi=t,this.theta=r,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=Rt(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,r){return this.radius=Math.sqrt(e*e+t*t+r*r),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,r),this.phi=Math.acos(Rt(t/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}}class Og{static{Og.prototype.isMatrix2=!0}constructor(e,t,r,a){this.elements=[1,0,0,1],e!==void 0&&this.set(e,t,r,a)}identity(){return this.set(1,0,0,1),this}fromArray(e,t=0){for(let r=0;r<4;r++)this.elements[r]=e[r+t];return this}set(e,t,r,a){const l=this.elements;return l[0]=e,l[2]=t,l[1]=r,l[3]=a,this}}class r1 extends Gy{constructor(e=10,t=10,r=4473924,a=8947848){r=new vt(r),a=new vt(a);const l=t/2,d=e/t,h=e/2,f=[],m=[];for(let v=0,b=0,M=-h;v<=t;v++,M+=d){f.push(-h,0,M,h,0,M),f.push(M,0,-h,M,0,h);const E=v===l?r:a;E.toArray(m,b),b+=3,E.toArray(m,b),b+=3,E.toArray(m,b),b+=3,E.toArray(m,b),b+=3}const _=new Hn;_.setAttribute("position",new $n(f,3)),_.setAttribute("color",new $n(m,3));const S=new uf({vertexColors:!0,toneMapped:!1});super(_,S),this.type="GridHelper"}dispose(){this.geometry.dispose(),this.material.dispose()}}class s1 extends Jr{constructor(e,t=null){super(),this.object=e,this.domElement=t,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(e){if(e===void 0){gt("Controls: connect() now requires an element.");return}this.domElement!==null&&this.disconnect(),this.domElement=e}disconnect(){}dispose(){}update(){}}function T0(s,e,t,r){const a=a1(r);switch(t){case Mg:return s*e;case Eg:return s*e/a.components*a.byteLength;case ef:return s*e/a.components*a.byteLength;case Zr:return s*e*2/a.components*a.byteLength;case tf:return s*e*2/a.components*a.byteLength;case wg:return s*e*3/a.components*a.byteLength;case ji:return s*e*4/a.components*a.byteLength;case nf:return s*e*4/a.components*a.byteLength;case cc:case uc:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*8;case dc:case hc:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*16;case ch:case dh:return Math.max(s,16)*Math.max(e,8)/4;case lh:case uh:return Math.max(s,8)*Math.max(e,8)/2;case hh:case fh:case mh:case gh:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*8;case ph:case bc:case xh:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*16;case vh:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*16;case _h:return Math.floor((s+4)/5)*Math.floor((e+3)/4)*16;case yh:return Math.floor((s+4)/5)*Math.floor((e+4)/5)*16;case bh:return Math.floor((s+5)/6)*Math.floor((e+4)/5)*16;case Sh:return Math.floor((s+5)/6)*Math.floor((e+5)/6)*16;case Mh:return Math.floor((s+7)/8)*Math.floor((e+4)/5)*16;case wh:return Math.floor((s+7)/8)*Math.floor((e+5)/6)*16;case Eh:return Math.floor((s+7)/8)*Math.floor((e+7)/8)*16;case Th:return Math.floor((s+9)/10)*Math.floor((e+4)/5)*16;case Ah:return Math.floor((s+9)/10)*Math.floor((e+5)/6)*16;case Ch:return Math.floor((s+9)/10)*Math.floor((e+7)/8)*16;case Rh:return Math.floor((s+9)/10)*Math.floor((e+9)/10)*16;case Ph:return Math.floor((s+11)/12)*Math.floor((e+9)/10)*16;case Nh:return Math.floor((s+11)/12)*Math.floor((e+11)/12)*16;case Lh:case Dh:case Ih:return Math.ceil(s/4)*Math.ceil(e/4)*16;case kh:case Fh:return Math.ceil(s/4)*Math.ceil(e/4)*8;case Sc:case Uh:return Math.ceil(s/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function a1(s){switch(s){case Ei:case _g:return{byteLength:1,components:1};case yo:case yg:case pi:return{byteLength:2,components:1};case Qh:case Jh:return{byteLength:2,components:4};case er:case Zh:case zi:return{byteLength:4,components:1};case bg:case Sg:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${s}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Kh}}));typeof window<"u"&&(window.__THREE__?gt("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Kh);/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function Bg(){let s=null,e=!1,t=null,r=null;function a(l,d){t(l,d),r=s.requestAnimationFrame(a)}return{start:function(){e!==!0&&t!==null&&s!==null&&(r=s.requestAnimationFrame(a),e=!0)},stop:function(){s!==null&&s.cancelAnimationFrame(r),e=!1},setAnimationLoop:function(l){t=l},setContext:function(l){s=l}}}function o1(s){const e=new WeakMap;function t(h,f){const m=h.array,_=h.usage,S=m.byteLength,v=s.createBuffer();s.bindBuffer(f,v),s.bufferData(f,m,_),h.onUploadCallback();let b;if(m instanceof Float32Array)b=s.FLOAT;else if(typeof Float16Array<"u"&&m instanceof Float16Array)b=s.HALF_FLOAT;else if(m instanceof Uint16Array)h.isFloat16BufferAttribute?b=s.HALF_FLOAT:b=s.UNSIGNED_SHORT;else if(m instanceof Int16Array)b=s.SHORT;else if(m instanceof Uint32Array)b=s.UNSIGNED_INT;else if(m instanceof Int32Array)b=s.INT;else if(m instanceof Int8Array)b=s.BYTE;else if(m instanceof Uint8Array)b=s.UNSIGNED_BYTE;else if(m instanceof Uint8ClampedArray)b=s.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+m);return{buffer:v,type:b,bytesPerElement:m.BYTES_PER_ELEMENT,version:h.version,size:S}}function r(h,f,m){const _=f.array,S=f.updateRanges;if(s.bindBuffer(m,h),S.length===0)s.bufferSubData(m,0,_);else{S.sort((b,M)=>b.start-M.start);let v=0;for(let b=1;b<S.length;b++){const M=S[v],E=S[b];E.start<=M.start+M.count+1?M.count=Math.max(M.count,E.start+E.count-M.start):(++v,S[v]=E)}S.length=v+1;for(let b=0,M=S.length;b<M;b++){const E=S[b];s.bufferSubData(m,E.start*_.BYTES_PER_ELEMENT,_,E.start,E.count)}f.clearUpdateRanges()}f.onUploadCallback()}function a(h){return h.isInterleavedBufferAttribute&&(h=h.data),e.get(h)}function l(h){h.isInterleavedBufferAttribute&&(h=h.data);const f=e.get(h);f&&(s.deleteBuffer(f.buffer),e.delete(h))}function d(h,f){if(h.isInterleavedBufferAttribute&&(h=h.data),h.isGLBufferAttribute){const _=e.get(h);(!_||_.version<h.version)&&e.set(h,{buffer:h.buffer,type:h.type,bytesPerElement:h.elementSize,version:h.version});return}const m=e.get(h);if(m===void 0)e.set(h,t(h,f));else if(m.version<h.version){if(m.size!==h.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(m.buffer,h,f),m.version=h.version}}return{get:a,remove:l,update:d}}var l1=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,c1=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,u1=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,d1=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,h1=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,f1=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,p1=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,m1=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,g1=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,x1=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,v1=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,_1=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,y1=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,b1=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,S1=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,M1=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,w1=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,E1=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,T1=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,A1=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,C1=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,R1=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,P1=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,N1=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,L1=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,D1=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,I1=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,k1=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,F1=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,U1=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,O1="gl_FragColor = linearToOutputTexel( gl_FragColor );",B1=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,z1=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,j1=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,H1=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,G1=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,V1=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,W1=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,X1=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,q1=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,$1=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Y1=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,K1=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Z1=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Q1=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,J1=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,eb=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,tb=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,nb=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,ib=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,rb=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,sb=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,ab=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,ob=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,lb=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,cb=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,ub=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,db=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,hb=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,fb=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,pb=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,mb=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,gb=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,xb=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,vb=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,_b=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,yb=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,bb=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Sb=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Mb=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,wb=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Eb=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Tb=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Ab=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Cb=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Rb=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Pb=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,Nb=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Lb=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Db=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Ib=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,kb=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Fb=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Ub=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,Ob=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Bb=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,zb=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,jb=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Hb=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Gb=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Vb=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,Wb=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Xb=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,qb=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,$b=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Yb=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Kb=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Zb=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Qb=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Jb=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,eS=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tS=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,nS=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,iS=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,rS=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,sS=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,aS=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,oS=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const lS=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,cS=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,uS=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,dS=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,hS=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,fS=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,pS=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,mS=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,gS=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,xS=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,vS=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,_S=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,yS=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,bS=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,SS=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,MS=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,wS=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ES=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,TS=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,AS=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,CS=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,RS=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,PS=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,NS=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,LS=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,DS=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,IS=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,kS=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,FS=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,US=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,OS=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,BS=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,zS=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,jS=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,wt={alphahash_fragment:l1,alphahash_pars_fragment:c1,alphamap_fragment:u1,alphamap_pars_fragment:d1,alphatest_fragment:h1,alphatest_pars_fragment:f1,aomap_fragment:p1,aomap_pars_fragment:m1,batching_pars_vertex:g1,batching_vertex:x1,begin_vertex:v1,beginnormal_vertex:_1,bsdfs:y1,iridescence_fragment:b1,bumpmap_pars_fragment:S1,clipping_planes_fragment:M1,clipping_planes_pars_fragment:w1,clipping_planes_pars_vertex:E1,clipping_planes_vertex:T1,color_fragment:A1,color_pars_fragment:C1,color_pars_vertex:R1,color_vertex:P1,common:N1,cube_uv_reflection_fragment:L1,defaultnormal_vertex:D1,displacementmap_pars_vertex:I1,displacementmap_vertex:k1,emissivemap_fragment:F1,emissivemap_pars_fragment:U1,colorspace_fragment:O1,colorspace_pars_fragment:B1,envmap_fragment:z1,envmap_common_pars_fragment:j1,envmap_pars_fragment:H1,envmap_pars_vertex:G1,envmap_physical_pars_fragment:eb,envmap_vertex:V1,fog_vertex:W1,fog_pars_vertex:X1,fog_fragment:q1,fog_pars_fragment:$1,gradientmap_pars_fragment:Y1,lightmap_pars_fragment:K1,lights_lambert_fragment:Z1,lights_lambert_pars_fragment:Q1,lights_pars_begin:J1,lights_toon_fragment:tb,lights_toon_pars_fragment:nb,lights_phong_fragment:ib,lights_phong_pars_fragment:rb,lights_physical_fragment:sb,lights_physical_pars_fragment:ab,lights_fragment_begin:ob,lights_fragment_maps:lb,lights_fragment_end:cb,lightprobes_pars_fragment:ub,logdepthbuf_fragment:db,logdepthbuf_pars_fragment:hb,logdepthbuf_pars_vertex:fb,logdepthbuf_vertex:pb,map_fragment:mb,map_pars_fragment:gb,map_particle_fragment:xb,map_particle_pars_fragment:vb,metalnessmap_fragment:_b,metalnessmap_pars_fragment:yb,morphinstance_vertex:bb,morphcolor_vertex:Sb,morphnormal_vertex:Mb,morphtarget_pars_vertex:wb,morphtarget_vertex:Eb,normal_fragment_begin:Tb,normal_fragment_maps:Ab,normal_pars_fragment:Cb,normal_pars_vertex:Rb,normal_vertex:Pb,normalmap_pars_fragment:Nb,clearcoat_normal_fragment_begin:Lb,clearcoat_normal_fragment_maps:Db,clearcoat_pars_fragment:Ib,iridescence_pars_fragment:kb,opaque_fragment:Fb,packing:Ub,premultiplied_alpha_fragment:Ob,project_vertex:Bb,dithering_fragment:zb,dithering_pars_fragment:jb,roughnessmap_fragment:Hb,roughnessmap_pars_fragment:Gb,shadowmap_pars_fragment:Vb,shadowmap_pars_vertex:Wb,shadowmap_vertex:Xb,shadowmask_pars_fragment:qb,skinbase_vertex:$b,skinning_pars_vertex:Yb,skinning_vertex:Kb,skinnormal_vertex:Zb,specularmap_fragment:Qb,specularmap_pars_fragment:Jb,tonemapping_fragment:eS,tonemapping_pars_fragment:tS,transmission_fragment:nS,transmission_pars_fragment:iS,uv_pars_fragment:rS,uv_pars_vertex:sS,uv_vertex:aS,worldpos_vertex:oS,background_vert:lS,background_frag:cS,backgroundCube_vert:uS,backgroundCube_frag:dS,cube_vert:hS,cube_frag:fS,depth_vert:pS,depth_frag:mS,distance_vert:gS,distance_frag:xS,equirect_vert:vS,equirect_frag:_S,linedashed_vert:yS,linedashed_frag:bS,meshbasic_vert:SS,meshbasic_frag:MS,meshlambert_vert:wS,meshlambert_frag:ES,meshmatcap_vert:TS,meshmatcap_frag:AS,meshnormal_vert:CS,meshnormal_frag:RS,meshphong_vert:PS,meshphong_frag:NS,meshphysical_vert:LS,meshphysical_frag:DS,meshtoon_vert:IS,meshtoon_frag:kS,points_vert:FS,points_frag:US,shadow_vert:OS,shadow_frag:BS,sprite_vert:zS,sprite_frag:jS},Ge={common:{diffuse:{value:new vt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new yt},alphaMap:{value:null},alphaMapTransform:{value:new yt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new yt}},envmap:{envMap:{value:null},envMapRotation:{value:new yt},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new yt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new yt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new yt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new yt},normalScale:{value:new ut(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new yt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new yt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new yt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new yt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new vt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new K},probesMax:{value:new K},probesResolution:{value:new K}},points:{diffuse:{value:new vt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new yt},alphaTest:{value:0},uvTransform:{value:new yt}},sprite:{diffuse:{value:new vt(16777215)},opacity:{value:1},center:{value:new ut(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new yt},alphaMap:{value:null},alphaMapTransform:{value:new yt},alphaTest:{value:0}}},Ki={basic:{uniforms:Wn([Ge.common,Ge.specularmap,Ge.envmap,Ge.aomap,Ge.lightmap,Ge.fog]),vertexShader:wt.meshbasic_vert,fragmentShader:wt.meshbasic_frag},lambert:{uniforms:Wn([Ge.common,Ge.specularmap,Ge.envmap,Ge.aomap,Ge.lightmap,Ge.emissivemap,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,Ge.fog,Ge.lights,{emissive:{value:new vt(0)},envMapIntensity:{value:1}}]),vertexShader:wt.meshlambert_vert,fragmentShader:wt.meshlambert_frag},phong:{uniforms:Wn([Ge.common,Ge.specularmap,Ge.envmap,Ge.aomap,Ge.lightmap,Ge.emissivemap,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,Ge.fog,Ge.lights,{emissive:{value:new vt(0)},specular:{value:new vt(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:wt.meshphong_vert,fragmentShader:wt.meshphong_frag},standard:{uniforms:Wn([Ge.common,Ge.envmap,Ge.aomap,Ge.lightmap,Ge.emissivemap,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,Ge.roughnessmap,Ge.metalnessmap,Ge.fog,Ge.lights,{emissive:{value:new vt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:wt.meshphysical_vert,fragmentShader:wt.meshphysical_frag},toon:{uniforms:Wn([Ge.common,Ge.aomap,Ge.lightmap,Ge.emissivemap,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,Ge.gradientmap,Ge.fog,Ge.lights,{emissive:{value:new vt(0)}}]),vertexShader:wt.meshtoon_vert,fragmentShader:wt.meshtoon_frag},matcap:{uniforms:Wn([Ge.common,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,Ge.fog,{matcap:{value:null}}]),vertexShader:wt.meshmatcap_vert,fragmentShader:wt.meshmatcap_frag},points:{uniforms:Wn([Ge.points,Ge.fog]),vertexShader:wt.points_vert,fragmentShader:wt.points_frag},dashed:{uniforms:Wn([Ge.common,Ge.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:wt.linedashed_vert,fragmentShader:wt.linedashed_frag},depth:{uniforms:Wn([Ge.common,Ge.displacementmap]),vertexShader:wt.depth_vert,fragmentShader:wt.depth_frag},normal:{uniforms:Wn([Ge.common,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,{opacity:{value:1}}]),vertexShader:wt.meshnormal_vert,fragmentShader:wt.meshnormal_frag},sprite:{uniforms:Wn([Ge.sprite,Ge.fog]),vertexShader:wt.sprite_vert,fragmentShader:wt.sprite_frag},background:{uniforms:{uvTransform:{value:new yt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:wt.background_vert,fragmentShader:wt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new yt}},vertexShader:wt.backgroundCube_vert,fragmentShader:wt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:wt.cube_vert,fragmentShader:wt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:wt.equirect_vert,fragmentShader:wt.equirect_frag},distance:{uniforms:Wn([Ge.common,Ge.displacementmap,{referencePosition:{value:new K},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:wt.distance_vert,fragmentShader:wt.distance_frag},shadow:{uniforms:Wn([Ge.lights,Ge.fog,{color:{value:new vt(0)},opacity:{value:1}}]),vertexShader:wt.shadow_vert,fragmentShader:wt.shadow_frag}};Ki.physical={uniforms:Wn([Ki.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new yt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new yt},clearcoatNormalScale:{value:new ut(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new yt},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new yt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new yt},sheen:{value:0},sheenColor:{value:new vt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new yt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new yt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new yt},transmissionSamplerSize:{value:new ut},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new yt},attenuationDistance:{value:0},attenuationColor:{value:new vt(0)},specularColor:{value:new vt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new yt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new yt},anisotropyVector:{value:new ut},anisotropyMap:{value:null},anisotropyMapTransform:{value:new yt}}]),vertexShader:wt.meshphysical_vert,fragmentShader:wt.meshphysical_frag};const tc={r:0,b:0,g:0},HS=new nn,zg=new yt;zg.set(-1,0,0,0,1,0,0,0,1);function GS(s,e,t,r,a,l){const d=new vt(0);let h=a===!0?0:1,f,m,_=null,S=0,v=null;function b(N){let P=N.isScene===!0?N.background:null;if(P&&P.isTexture){const C=N.backgroundBlurriness>0;P=e.get(P,C)}return P}function M(N){let P=!1;const C=b(N);C===null?g(d,h):C&&C.isColor&&(g(C,1),P=!0);const D=s.xr.getEnvironmentBlendMode();D==="additive"?t.buffers.color.setClear(0,0,0,1,l):D==="alpha-blend"&&t.buffers.color.setClear(0,0,0,0,l),(s.autoClear||P)&&(t.buffers.depth.setTest(!0),t.buffers.depth.setMask(!0),t.buffers.color.setMask(!0),s.clear(s.autoClearColor,s.autoClearDepth,s.autoClearStencil))}function E(N,P){const C=b(P);C&&(C.isCubeTexture||C.mapping===Dc)?(m===void 0&&(m=new Ti(new Ao(1,1,1),new bn({name:"BackgroundCubeMaterial",uniforms:Ma(Ki.backgroundCube.uniforms),vertexShader:Ki.backgroundCube.vertexShader,fragmentShader:Ki.backgroundCube.fragmentShader,side:si,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),m.geometry.deleteAttribute("normal"),m.geometry.deleteAttribute("uv"),m.onBeforeRender=function(D,L,O){this.matrixWorld.copyPosition(O.matrixWorld)},Object.defineProperty(m.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(m)),m.material.uniforms.envMap.value=C,m.material.uniforms.backgroundBlurriness.value=P.backgroundBlurriness,m.material.uniforms.backgroundIntensity.value=P.backgroundIntensity,m.material.uniforms.backgroundRotation.value.setFromMatrix4(HS.makeRotationFromEuler(P.backgroundRotation)).transpose(),C.isCubeTexture&&C.isRenderTargetTexture===!1&&m.material.uniforms.backgroundRotation.value.premultiply(zg),m.material.toneMapped=Lt.getTransfer(C.colorSpace)!==Wt,(_!==C||S!==C.version||v!==s.toneMapping)&&(m.material.needsUpdate=!0,_=C,S=C.version,v=s.toneMapping),m.layers.enableAll(),N.unshift(m,m.geometry,m.material,0,0,null)):C&&C.isTexture&&(f===void 0&&(f=new Ti(new Co(2,2),new bn({name:"BackgroundMaterial",uniforms:Ma(Ki.background.uniforms),vertexShader:Ki.background.vertexShader,fragmentShader:Ki.background.fragmentShader,side:Kr,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),f.geometry.deleteAttribute("normal"),Object.defineProperty(f.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(f)),f.material.uniforms.t2D.value=C,f.material.uniforms.backgroundIntensity.value=P.backgroundIntensity,f.material.toneMapped=Lt.getTransfer(C.colorSpace)!==Wt,C.matrixAutoUpdate===!0&&C.updateMatrix(),f.material.uniforms.uvTransform.value.copy(C.matrix),(_!==C||S!==C.version||v!==s.toneMapping)&&(f.material.needsUpdate=!0,_=C,S=C.version,v=s.toneMapping),f.layers.enableAll(),N.unshift(f,f.geometry,f.material,0,0,null))}function g(N,P){N.getRGB(tc,Fg(s)),t.buffers.color.setClear(tc.r,tc.g,tc.b,P,l)}function x(){m!==void 0&&(m.geometry.dispose(),m.material.dispose(),m=void 0),f!==void 0&&(f.geometry.dispose(),f.material.dispose(),f=void 0)}return{getClearColor:function(){return d},setClearColor:function(N,P=1){d.set(N),h=P,g(d,h)},getClearAlpha:function(){return h},setClearAlpha:function(N){h=N,g(d,h)},render:M,addToRenderList:E,dispose:x}}function VS(s,e){const t=s.getParameter(s.MAX_VERTEX_ATTRIBS),r={},a=v(null);let l=a,d=!1;function h(B,V,ae,Q,ie){let de=!1;const re=S(B,Q,ae,V);l!==re&&(l=re,m(l.object)),de=b(B,Q,ae,ie),de&&M(B,Q,ae,ie),ie!==null&&e.update(ie,s.ELEMENT_ARRAY_BUFFER),(de||d)&&(d=!1,C(B,V,ae,Q),ie!==null&&s.bindBuffer(s.ELEMENT_ARRAY_BUFFER,e.get(ie).buffer))}function f(){return s.createVertexArray()}function m(B){return s.bindVertexArray(B)}function _(B){return s.deleteVertexArray(B)}function S(B,V,ae,Q){const ie=Q.wireframe===!0;let de=r[V.id];de===void 0&&(de={},r[V.id]=de);const re=B.isInstancedMesh===!0?B.id:0;let X=de[re];X===void 0&&(X={},de[re]=X);let J=X[ae.id];J===void 0&&(J={},X[ae.id]=J);let le=J[ie];return le===void 0&&(le=v(f()),J[ie]=le),le}function v(B){const V=[],ae=[],Q=[];for(let ie=0;ie<t;ie++)V[ie]=0,ae[ie]=0,Q[ie]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:V,enabledAttributes:ae,attributeDivisors:Q,object:B,attributes:{},index:null}}function b(B,V,ae,Q){const ie=l.attributes,de=V.attributes;let re=0;const X=ae.getAttributes();for(const J in X)if(X[J].location>=0){const U=ie[J];let q=de[J];if(q===void 0&&(J==="instanceMatrix"&&B.instanceMatrix&&(q=B.instanceMatrix),J==="instanceColor"&&B.instanceColor&&(q=B.instanceColor)),U===void 0||U.attribute!==q||q&&U.data!==q.data)return!0;re++}return l.attributesNum!==re||l.index!==Q}function M(B,V,ae,Q){const ie={},de=V.attributes;let re=0;const X=ae.getAttributes();for(const J in X)if(X[J].location>=0){let U=de[J];U===void 0&&(J==="instanceMatrix"&&B.instanceMatrix&&(U=B.instanceMatrix),J==="instanceColor"&&B.instanceColor&&(U=B.instanceColor));const q={};q.attribute=U,U&&U.data&&(q.data=U.data),ie[J]=q,re++}l.attributes=ie,l.attributesNum=re,l.index=Q}function E(){const B=l.newAttributes;for(let V=0,ae=B.length;V<ae;V++)B[V]=0}function g(B){x(B,0)}function x(B,V){const ae=l.newAttributes,Q=l.enabledAttributes,ie=l.attributeDivisors;ae[B]=1,Q[B]===0&&(s.enableVertexAttribArray(B),Q[B]=1),ie[B]!==V&&(s.vertexAttribDivisor(B,V),ie[B]=V)}function N(){const B=l.newAttributes,V=l.enabledAttributes;for(let ae=0,Q=V.length;ae<Q;ae++)V[ae]!==B[ae]&&(s.disableVertexAttribArray(ae),V[ae]=0)}function P(B,V,ae,Q,ie,de,re){re===!0?s.vertexAttribIPointer(B,V,ae,ie,de):s.vertexAttribPointer(B,V,ae,Q,ie,de)}function C(B,V,ae,Q){E();const ie=Q.attributes,de=ae.getAttributes(),re=V.defaultAttributeValues;for(const X in de){const J=de[X];if(J.location>=0){let le=ie[X];if(le===void 0&&(X==="instanceMatrix"&&B.instanceMatrix&&(le=B.instanceMatrix),X==="instanceColor"&&B.instanceColor&&(le=B.instanceColor)),le!==void 0){const U=le.normalized,q=le.itemSize,Re=e.get(le);if(Re===void 0)continue;const qe=Re.buffer,be=Re.type,ee=Re.bytesPerElement,me=be===s.INT||be===s.UNSIGNED_INT||le.gpuType===Zh;if(le.isInterleavedBufferAttribute){const ve=le.data,ce=ve.stride,we=le.offset;if(ve.isInstancedInterleavedBuffer){for(let Ze=0;Ze<J.locationSize;Ze++)x(J.location+Ze,ve.meshPerAttribute);B.isInstancedMesh!==!0&&Q._maxInstanceCount===void 0&&(Q._maxInstanceCount=ve.meshPerAttribute*ve.count)}else for(let Ze=0;Ze<J.locationSize;Ze++)g(J.location+Ze);s.bindBuffer(s.ARRAY_BUFFER,qe);for(let Ze=0;Ze<J.locationSize;Ze++)P(J.location+Ze,q/J.locationSize,be,U,ce*ee,(we+q/J.locationSize*Ze)*ee,me)}else{if(le.isInstancedBufferAttribute){for(let ve=0;ve<J.locationSize;ve++)x(J.location+ve,le.meshPerAttribute);B.isInstancedMesh!==!0&&Q._maxInstanceCount===void 0&&(Q._maxInstanceCount=le.meshPerAttribute*le.count)}else for(let ve=0;ve<J.locationSize;ve++)g(J.location+ve);s.bindBuffer(s.ARRAY_BUFFER,qe);for(let ve=0;ve<J.locationSize;ve++)P(J.location+ve,q/J.locationSize,be,U,q*ee,q/J.locationSize*ve*ee,me)}}else if(re!==void 0){const U=re[X];if(U!==void 0)switch(U.length){case 2:s.vertexAttrib2fv(J.location,U);break;case 3:s.vertexAttrib3fv(J.location,U);break;case 4:s.vertexAttrib4fv(J.location,U);break;default:s.vertexAttrib1fv(J.location,U)}}}}N()}function D(){I();for(const B in r){const V=r[B];for(const ae in V){const Q=V[ae];for(const ie in Q){const de=Q[ie];for(const re in de)_(de[re].object),delete de[re];delete Q[ie]}}delete r[B]}}function L(B){if(r[B.id]===void 0)return;const V=r[B.id];for(const ae in V){const Q=V[ae];for(const ie in Q){const de=Q[ie];for(const re in de)_(de[re].object),delete de[re];delete Q[ie]}}delete r[B.id]}function O(B){for(const V in r){const ae=r[V];for(const Q in ae){const ie=ae[Q];if(ie[B.id]===void 0)continue;const de=ie[B.id];for(const re in de)_(de[re].object),delete de[re];delete ie[B.id]}}}function T(B){for(const V in r){const ae=r[V],Q=B.isInstancedMesh===!0?B.id:0,ie=ae[Q];if(ie!==void 0){for(const de in ie){const re=ie[de];for(const X in re)_(re[X].object),delete re[X];delete ie[de]}delete ae[Q],Object.keys(ae).length===0&&delete r[V]}}}function I(){H(),d=!0,l!==a&&(l=a,m(l.object))}function H(){a.geometry=null,a.program=null,a.wireframe=!1}return{setup:h,reset:I,resetDefaultState:H,dispose:D,releaseStatesOfGeometry:L,releaseStatesOfObject:T,releaseStatesOfProgram:O,initAttributes:E,enableAttribute:g,disableUnusedAttributes:N}}function WS(s,e,t){let r;function a(f){r=f}function l(f,m){s.drawArrays(r,f,m),t.update(m,r,1)}function d(f,m,_){_!==0&&(s.drawArraysInstanced(r,f,m,_),t.update(m,r,_))}function h(f,m,_){if(_===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(r,f,0,m,0,_);let v=0;for(let b=0;b<_;b++)v+=m[b];t.update(v,r,1)}this.setMode=a,this.render=l,this.renderInstances=d,this.renderMultiDraw=h}function XS(s,e,t,r){let a;function l(){if(a!==void 0)return a;if(e.has("EXT_texture_filter_anisotropic")===!0){const O=e.get("EXT_texture_filter_anisotropic");a=s.getParameter(O.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else a=0;return a}function d(O){return!(O!==ji&&r.convert(O)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_FORMAT))}function h(O){const T=O===pi&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(O!==Ei&&r.convert(O)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_TYPE)&&O!==zi&&!T)}function f(O){if(O==="highp"){if(s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.HIGH_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.HIGH_FLOAT).precision>0)return"highp";O="mediump"}return O==="mediump"&&s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.MEDIUM_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let m=t.precision!==void 0?t.precision:"highp";const _=f(m);_!==m&&(gt("WebGLRenderer:",m,"not supported, using",_,"instead."),m=_);const S=t.logarithmicDepthBuffer===!0,v=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control");t.reversedDepthBuffer===!0&&v===!1&&gt("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const b=s.getParameter(s.MAX_TEXTURE_IMAGE_UNITS),M=s.getParameter(s.MAX_VERTEX_TEXTURE_IMAGE_UNITS),E=s.getParameter(s.MAX_TEXTURE_SIZE),g=s.getParameter(s.MAX_CUBE_MAP_TEXTURE_SIZE),x=s.getParameter(s.MAX_VERTEX_ATTRIBS),N=s.getParameter(s.MAX_VERTEX_UNIFORM_VECTORS),P=s.getParameter(s.MAX_VARYING_VECTORS),C=s.getParameter(s.MAX_FRAGMENT_UNIFORM_VECTORS),D=s.getParameter(s.MAX_SAMPLES),L=s.getParameter(s.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:l,getMaxPrecision:f,textureFormatReadable:d,textureTypeReadable:h,precision:m,logarithmicDepthBuffer:S,reversedDepthBuffer:v,maxTextures:b,maxVertexTextures:M,maxTextureSize:E,maxCubemapSize:g,maxAttributes:x,maxVertexUniforms:N,maxVaryings:P,maxFragmentUniforms:C,maxSamples:D,samples:L}}function qS(s){const e=this;let t=null,r=0,a=!1,l=!1;const d=new Xr,h=new yt,f={value:null,needsUpdate:!1};this.uniform=f,this.numPlanes=0,this.numIntersection=0,this.init=function(S,v){const b=S.length!==0||v||r!==0||a;return a=v,r=S.length,b},this.beginShadows=function(){l=!0,_(null)},this.endShadows=function(){l=!1},this.setGlobalState=function(S,v){t=_(S,v,0)},this.setState=function(S,v,b){const M=S.clippingPlanes,E=S.clipIntersection,g=S.clipShadows,x=s.get(S);if(!a||M===null||M.length===0||l&&!g)l?_(null):m();else{const N=l?0:r,P=N*4;let C=x.clippingState||null;f.value=C,C=_(M,v,P,b);for(let D=0;D!==P;++D)C[D]=t[D];x.clippingState=C,this.numIntersection=E?this.numPlanes:0,this.numPlanes+=N}};function m(){f.value!==t&&(f.value=t,f.needsUpdate=r>0),e.numPlanes=r,e.numIntersection=0}function _(S,v,b,M){const E=S!==null?S.length:0;let g=null;if(E!==0){if(g=f.value,M!==!0||g===null){const x=b+E*4,N=v.matrixWorldInverse;h.getNormalMatrix(N),(g===null||g.length<x)&&(g=new Float32Array(x));for(let P=0,C=b;P!==E;++P,C+=4)d.copy(S[P]).applyMatrix4(N,h),d.normal.toArray(g,C),g[C+3]=d.constant}f.value=g,f.needsUpdate=!0}return e.numPlanes=E,e.numIntersection=0,g}}const $r=4,A0=[.125,.215,.35,.446,.526,.582],_s=20,$S=256,po=new df,C0=new vt;let Hd=null,Gd=0,Vd=0,Wd=!1;const YS=new K;class R0{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,r=.1,a=100,l={}){const{size:d=256,position:h=YS}=l;Hd=this._renderer.getRenderTarget(),Gd=this._renderer.getActiveCubeFace(),Vd=this._renderer.getActiveMipmapLevel(),Wd=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(d);const f=this._allocateTargets();return f.depthBuffer=!0,this._sceneToCubeUV(e,r,a,f,h),t>0&&this._blur(f,0,0,t),this._applyPMREM(f),this._cleanup(f),f}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=L0(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=N0(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(Hd,Gd,Vd),this._renderer.xr.enabled=Wd,e.scissorTest=!1,da(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Es||e.mapping===ba?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Hd=this._renderer.getRenderTarget(),Gd=this._renderer.getActiveCubeFace(),Vd=this._renderer.getActiveMipmapLevel(),Wd=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const r=t||this._allocateTargets();return this._textureToCubeUV(e,r),this._applyPMREM(r),this._cleanup(r),r}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,r={magFilter:jn,minFilter:jn,generateMipmaps:!1,type:pi,format:ji,colorSpace:Mc,depthBuffer:!1},a=P0(e,t,r);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=P0(e,t,r);const{_lodMax:l}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=KS(l)),this._blurMaterial=QS(l,e,t),this._ggxMaterial=ZS(l,e,t)}return a}_compileMaterial(e){const t=new Ti(new Hn,e);this._renderer.compile(t,po)}_sceneToCubeUV(e,t,r,a,l){const f=new wi(90,1,t,r),m=[1,-1,1,1,1,1],_=[1,1,1,-1,-1,-1],S=this._renderer,v=S.autoClear,b=S.toneMapping;S.getClearColor(C0),S.toneMapping=Ji,S.autoClear=!1,S.state.buffers.depth.getReversed()&&(S.setRenderTarget(a),S.clearDepth(),S.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new Ti(new Ao,new cf({name:"PMREM.Background",side:si,depthWrite:!1,depthTest:!1})));const E=this._backgroundBox,g=E.material;let x=!1;const N=e.background;N?N.isColor&&(g.color.copy(N),e.background=null,x=!0):(g.color.copy(C0),x=!0);for(let P=0;P<6;P++){const C=P%3;C===0?(f.up.set(0,m[P],0),f.position.set(l.x,l.y,l.z),f.lookAt(l.x+_[P],l.y,l.z)):C===1?(f.up.set(0,0,m[P]),f.position.set(l.x,l.y,l.z),f.lookAt(l.x,l.y+_[P],l.z)):(f.up.set(0,m[P],0),f.position.set(l.x,l.y,l.z),f.lookAt(l.x,l.y,l.z+_[P]));const D=this._cubeSize;da(a,C*D,P>2?D:0,D,D),S.setRenderTarget(a),x&&S.render(E,f),S.render(e,f)}S.toneMapping=b,S.autoClear=v,e.background=N}_textureToCubeUV(e,t){const r=this._renderer,a=e.mapping===Es||e.mapping===ba;a?(this._cubemapMaterial===null&&(this._cubemapMaterial=L0()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=N0());const l=a?this._cubemapMaterial:this._equirectMaterial,d=this._lodMeshes[0];d.material=l;const h=l.uniforms;h.envMap.value=e;const f=this._cubeSize;da(t,0,0,3*f,2*f),r.setRenderTarget(t),r.render(d,po)}_applyPMREM(e){const t=this._renderer,r=t.autoClear;t.autoClear=!1;const a=this._lodMeshes.length;for(let l=1;l<a;l++)this._applyGGXFilter(e,l-1,l);t.autoClear=r}_applyGGXFilter(e,t,r){const a=this._renderer,l=this._pingPongRenderTarget,d=this._ggxMaterial,h=this._lodMeshes[r];h.material=d;const f=d.uniforms,m=r/(this._lodMeshes.length-1),_=t/(this._lodMeshes.length-1),S=Math.sqrt(m*m-_*_),v=0+m*1.25,b=S*v,{_lodMax:M}=this,E=this._sizeLods[r],g=3*E*(r>M-$r?r-M+$r:0),x=4*(this._cubeSize-E);f.envMap.value=e.texture,f.roughness.value=b,f.mipInt.value=M-t,da(l,g,x,3*E,2*E),a.setRenderTarget(l),a.render(h,po),f.envMap.value=l.texture,f.roughness.value=0,f.mipInt.value=M-r,da(e,g,x,3*E,2*E),a.setRenderTarget(e),a.render(h,po)}_blur(e,t,r,a,l){const d=this._pingPongRenderTarget;this._halfBlur(e,d,t,r,a,"latitudinal",l),this._halfBlur(d,e,r,r,a,"longitudinal",l)}_halfBlur(e,t,r,a,l,d,h){const f=this._renderer,m=this._blurMaterial;d!=="latitudinal"&&d!=="longitudinal"&&kt("blur direction must be either latitudinal or longitudinal!");const _=3,S=this._lodMeshes[a];S.material=m;const v=m.uniforms,b=this._sizeLods[r]-1,M=isFinite(l)?Math.PI/(2*b):2*Math.PI/(2*_s-1),E=l/M,g=isFinite(l)?1+Math.floor(_*E):_s;g>_s&&gt(`sigmaRadians, ${l}, is too large and will clip, as it requested ${g} samples when the maximum is set to ${_s}`);const x=[];let N=0;for(let O=0;O<_s;++O){const T=O/E,I=Math.exp(-T*T/2);x.push(I),O===0?N+=I:O<g&&(N+=2*I)}for(let O=0;O<x.length;O++)x[O]=x[O]/N;v.envMap.value=e.texture,v.samples.value=g,v.weights.value=x,v.latitudinal.value=d==="latitudinal",h&&(v.poleAxis.value=h);const{_lodMax:P}=this;v.dTheta.value=M,v.mipInt.value=P-r;const C=this._sizeLods[a],D=3*C*(a>P-$r?a-P+$r:0),L=4*(this._cubeSize-C);da(t,D,L,3*C,2*C),f.setRenderTarget(t),f.render(S,po)}}function KS(s){const e=[],t=[],r=[];let a=s;const l=s-$r+1+A0.length;for(let d=0;d<l;d++){const h=Math.pow(2,a);e.push(h);let f=1/h;d>s-$r?f=A0[d-s+$r-1]:d===0&&(f=0),t.push(f);const m=1/(h-2),_=-m,S=1+m,v=[_,_,S,_,S,S,_,_,S,S,_,S],b=6,M=6,E=3,g=2,x=1,N=new Float32Array(E*M*b),P=new Float32Array(g*M*b),C=new Float32Array(x*M*b);for(let L=0;L<b;L++){const O=L%3*2/3-1,T=L>2?0:-1,I=[O,T,0,O+2/3,T,0,O+2/3,T+1,0,O,T,0,O+2/3,T+1,0,O,T+1,0];N.set(I,E*M*L),P.set(v,g*M*L);const H=[L,L,L,L,L,L];C.set(H,x*M*L)}const D=new Hn;D.setAttribute("position",new Cn(N,E)),D.setAttribute("uv",new Cn(P,g)),D.setAttribute("faceIndex",new Cn(C,x)),r.push(new Ti(D,null)),a>$r&&a--}return{lodMeshes:r,sizeLods:e,sigmas:t}}function P0(s,e,t){const r=new ai(s,e,t);return r.texture.mapping=Dc,r.texture.name="PMREM.cubeUv",r.scissorTest=!0,r}function da(s,e,t,r,a){s.viewport.set(e,t,r,a),s.scissor.set(e,t,r,a)}function ZS(s,e,t){return new bn({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:$S,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:Ic(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Qi,depthTest:!1,depthWrite:!1})}function QS(s,e,t){const r=new Float32Array(_s),a=new K(0,1,0);return new bn({name:"SphericalGaussianBlur",defines:{n:_s,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:r},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:a}},vertexShader:Ic(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Qi,depthTest:!1,depthWrite:!1})}function N0(){return new bn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Ic(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Qi,depthTest:!1,depthWrite:!1})}function L0(){return new bn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Ic(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Qi,depthTest:!1,depthWrite:!1})}function Ic(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}class jg extends ai{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const r={width:e,height:e,depth:1},a=[r,r,r,r,r,r];this.texture=new Ig(a),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const r={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},a=new Ao(5,5,5),l=new bn({name:"CubemapFromEquirect",uniforms:Ma(r.uniforms),vertexShader:r.vertexShader,fragmentShader:r.fragmentShader,side:si,blending:Qi});l.uniforms.tEquirect.value=t;const d=new Ti(a,l),h=t.minFilter;return t.minFilter===Ss&&(t.minFilter=jn),new Jy(1,10,this).update(e,d),t.minFilter=h,d.geometry.dispose(),d.material.dispose(),this}clear(e,t=!0,r=!0,a=!0){const l=e.getRenderTarget();for(let d=0;d<6;d++)e.setRenderTarget(this,d),e.clear(t,r,a);e.setRenderTarget(l)}}function JS(s){let e=new WeakMap,t=new WeakMap,r=null;function a(v,b=!1){return v==null?null:b?d(v):l(v)}function l(v){if(v&&v.isTexture){const b=v.mapping;if(b===md||b===gd)if(e.has(v)){const M=e.get(v).texture;return h(M,v.mapping)}else{const M=v.image;if(M&&M.height>0){const E=new jg(M.height);return E.fromEquirectangularTexture(s,v),e.set(v,E),v.addEventListener("dispose",m),h(E.texture,v.mapping)}else return null}}return v}function d(v){if(v&&v.isTexture){const b=v.mapping,M=b===md||b===gd,E=b===Es||b===ba;if(M||E){let g=t.get(v);const x=g!==void 0?g.texture.pmremVersion:0;if(v.isRenderTargetTexture&&v.pmremVersion!==x)return r===null&&(r=new R0(s)),g=M?r.fromEquirectangular(v,g):r.fromCubemap(v,g),g.texture.pmremVersion=v.pmremVersion,t.set(v,g),g.texture;if(g!==void 0)return g.texture;{const N=v.image;return M&&N&&N.height>0||E&&N&&f(N)?(r===null&&(r=new R0(s)),g=M?r.fromEquirectangular(v):r.fromCubemap(v),g.texture.pmremVersion=v.pmremVersion,t.set(v,g),v.addEventListener("dispose",_),g.texture):null}}}return v}function h(v,b){return b===md?v.mapping=Es:b===gd&&(v.mapping=ba),v}function f(v){let b=0;const M=6;for(let E=0;E<M;E++)v[E]!==void 0&&b++;return b===M}function m(v){const b=v.target;b.removeEventListener("dispose",m);const M=e.get(b);M!==void 0&&(e.delete(b),M.dispose())}function _(v){const b=v.target;b.removeEventListener("dispose",_);const M=t.get(b);M!==void 0&&(t.delete(b),M.dispose())}function S(){e=new WeakMap,t=new WeakMap,r!==null&&(r.dispose(),r=null)}return{get:a,dispose:S}}function eM(s){const e={};function t(r){if(e[r]!==void 0)return e[r];const a=s.getExtension(r);return e[r]=a,a}return{has:function(r){return t(r)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(r){const a=t(r);return a===null&&va("WebGLRenderer: "+r+" extension not supported."),a}}}function tM(s,e,t,r){const a={},l=new WeakMap;function d(S){const v=S.target;v.index!==null&&e.remove(v.index);for(const M in v.attributes)e.remove(v.attributes[M]);v.removeEventListener("dispose",d),delete a[v.id];const b=l.get(v);b&&(e.remove(b),l.delete(v)),r.releaseStatesOfGeometry(v),v.isInstancedBufferGeometry===!0&&delete v._maxInstanceCount,t.memory.geometries--}function h(S,v){return a[v.id]===!0||(v.addEventListener("dispose",d),a[v.id]=!0,t.memory.geometries++),v}function f(S){const v=S.attributes;for(const b in v)e.update(v[b],s.ARRAY_BUFFER)}function m(S){const v=[],b=S.index,M=S.attributes.position;let E=0;if(M===void 0)return;if(b!==null){const N=b.array;E=b.version;for(let P=0,C=N.length;P<C;P+=3){const D=N[P+0],L=N[P+1],O=N[P+2];v.push(D,L,L,O,O,D)}}else{const N=M.array;E=M.version;for(let P=0,C=N.length/3-1;P<C;P+=3){const D=P+0,L=P+1,O=P+2;v.push(D,L,L,O,O,D)}}const g=new(M.count>=65535?Pg:Rg)(v,1);g.version=E;const x=l.get(S);x&&e.remove(x),l.set(S,g)}function _(S){const v=l.get(S);if(v){const b=S.index;b!==null&&v.version<b.version&&m(S)}else m(S);return l.get(S)}return{get:h,update:f,getWireframeAttribute:_}}function nM(s,e,t){let r;function a(S){r=S}let l,d;function h(S){l=S.type,d=S.bytesPerElement}function f(S,v){s.drawElements(r,v,l,S*d),t.update(v,r,1)}function m(S,v,b){b!==0&&(s.drawElementsInstanced(r,v,l,S*d,b),t.update(v,r,b))}function _(S,v,b){if(b===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(r,v,0,l,S,0,b);let E=0;for(let g=0;g<b;g++)E+=v[g];t.update(E,r,1)}this.setMode=a,this.setIndex=h,this.render=f,this.renderInstances=m,this.renderMultiDraw=_}function iM(s){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function r(l,d,h){switch(t.calls++,d){case s.TRIANGLES:t.triangles+=h*(l/3);break;case s.LINES:t.lines+=h*(l/2);break;case s.LINE_STRIP:t.lines+=h*(l-1);break;case s.LINE_LOOP:t.lines+=h*l;break;case s.POINTS:t.points+=h*l;break;default:kt("WebGLInfo: Unknown draw mode:",d);break}}function a(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:a,update:r}}function rM(s,e,t){const r=new WeakMap,a=new dn;function l(d,h,f){const m=d.morphTargetInfluences,_=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,S=_!==void 0?_.length:0;let v=r.get(h);if(v===void 0||v.count!==S){let I=function(){O.dispose(),r.delete(h),h.removeEventListener("dispose",I)};v!==void 0&&v.texture.dispose();const b=h.morphAttributes.position!==void 0,M=h.morphAttributes.normal!==void 0,E=h.morphAttributes.color!==void 0,g=h.morphAttributes.position||[],x=h.morphAttributes.normal||[],N=h.morphAttributes.color||[];let P=0;b===!0&&(P=1),M===!0&&(P=2),E===!0&&(P=3);let C=h.attributes.position.count*P,D=1;C>e.maxTextureSize&&(D=Math.ceil(C/e.maxTextureSize),C=e.maxTextureSize);const L=new Float32Array(C*D*4*S),O=new Ag(L,C,D,S);O.type=zi,O.needsUpdate=!0;const T=P*4;for(let H=0;H<S;H++){const B=g[H],V=x[H],ae=N[H],Q=C*D*4*H;for(let ie=0;ie<B.count;ie++){const de=ie*T;b===!0&&(a.fromBufferAttribute(B,ie),L[Q+de+0]=a.x,L[Q+de+1]=a.y,L[Q+de+2]=a.z,L[Q+de+3]=0),M===!0&&(a.fromBufferAttribute(V,ie),L[Q+de+4]=a.x,L[Q+de+5]=a.y,L[Q+de+6]=a.z,L[Q+de+7]=0),E===!0&&(a.fromBufferAttribute(ae,ie),L[Q+de+8]=a.x,L[Q+de+9]=a.y,L[Q+de+10]=a.z,L[Q+de+11]=ae.itemSize===4?a.w:1)}}v={count:S,texture:O,size:new ut(C,D)},r.set(h,v),h.addEventListener("dispose",I)}if(d.isInstancedMesh===!0&&d.morphTexture!==null)f.getUniforms().setValue(s,"morphTexture",d.morphTexture,t);else{let b=0;for(let E=0;E<m.length;E++)b+=m[E];const M=h.morphTargetsRelative?1:1-b;f.getUniforms().setValue(s,"morphTargetBaseInfluence",M),f.getUniforms().setValue(s,"morphTargetInfluences",m)}f.getUniforms().setValue(s,"morphTargetsTexture",v.texture,t),f.getUniforms().setValue(s,"morphTargetsTextureSize",v.size)}return{update:l}}function sM(s,e,t,r,a){let l=new WeakMap;function d(m){const _=a.render.frame,S=m.geometry,v=e.get(m,S);if(l.get(v)!==_&&(e.update(v),l.set(v,_)),m.isInstancedMesh&&(m.hasEventListener("dispose",f)===!1&&m.addEventListener("dispose",f),l.get(m)!==_&&(t.update(m.instanceMatrix,s.ARRAY_BUFFER),m.instanceColor!==null&&t.update(m.instanceColor,s.ARRAY_BUFFER),l.set(m,_))),m.isSkinnedMesh){const b=m.skeleton;l.get(b)!==_&&(b.update(),l.set(b,_))}return v}function h(){l=new WeakMap}function f(m){const _=m.target;_.removeEventListener("dispose",f),r.releaseStatesOfObject(_),t.remove(_.instanceMatrix),_.instanceColor!==null&&t.remove(_.instanceColor)}return{update:d,dispose:h}}const aM={[dg]:"LINEAR_TONE_MAPPING",[hg]:"REINHARD_TONE_MAPPING",[fg]:"CINEON_TONE_MAPPING",[pg]:"ACES_FILMIC_TONE_MAPPING",[gg]:"AGX_TONE_MAPPING",[xg]:"NEUTRAL_TONE_MAPPING",[mg]:"CUSTOM_TONE_MAPPING"};function oM(s,e,t,r,a,l){const d=new ai(e,t,{type:s,depthBuffer:a,stencilBuffer:l,samples:r?4:0,depthTexture:a?new Sa(e,t):void 0}),h=new ai(e,t,{type:pi,depthBuffer:!1,stencilBuffer:!1}),f=new Hn;f.setAttribute("position",new $n([-1,3,0,-1,-1,0,3,-1,0],3)),f.setAttribute("uv",new $n([0,2,0,0,2,0],2));const m=new Ky({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),_=new Ti(f,m),S=new df(-1,1,1,-1,0,1);let v=null,b=null,M=!1,E,g=null,x=[],N=!1;this.setSize=function(P,C){d.setSize(P,C),h.setSize(P,C);for(let D=0;D<x.length;D++){const L=x[D];L.setSize&&L.setSize(P,C)}},this.setEffects=function(P){x=P,N=x.length>0&&x[0].isRenderPass===!0;const C=d.width,D=d.height;for(let L=0;L<x.length;L++){const O=x[L];O.setSize&&O.setSize(C,D)}},this.begin=function(P,C){if(M||P.toneMapping===Ji&&x.length===0)return!1;if(g=C,C!==null){const D=C.width,L=C.height;(d.width!==D||d.height!==L)&&this.setSize(D,L)}return N===!1&&P.setRenderTarget(d),E=P.toneMapping,P.toneMapping=Ji,!0},this.hasRenderPass=function(){return N},this.end=function(P,C){P.toneMapping=E,M=!0;let D=d,L=h;for(let O=0;O<x.length;O++){const T=x[O];if(T.enabled!==!1&&(T.render(P,L,D,C),T.needsSwap!==!1)){const I=D;D=L,L=I}}if(v!==P.outputColorSpace||b!==P.toneMapping){v=P.outputColorSpace,b=P.toneMapping,m.defines={},Lt.getTransfer(v)===Wt&&(m.defines.SRGB_TRANSFER="");const O=aM[b];O&&(m.defines[O]=""),m.needsUpdate=!0}m.uniforms.tDiffuse.value=D.texture,P.setRenderTarget(g),P.render(_,S),g=null,M=!1},this.isCompositing=function(){return M},this.dispose=function(){d.depthTexture&&d.depthTexture.dispose(),d.dispose(),h.dispose(),f.dispose(),m.dispose()}}const Hg=new Xn,jh=new Sa(1,1),Gg=new Ag,Vg=new Ty,Wg=new Ig,D0=[],I0=[],k0=new Float32Array(16),F0=new Float32Array(9),U0=new Float32Array(4);function Aa(s,e,t){const r=s[0];if(r<=0||r>0)return s;const a=e*t;let l=D0[a];if(l===void 0&&(l=new Float32Array(a),D0[a]=l),e!==0){r.toArray(l,0);for(let d=1,h=0;d!==e;++d)h+=t,s[d].toArray(l,h)}return l}function Sn(s,e){if(s.length!==e.length)return!1;for(let t=0,r=s.length;t<r;t++)if(s[t]!==e[t])return!1;return!0}function Mn(s,e){for(let t=0,r=e.length;t<r;t++)s[t]=e[t]}function kc(s,e){let t=I0[e];t===void 0&&(t=new Int32Array(e),I0[e]=t);for(let r=0;r!==e;++r)t[r]=s.allocateTextureUnit();return t}function lM(s,e){const t=this.cache;t[0]!==e&&(s.uniform1f(this.addr,e),t[0]=e)}function cM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(s.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Sn(t,e))return;s.uniform2fv(this.addr,e),Mn(t,e)}}function uM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(s.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(s.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Sn(t,e))return;s.uniform3fv(this.addr,e),Mn(t,e)}}function dM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(s.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Sn(t,e))return;s.uniform4fv(this.addr,e),Mn(t,e)}}function hM(s,e){const t=this.cache,r=e.elements;if(r===void 0){if(Sn(t,e))return;s.uniformMatrix2fv(this.addr,!1,e),Mn(t,e)}else{if(Sn(t,r))return;U0.set(r),s.uniformMatrix2fv(this.addr,!1,U0),Mn(t,r)}}function fM(s,e){const t=this.cache,r=e.elements;if(r===void 0){if(Sn(t,e))return;s.uniformMatrix3fv(this.addr,!1,e),Mn(t,e)}else{if(Sn(t,r))return;F0.set(r),s.uniformMatrix3fv(this.addr,!1,F0),Mn(t,r)}}function pM(s,e){const t=this.cache,r=e.elements;if(r===void 0){if(Sn(t,e))return;s.uniformMatrix4fv(this.addr,!1,e),Mn(t,e)}else{if(Sn(t,r))return;k0.set(r),s.uniformMatrix4fv(this.addr,!1,k0),Mn(t,r)}}function mM(s,e){const t=this.cache;t[0]!==e&&(s.uniform1i(this.addr,e),t[0]=e)}function gM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(s.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Sn(t,e))return;s.uniform2iv(this.addr,e),Mn(t,e)}}function xM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(s.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Sn(t,e))return;s.uniform3iv(this.addr,e),Mn(t,e)}}function vM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(s.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Sn(t,e))return;s.uniform4iv(this.addr,e),Mn(t,e)}}function _M(s,e){const t=this.cache;t[0]!==e&&(s.uniform1ui(this.addr,e),t[0]=e)}function yM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(s.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Sn(t,e))return;s.uniform2uiv(this.addr,e),Mn(t,e)}}function bM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(s.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Sn(t,e))return;s.uniform3uiv(this.addr,e),Mn(t,e)}}function SM(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(s.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Sn(t,e))return;s.uniform4uiv(this.addr,e),Mn(t,e)}}function MM(s,e,t){const r=this.cache,a=t.allocateTextureUnit();r[0]!==a&&(s.uniform1i(this.addr,a),r[0]=a);let l;this.type===s.SAMPLER_2D_SHADOW?(jh.compareFunction=t.isReversedDepthBuffer()?sf:rf,l=jh):l=Hg,t.setTexture2D(e||l,a)}function wM(s,e,t){const r=this.cache,a=t.allocateTextureUnit();r[0]!==a&&(s.uniform1i(this.addr,a),r[0]=a),t.setTexture3D(e||Vg,a)}function EM(s,e,t){const r=this.cache,a=t.allocateTextureUnit();r[0]!==a&&(s.uniform1i(this.addr,a),r[0]=a),t.setTextureCube(e||Wg,a)}function TM(s,e,t){const r=this.cache,a=t.allocateTextureUnit();r[0]!==a&&(s.uniform1i(this.addr,a),r[0]=a),t.setTexture2DArray(e||Gg,a)}function AM(s){switch(s){case 5126:return lM;case 35664:return cM;case 35665:return uM;case 35666:return dM;case 35674:return hM;case 35675:return fM;case 35676:return pM;case 5124:case 35670:return mM;case 35667:case 35671:return gM;case 35668:case 35672:return xM;case 35669:case 35673:return vM;case 5125:return _M;case 36294:return yM;case 36295:return bM;case 36296:return SM;case 35678:case 36198:case 36298:case 36306:case 35682:return MM;case 35679:case 36299:case 36307:return wM;case 35680:case 36300:case 36308:case 36293:return EM;case 36289:case 36303:case 36311:case 36292:return TM}}function CM(s,e){s.uniform1fv(this.addr,e)}function RM(s,e){const t=Aa(e,this.size,2);s.uniform2fv(this.addr,t)}function PM(s,e){const t=Aa(e,this.size,3);s.uniform3fv(this.addr,t)}function NM(s,e){const t=Aa(e,this.size,4);s.uniform4fv(this.addr,t)}function LM(s,e){const t=Aa(e,this.size,4);s.uniformMatrix2fv(this.addr,!1,t)}function DM(s,e){const t=Aa(e,this.size,9);s.uniformMatrix3fv(this.addr,!1,t)}function IM(s,e){const t=Aa(e,this.size,16);s.uniformMatrix4fv(this.addr,!1,t)}function kM(s,e){s.uniform1iv(this.addr,e)}function FM(s,e){s.uniform2iv(this.addr,e)}function UM(s,e){s.uniform3iv(this.addr,e)}function OM(s,e){s.uniform4iv(this.addr,e)}function BM(s,e){s.uniform1uiv(this.addr,e)}function zM(s,e){s.uniform2uiv(this.addr,e)}function jM(s,e){s.uniform3uiv(this.addr,e)}function HM(s,e){s.uniform4uiv(this.addr,e)}function GM(s,e,t){const r=this.cache,a=e.length,l=kc(t,a);Sn(r,l)||(s.uniform1iv(this.addr,l),Mn(r,l));let d;this.type===s.SAMPLER_2D_SHADOW?d=jh:d=Hg;for(let h=0;h!==a;++h)t.setTexture2D(e[h]||d,l[h])}function VM(s,e,t){const r=this.cache,a=e.length,l=kc(t,a);Sn(r,l)||(s.uniform1iv(this.addr,l),Mn(r,l));for(let d=0;d!==a;++d)t.setTexture3D(e[d]||Vg,l[d])}function WM(s,e,t){const r=this.cache,a=e.length,l=kc(t,a);Sn(r,l)||(s.uniform1iv(this.addr,l),Mn(r,l));for(let d=0;d!==a;++d)t.setTextureCube(e[d]||Wg,l[d])}function XM(s,e,t){const r=this.cache,a=e.length,l=kc(t,a);Sn(r,l)||(s.uniform1iv(this.addr,l),Mn(r,l));for(let d=0;d!==a;++d)t.setTexture2DArray(e[d]||Gg,l[d])}function qM(s){switch(s){case 5126:return CM;case 35664:return RM;case 35665:return PM;case 35666:return NM;case 35674:return LM;case 35675:return DM;case 35676:return IM;case 5124:case 35670:return kM;case 35667:case 35671:return FM;case 35668:case 35672:return UM;case 35669:case 35673:return OM;case 5125:return BM;case 36294:return zM;case 36295:return jM;case 36296:return HM;case 35678:case 36198:case 36298:case 36306:case 35682:return GM;case 35679:case 36299:case 36307:return VM;case 35680:case 36300:case 36308:case 36293:return WM;case 36289:case 36303:case 36311:case 36292:return XM}}class $M{constructor(e,t,r){this.id=e,this.addr=r,this.cache=[],this.type=t.type,this.setValue=AM(t.type)}}class YM{constructor(e,t,r){this.id=e,this.addr=r,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=qM(t.type)}}class KM{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,r){const a=this.seq;for(let l=0,d=a.length;l!==d;++l){const h=a[l];h.setValue(e,t[h.id],r)}}}const Xd=/(\w+)(\])?(\[|\.)?/g;function O0(s,e){s.seq.push(e),s.map[e.id]=e}function ZM(s,e,t){const r=s.name,a=r.length;for(Xd.lastIndex=0;;){const l=Xd.exec(r),d=Xd.lastIndex;let h=l[1];const f=l[2]==="]",m=l[3];if(f&&(h=h|0),m===void 0||m==="["&&d+2===a){O0(t,m===void 0?new $M(h,s,e):new YM(h,s,e));break}else{let S=t.map[h];S===void 0&&(S=new KM(h),O0(t,S)),t=S}}}class pc{constructor(e,t){this.seq=[],this.map={};const r=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let d=0;d<r;++d){const h=e.getActiveUniform(t,d),f=e.getUniformLocation(t,h.name);ZM(h,f,this)}const a=[],l=[];for(const d of this.seq)d.type===e.SAMPLER_2D_SHADOW||d.type===e.SAMPLER_CUBE_SHADOW||d.type===e.SAMPLER_2D_ARRAY_SHADOW?a.push(d):l.push(d);a.length>0&&(this.seq=a.concat(l))}setValue(e,t,r,a){const l=this.map[t];l!==void 0&&l.setValue(e,r,a)}setOptional(e,t,r){const a=t[r];a!==void 0&&this.setValue(e,r,a)}static upload(e,t,r,a){for(let l=0,d=t.length;l!==d;++l){const h=t[l],f=r[h.id];f.needsUpdate!==!1&&h.setValue(e,f.value,a)}}static seqWithValue(e,t){const r=[];for(let a=0,l=e.length;a!==l;++a){const d=e[a];d.id in t&&r.push(d)}return r}}function B0(s,e,t){const r=s.createShader(e);return s.shaderSource(r,t),s.compileShader(r),r}const QM=37297;let JM=0;function ew(s,e){const t=s.split(`
`),r=[],a=Math.max(e-6,0),l=Math.min(e+6,t.length);for(let d=a;d<l;d++){const h=d+1;r.push(`${h===e?">":" "} ${h}: ${t[d]}`)}return r.join(`
`)}const z0=new yt;function tw(s){Lt._getMatrix(z0,Lt.workingColorSpace,s);const e=`mat3( ${z0.elements.map(t=>t.toFixed(4))} )`;switch(Lt.getTransfer(s)){case wc:return[e,"LinearTransferOETF"];case Wt:return[e,"sRGBTransferOETF"];default:return gt("WebGLProgram: Unsupported color space: ",s),[e,"LinearTransferOETF"]}}function j0(s,e,t){const r=s.getShaderParameter(e,s.COMPILE_STATUS),l=(s.getShaderInfoLog(e)||"").trim();if(r&&l==="")return"";const d=/ERROR: 0:(\d+)/.exec(l);if(d){const h=parseInt(d[1]);return t.toUpperCase()+`

`+l+`

`+ew(s.getShaderSource(e),h)}else return l}function nw(s,e){const t=tw(e);return[`vec4 ${s}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}const iw={[dg]:"Linear",[hg]:"Reinhard",[fg]:"Cineon",[pg]:"ACESFilmic",[gg]:"AgX",[xg]:"Neutral",[mg]:"Custom"};function rw(s,e){const t=iw[e];return t===void 0?(gt("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+s+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+s+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const nc=new K;function sw(){Lt.getLuminanceCoefficients(nc);const s=nc.x.toFixed(4),e=nc.y.toFixed(4),t=nc.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${s}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function aw(s){return[s.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",s.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(_o).join(`
`)}function ow(s){const e=[];for(const t in s){const r=s[t];r!==!1&&e.push("#define "+t+" "+r)}return e.join(`
`)}function lw(s,e){const t={},r=s.getProgramParameter(e,s.ACTIVE_ATTRIBUTES);for(let a=0;a<r;a++){const l=s.getActiveAttrib(e,a),d=l.name;let h=1;l.type===s.FLOAT_MAT2&&(h=2),l.type===s.FLOAT_MAT3&&(h=3),l.type===s.FLOAT_MAT4&&(h=4),t[d]={type:l.type,location:s.getAttribLocation(e,d),locationSize:h}}return t}function _o(s){return s!==""}function H0(s,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return s.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function G0(s,e){return s.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const cw=/^[ \t]*#include +<([\w\d./]+)>/gm;function Hh(s){return s.replace(cw,dw)}const uw=new Map;function dw(s,e){let t=wt[e];if(t===void 0){const r=uw.get(e);if(r!==void 0)t=wt[r],gt('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,r);else throw new Error("THREE.WebGLProgram: Can not resolve #include <"+e+">")}return Hh(t)}const hw=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function V0(s){return s.replace(hw,fw)}function fw(s,e,t,r){let a="";for(let l=parseInt(e);l<parseInt(t);l++)a+=r.replace(/\[\s*i\s*\]/g,"[ "+l+" ]").replace(/UNROLLED_LOOP_INDEX/g,l);return a}function W0(s){let e=`precision ${s.precision} float;
	precision ${s.precision} int;
	precision ${s.precision} sampler2D;
	precision ${s.precision} samplerCube;
	precision ${s.precision} sampler3D;
	precision ${s.precision} sampler2DArray;
	precision ${s.precision} sampler2DShadow;
	precision ${s.precision} samplerCubeShadow;
	precision ${s.precision} sampler2DArrayShadow;
	precision ${s.precision} isampler2D;
	precision ${s.precision} isampler3D;
	precision ${s.precision} isamplerCube;
	precision ${s.precision} isampler2DArray;
	precision ${s.precision} usampler2D;
	precision ${s.precision} usampler3D;
	precision ${s.precision} usamplerCube;
	precision ${s.precision} usampler2DArray;
	`;return s.precision==="highp"?e+=`
#define HIGH_PRECISION`:s.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:s.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const pw={[lc]:"SHADOWMAP_TYPE_PCF",[vo]:"SHADOWMAP_TYPE_VSM"};function mw(s){return pw[s.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const gw={[Es]:"ENVMAP_TYPE_CUBE",[ba]:"ENVMAP_TYPE_CUBE",[Dc]:"ENVMAP_TYPE_CUBE_UV"};function xw(s){return s.envMap===!1?"ENVMAP_TYPE_CUBE":gw[s.envMapMode]||"ENVMAP_TYPE_CUBE"}const vw={[ba]:"ENVMAP_MODE_REFRACTION"};function _w(s){return s.envMap===!1?"ENVMAP_MODE_REFLECTION":vw[s.envMapMode]||"ENVMAP_MODE_REFLECTION"}const yw={[ug]:"ENVMAP_BLENDING_MULTIPLY",[ry]:"ENVMAP_BLENDING_MIX",[sy]:"ENVMAP_BLENDING_ADD"};function bw(s){return s.envMap===!1?"ENVMAP_BLENDING_NONE":yw[s.combine]||"ENVMAP_BLENDING_NONE"}function Sw(s){const e=s.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,r=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:r,maxMip:t}}function Mw(s,e,t,r){const a=s.getContext(),l=t.defines;let d=t.vertexShader,h=t.fragmentShader;const f=mw(t),m=xw(t),_=_w(t),S=bw(t),v=Sw(t),b=aw(t),M=ow(l),E=a.createProgram();let g,x,N=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(g=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,M].filter(_o).join(`
`),g.length>0&&(g+=`
`),x=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,M].filter(_o).join(`
`),x.length>0&&(x+=`
`)):(g=[W0(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,M,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+_:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexNormals?"#define HAS_NORMAL":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+f:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(_o).join(`
`),x=[W0(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,M,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+m:"",t.envMap?"#define "+_:"",t.envMap?"#define "+S:"",v?"#define CUBEUV_TEXEL_WIDTH "+v.texelWidth:"",v?"#define CUBEUV_TEXEL_HEIGHT "+v.texelHeight:"",v?"#define CUBEUV_MAX_MIP "+v.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas||t.batchingColor?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+f:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Ji?"#define TONE_MAPPING":"",t.toneMapping!==Ji?wt.tonemapping_pars_fragment:"",t.toneMapping!==Ji?rw("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",wt.colorspace_pars_fragment,nw("linearToOutputTexel",t.outputColorSpace),sw(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(_o).join(`
`)),d=Hh(d),d=H0(d,t),d=G0(d,t),h=Hh(h),h=H0(h,t),h=G0(h,t),d=V0(d),h=V0(h),t.isRawShaderMaterial!==!0&&(N=`#version 300 es
`,g=[b,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+g,x=["#define varying in",t.glslVersion===Zm?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Zm?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+x);const P=N+g+d,C=N+x+h,D=B0(a,a.VERTEX_SHADER,P),L=B0(a,a.FRAGMENT_SHADER,C);a.attachShader(E,D),a.attachShader(E,L),t.index0AttributeName!==void 0?a.bindAttribLocation(E,0,t.index0AttributeName):t.hasPositionAttribute===!0&&a.bindAttribLocation(E,0,"position"),a.linkProgram(E);function O(B){if(s.debug.checkShaderErrors){const V=a.getProgramInfoLog(E)||"",ae=a.getShaderInfoLog(D)||"",Q=a.getShaderInfoLog(L)||"",ie=V.trim(),de=ae.trim(),re=Q.trim();let X=!0,J=!0;if(a.getProgramParameter(E,a.LINK_STATUS)===!1)if(X=!1,typeof s.debug.onShaderError=="function")s.debug.onShaderError(a,E,D,L);else{const le=j0(a,D,"vertex"),U=j0(a,L,"fragment");kt("WebGLProgram: Shader Error "+a.getError()+" - VALIDATE_STATUS "+a.getProgramParameter(E,a.VALIDATE_STATUS)+`

Material Name: `+B.name+`
Material Type: `+B.type+`

Program Info Log: `+ie+`
`+le+`
`+U)}else ie!==""?gt("WebGLProgram: Program Info Log:",ie):(de===""||re==="")&&(J=!1);J&&(B.diagnostics={runnable:X,programLog:ie,vertexShader:{log:de,prefix:g},fragmentShader:{log:re,prefix:x}})}a.deleteShader(D),a.deleteShader(L),T=new pc(a,E),I=lw(a,E)}let T;this.getUniforms=function(){return T===void 0&&O(this),T};let I;this.getAttributes=function(){return I===void 0&&O(this),I};let H=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return H===!1&&(H=a.getProgramParameter(E,QM)),H},this.destroy=function(){r.releaseStatesOfProgram(this),a.deleteProgram(E),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=JM++,this.cacheKey=e,this.usedTimes=1,this.program=E,this.vertexShader=D,this.fragmentShader=L,this}let ww=0;class Ew{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,r){const a=this._getShaderCacheForMaterial(e);return a.has(t)===!1&&(a.add(t),t.usedTimes++),a.has(r)===!1&&(a.add(r),r.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const r of t)r.usedTimes--,r.usedTimes===0&&this.shaderCache.delete(r.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let r=t.get(e);return r===void 0&&(r=new Set,t.set(e,r)),r}_getShaderStage(e){const t=this.shaderCache;let r=t.get(e);return r===void 0&&(r=new Tw(e),t.set(e,r)),r}}class Tw{constructor(e){this.id=ww++,this.code=e,this.usedTimes=0}}function Aw(s){return s===Zr||s===bc||s===Sc}function Cw(s,e,t,r,a,l){const d=new of,h=new Ew,f=new Set,m=[],_=new Map,S=r.logarithmicDepthBuffer;let v=r.precision;const b={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function M(T){return f.add(T),T===0?"uv":`uv${T}`}function E(T,I,H,B,V,ae){const Q=B.fog,ie=V.geometry,de=T.isMeshStandardMaterial||T.isMeshLambertMaterial||T.isMeshPhongMaterial?B.environment:null,re=T.isMeshStandardMaterial||T.isMeshLambertMaterial&&!T.envMap||T.isMeshPhongMaterial&&!T.envMap,X=e.get(T.envMap||de,re),J=X&&X.mapping===Dc?X.image.height:null,le=b[T.type];T.precision!==null&&(v=r.getMaxPrecision(T.precision),v!==T.precision&&gt("WebGLProgram.getParameters:",T.precision,"not supported, using",v,"instead."));const U=ie.morphAttributes.position||ie.morphAttributes.normal||ie.morphAttributes.color,q=U!==void 0?U.length:0;let Re=0;ie.morphAttributes.position!==void 0&&(Re=1),ie.morphAttributes.normal!==void 0&&(Re=2),ie.morphAttributes.color!==void 0&&(Re=3);let qe,be,ee,me;if(le){const He=Ki[le];qe=He.vertexShader,be=He.fragmentShader}else{qe=T.vertexShader,be=T.fragmentShader;const He=h.getVertexShaderStage(T),Tt=h.getFragmentShaderStage(T);h.update(T,He,Tt),ee=He.id,me=Tt.id}const ve=s.getRenderTarget(),ce=s.state.buffers.depth.getReversed(),we=V.isInstancedMesh===!0,Ze=V.isBatchedMesh===!0,bt=!!T.map,ot=!!T.matcap,at=!!X,$e=!!T.aoMap,Mt=!!T.lightMap,St=!!T.bumpMap&&T.wireframe===!1,Dt=!!T.normalMap,It=!!T.displacementMap,Nt=!!T.emissiveMap,ht=!!T.metalnessMap,jt=!!T.roughnessMap,j=T.anisotropy>0,Qe=T.clearcoat>0,je=T.dispersion>0,k=T.iridescence>0,w=T.sheen>0,$=T.transmission>0,se=j&&!!T.anisotropyMap,he=Qe&&!!T.clearcoatMap,Me=Qe&&!!T.clearcoatNormalMap,Ee=Qe&&!!T.clearcoatRoughnessMap,_e=k&&!!T.iridescenceMap,fe=k&&!!T.iridescenceThicknessMap,ke=w&&!!T.sheenColorMap,We=w&&!!T.sheenRoughnessMap,Ue=!!T.specularMap,Le=!!T.specularColorMap,Xe=!!T.specularIntensityMap,tt=$&&!!T.transmissionMap,lt=$&&!!T.thicknessMap,F=!!T.gradientMap,ye=!!T.alphaMap,ge=T.alphaTest>0,Pe=!!T.alphaHash,Ae=!!T.extensions;let Se=Ji;T.toneMapped&&(ve===null||ve.isXRRenderTarget===!0)&&(Se=s.toneMapping);const Oe={shaderID:le,shaderType:T.type,shaderName:T.name,vertexShader:qe,fragmentShader:be,defines:T.defines,customVertexShaderID:ee,customFragmentShaderID:me,isRawShaderMaterial:T.isRawShaderMaterial===!0,glslVersion:T.glslVersion,precision:v,batching:Ze,batchingColor:Ze&&V._colorsTexture!==null,instancing:we,instancingColor:we&&V.instanceColor!==null,instancingMorph:we&&V.morphTexture!==null,outputColorSpace:ve===null?s.outputColorSpace:ve.isXRRenderTarget===!0?ve.texture.colorSpace:Lt.workingColorSpace,alphaToCoverage:!!T.alphaToCoverage,map:bt,matcap:ot,envMap:at,envMapMode:at&&X.mapping,envMapCubeUVHeight:J,aoMap:$e,lightMap:Mt,bumpMap:St,normalMap:Dt,displacementMap:It,emissiveMap:Nt,normalMapObjectSpace:Dt&&T.normalMapType===ly,normalMapTangentSpace:Dt&&T.normalMapType===$m,packedNormalMap:Dt&&T.normalMapType===$m&&Aw(T.normalMap.format),metalnessMap:ht,roughnessMap:jt,anisotropy:j,anisotropyMap:se,clearcoat:Qe,clearcoatMap:he,clearcoatNormalMap:Me,clearcoatRoughnessMap:Ee,dispersion:je,iridescence:k,iridescenceMap:_e,iridescenceThicknessMap:fe,sheen:w,sheenColorMap:ke,sheenRoughnessMap:We,specularMap:Ue,specularColorMap:Le,specularIntensityMap:Xe,transmission:$,transmissionMap:tt,thicknessMap:lt,gradientMap:F,opaque:T.transparent===!1&&T.blending===ws&&T.alphaToCoverage===!1,alphaMap:ye,alphaTest:ge,alphaHash:Pe,combine:T.combine,mapUv:bt&&M(T.map.channel),aoMapUv:$e&&M(T.aoMap.channel),lightMapUv:Mt&&M(T.lightMap.channel),bumpMapUv:St&&M(T.bumpMap.channel),normalMapUv:Dt&&M(T.normalMap.channel),displacementMapUv:It&&M(T.displacementMap.channel),emissiveMapUv:Nt&&M(T.emissiveMap.channel),metalnessMapUv:ht&&M(T.metalnessMap.channel),roughnessMapUv:jt&&M(T.roughnessMap.channel),anisotropyMapUv:se&&M(T.anisotropyMap.channel),clearcoatMapUv:he&&M(T.clearcoatMap.channel),clearcoatNormalMapUv:Me&&M(T.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ee&&M(T.clearcoatRoughnessMap.channel),iridescenceMapUv:_e&&M(T.iridescenceMap.channel),iridescenceThicknessMapUv:fe&&M(T.iridescenceThicknessMap.channel),sheenColorMapUv:ke&&M(T.sheenColorMap.channel),sheenRoughnessMapUv:We&&M(T.sheenRoughnessMap.channel),specularMapUv:Ue&&M(T.specularMap.channel),specularColorMapUv:Le&&M(T.specularColorMap.channel),specularIntensityMapUv:Xe&&M(T.specularIntensityMap.channel),transmissionMapUv:tt&&M(T.transmissionMap.channel),thicknessMapUv:lt&&M(T.thicknessMap.channel),alphaMapUv:ye&&M(T.alphaMap.channel),vertexTangents:!!ie.attributes.tangent&&(Dt||j),vertexNormals:!!ie.attributes.normal,vertexColors:T.vertexColors,vertexAlphas:T.vertexColors===!0&&!!ie.attributes.color&&ie.attributes.color.itemSize===4,pointsUvs:V.isPoints===!0&&!!ie.attributes.uv&&(bt||ye),fog:!!Q,useFog:T.fog===!0,fogExp2:!!Q&&Q.isFogExp2,flatShading:T.wireframe===!1&&(T.flatShading===!0||ie.attributes.normal===void 0&&Dt===!1&&(T.isMeshLambertMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isMeshPhysicalMaterial)),sizeAttenuation:T.sizeAttenuation===!0,logarithmicDepthBuffer:S,reversedDepthBuffer:ce,skinning:V.isSkinnedMesh===!0,hasPositionAttribute:ie.attributes.position!==void 0,morphTargets:ie.morphAttributes.position!==void 0,morphNormals:ie.morphAttributes.normal!==void 0,morphColors:ie.morphAttributes.color!==void 0,morphTargetsCount:q,morphTextureStride:Re,numDirLights:I.directional.length,numPointLights:I.point.length,numSpotLights:I.spot.length,numSpotLightMaps:I.spotLightMap.length,numRectAreaLights:I.rectArea.length,numHemiLights:I.hemi.length,numDirLightShadows:I.directionalShadowMap.length,numPointLightShadows:I.pointShadowMap.length,numSpotLightShadows:I.spotShadowMap.length,numSpotLightShadowsWithMaps:I.numSpotLightShadowsWithMaps,numLightProbes:I.numLightProbes,numLightProbeGrids:ae.length,numClippingPlanes:l.numPlanes,numClipIntersection:l.numIntersection,dithering:T.dithering,shadowMapEnabled:s.shadowMap.enabled&&H.length>0,shadowMapType:s.shadowMap.type,toneMapping:Se,decodeVideoTexture:bt&&T.map.isVideoTexture===!0&&Lt.getTransfer(T.map.colorSpace)===Wt,decodeVideoTextureEmissive:Nt&&T.emissiveMap.isVideoTexture===!0&&Lt.getTransfer(T.emissiveMap.colorSpace)===Wt,premultipliedAlpha:T.premultipliedAlpha,doubleSided:T.side===Oi,flipSided:T.side===si,useDepthPacking:T.depthPacking>=0,depthPacking:T.depthPacking||0,index0AttributeName:T.index0AttributeName,extensionClipCullDistance:Ae&&T.extensions.clipCullDistance===!0&&t.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Ae&&T.extensions.multiDraw===!0||Ze)&&t.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:t.has("KHR_parallel_shader_compile"),customProgramCacheKey:T.customProgramCacheKey()};return Oe.vertexUv1s=f.has(1),Oe.vertexUv2s=f.has(2),Oe.vertexUv3s=f.has(3),f.clear(),Oe}function g(T){const I=[];if(T.shaderID?I.push(T.shaderID):(I.push(T.customVertexShaderID),I.push(T.customFragmentShaderID)),T.defines!==void 0)for(const H in T.defines)I.push(H),I.push(T.defines[H]);return T.isRawShaderMaterial===!1&&(x(I,T),N(I,T),I.push(s.outputColorSpace)),I.push(T.customProgramCacheKey),I.join()}function x(T,I){T.push(I.precision),T.push(I.outputColorSpace),T.push(I.envMapMode),T.push(I.envMapCubeUVHeight),T.push(I.mapUv),T.push(I.alphaMapUv),T.push(I.lightMapUv),T.push(I.aoMapUv),T.push(I.bumpMapUv),T.push(I.normalMapUv),T.push(I.displacementMapUv),T.push(I.emissiveMapUv),T.push(I.metalnessMapUv),T.push(I.roughnessMapUv),T.push(I.anisotropyMapUv),T.push(I.clearcoatMapUv),T.push(I.clearcoatNormalMapUv),T.push(I.clearcoatRoughnessMapUv),T.push(I.iridescenceMapUv),T.push(I.iridescenceThicknessMapUv),T.push(I.sheenColorMapUv),T.push(I.sheenRoughnessMapUv),T.push(I.specularMapUv),T.push(I.specularColorMapUv),T.push(I.specularIntensityMapUv),T.push(I.transmissionMapUv),T.push(I.thicknessMapUv),T.push(I.combine),T.push(I.fogExp2),T.push(I.sizeAttenuation),T.push(I.morphTargetsCount),T.push(I.morphAttributeCount),T.push(I.numDirLights),T.push(I.numPointLights),T.push(I.numSpotLights),T.push(I.numSpotLightMaps),T.push(I.numHemiLights),T.push(I.numRectAreaLights),T.push(I.numDirLightShadows),T.push(I.numPointLightShadows),T.push(I.numSpotLightShadows),T.push(I.numSpotLightShadowsWithMaps),T.push(I.numLightProbes),T.push(I.shadowMapType),T.push(I.toneMapping),T.push(I.numClippingPlanes),T.push(I.numClipIntersection),T.push(I.depthPacking)}function N(T,I){d.disableAll(),I.instancing&&d.enable(0),I.instancingColor&&d.enable(1),I.instancingMorph&&d.enable(2),I.matcap&&d.enable(3),I.envMap&&d.enable(4),I.normalMapObjectSpace&&d.enable(5),I.normalMapTangentSpace&&d.enable(6),I.clearcoat&&d.enable(7),I.iridescence&&d.enable(8),I.alphaTest&&d.enable(9),I.vertexColors&&d.enable(10),I.vertexAlphas&&d.enable(11),I.vertexUv1s&&d.enable(12),I.vertexUv2s&&d.enable(13),I.vertexUv3s&&d.enable(14),I.vertexTangents&&d.enable(15),I.anisotropy&&d.enable(16),I.alphaHash&&d.enable(17),I.batching&&d.enable(18),I.dispersion&&d.enable(19),I.batchingColor&&d.enable(20),I.gradientMap&&d.enable(21),I.packedNormalMap&&d.enable(22),I.vertexNormals&&d.enable(23),T.push(d.mask),d.disableAll(),I.fog&&d.enable(0),I.useFog&&d.enable(1),I.flatShading&&d.enable(2),I.logarithmicDepthBuffer&&d.enable(3),I.reversedDepthBuffer&&d.enable(4),I.skinning&&d.enable(5),I.morphTargets&&d.enable(6),I.morphNormals&&d.enable(7),I.morphColors&&d.enable(8),I.premultipliedAlpha&&d.enable(9),I.shadowMapEnabled&&d.enable(10),I.doubleSided&&d.enable(11),I.flipSided&&d.enable(12),I.useDepthPacking&&d.enable(13),I.dithering&&d.enable(14),I.transmission&&d.enable(15),I.sheen&&d.enable(16),I.opaque&&d.enable(17),I.pointsUvs&&d.enable(18),I.decodeVideoTexture&&d.enable(19),I.decodeVideoTextureEmissive&&d.enable(20),I.alphaToCoverage&&d.enable(21),I.numLightProbeGrids>0&&d.enable(22),I.hasPositionAttribute&&d.enable(23),T.push(d.mask)}function P(T){const I=b[T.type];let H;if(I){const B=Ki[I];H=Rc.clone(B.uniforms)}else H=T.uniforms;return H}function C(T,I){let H=_.get(I);return H!==void 0?++H.usedTimes:(H=new Mw(s,I,T,a),m.push(H),_.set(I,H)),H}function D(T){if(--T.usedTimes===0){const I=m.indexOf(T);m[I]=m[m.length-1],m.pop(),_.delete(T.cacheKey),T.destroy()}}function L(T){h.remove(T)}function O(){h.dispose()}return{getParameters:E,getProgramCacheKey:g,getUniforms:P,acquireProgram:C,releaseProgram:D,releaseShaderCache:L,programs:m,dispose:O}}function Rw(){let s=new WeakMap;function e(d){return s.has(d)}function t(d){let h=s.get(d);return h===void 0&&(h={},s.set(d,h)),h}function r(d){s.delete(d)}function a(d,h,f){s.get(d)[h]=f}function l(){s=new WeakMap}return{has:e,get:t,remove:r,update:a,dispose:l}}function Pw(s,e){return s.groupOrder!==e.groupOrder?s.groupOrder-e.groupOrder:s.renderOrder!==e.renderOrder?s.renderOrder-e.renderOrder:s.material.id!==e.material.id?s.material.id-e.material.id:s.materialVariant!==e.materialVariant?s.materialVariant-e.materialVariant:s.z!==e.z?s.z-e.z:s.id-e.id}function X0(s,e){return s.groupOrder!==e.groupOrder?s.groupOrder-e.groupOrder:s.renderOrder!==e.renderOrder?s.renderOrder-e.renderOrder:s.z!==e.z?e.z-s.z:s.id-e.id}function q0(){const s=[];let e=0;const t=[],r=[],a=[];function l(){e=0,t.length=0,r.length=0,a.length=0}function d(v){let b=0;return v.isInstancedMesh&&(b+=2),v.isSkinnedMesh&&(b+=1),b}function h(v,b,M,E,g,x){let N=s[e];return N===void 0?(N={id:v.id,object:v,geometry:b,material:M,materialVariant:d(v),groupOrder:E,renderOrder:v.renderOrder,z:g,group:x},s[e]=N):(N.id=v.id,N.object=v,N.geometry=b,N.material=M,N.materialVariant=d(v),N.groupOrder=E,N.renderOrder=v.renderOrder,N.z=g,N.group=x),e++,N}function f(v,b,M,E,g,x){const N=h(v,b,M,E,g,x);M.transmission>0?r.push(N):M.transparent===!0?a.push(N):t.push(N)}function m(v,b,M,E,g,x){const N=h(v,b,M,E,g,x);M.transmission>0?r.unshift(N):M.transparent===!0?a.unshift(N):t.unshift(N)}function _(v,b,M){t.length>1&&t.sort(v||Pw),r.length>1&&r.sort(b||X0),a.length>1&&a.sort(b||X0),M&&(t.reverse(),r.reverse(),a.reverse())}function S(){for(let v=e,b=s.length;v<b;v++){const M=s[v];if(M.id===null)break;M.id=null,M.object=null,M.geometry=null,M.material=null,M.group=null}}return{opaque:t,transmissive:r,transparent:a,init:l,push:f,unshift:m,finish:S,sort:_}}function Nw(){let s=new WeakMap;function e(r,a){const l=s.get(r);let d;return l===void 0?(d=new q0,s.set(r,[d])):a>=l.length?(d=new q0,l.push(d)):d=l[a],d}function t(){s=new WeakMap}return{get:e,dispose:t}}function Lw(){const s={};return{get:function(e){if(s[e.id]!==void 0)return s[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new K,color:new vt};break;case"SpotLight":t={position:new K,direction:new K,color:new vt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new K,color:new vt,distance:0,decay:0};break;case"HemisphereLight":t={direction:new K,skyColor:new vt,groundColor:new vt};break;case"RectAreaLight":t={color:new vt,position:new K,halfWidth:new K,halfHeight:new K};break}return s[e.id]=t,t}}}function Dw(){const s={};return{get:function(e){if(s[e.id]!==void 0)return s[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ut};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ut};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ut,shadowCameraNear:1,shadowCameraFar:1e3};break}return s[e.id]=t,t}}}let Iw=0;function kw(s,e){return(e.castShadow?2:0)-(s.castShadow?2:0)+(e.map?1:0)-(s.map?1:0)}function Fw(s){const e=new Lw,t=Dw(),r={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let m=0;m<9;m++)r.probe.push(new K);const a=new K,l=new nn,d=new nn;function h(m){let _=0,S=0,v=0;for(let I=0;I<9;I++)r.probe[I].set(0,0,0);let b=0,M=0,E=0,g=0,x=0,N=0,P=0,C=0,D=0,L=0,O=0;m.sort(kw);for(let I=0,H=m.length;I<H;I++){const B=m[I],V=B.color,ae=B.intensity,Q=B.distance;let ie=null;if(B.shadow&&B.shadow.map&&(B.shadow.map.texture.format===Zr?ie=B.shadow.map.texture:ie=B.shadow.map.depthTexture||B.shadow.map.texture),B.isAmbientLight)_+=V.r*ae,S+=V.g*ae,v+=V.b*ae;else if(B.isLightProbe){for(let de=0;de<9;de++)r.probe[de].addScaledVector(B.sh.coefficients[de],ae);O++}else if(B.isDirectionalLight){const de=e.get(B);if(de.color.copy(B.color).multiplyScalar(B.intensity),B.castShadow){const re=B.shadow,X=t.get(B);X.shadowIntensity=re.intensity,X.shadowBias=re.bias,X.shadowNormalBias=re.normalBias,X.shadowRadius=re.radius,X.shadowMapSize=re.mapSize,r.directionalShadow[b]=X,r.directionalShadowMap[b]=ie,r.directionalShadowMatrix[b]=B.shadow.matrix,N++}r.directional[b]=de,b++}else if(B.isSpotLight){const de=e.get(B);de.position.setFromMatrixPosition(B.matrixWorld),de.color.copy(V).multiplyScalar(ae),de.distance=Q,de.coneCos=Math.cos(B.angle),de.penumbraCos=Math.cos(B.angle*(1-B.penumbra)),de.decay=B.decay,r.spot[E]=de;const re=B.shadow;if(B.map&&(r.spotLightMap[D]=B.map,D++,re.updateMatrices(B),B.castShadow&&L++),r.spotLightMatrix[E]=re.matrix,B.castShadow){const X=t.get(B);X.shadowIntensity=re.intensity,X.shadowBias=re.bias,X.shadowNormalBias=re.normalBias,X.shadowRadius=re.radius,X.shadowMapSize=re.mapSize,r.spotShadow[E]=X,r.spotShadowMap[E]=ie,C++}E++}else if(B.isRectAreaLight){const de=e.get(B);de.color.copy(V).multiplyScalar(ae),de.halfWidth.set(B.width*.5,0,0),de.halfHeight.set(0,B.height*.5,0),r.rectArea[g]=de,g++}else if(B.isPointLight){const de=e.get(B);if(de.color.copy(B.color).multiplyScalar(B.intensity),de.distance=B.distance,de.decay=B.decay,B.castShadow){const re=B.shadow,X=t.get(B);X.shadowIntensity=re.intensity,X.shadowBias=re.bias,X.shadowNormalBias=re.normalBias,X.shadowRadius=re.radius,X.shadowMapSize=re.mapSize,X.shadowCameraNear=re.camera.near,X.shadowCameraFar=re.camera.far,r.pointShadow[M]=X,r.pointShadowMap[M]=ie,r.pointShadowMatrix[M]=B.shadow.matrix,P++}r.point[M]=de,M++}else if(B.isHemisphereLight){const de=e.get(B);de.skyColor.copy(B.color).multiplyScalar(ae),de.groundColor.copy(B.groundColor).multiplyScalar(ae),r.hemi[x]=de,x++}}g>0&&(s.has("OES_texture_float_linear")===!0?(r.rectAreaLTC1=Ge.LTC_FLOAT_1,r.rectAreaLTC2=Ge.LTC_FLOAT_2):(r.rectAreaLTC1=Ge.LTC_HALF_1,r.rectAreaLTC2=Ge.LTC_HALF_2)),r.ambient[0]=_,r.ambient[1]=S,r.ambient[2]=v;const T=r.hash;(T.directionalLength!==b||T.pointLength!==M||T.spotLength!==E||T.rectAreaLength!==g||T.hemiLength!==x||T.numDirectionalShadows!==N||T.numPointShadows!==P||T.numSpotShadows!==C||T.numSpotMaps!==D||T.numLightProbes!==O)&&(r.directional.length=b,r.spot.length=E,r.rectArea.length=g,r.point.length=M,r.hemi.length=x,r.directionalShadow.length=N,r.directionalShadowMap.length=N,r.pointShadow.length=P,r.pointShadowMap.length=P,r.spotShadow.length=C,r.spotShadowMap.length=C,r.directionalShadowMatrix.length=N,r.pointShadowMatrix.length=P,r.spotLightMatrix.length=C+D-L,r.spotLightMap.length=D,r.numSpotLightShadowsWithMaps=L,r.numLightProbes=O,T.directionalLength=b,T.pointLength=M,T.spotLength=E,T.rectAreaLength=g,T.hemiLength=x,T.numDirectionalShadows=N,T.numPointShadows=P,T.numSpotShadows=C,T.numSpotMaps=D,T.numLightProbes=O,r.version=Iw++)}function f(m,_){let S=0,v=0,b=0,M=0,E=0;const g=_.matrixWorldInverse;for(let x=0,N=m.length;x<N;x++){const P=m[x];if(P.isDirectionalLight){const C=r.directional[S];C.direction.setFromMatrixPosition(P.matrixWorld),a.setFromMatrixPosition(P.target.matrixWorld),C.direction.sub(a),C.direction.transformDirection(g),S++}else if(P.isSpotLight){const C=r.spot[b];C.position.setFromMatrixPosition(P.matrixWorld),C.position.applyMatrix4(g),C.direction.setFromMatrixPosition(P.matrixWorld),a.setFromMatrixPosition(P.target.matrixWorld),C.direction.sub(a),C.direction.transformDirection(g),b++}else if(P.isRectAreaLight){const C=r.rectArea[M];C.position.setFromMatrixPosition(P.matrixWorld),C.position.applyMatrix4(g),d.identity(),l.copy(P.matrixWorld),l.premultiply(g),d.extractRotation(l),C.halfWidth.set(P.width*.5,0,0),C.halfHeight.set(0,P.height*.5,0),C.halfWidth.applyMatrix4(d),C.halfHeight.applyMatrix4(d),M++}else if(P.isPointLight){const C=r.point[v];C.position.setFromMatrixPosition(P.matrixWorld),C.position.applyMatrix4(g),v++}else if(P.isHemisphereLight){const C=r.hemi[E];C.direction.setFromMatrixPosition(P.matrixWorld),C.direction.transformDirection(g),E++}}}return{setup:h,setupView:f,state:r}}function $0(s){const e=new Fw(s),t=[],r=[],a=[];function l(v){S.camera=v,t.length=0,r.length=0,a.length=0}function d(v){t.push(v)}function h(v){r.push(v)}function f(v){a.push(v)}function m(){e.setup(t)}function _(v){e.setupView(t,v)}const S={lightsArray:t,shadowsArray:r,lightProbeGridArray:a,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:l,state:S,setupLights:m,setupLightsView:_,pushLight:d,pushShadow:h,pushLightProbeGrid:f}}function Uw(s){let e=new WeakMap;function t(a,l=0){const d=e.get(a);let h;return d===void 0?(h=new $0(s),e.set(a,[h])):l>=d.length?(h=new $0(s),d.push(h)):h=d[l],h}function r(){e=new WeakMap}return{get:t,dispose:r}}const Ow=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Bw=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,zw=[new K(1,0,0),new K(-1,0,0),new K(0,1,0),new K(0,-1,0),new K(0,0,1),new K(0,0,-1)],jw=[new K(0,-1,0),new K(0,-1,0),new K(0,0,1),new K(0,0,-1),new K(0,-1,0),new K(0,-1,0)],Y0=new nn,mo=new K,qd=new K;function Hw(s,e,t){let r=new Lg;const a=new ut,l=new ut,d=new dn,h=new Zy,f=new Qy,m={},_=t.maxTextureSize,S={[Kr]:si,[si]:Kr,[Oi]:Oi},v=new bn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new ut},radius:{value:4}},vertexShader:Ow,fragmentShader:Bw}),b=v.clone();b.defines.HORIZONTAL_PASS=1;const M=new Hn;M.setAttribute("position",new Cn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const E=new Ti(M,v),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=lc;let x=this.type;this.render=function(L,O,T){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||L.length===0)return;this.type===B_&&(gt("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=lc);const I=s.getRenderTarget(),H=s.getActiveCubeFace(),B=s.getActiveMipmapLevel(),V=s.state;V.setBlending(Qi),V.buffers.depth.getReversed()===!0?V.buffers.color.setClear(0,0,0,0):V.buffers.color.setClear(1,1,1,1),V.buffers.depth.setTest(!0),V.setScissorTest(!1);const ae=x!==this.type;ae&&O.traverse(function(Q){Q.material&&(Array.isArray(Q.material)?Q.material.forEach(ie=>ie.needsUpdate=!0):Q.material.needsUpdate=!0)});for(let Q=0,ie=L.length;Q<ie;Q++){const de=L[Q],re=de.shadow;if(re===void 0){gt("WebGLShadowMap:",de,"has no shadow.");continue}if(re.autoUpdate===!1&&re.needsUpdate===!1)continue;a.copy(re.mapSize);const X=re.getFrameExtents();a.multiply(X),l.copy(re.mapSize),(a.x>_||a.y>_)&&(a.x>_&&(l.x=Math.floor(_/X.x),a.x=l.x*X.x,re.mapSize.x=l.x),a.y>_&&(l.y=Math.floor(_/X.y),a.y=l.y*X.y,re.mapSize.y=l.y));const J=s.state.buffers.depth.getReversed();if(re.camera._reversedDepth=J,re.map===null||ae===!0){if(re.map!==null&&(re.map.depthTexture!==null&&(re.map.depthTexture.dispose(),re.map.depthTexture=null),re.map.dispose()),this.type===vo){if(de.isPointLight){gt("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}re.map=new ai(a.x,a.y,{format:Zr,type:pi,minFilter:jn,magFilter:jn,generateMipmaps:!1}),re.map.texture.name=de.name+".shadowMap",re.map.depthTexture=new Sa(a.x,a.y,zi),re.map.depthTexture.name=de.name+".shadowMapDepth",re.map.depthTexture.format=vr,re.map.depthTexture.compareFunction=null,re.map.depthTexture.minFilter=Ln,re.map.depthTexture.magFilter=Ln}else de.isPointLight?(re.map=new jg(a.x),re.map.depthTexture=new Xy(a.x,er)):(re.map=new ai(a.x,a.y),re.map.depthTexture=new Sa(a.x,a.y,er)),re.map.depthTexture.name=de.name+".shadowMap",re.map.depthTexture.format=vr,this.type===lc?(re.map.depthTexture.compareFunction=J?sf:rf,re.map.depthTexture.minFilter=jn,re.map.depthTexture.magFilter=jn):(re.map.depthTexture.compareFunction=null,re.map.depthTexture.minFilter=Ln,re.map.depthTexture.magFilter=Ln);re.camera.updateProjectionMatrix()}const le=re.map.isWebGLCubeRenderTarget?6:1;for(let U=0;U<le;U++){if(re.map.isWebGLCubeRenderTarget)s.setRenderTarget(re.map,U),s.clear();else{U===0&&(s.setRenderTarget(re.map),s.clear());const q=re.getViewport(U);d.set(l.x*q.x,l.y*q.y,l.x*q.z,l.y*q.w),V.viewport(d)}if(de.isPointLight){const q=re.camera,Re=re.matrix,qe=de.distance||q.far;qe!==q.far&&(q.far=qe,q.updateProjectionMatrix()),mo.setFromMatrixPosition(de.matrixWorld),q.position.copy(mo),qd.copy(q.position),qd.add(zw[U]),q.up.copy(jw[U]),q.lookAt(qd),q.updateMatrixWorld(),Re.makeTranslation(-mo.x,-mo.y,-mo.z),Y0.multiplyMatrices(q.projectionMatrix,q.matrixWorldInverse),re._frustum.setFromProjectionMatrix(Y0,q.coordinateSystem,q.reversedDepth)}else re.updateMatrices(de);r=re.getFrustum(),C(O,T,re.camera,de,this.type)}re.isPointLightShadow!==!0&&this.type===vo&&N(re,T),re.needsUpdate=!1}x=this.type,g.needsUpdate=!1,s.setRenderTarget(I,H,B)};function N(L,O){const T=e.update(E);v.defines.VSM_SAMPLES!==L.blurSamples&&(v.defines.VSM_SAMPLES=L.blurSamples,b.defines.VSM_SAMPLES=L.blurSamples,v.needsUpdate=!0,b.needsUpdate=!0),L.mapPass===null&&(L.mapPass=new ai(a.x,a.y,{format:Zr,type:pi})),v.uniforms.shadow_pass.value=L.map.depthTexture,v.uniforms.resolution.value=L.mapSize,v.uniforms.radius.value=L.radius,s.setRenderTarget(L.mapPass),s.clear(),s.renderBufferDirect(O,null,T,v,E,null),b.uniforms.shadow_pass.value=L.mapPass.texture,b.uniforms.resolution.value=L.mapSize,b.uniforms.radius.value=L.radius,s.setRenderTarget(L.map),s.clear(),s.renderBufferDirect(O,null,T,b,E,null)}function P(L,O,T,I){let H=null;const B=T.isPointLight===!0?L.customDistanceMaterial:L.customDepthMaterial;if(B!==void 0)H=B;else if(H=T.isPointLight===!0?f:h,s.localClippingEnabled&&O.clipShadows===!0&&Array.isArray(O.clippingPlanes)&&O.clippingPlanes.length!==0||O.displacementMap&&O.displacementScale!==0||O.alphaMap&&O.alphaTest>0||O.map&&O.alphaTest>0||O.alphaToCoverage===!0){const V=H.uuid,ae=O.uuid;let Q=m[V];Q===void 0&&(Q={},m[V]=Q);let ie=Q[ae];ie===void 0&&(ie=H.clone(),Q[ae]=ie,O.addEventListener("dispose",D)),H=ie}if(H.visible=O.visible,H.wireframe=O.wireframe,I===vo?H.side=O.shadowSide!==null?O.shadowSide:O.side:H.side=O.shadowSide!==null?O.shadowSide:S[O.side],H.alphaMap=O.alphaMap,H.alphaTest=O.alphaToCoverage===!0?.5:O.alphaTest,H.map=O.map,H.clipShadows=O.clipShadows,H.clippingPlanes=O.clippingPlanes,H.clipIntersection=O.clipIntersection,H.displacementMap=O.displacementMap,H.displacementScale=O.displacementScale,H.displacementBias=O.displacementBias,H.wireframeLinewidth=O.wireframeLinewidth,H.linewidth=O.linewidth,T.isPointLight===!0&&H.isMeshDistanceMaterial===!0){const V=s.properties.get(H);V.light=T}return H}function C(L,O,T,I,H){if(L.visible===!1)return;if(L.layers.test(O.layers)&&(L.isMesh||L.isLine||L.isPoints)&&(L.castShadow||L.receiveShadow&&H===vo)&&(!L.frustumCulled||r.intersectsObject(L))){L.modelViewMatrix.multiplyMatrices(T.matrixWorldInverse,L.matrixWorld);const ae=e.update(L),Q=L.material;if(Array.isArray(Q)){const ie=ae.groups;for(let de=0,re=ie.length;de<re;de++){const X=ie[de],J=Q[X.materialIndex];if(J&&J.visible){const le=P(L,J,I,H);L.onBeforeShadow(s,L,O,T,ae,le,X),s.renderBufferDirect(T,null,ae,le,L,X),L.onAfterShadow(s,L,O,T,ae,le,X)}}}else if(Q.visible){const ie=P(L,Q,I,H);L.onBeforeShadow(s,L,O,T,ae,ie,null),s.renderBufferDirect(T,null,ae,ie,L,null),L.onAfterShadow(s,L,O,T,ae,ie,null)}}const V=L.children;for(let ae=0,Q=V.length;ae<Q;ae++)C(V[ae],O,T,I,H)}function D(L){L.target.removeEventListener("dispose",D);for(const T in m){const I=m[T],H=L.target.uuid;H in I&&(I[H].dispose(),delete I[H])}}}function Gw(s,e){function t(){let F=!1;const ye=new dn;let ge=null;const Pe=new dn(0,0,0,0);return{setMask:function(Ae){ge!==Ae&&!F&&(s.colorMask(Ae,Ae,Ae,Ae),ge=Ae)},setLocked:function(Ae){F=Ae},setClear:function(Ae,Se,Oe,He,Tt){Tt===!0&&(Ae*=He,Se*=He,Oe*=He),ye.set(Ae,Se,Oe,He),Pe.equals(ye)===!1&&(s.clearColor(Ae,Se,Oe,He),Pe.copy(ye))},reset:function(){F=!1,ge=null,Pe.set(-1,0,0,0)}}}function r(){let F=!1,ye=!1,ge=null,Pe=null,Ae=null;return{setReversed:function(Se){if(ye!==Se){const Oe=e.get("EXT_clip_control");Se?Oe.clipControlEXT(Oe.LOWER_LEFT_EXT,Oe.ZERO_TO_ONE_EXT):Oe.clipControlEXT(Oe.LOWER_LEFT_EXT,Oe.NEGATIVE_ONE_TO_ONE_EXT),ye=Se;const He=Ae;Ae=null,this.setClear(He)}},getReversed:function(){return ye},setTest:function(Se){Se?ve(s.DEPTH_TEST):ce(s.DEPTH_TEST)},setMask:function(Se){ge!==Se&&!F&&(s.depthMask(Se),ge=Se)},setFunc:function(Se){if(ye&&(Se=vy[Se]),Pe!==Se){switch(Se){case Jd:s.depthFunc(s.NEVER);break;case eh:s.depthFunc(s.ALWAYS);break;case th:s.depthFunc(s.LESS);break;case ya:s.depthFunc(s.LEQUAL);break;case nh:s.depthFunc(s.EQUAL);break;case ih:s.depthFunc(s.GEQUAL);break;case rh:s.depthFunc(s.GREATER);break;case sh:s.depthFunc(s.NOTEQUAL);break;default:s.depthFunc(s.LEQUAL)}Pe=Se}},setLocked:function(Se){F=Se},setClear:function(Se){Ae!==Se&&(Ae=Se,ye&&(Se=1-Se),s.clearDepth(Se))},reset:function(){F=!1,ge=null,Pe=null,Ae=null,ye=!1}}}function a(){let F=!1,ye=null,ge=null,Pe=null,Ae=null,Se=null,Oe=null,He=null,Tt=null;return{setTest:function(dt){F||(dt?ve(s.STENCIL_TEST):ce(s.STENCIL_TEST))},setMask:function(dt){ye!==dt&&!F&&(s.stencilMask(dt),ye=dt)},setFunc:function(dt,Ft,ln){(ge!==dt||Pe!==Ft||Ae!==ln)&&(s.stencilFunc(dt,Ft,ln),ge=dt,Pe=Ft,Ae=ln)},setOp:function(dt,Ft,ln){(Se!==dt||Oe!==Ft||He!==ln)&&(s.stencilOp(dt,Ft,ln),Se=dt,Oe=Ft,He=ln)},setLocked:function(dt){F=dt},setClear:function(dt){Tt!==dt&&(s.clearStencil(dt),Tt=dt)},reset:function(){F=!1,ye=null,ge=null,Pe=null,Ae=null,Se=null,Oe=null,He=null,Tt=null}}}const l=new t,d=new r,h=new a,f=new WeakMap,m=new WeakMap;let _={},S={},v={},b=new WeakMap,M=[],E=null,g=!1,x=null,N=null,P=null,C=null,D=null,L=null,O=null,T=new vt(0,0,0),I=0,H=!1,B=null,V=null,ae=null,Q=null,ie=null;const de=s.getParameter(s.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let re=!1,X=0;const J=s.getParameter(s.VERSION);J.indexOf("WebGL")!==-1?(X=parseFloat(/^WebGL (\d)/.exec(J)[1]),re=X>=1):J.indexOf("OpenGL ES")!==-1&&(X=parseFloat(/^OpenGL ES (\d)/.exec(J)[1]),re=X>=2);let le=null,U={};const q=s.getParameter(s.SCISSOR_BOX),Re=s.getParameter(s.VIEWPORT),qe=new dn().fromArray(q),be=new dn().fromArray(Re);function ee(F,ye,ge,Pe){const Ae=new Uint8Array(4),Se=s.createTexture();s.bindTexture(F,Se),s.texParameteri(F,s.TEXTURE_MIN_FILTER,s.NEAREST),s.texParameteri(F,s.TEXTURE_MAG_FILTER,s.NEAREST);for(let Oe=0;Oe<ge;Oe++)F===s.TEXTURE_3D||F===s.TEXTURE_2D_ARRAY?s.texImage3D(ye,0,s.RGBA,1,1,Pe,0,s.RGBA,s.UNSIGNED_BYTE,Ae):s.texImage2D(ye+Oe,0,s.RGBA,1,1,0,s.RGBA,s.UNSIGNED_BYTE,Ae);return Se}const me={};me[s.TEXTURE_2D]=ee(s.TEXTURE_2D,s.TEXTURE_2D,1),me[s.TEXTURE_CUBE_MAP]=ee(s.TEXTURE_CUBE_MAP,s.TEXTURE_CUBE_MAP_POSITIVE_X,6),me[s.TEXTURE_2D_ARRAY]=ee(s.TEXTURE_2D_ARRAY,s.TEXTURE_2D_ARRAY,1,1),me[s.TEXTURE_3D]=ee(s.TEXTURE_3D,s.TEXTURE_3D,1,1),l.setClear(0,0,0,1),d.setClear(1),h.setClear(0),ve(s.DEPTH_TEST),d.setFunc(ya),St(!1),Dt(Wm),ve(s.CULL_FACE),$e(Qi);function ve(F){_[F]!==!0&&(s.enable(F),_[F]=!0)}function ce(F){_[F]!==!1&&(s.disable(F),_[F]=!1)}function we(F,ye){return v[F]!==ye?(s.bindFramebuffer(F,ye),v[F]=ye,F===s.DRAW_FRAMEBUFFER&&(v[s.FRAMEBUFFER]=ye),F===s.FRAMEBUFFER&&(v[s.DRAW_FRAMEBUFFER]=ye),!0):!1}function Ze(F,ye){let ge=M,Pe=!1;if(F){ge=b.get(ye),ge===void 0&&(ge=[],b.set(ye,ge));const Ae=F.textures;if(ge.length!==Ae.length||ge[0]!==s.COLOR_ATTACHMENT0){for(let Se=0,Oe=Ae.length;Se<Oe;Se++)ge[Se]=s.COLOR_ATTACHMENT0+Se;ge.length=Ae.length,Pe=!0}}else ge[0]!==s.BACK&&(ge[0]=s.BACK,Pe=!0);Pe&&s.drawBuffers(ge)}function bt(F){return E!==F?(s.useProgram(F),E=F,!0):!1}const ot={[vs]:s.FUNC_ADD,[j_]:s.FUNC_SUBTRACT,[H_]:s.FUNC_REVERSE_SUBTRACT};ot[G_]=s.MIN,ot[V_]=s.MAX;const at={[W_]:s.ZERO,[X_]:s.ONE,[q_]:s.SRC_COLOR,[Zd]:s.SRC_ALPHA,[J_]:s.SRC_ALPHA_SATURATE,[Z_]:s.DST_COLOR,[Y_]:s.DST_ALPHA,[$_]:s.ONE_MINUS_SRC_COLOR,[Qd]:s.ONE_MINUS_SRC_ALPHA,[Q_]:s.ONE_MINUS_DST_COLOR,[K_]:s.ONE_MINUS_DST_ALPHA,[ey]:s.CONSTANT_COLOR,[ty]:s.ONE_MINUS_CONSTANT_COLOR,[ny]:s.CONSTANT_ALPHA,[iy]:s.ONE_MINUS_CONSTANT_ALPHA};function $e(F,ye,ge,Pe,Ae,Se,Oe,He,Tt,dt){if(F===Qi){g===!0&&(ce(s.BLEND),g=!1);return}if(g===!1&&(ve(s.BLEND),g=!0),F!==z_){if(F!==x||dt!==H){if((N!==vs||D!==vs)&&(s.blendEquation(s.FUNC_ADD),N=vs,D=vs),dt)switch(F){case ws:s.blendFuncSeparate(s.ONE,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case yc:s.blendFunc(s.ONE,s.ONE);break;case Xm:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case qm:s.blendFuncSeparate(s.DST_COLOR,s.ONE_MINUS_SRC_ALPHA,s.ZERO,s.ONE);break;default:kt("WebGLState: Invalid blending: ",F);break}else switch(F){case ws:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case yc:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE,s.ONE,s.ONE);break;case Xm:kt("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case qm:kt("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:kt("WebGLState: Invalid blending: ",F);break}P=null,C=null,L=null,O=null,T.set(0,0,0),I=0,x=F,H=dt}return}Ae=Ae||ye,Se=Se||ge,Oe=Oe||Pe,(ye!==N||Ae!==D)&&(s.blendEquationSeparate(ot[ye],ot[Ae]),N=ye,D=Ae),(ge!==P||Pe!==C||Se!==L||Oe!==O)&&(s.blendFuncSeparate(at[ge],at[Pe],at[Se],at[Oe]),P=ge,C=Pe,L=Se,O=Oe),(He.equals(T)===!1||Tt!==I)&&(s.blendColor(He.r,He.g,He.b,Tt),T.copy(He),I=Tt),x=F,H=!1}function Mt(F,ye){F.side===Oi?ce(s.CULL_FACE):ve(s.CULL_FACE);let ge=F.side===si;ye&&(ge=!ge),St(ge),F.blending===ws&&F.transparent===!1?$e(Qi):$e(F.blending,F.blendEquation,F.blendSrc,F.blendDst,F.blendEquationAlpha,F.blendSrcAlpha,F.blendDstAlpha,F.blendColor,F.blendAlpha,F.premultipliedAlpha),d.setFunc(F.depthFunc),d.setTest(F.depthTest),d.setMask(F.depthWrite),l.setMask(F.colorWrite);const Pe=F.stencilWrite;h.setTest(Pe),Pe&&(h.setMask(F.stencilWriteMask),h.setFunc(F.stencilFunc,F.stencilRef,F.stencilFuncMask),h.setOp(F.stencilFail,F.stencilZFail,F.stencilZPass)),Nt(F.polygonOffset,F.polygonOffsetFactor,F.polygonOffsetUnits),F.alphaToCoverage===!0?ve(s.SAMPLE_ALPHA_TO_COVERAGE):ce(s.SAMPLE_ALPHA_TO_COVERAGE)}function St(F){B!==F&&(F?s.frontFace(s.CW):s.frontFace(s.CCW),B=F)}function Dt(F){F!==U_?(ve(s.CULL_FACE),F!==V&&(F===Wm?s.cullFace(s.BACK):F===O_?s.cullFace(s.FRONT):s.cullFace(s.FRONT_AND_BACK))):ce(s.CULL_FACE),V=F}function It(F){F!==ae&&(re&&s.lineWidth(F),ae=F)}function Nt(F,ye,ge){F?(ve(s.POLYGON_OFFSET_FILL),(Q!==ye||ie!==ge)&&(Q=ye,ie=ge,d.getReversed()&&(ye=-ye),s.polygonOffset(ye,ge))):ce(s.POLYGON_OFFSET_FILL)}function ht(F){F?ve(s.SCISSOR_TEST):ce(s.SCISSOR_TEST)}function jt(F){F===void 0&&(F=s.TEXTURE0+de-1),le!==F&&(s.activeTexture(F),le=F)}function j(F,ye,ge){ge===void 0&&(le===null?ge=s.TEXTURE0+de-1:ge=le);let Pe=U[ge];Pe===void 0&&(Pe={type:void 0,texture:void 0},U[ge]=Pe),(Pe.type!==F||Pe.texture!==ye)&&(le!==ge&&(s.activeTexture(ge),le=ge),s.bindTexture(F,ye||me[F]),Pe.type=F,Pe.texture=ye)}function Qe(){const F=U[le];F!==void 0&&F.type!==void 0&&(s.bindTexture(F.type,null),F.type=void 0,F.texture=void 0)}function je(){try{s.compressedTexImage2D(...arguments)}catch(F){kt("WebGLState:",F)}}function k(){try{s.compressedTexImage3D(...arguments)}catch(F){kt("WebGLState:",F)}}function w(){try{s.texSubImage2D(...arguments)}catch(F){kt("WebGLState:",F)}}function $(){try{s.texSubImage3D(...arguments)}catch(F){kt("WebGLState:",F)}}function se(){try{s.compressedTexSubImage2D(...arguments)}catch(F){kt("WebGLState:",F)}}function he(){try{s.compressedTexSubImage3D(...arguments)}catch(F){kt("WebGLState:",F)}}function Me(){try{s.texStorage2D(...arguments)}catch(F){kt("WebGLState:",F)}}function Ee(){try{s.texStorage3D(...arguments)}catch(F){kt("WebGLState:",F)}}function _e(){try{s.texImage2D(...arguments)}catch(F){kt("WebGLState:",F)}}function fe(){try{s.texImage3D(...arguments)}catch(F){kt("WebGLState:",F)}}function ke(F){return S[F]!==void 0?S[F]:s.getParameter(F)}function We(F,ye){S[F]!==ye&&(s.pixelStorei(F,ye),S[F]=ye)}function Ue(F){qe.equals(F)===!1&&(s.scissor(F.x,F.y,F.z,F.w),qe.copy(F))}function Le(F){be.equals(F)===!1&&(s.viewport(F.x,F.y,F.z,F.w),be.copy(F))}function Xe(F,ye){let ge=m.get(ye);ge===void 0&&(ge=new WeakMap,m.set(ye,ge));let Pe=ge.get(F);Pe===void 0&&(Pe=s.getUniformBlockIndex(ye,F.name),ge.set(F,Pe))}function tt(F,ye){const Pe=m.get(ye).get(F);f.get(ye)!==Pe&&(s.uniformBlockBinding(ye,Pe,F.__bindingPointIndex),f.set(ye,Pe))}function lt(){s.disable(s.BLEND),s.disable(s.CULL_FACE),s.disable(s.DEPTH_TEST),s.disable(s.POLYGON_OFFSET_FILL),s.disable(s.SCISSOR_TEST),s.disable(s.STENCIL_TEST),s.disable(s.SAMPLE_ALPHA_TO_COVERAGE),s.blendEquation(s.FUNC_ADD),s.blendFunc(s.ONE,s.ZERO),s.blendFuncSeparate(s.ONE,s.ZERO,s.ONE,s.ZERO),s.blendColor(0,0,0,0),s.colorMask(!0,!0,!0,!0),s.clearColor(0,0,0,0),s.depthMask(!0),s.depthFunc(s.LESS),d.setReversed(!1),s.clearDepth(1),s.stencilMask(4294967295),s.stencilFunc(s.ALWAYS,0,4294967295),s.stencilOp(s.KEEP,s.KEEP,s.KEEP),s.clearStencil(0),s.cullFace(s.BACK),s.frontFace(s.CCW),s.polygonOffset(0,0),s.activeTexture(s.TEXTURE0),s.bindFramebuffer(s.FRAMEBUFFER,null),s.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),s.bindFramebuffer(s.READ_FRAMEBUFFER,null),s.useProgram(null),s.lineWidth(1),s.scissor(0,0,s.canvas.width,s.canvas.height),s.viewport(0,0,s.canvas.width,s.canvas.height),s.pixelStorei(s.PACK_ALIGNMENT,4),s.pixelStorei(s.UNPACK_ALIGNMENT,4),s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,!1),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,s.BROWSER_DEFAULT_WEBGL),s.pixelStorei(s.PACK_ROW_LENGTH,0),s.pixelStorei(s.PACK_SKIP_PIXELS,0),s.pixelStorei(s.PACK_SKIP_ROWS,0),s.pixelStorei(s.UNPACK_ROW_LENGTH,0),s.pixelStorei(s.UNPACK_IMAGE_HEIGHT,0),s.pixelStorei(s.UNPACK_SKIP_PIXELS,0),s.pixelStorei(s.UNPACK_SKIP_ROWS,0),s.pixelStorei(s.UNPACK_SKIP_IMAGES,0),_={},S={},le=null,U={},v={},b=new WeakMap,M=[],E=null,g=!1,x=null,N=null,P=null,C=null,D=null,L=null,O=null,T=new vt(0,0,0),I=0,H=!1,B=null,V=null,ae=null,Q=null,ie=null,qe.set(0,0,s.canvas.width,s.canvas.height),be.set(0,0,s.canvas.width,s.canvas.height),l.reset(),d.reset(),h.reset()}return{buffers:{color:l,depth:d,stencil:h},enable:ve,disable:ce,bindFramebuffer:we,drawBuffers:Ze,useProgram:bt,setBlending:$e,setMaterial:Mt,setFlipSided:St,setCullFace:Dt,setLineWidth:It,setPolygonOffset:Nt,setScissorTest:ht,activeTexture:jt,bindTexture:j,unbindTexture:Qe,compressedTexImage2D:je,compressedTexImage3D:k,texImage2D:_e,texImage3D:fe,pixelStorei:We,getParameter:ke,updateUBOMapping:Xe,uniformBlockBinding:tt,texStorage2D:Me,texStorage3D:Ee,texSubImage2D:w,texSubImage3D:$,compressedTexSubImage2D:se,compressedTexSubImage3D:he,scissor:Ue,viewport:Le,reset:lt}}function Vw(s,e,t,r,a,l,d){const h=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,f=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),m=new ut,_=new WeakMap,S=new Set;let v;const b=new WeakMap;let M=!1;try{M=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function E(k,w){return M?new OffscreenCanvas(k,w):Tc("canvas")}function g(k,w,$){let se=1;const he=je(k);if((he.width>$||he.height>$)&&(se=$/Math.max(he.width,he.height)),se<1)if(typeof HTMLImageElement<"u"&&k instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&k instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&k instanceof ImageBitmap||typeof VideoFrame<"u"&&k instanceof VideoFrame){const Me=Math.floor(se*he.width),Ee=Math.floor(se*he.height);v===void 0&&(v=E(Me,Ee));const _e=w?E(Me,Ee):v;return _e.width=Me,_e.height=Ee,_e.getContext("2d").drawImage(k,0,0,Me,Ee),gt("WebGLRenderer: Texture has been resized from ("+he.width+"x"+he.height+") to ("+Me+"x"+Ee+")."),_e}else return"data"in k&&gt("WebGLRenderer: Image in DataTexture is too big ("+he.width+"x"+he.height+")."),k;return k}function x(k){return k.generateMipmaps}function N(k){s.generateMipmap(k)}function P(k){return k.isWebGLCubeRenderTarget?s.TEXTURE_CUBE_MAP:k.isWebGL3DRenderTarget?s.TEXTURE_3D:k.isWebGLArrayRenderTarget||k.isCompressedArrayTexture?s.TEXTURE_2D_ARRAY:s.TEXTURE_2D}function C(k,w,$,se,he,Me=!1){if(k!==null){if(s[k]!==void 0)return s[k];gt("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+k+"'")}let Ee;se&&(Ee=e.get("EXT_texture_norm16"),Ee||gt("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let _e=w;if(w===s.RED&&($===s.FLOAT&&(_e=s.R32F),$===s.HALF_FLOAT&&(_e=s.R16F),$===s.UNSIGNED_BYTE&&(_e=s.R8),$===s.UNSIGNED_SHORT&&Ee&&(_e=Ee.R16_EXT),$===s.SHORT&&Ee&&(_e=Ee.R16_SNORM_EXT)),w===s.RED_INTEGER&&($===s.UNSIGNED_BYTE&&(_e=s.R8UI),$===s.UNSIGNED_SHORT&&(_e=s.R16UI),$===s.UNSIGNED_INT&&(_e=s.R32UI),$===s.BYTE&&(_e=s.R8I),$===s.SHORT&&(_e=s.R16I),$===s.INT&&(_e=s.R32I)),w===s.RG&&($===s.FLOAT&&(_e=s.RG32F),$===s.HALF_FLOAT&&(_e=s.RG16F),$===s.UNSIGNED_BYTE&&(_e=s.RG8),$===s.UNSIGNED_SHORT&&Ee&&(_e=Ee.RG16_EXT),$===s.SHORT&&Ee&&(_e=Ee.RG16_SNORM_EXT)),w===s.RG_INTEGER&&($===s.UNSIGNED_BYTE&&(_e=s.RG8UI),$===s.UNSIGNED_SHORT&&(_e=s.RG16UI),$===s.UNSIGNED_INT&&(_e=s.RG32UI),$===s.BYTE&&(_e=s.RG8I),$===s.SHORT&&(_e=s.RG16I),$===s.INT&&(_e=s.RG32I)),w===s.RGB_INTEGER&&($===s.UNSIGNED_BYTE&&(_e=s.RGB8UI),$===s.UNSIGNED_SHORT&&(_e=s.RGB16UI),$===s.UNSIGNED_INT&&(_e=s.RGB32UI),$===s.BYTE&&(_e=s.RGB8I),$===s.SHORT&&(_e=s.RGB16I),$===s.INT&&(_e=s.RGB32I)),w===s.RGBA_INTEGER&&($===s.UNSIGNED_BYTE&&(_e=s.RGBA8UI),$===s.UNSIGNED_SHORT&&(_e=s.RGBA16UI),$===s.UNSIGNED_INT&&(_e=s.RGBA32UI),$===s.BYTE&&(_e=s.RGBA8I),$===s.SHORT&&(_e=s.RGBA16I),$===s.INT&&(_e=s.RGBA32I)),w===s.RGB&&($===s.UNSIGNED_SHORT&&Ee&&(_e=Ee.RGB16_EXT),$===s.SHORT&&Ee&&(_e=Ee.RGB16_SNORM_EXT),$===s.UNSIGNED_INT_5_9_9_9_REV&&(_e=s.RGB9_E5),$===s.UNSIGNED_INT_10F_11F_11F_REV&&(_e=s.R11F_G11F_B10F)),w===s.RGBA){const fe=Me?wc:Lt.getTransfer(he);$===s.FLOAT&&(_e=s.RGBA32F),$===s.HALF_FLOAT&&(_e=s.RGBA16F),$===s.UNSIGNED_BYTE&&(_e=fe===Wt?s.SRGB8_ALPHA8:s.RGBA8),$===s.UNSIGNED_SHORT&&Ee&&(_e=Ee.RGBA16_EXT),$===s.SHORT&&Ee&&(_e=Ee.RGBA16_SNORM_EXT),$===s.UNSIGNED_SHORT_4_4_4_4&&(_e=s.RGBA4),$===s.UNSIGNED_SHORT_5_5_5_1&&(_e=s.RGB5_A1)}return(_e===s.R16F||_e===s.R32F||_e===s.RG16F||_e===s.RG32F||_e===s.RGBA16F||_e===s.RGBA32F)&&e.get("EXT_color_buffer_float"),_e}function D(k,w){let $;return k?w===null||w===er||w===bo?$=s.DEPTH24_STENCIL8:w===zi?$=s.DEPTH32F_STENCIL8:w===yo&&($=s.DEPTH24_STENCIL8,gt("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):w===null||w===er||w===bo?$=s.DEPTH_COMPONENT24:w===zi?$=s.DEPTH_COMPONENT32F:w===yo&&($=s.DEPTH_COMPONENT16),$}function L(k,w){return x(k)===!0||k.isFramebufferTexture&&k.minFilter!==Ln&&k.minFilter!==jn?Math.log2(Math.max(w.width,w.height))+1:k.mipmaps!==void 0&&k.mipmaps.length>0?k.mipmaps.length:k.isCompressedTexture&&Array.isArray(k.image)?w.mipmaps.length:1}function O(k){const w=k.target;w.removeEventListener("dispose",O),I(w),w.isVideoTexture&&_.delete(w),w.isHTMLTexture&&S.delete(w)}function T(k){const w=k.target;w.removeEventListener("dispose",T),B(w)}function I(k){const w=r.get(k);if(w.__webglInit===void 0)return;const $=k.source,se=b.get($);if(se){const he=se[w.__cacheKey];he.usedTimes--,he.usedTimes===0&&H(k),Object.keys(se).length===0&&b.delete($)}r.remove(k)}function H(k){const w=r.get(k);s.deleteTexture(w.__webglTexture);const $=k.source,se=b.get($);delete se[w.__cacheKey],d.memory.textures--}function B(k){const w=r.get(k);if(k.depthTexture&&(k.depthTexture.dispose(),r.remove(k.depthTexture)),k.isWebGLCubeRenderTarget)for(let se=0;se<6;se++){if(Array.isArray(w.__webglFramebuffer[se]))for(let he=0;he<w.__webglFramebuffer[se].length;he++)s.deleteFramebuffer(w.__webglFramebuffer[se][he]);else s.deleteFramebuffer(w.__webglFramebuffer[se]);w.__webglDepthbuffer&&s.deleteRenderbuffer(w.__webglDepthbuffer[se])}else{if(Array.isArray(w.__webglFramebuffer))for(let se=0;se<w.__webglFramebuffer.length;se++)s.deleteFramebuffer(w.__webglFramebuffer[se]);else s.deleteFramebuffer(w.__webglFramebuffer);if(w.__webglDepthbuffer&&s.deleteRenderbuffer(w.__webglDepthbuffer),w.__webglMultisampledFramebuffer&&s.deleteFramebuffer(w.__webglMultisampledFramebuffer),w.__webglColorRenderbuffer)for(let se=0;se<w.__webglColorRenderbuffer.length;se++)w.__webglColorRenderbuffer[se]&&s.deleteRenderbuffer(w.__webglColorRenderbuffer[se]);w.__webglDepthRenderbuffer&&s.deleteRenderbuffer(w.__webglDepthRenderbuffer)}const $=k.textures;for(let se=0,he=$.length;se<he;se++){const Me=r.get($[se]);Me.__webglTexture&&(s.deleteTexture(Me.__webglTexture),d.memory.textures--),r.remove($[se])}r.remove(k)}let V=0;function ae(){V=0}function Q(){return V}function ie(k){V=k}function de(){const k=V;return k>=a.maxTextures&&gt("WebGLTextures: Trying to use "+k+" texture units while this GPU supports only "+a.maxTextures),V+=1,k}function re(k){const w=[];return w.push(k.wrapS),w.push(k.wrapT),w.push(k.wrapR||0),w.push(k.magFilter),w.push(k.minFilter),w.push(k.anisotropy),w.push(k.internalFormat),w.push(k.format),w.push(k.type),w.push(k.generateMipmaps),w.push(k.premultiplyAlpha),w.push(k.flipY),w.push(k.unpackAlignment),w.push(k.colorSpace),w.join()}function X(k,w){const $=r.get(k);if(k.isVideoTexture&&j(k),k.isRenderTargetTexture===!1&&k.isExternalTexture!==!0&&k.version>0&&$.__version!==k.version){const se=k.image;if(se===null)gt("WebGLRenderer: Texture marked for update but no image data found.");else if(se.complete===!1)gt("WebGLRenderer: Texture marked for update but image is incomplete");else{ce($,k,w);return}}else k.isExternalTexture&&($.__webglTexture=k.sourceTexture?k.sourceTexture:null);t.bindTexture(s.TEXTURE_2D,$.__webglTexture,s.TEXTURE0+w)}function J(k,w){const $=r.get(k);if(k.isRenderTargetTexture===!1&&k.version>0&&$.__version!==k.version){ce($,k,w);return}else k.isExternalTexture&&($.__webglTexture=k.sourceTexture?k.sourceTexture:null);t.bindTexture(s.TEXTURE_2D_ARRAY,$.__webglTexture,s.TEXTURE0+w)}function le(k,w){const $=r.get(k);if(k.isRenderTargetTexture===!1&&k.version>0&&$.__version!==k.version){ce($,k,w);return}t.bindTexture(s.TEXTURE_3D,$.__webglTexture,s.TEXTURE0+w)}function U(k,w){const $=r.get(k);if(k.isCubeDepthTexture!==!0&&k.version>0&&$.__version!==k.version){we($,k,w);return}t.bindTexture(s.TEXTURE_CUBE_MAP,$.__webglTexture,s.TEXTURE0+w)}const q={[ah]:s.REPEAT,[mr]:s.CLAMP_TO_EDGE,[oh]:s.MIRRORED_REPEAT},Re={[Ln]:s.NEAREST,[ay]:s.NEAREST_MIPMAP_NEAREST,[Pl]:s.NEAREST_MIPMAP_LINEAR,[jn]:s.LINEAR,[xd]:s.LINEAR_MIPMAP_NEAREST,[Ss]:s.LINEAR_MIPMAP_LINEAR},qe={[cy]:s.NEVER,[py]:s.ALWAYS,[uy]:s.LESS,[rf]:s.LEQUAL,[dy]:s.EQUAL,[sf]:s.GEQUAL,[hy]:s.GREATER,[fy]:s.NOTEQUAL};function be(k,w){if(w.type===zi&&e.has("OES_texture_float_linear")===!1&&(w.magFilter===jn||w.magFilter===xd||w.magFilter===Pl||w.magFilter===Ss||w.minFilter===jn||w.minFilter===xd||w.minFilter===Pl||w.minFilter===Ss)&&gt("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),s.texParameteri(k,s.TEXTURE_WRAP_S,q[w.wrapS]),s.texParameteri(k,s.TEXTURE_WRAP_T,q[w.wrapT]),(k===s.TEXTURE_3D||k===s.TEXTURE_2D_ARRAY)&&s.texParameteri(k,s.TEXTURE_WRAP_R,q[w.wrapR]),s.texParameteri(k,s.TEXTURE_MAG_FILTER,Re[w.magFilter]),s.texParameteri(k,s.TEXTURE_MIN_FILTER,Re[w.minFilter]),w.compareFunction&&(s.texParameteri(k,s.TEXTURE_COMPARE_MODE,s.COMPARE_REF_TO_TEXTURE),s.texParameteri(k,s.TEXTURE_COMPARE_FUNC,qe[w.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(w.magFilter===Ln||w.minFilter!==Pl&&w.minFilter!==Ss||w.type===zi&&e.has("OES_texture_float_linear")===!1)return;if(w.anisotropy>1||r.get(w).__currentAnisotropy){const $=e.get("EXT_texture_filter_anisotropic");s.texParameterf(k,$.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(w.anisotropy,a.getMaxAnisotropy())),r.get(w).__currentAnisotropy=w.anisotropy}}}function ee(k,w){let $=!1;k.__webglInit===void 0&&(k.__webglInit=!0,w.addEventListener("dispose",O));const se=w.source;let he=b.get(se);he===void 0&&(he={},b.set(se,he));const Me=re(w);if(Me!==k.__cacheKey){he[Me]===void 0&&(he[Me]={texture:s.createTexture(),usedTimes:0},d.memory.textures++,$=!0),he[Me].usedTimes++;const Ee=he[k.__cacheKey];Ee!==void 0&&(he[k.__cacheKey].usedTimes--,Ee.usedTimes===0&&H(w)),k.__cacheKey=Me,k.__webglTexture=he[Me].texture}return $}function me(k,w,$){return Math.floor(Math.floor(k/$)/w)}function ve(k,w,$,se){const Me=k.updateRanges;if(Me.length===0)t.texSubImage2D(s.TEXTURE_2D,0,0,0,w.width,w.height,$,se,w.data);else{Me.sort((We,Ue)=>We.start-Ue.start);let Ee=0;for(let We=1;We<Me.length;We++){const Ue=Me[Ee],Le=Me[We],Xe=Ue.start+Ue.count,tt=me(Le.start,w.width,4),lt=me(Ue.start,w.width,4);Le.start<=Xe+1&&tt===lt&&me(Le.start+Le.count-1,w.width,4)===tt?Ue.count=Math.max(Ue.count,Le.start+Le.count-Ue.start):(++Ee,Me[Ee]=Le)}Me.length=Ee+1;const _e=t.getParameter(s.UNPACK_ROW_LENGTH),fe=t.getParameter(s.UNPACK_SKIP_PIXELS),ke=t.getParameter(s.UNPACK_SKIP_ROWS);t.pixelStorei(s.UNPACK_ROW_LENGTH,w.width);for(let We=0,Ue=Me.length;We<Ue;We++){const Le=Me[We],Xe=Math.floor(Le.start/4),tt=Math.ceil(Le.count/4),lt=Xe%w.width,F=Math.floor(Xe/w.width),ye=tt,ge=1;t.pixelStorei(s.UNPACK_SKIP_PIXELS,lt),t.pixelStorei(s.UNPACK_SKIP_ROWS,F),t.texSubImage2D(s.TEXTURE_2D,0,lt,F,ye,ge,$,se,w.data)}k.clearUpdateRanges(),t.pixelStorei(s.UNPACK_ROW_LENGTH,_e),t.pixelStorei(s.UNPACK_SKIP_PIXELS,fe),t.pixelStorei(s.UNPACK_SKIP_ROWS,ke)}}function ce(k,w,$){let se=s.TEXTURE_2D;(w.isDataArrayTexture||w.isCompressedArrayTexture)&&(se=s.TEXTURE_2D_ARRAY),w.isData3DTexture&&(se=s.TEXTURE_3D);const he=ee(k,w),Me=w.source;t.bindTexture(se,k.__webglTexture,s.TEXTURE0+$);const Ee=r.get(Me);if(Me.version!==Ee.__version||he===!0){if(t.activeTexture(s.TEXTURE0+$),(typeof ImageBitmap<"u"&&w.image instanceof ImageBitmap)===!1){const ge=Lt.getPrimaries(Lt.workingColorSpace),Pe=w.colorSpace===qr?null:Lt.getPrimaries(w.colorSpace),Ae=w.colorSpace===qr||ge===Pe?s.NONE:s.BROWSER_DEFAULT_WEBGL;t.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,w.flipY),t.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,w.premultiplyAlpha),t.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ae)}t.pixelStorei(s.UNPACK_ALIGNMENT,w.unpackAlignment);let fe=g(w.image,!1,a.maxTextureSize);fe=Qe(w,fe);const ke=l.convert(w.format,w.colorSpace),We=l.convert(w.type);let Ue=C(w.internalFormat,ke,We,w.normalized,w.colorSpace,w.isVideoTexture);be(se,w);let Le;const Xe=w.mipmaps,tt=w.isVideoTexture!==!0,lt=Ee.__version===void 0||he===!0,F=Me.dataReady,ye=L(w,fe);if(w.isDepthTexture)Ue=D(w.format===Ms,w.type),lt&&(tt?t.texStorage2D(s.TEXTURE_2D,1,Ue,fe.width,fe.height):t.texImage2D(s.TEXTURE_2D,0,Ue,fe.width,fe.height,0,ke,We,null));else if(w.isDataTexture)if(Xe.length>0){tt&&lt&&t.texStorage2D(s.TEXTURE_2D,ye,Ue,Xe[0].width,Xe[0].height);for(let ge=0,Pe=Xe.length;ge<Pe;ge++)Le=Xe[ge],tt?F&&t.texSubImage2D(s.TEXTURE_2D,ge,0,0,Le.width,Le.height,ke,We,Le.data):t.texImage2D(s.TEXTURE_2D,ge,Ue,Le.width,Le.height,0,ke,We,Le.data);w.generateMipmaps=!1}else tt?(lt&&t.texStorage2D(s.TEXTURE_2D,ye,Ue,fe.width,fe.height),F&&ve(w,fe,ke,We)):t.texImage2D(s.TEXTURE_2D,0,Ue,fe.width,fe.height,0,ke,We,fe.data);else if(w.isCompressedTexture)if(w.isCompressedArrayTexture){tt&&lt&&t.texStorage3D(s.TEXTURE_2D_ARRAY,ye,Ue,Xe[0].width,Xe[0].height,fe.depth);for(let ge=0,Pe=Xe.length;ge<Pe;ge++)if(Le=Xe[ge],w.format!==ji)if(ke!==null)if(tt){if(F)if(w.layerUpdates.size>0){const Ae=T0(Le.width,Le.height,w.format,w.type);for(const Se of w.layerUpdates){const Oe=Le.data.subarray(Se*Ae/Le.data.BYTES_PER_ELEMENT,(Se+1)*Ae/Le.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,ge,0,0,Se,Le.width,Le.height,1,ke,Oe)}w.clearLayerUpdates()}else t.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,ge,0,0,0,Le.width,Le.height,fe.depth,ke,Le.data)}else t.compressedTexImage3D(s.TEXTURE_2D_ARRAY,ge,Ue,Le.width,Le.height,fe.depth,0,Le.data,0,0);else gt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else tt?F&&t.texSubImage3D(s.TEXTURE_2D_ARRAY,ge,0,0,0,Le.width,Le.height,fe.depth,ke,We,Le.data):t.texImage3D(s.TEXTURE_2D_ARRAY,ge,Ue,Le.width,Le.height,fe.depth,0,ke,We,Le.data)}else{tt&&lt&&t.texStorage2D(s.TEXTURE_2D,ye,Ue,Xe[0].width,Xe[0].height);for(let ge=0,Pe=Xe.length;ge<Pe;ge++)Le=Xe[ge],w.format!==ji?ke!==null?tt?F&&t.compressedTexSubImage2D(s.TEXTURE_2D,ge,0,0,Le.width,Le.height,ke,Le.data):t.compressedTexImage2D(s.TEXTURE_2D,ge,Ue,Le.width,Le.height,0,Le.data):gt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):tt?F&&t.texSubImage2D(s.TEXTURE_2D,ge,0,0,Le.width,Le.height,ke,We,Le.data):t.texImage2D(s.TEXTURE_2D,ge,Ue,Le.width,Le.height,0,ke,We,Le.data)}else if(w.isDataArrayTexture)if(tt){if(lt&&t.texStorage3D(s.TEXTURE_2D_ARRAY,ye,Ue,fe.width,fe.height,fe.depth),F)if(w.layerUpdates.size>0){const ge=T0(fe.width,fe.height,w.format,w.type);for(const Pe of w.layerUpdates){const Ae=fe.data.subarray(Pe*ge/fe.data.BYTES_PER_ELEMENT,(Pe+1)*ge/fe.data.BYTES_PER_ELEMENT);t.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,Pe,fe.width,fe.height,1,ke,We,Ae)}w.clearLayerUpdates()}else t.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,0,fe.width,fe.height,fe.depth,ke,We,fe.data)}else t.texImage3D(s.TEXTURE_2D_ARRAY,0,Ue,fe.width,fe.height,fe.depth,0,ke,We,fe.data);else if(w.isData3DTexture)tt?(lt&&t.texStorage3D(s.TEXTURE_3D,ye,Ue,fe.width,fe.height,fe.depth),F&&t.texSubImage3D(s.TEXTURE_3D,0,0,0,0,fe.width,fe.height,fe.depth,ke,We,fe.data)):t.texImage3D(s.TEXTURE_3D,0,Ue,fe.width,fe.height,fe.depth,0,ke,We,fe.data);else if(w.isFramebufferTexture){if(lt)if(tt)t.texStorage2D(s.TEXTURE_2D,ye,Ue,fe.width,fe.height);else{let ge=fe.width,Pe=fe.height;for(let Ae=0;Ae<ye;Ae++)t.texImage2D(s.TEXTURE_2D,Ae,Ue,ge,Pe,0,ke,We,null),ge>>=1,Pe>>=1}}else if(w.isHTMLTexture){if("texElementImage2D"in s){const ge=s.canvas;if(ge.hasAttribute("layoutsubtree")||ge.setAttribute("layoutsubtree","true"),fe.parentNode!==ge){ge.appendChild(fe),S.add(w),ge.onpaint=Pe=>{const Ae=Pe.changedElements;for(const Se of S)Ae.includes(Se.image)&&(Se.needsUpdate=!0)},ge.requestPaint();return}if(s.texElementImage2D.length===3)s.texElementImage2D(s.TEXTURE_2D,s.RGBA8,fe);else{const Ae=s.RGBA,Se=s.RGBA,Oe=s.UNSIGNED_BYTE;s.texElementImage2D(s.TEXTURE_2D,0,Ae,Se,Oe,fe)}s.texParameteri(s.TEXTURE_2D,s.TEXTURE_MIN_FILTER,s.LINEAR),s.texParameteri(s.TEXTURE_2D,s.TEXTURE_WRAP_S,s.CLAMP_TO_EDGE),s.texParameteri(s.TEXTURE_2D,s.TEXTURE_WRAP_T,s.CLAMP_TO_EDGE)}}else if(Xe.length>0){if(tt&&lt){const ge=je(Xe[0]);t.texStorage2D(s.TEXTURE_2D,ye,Ue,ge.width,ge.height)}for(let ge=0,Pe=Xe.length;ge<Pe;ge++)Le=Xe[ge],tt?F&&t.texSubImage2D(s.TEXTURE_2D,ge,0,0,ke,We,Le):t.texImage2D(s.TEXTURE_2D,ge,Ue,ke,We,Le);w.generateMipmaps=!1}else if(tt){if(lt){const ge=je(fe);t.texStorage2D(s.TEXTURE_2D,ye,Ue,ge.width,ge.height)}F&&t.texSubImage2D(s.TEXTURE_2D,0,0,0,ke,We,fe)}else t.texImage2D(s.TEXTURE_2D,0,Ue,ke,We,fe);x(w)&&N(se),Ee.__version=Me.version,w.onUpdate&&w.onUpdate(w)}k.__version=w.version}function we(k,w,$){if(w.image.length!==6)return;const se=ee(k,w),he=w.source;t.bindTexture(s.TEXTURE_CUBE_MAP,k.__webglTexture,s.TEXTURE0+$);const Me=r.get(he);if(he.version!==Me.__version||se===!0){t.activeTexture(s.TEXTURE0+$);const Ee=Lt.getPrimaries(Lt.workingColorSpace),_e=w.colorSpace===qr?null:Lt.getPrimaries(w.colorSpace),fe=w.colorSpace===qr||Ee===_e?s.NONE:s.BROWSER_DEFAULT_WEBGL;t.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,w.flipY),t.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,w.premultiplyAlpha),t.pixelStorei(s.UNPACK_ALIGNMENT,w.unpackAlignment),t.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,fe);const ke=w.isCompressedTexture||w.image[0].isCompressedTexture,We=w.image[0]&&w.image[0].isDataTexture,Ue=[];for(let Se=0;Se<6;Se++)!ke&&!We?Ue[Se]=g(w.image[Se],!0,a.maxCubemapSize):Ue[Se]=We?w.image[Se].image:w.image[Se],Ue[Se]=Qe(w,Ue[Se]);const Le=Ue[0],Xe=l.convert(w.format,w.colorSpace),tt=l.convert(w.type),lt=C(w.internalFormat,Xe,tt,w.normalized,w.colorSpace),F=w.isVideoTexture!==!0,ye=Me.__version===void 0||se===!0,ge=he.dataReady;let Pe=L(w,Le);be(s.TEXTURE_CUBE_MAP,w);let Ae;if(ke){F&&ye&&t.texStorage2D(s.TEXTURE_CUBE_MAP,Pe,lt,Le.width,Le.height);for(let Se=0;Se<6;Se++){Ae=Ue[Se].mipmaps;for(let Oe=0;Oe<Ae.length;Oe++){const He=Ae[Oe];w.format!==ji?Xe!==null?F?ge&&t.compressedTexSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Se,Oe,0,0,He.width,He.height,Xe,He.data):t.compressedTexImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Se,Oe,lt,He.width,He.height,0,He.data):gt("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):F?ge&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Se,Oe,0,0,He.width,He.height,Xe,tt,He.data):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Se,Oe,lt,He.width,He.height,0,Xe,tt,He.data)}}}else{if(Ae=w.mipmaps,F&&ye){Ae.length>0&&Pe++;const Se=je(Ue[0]);t.texStorage2D(s.TEXTURE_CUBE_MAP,Pe,lt,Se.width,Se.height)}for(let Se=0;Se<6;Se++)if(We){F?ge&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Se,0,0,0,Ue[Se].width,Ue[Se].height,Xe,tt,Ue[Se].data):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Se,0,lt,Ue[Se].width,Ue[Se].height,0,Xe,tt,Ue[Se].data);for(let Oe=0;Oe<Ae.length;Oe++){const Tt=Ae[Oe].image[Se].image;F?ge&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Se,Oe+1,0,0,Tt.width,Tt.height,Xe,tt,Tt.data):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Se,Oe+1,lt,Tt.width,Tt.height,0,Xe,tt,Tt.data)}}else{F?ge&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Se,0,0,0,Xe,tt,Ue[Se]):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Se,0,lt,Xe,tt,Ue[Se]);for(let Oe=0;Oe<Ae.length;Oe++){const He=Ae[Oe];F?ge&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Se,Oe+1,0,0,Xe,tt,He.image[Se]):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Se,Oe+1,lt,Xe,tt,He.image[Se])}}}x(w)&&N(s.TEXTURE_CUBE_MAP),Me.__version=he.version,w.onUpdate&&w.onUpdate(w)}k.__version=w.version}function Ze(k,w,$,se,he,Me){const Ee=l.convert($.format,$.colorSpace),_e=l.convert($.type),fe=C($.internalFormat,Ee,_e,$.normalized,$.colorSpace),ke=r.get(w),We=r.get($);if(We.__renderTarget=w,!ke.__hasExternalTextures){const Ue=Math.max(1,w.width>>Me),Le=Math.max(1,w.height>>Me);he===s.TEXTURE_3D||he===s.TEXTURE_2D_ARRAY?t.texImage3D(he,Me,fe,Ue,Le,w.depth,0,Ee,_e,null):t.texImage2D(he,Me,fe,Ue,Le,0,Ee,_e,null)}t.bindFramebuffer(s.FRAMEBUFFER,k),jt(w)?h.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,se,he,We.__webglTexture,0,ht(w)):(he===s.TEXTURE_2D||he>=s.TEXTURE_CUBE_MAP_POSITIVE_X&&he<=s.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&s.framebufferTexture2D(s.FRAMEBUFFER,se,he,We.__webglTexture,Me),t.bindFramebuffer(s.FRAMEBUFFER,null)}function bt(k,w,$){if(s.bindRenderbuffer(s.RENDERBUFFER,k),w.depthBuffer){const se=w.depthTexture,he=se&&se.isDepthTexture?se.type:null,Me=D(w.stencilBuffer,he),Ee=w.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;jt(w)?h.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,ht(w),Me,w.width,w.height):$?s.renderbufferStorageMultisample(s.RENDERBUFFER,ht(w),Me,w.width,w.height):s.renderbufferStorage(s.RENDERBUFFER,Me,w.width,w.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,Ee,s.RENDERBUFFER,k)}else{const se=w.textures;for(let he=0;he<se.length;he++){const Me=se[he],Ee=l.convert(Me.format,Me.colorSpace),_e=l.convert(Me.type),fe=C(Me.internalFormat,Ee,_e,Me.normalized,Me.colorSpace);jt(w)?h.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,ht(w),fe,w.width,w.height):$?s.renderbufferStorageMultisample(s.RENDERBUFFER,ht(w),fe,w.width,w.height):s.renderbufferStorage(s.RENDERBUFFER,fe,w.width,w.height)}}s.bindRenderbuffer(s.RENDERBUFFER,null)}function ot(k,w,$){const se=w.isWebGLCubeRenderTarget===!0;if(t.bindFramebuffer(s.FRAMEBUFFER,k),!(w.depthTexture&&w.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const he=r.get(w.depthTexture);if(he.__renderTarget=w,(!he.__webglTexture||w.depthTexture.image.width!==w.width||w.depthTexture.image.height!==w.height)&&(w.depthTexture.image.width=w.width,w.depthTexture.image.height=w.height,w.depthTexture.needsUpdate=!0),se){if(he.__webglInit===void 0&&(he.__webglInit=!0,w.depthTexture.addEventListener("dispose",O)),he.__webglTexture===void 0){he.__webglTexture=s.createTexture(),t.bindTexture(s.TEXTURE_CUBE_MAP,he.__webglTexture),be(s.TEXTURE_CUBE_MAP,w.depthTexture);const ke=l.convert(w.depthTexture.format),We=l.convert(w.depthTexture.type);let Ue;w.depthTexture.format===vr?Ue=s.DEPTH_COMPONENT24:w.depthTexture.format===Ms&&(Ue=s.DEPTH24_STENCIL8);for(let Le=0;Le<6;Le++)s.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Le,0,Ue,w.width,w.height,0,ke,We,null)}}else X(w.depthTexture,0);const Me=he.__webglTexture,Ee=ht(w),_e=se?s.TEXTURE_CUBE_MAP_POSITIVE_X+$:s.TEXTURE_2D,fe=w.depthTexture.format===Ms?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;if(w.depthTexture.format===vr)jt(w)?h.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,fe,_e,Me,0,Ee):s.framebufferTexture2D(s.FRAMEBUFFER,fe,_e,Me,0);else if(w.depthTexture.format===Ms)jt(w)?h.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,fe,_e,Me,0,Ee):s.framebufferTexture2D(s.FRAMEBUFFER,fe,_e,Me,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function at(k){const w=r.get(k),$=k.isWebGLCubeRenderTarget===!0;if(w.__boundDepthTexture!==k.depthTexture){const se=k.depthTexture;if(w.__depthDisposeCallback&&w.__depthDisposeCallback(),se){const he=()=>{delete w.__boundDepthTexture,delete w.__depthDisposeCallback,se.removeEventListener("dispose",he)};se.addEventListener("dispose",he),w.__depthDisposeCallback=he}w.__boundDepthTexture=se}if(k.depthTexture&&!w.__autoAllocateDepthBuffer)if($)for(let se=0;se<6;se++)ot(w.__webglFramebuffer[se],k,se);else{const se=k.texture.mipmaps;se&&se.length>0?ot(w.__webglFramebuffer[0],k,0):ot(w.__webglFramebuffer,k,0)}else if($){w.__webglDepthbuffer=[];for(let se=0;se<6;se++)if(t.bindFramebuffer(s.FRAMEBUFFER,w.__webglFramebuffer[se]),w.__webglDepthbuffer[se]===void 0)w.__webglDepthbuffer[se]=s.createRenderbuffer(),bt(w.__webglDepthbuffer[se],k,!1);else{const he=k.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,Me=w.__webglDepthbuffer[se];s.bindRenderbuffer(s.RENDERBUFFER,Me),s.framebufferRenderbuffer(s.FRAMEBUFFER,he,s.RENDERBUFFER,Me)}}else{const se=k.texture.mipmaps;if(se&&se.length>0?t.bindFramebuffer(s.FRAMEBUFFER,w.__webglFramebuffer[0]):t.bindFramebuffer(s.FRAMEBUFFER,w.__webglFramebuffer),w.__webglDepthbuffer===void 0)w.__webglDepthbuffer=s.createRenderbuffer(),bt(w.__webglDepthbuffer,k,!1);else{const he=k.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,Me=w.__webglDepthbuffer;s.bindRenderbuffer(s.RENDERBUFFER,Me),s.framebufferRenderbuffer(s.FRAMEBUFFER,he,s.RENDERBUFFER,Me)}}t.bindFramebuffer(s.FRAMEBUFFER,null)}function $e(k,w,$){const se=r.get(k);w!==void 0&&Ze(se.__webglFramebuffer,k,k.texture,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,0),$!==void 0&&at(k)}function Mt(k){const w=k.texture,$=r.get(k),se=r.get(w);k.addEventListener("dispose",T);const he=k.textures,Me=k.isWebGLCubeRenderTarget===!0,Ee=he.length>1;if(Ee||(se.__webglTexture===void 0&&(se.__webglTexture=s.createTexture()),se.__version=w.version,d.memory.textures++),Me){$.__webglFramebuffer=[];for(let _e=0;_e<6;_e++)if(w.mipmaps&&w.mipmaps.length>0){$.__webglFramebuffer[_e]=[];for(let fe=0;fe<w.mipmaps.length;fe++)$.__webglFramebuffer[_e][fe]=s.createFramebuffer()}else $.__webglFramebuffer[_e]=s.createFramebuffer()}else{if(w.mipmaps&&w.mipmaps.length>0){$.__webglFramebuffer=[];for(let _e=0;_e<w.mipmaps.length;_e++)$.__webglFramebuffer[_e]=s.createFramebuffer()}else $.__webglFramebuffer=s.createFramebuffer();if(Ee)for(let _e=0,fe=he.length;_e<fe;_e++){const ke=r.get(he[_e]);ke.__webglTexture===void 0&&(ke.__webglTexture=s.createTexture(),d.memory.textures++)}if(k.samples>0&&jt(k)===!1){$.__webglMultisampledFramebuffer=s.createFramebuffer(),$.__webglColorRenderbuffer=[],t.bindFramebuffer(s.FRAMEBUFFER,$.__webglMultisampledFramebuffer);for(let _e=0;_e<he.length;_e++){const fe=he[_e];$.__webglColorRenderbuffer[_e]=s.createRenderbuffer(),s.bindRenderbuffer(s.RENDERBUFFER,$.__webglColorRenderbuffer[_e]);const ke=l.convert(fe.format,fe.colorSpace),We=l.convert(fe.type),Ue=C(fe.internalFormat,ke,We,fe.normalized,fe.colorSpace,k.isXRRenderTarget===!0),Le=ht(k);s.renderbufferStorageMultisample(s.RENDERBUFFER,Le,Ue,k.width,k.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+_e,s.RENDERBUFFER,$.__webglColorRenderbuffer[_e])}s.bindRenderbuffer(s.RENDERBUFFER,null),k.depthBuffer&&($.__webglDepthRenderbuffer=s.createRenderbuffer(),bt($.__webglDepthRenderbuffer,k,!0)),t.bindFramebuffer(s.FRAMEBUFFER,null)}}if(Me){t.bindTexture(s.TEXTURE_CUBE_MAP,se.__webglTexture),be(s.TEXTURE_CUBE_MAP,w);for(let _e=0;_e<6;_e++)if(w.mipmaps&&w.mipmaps.length>0)for(let fe=0;fe<w.mipmaps.length;fe++)Ze($.__webglFramebuffer[_e][fe],k,w,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+_e,fe);else Ze($.__webglFramebuffer[_e],k,w,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+_e,0);x(w)&&N(s.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(Ee){for(let _e=0,fe=he.length;_e<fe;_e++){const ke=he[_e],We=r.get(ke);let Ue=s.TEXTURE_2D;(k.isWebGL3DRenderTarget||k.isWebGLArrayRenderTarget)&&(Ue=k.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),t.bindTexture(Ue,We.__webglTexture),be(Ue,ke),Ze($.__webglFramebuffer,k,ke,s.COLOR_ATTACHMENT0+_e,Ue,0),x(ke)&&N(Ue)}t.unbindTexture()}else{let _e=s.TEXTURE_2D;if((k.isWebGL3DRenderTarget||k.isWebGLArrayRenderTarget)&&(_e=k.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),t.bindTexture(_e,se.__webglTexture),be(_e,w),w.mipmaps&&w.mipmaps.length>0)for(let fe=0;fe<w.mipmaps.length;fe++)Ze($.__webglFramebuffer[fe],k,w,s.COLOR_ATTACHMENT0,_e,fe);else Ze($.__webglFramebuffer,k,w,s.COLOR_ATTACHMENT0,_e,0);x(w)&&N(_e),t.unbindTexture()}k.depthBuffer&&at(k)}function St(k){const w=k.textures;for(let $=0,se=w.length;$<se;$++){const he=w[$];if(x(he)){const Me=P(k),Ee=r.get(he).__webglTexture;t.bindTexture(Me,Ee),N(Me),t.unbindTexture()}}}const Dt=[],It=[];function Nt(k){if(k.samples>0){if(jt(k)===!1){const w=k.textures,$=k.width,se=k.height;let he=s.COLOR_BUFFER_BIT;const Me=k.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,Ee=r.get(k),_e=w.length>1;if(_e)for(let ke=0;ke<w.length;ke++)t.bindFramebuffer(s.FRAMEBUFFER,Ee.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+ke,s.RENDERBUFFER,null),t.bindFramebuffer(s.FRAMEBUFFER,Ee.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+ke,s.TEXTURE_2D,null,0);t.bindFramebuffer(s.READ_FRAMEBUFFER,Ee.__webglMultisampledFramebuffer);const fe=k.texture.mipmaps;fe&&fe.length>0?t.bindFramebuffer(s.DRAW_FRAMEBUFFER,Ee.__webglFramebuffer[0]):t.bindFramebuffer(s.DRAW_FRAMEBUFFER,Ee.__webglFramebuffer);for(let ke=0;ke<w.length;ke++){if(k.resolveDepthBuffer&&(k.depthBuffer&&(he|=s.DEPTH_BUFFER_BIT),k.stencilBuffer&&k.resolveStencilBuffer&&(he|=s.STENCIL_BUFFER_BIT)),_e){s.framebufferRenderbuffer(s.READ_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.RENDERBUFFER,Ee.__webglColorRenderbuffer[ke]);const We=r.get(w[ke]).__webglTexture;s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,We,0)}s.blitFramebuffer(0,0,$,se,0,0,$,se,he,s.NEAREST),f===!0&&(Dt.length=0,It.length=0,Dt.push(s.COLOR_ATTACHMENT0+ke),k.depthBuffer&&k.resolveDepthBuffer===!1&&(Dt.push(Me),It.push(Me),s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,It)),s.invalidateFramebuffer(s.READ_FRAMEBUFFER,Dt))}if(t.bindFramebuffer(s.READ_FRAMEBUFFER,null),t.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),_e)for(let ke=0;ke<w.length;ke++){t.bindFramebuffer(s.FRAMEBUFFER,Ee.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+ke,s.RENDERBUFFER,Ee.__webglColorRenderbuffer[ke]);const We=r.get(w[ke]).__webglTexture;t.bindFramebuffer(s.FRAMEBUFFER,Ee.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+ke,s.TEXTURE_2D,We,0)}t.bindFramebuffer(s.DRAW_FRAMEBUFFER,Ee.__webglMultisampledFramebuffer)}else if(k.depthBuffer&&k.resolveDepthBuffer===!1&&f){const w=k.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,[w])}}}function ht(k){return Math.min(a.maxSamples,k.samples)}function jt(k){const w=r.get(k);return k.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&w.__useRenderToTexture!==!1}function j(k){const w=d.render.frame;_.get(k)!==w&&(_.set(k,w),k.update())}function Qe(k,w){const $=k.colorSpace,se=k.format,he=k.type;return k.isCompressedTexture===!0||k.isVideoTexture===!0||$!==Mc&&$!==qr&&(Lt.getTransfer($)===Wt?(se!==ji||he!==Ei)&&gt("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):kt("WebGLTextures: Unsupported texture color space:",$)),w}function je(k){return typeof HTMLImageElement<"u"&&k instanceof HTMLImageElement?(m.width=k.naturalWidth||k.width,m.height=k.naturalHeight||k.height):typeof VideoFrame<"u"&&k instanceof VideoFrame?(m.width=k.displayWidth,m.height=k.displayHeight):(m.width=k.width,m.height=k.height),m}this.allocateTextureUnit=de,this.resetTextureUnits=ae,this.getTextureUnits=Q,this.setTextureUnits=ie,this.setTexture2D=X,this.setTexture2DArray=J,this.setTexture3D=le,this.setTextureCube=U,this.rebindTextures=$e,this.setupRenderTarget=Mt,this.updateRenderTargetMipmap=St,this.updateMultisampleRenderTarget=Nt,this.setupDepthRenderbuffer=at,this.setupFrameBufferTexture=Ze,this.useMultisampledRTT=jt,this.isReversedDepthBuffer=function(){return t.buffers.depth.getReversed()}}function Ww(s,e){function t(r,a=qr){let l;const d=Lt.getTransfer(a);if(r===Ei)return s.UNSIGNED_BYTE;if(r===Qh)return s.UNSIGNED_SHORT_4_4_4_4;if(r===Jh)return s.UNSIGNED_SHORT_5_5_5_1;if(r===bg)return s.UNSIGNED_INT_5_9_9_9_REV;if(r===Sg)return s.UNSIGNED_INT_10F_11F_11F_REV;if(r===_g)return s.BYTE;if(r===yg)return s.SHORT;if(r===yo)return s.UNSIGNED_SHORT;if(r===Zh)return s.INT;if(r===er)return s.UNSIGNED_INT;if(r===zi)return s.FLOAT;if(r===pi)return s.HALF_FLOAT;if(r===Mg)return s.ALPHA;if(r===wg)return s.RGB;if(r===ji)return s.RGBA;if(r===vr)return s.DEPTH_COMPONENT;if(r===Ms)return s.DEPTH_STENCIL;if(r===Eg)return s.RED;if(r===ef)return s.RED_INTEGER;if(r===Zr)return s.RG;if(r===tf)return s.RG_INTEGER;if(r===nf)return s.RGBA_INTEGER;if(r===cc||r===uc||r===dc||r===hc)if(d===Wt)if(l=e.get("WEBGL_compressed_texture_s3tc_srgb"),l!==null){if(r===cc)return l.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===uc)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===dc)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===hc)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(l=e.get("WEBGL_compressed_texture_s3tc"),l!==null){if(r===cc)return l.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===uc)return l.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===dc)return l.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===hc)return l.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===lh||r===ch||r===uh||r===dh)if(l=e.get("WEBGL_compressed_texture_pvrtc"),l!==null){if(r===lh)return l.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===ch)return l.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===uh)return l.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===dh)return l.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===hh||r===fh||r===ph||r===mh||r===gh||r===bc||r===xh)if(l=e.get("WEBGL_compressed_texture_etc"),l!==null){if(r===hh||r===fh)return d===Wt?l.COMPRESSED_SRGB8_ETC2:l.COMPRESSED_RGB8_ETC2;if(r===ph)return d===Wt?l.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:l.COMPRESSED_RGBA8_ETC2_EAC;if(r===mh)return l.COMPRESSED_R11_EAC;if(r===gh)return l.COMPRESSED_SIGNED_R11_EAC;if(r===bc)return l.COMPRESSED_RG11_EAC;if(r===xh)return l.COMPRESSED_SIGNED_RG11_EAC}else return null;if(r===vh||r===_h||r===yh||r===bh||r===Sh||r===Mh||r===wh||r===Eh||r===Th||r===Ah||r===Ch||r===Rh||r===Ph||r===Nh)if(l=e.get("WEBGL_compressed_texture_astc"),l!==null){if(r===vh)return d===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:l.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===_h)return d===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:l.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===yh)return d===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:l.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===bh)return d===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:l.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===Sh)return d===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:l.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===Mh)return d===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:l.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===wh)return d===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:l.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===Eh)return d===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:l.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===Th)return d===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:l.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===Ah)return d===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:l.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===Ch)return d===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:l.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===Rh)return d===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:l.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===Ph)return d===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:l.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===Nh)return d===Wt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:l.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===Lh||r===Dh||r===Ih)if(l=e.get("EXT_texture_compression_bptc"),l!==null){if(r===Lh)return d===Wt?l.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:l.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===Dh)return l.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===Ih)return l.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===kh||r===Fh||r===Sc||r===Uh)if(l=e.get("EXT_texture_compression_rgtc"),l!==null){if(r===kh)return l.COMPRESSED_RED_RGTC1_EXT;if(r===Fh)return l.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===Sc)return l.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===Uh)return l.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===bo?s.UNSIGNED_INT_24_8:s[r]!==void 0?s[r]:null}return{convert:t}}const Xw=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,qw=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class $w{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const r=new kg(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=r}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,r=new bn({vertexShader:Xw,fragmentShader:qw,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new Ti(new Co(20,20),r)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class Yw extends Jr{constructor(e,t){super();const r=this;let a=null,l=1,d=null,h="local-floor",f=1,m=null,_=null,S=null,v=null,b=null,M=null;const E=typeof XRWebGLBinding<"u",g=new $w,x={},N=t.getContextAttributes();let P=null,C=null;const D=[],L=[],O=new ut;let T=null;const I=new wi;I.viewport=new dn;const H=new wi;H.viewport=new dn;const B=[I,H],V=new e1;let ae=null,Q=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(ee){let me=D[ee];return me===void 0&&(me=new wd,D[ee]=me),me.getTargetRaySpace()},this.getControllerGrip=function(ee){let me=D[ee];return me===void 0&&(me=new wd,D[ee]=me),me.getGripSpace()},this.getHand=function(ee){let me=D[ee];return me===void 0&&(me=new wd,D[ee]=me),me.getHandSpace()};function ie(ee){const me=L.indexOf(ee.inputSource);if(me===-1)return;const ve=D[me];ve!==void 0&&(ve.update(ee.inputSource,ee.frame,m||d),ve.dispatchEvent({type:ee.type,data:ee.inputSource}))}function de(){a.removeEventListener("select",ie),a.removeEventListener("selectstart",ie),a.removeEventListener("selectend",ie),a.removeEventListener("squeeze",ie),a.removeEventListener("squeezestart",ie),a.removeEventListener("squeezeend",ie),a.removeEventListener("end",de),a.removeEventListener("inputsourceschange",re);for(let ee=0;ee<D.length;ee++){const me=L[ee];me!==null&&(L[ee]=null,D[ee].disconnect(me))}ae=null,Q=null,g.reset();for(const ee in x)delete x[ee];e.setRenderTarget(P),b=null,v=null,S=null,a=null,C=null,be.stop(),r.isPresenting=!1,e.setPixelRatio(T),e.setSize(O.width,O.height,!1),r.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(ee){l=ee,r.isPresenting===!0&&gt("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(ee){h=ee,r.isPresenting===!0&&gt("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return m||d},this.setReferenceSpace=function(ee){m=ee},this.getBaseLayer=function(){return v!==null?v:b},this.getBinding=function(){return S===null&&E&&(S=new XRWebGLBinding(a,t)),S},this.getFrame=function(){return M},this.getSession=function(){return a},this.setSession=async function(ee){if(a=ee,a!==null){if(P=e.getRenderTarget(),a.addEventListener("select",ie),a.addEventListener("selectstart",ie),a.addEventListener("selectend",ie),a.addEventListener("squeeze",ie),a.addEventListener("squeezestart",ie),a.addEventListener("squeezeend",ie),a.addEventListener("end",de),a.addEventListener("inputsourceschange",re),N.xrCompatible!==!0&&await t.makeXRCompatible(),T=e.getPixelRatio(),e.getSize(O),E&&"createProjectionLayer"in XRWebGLBinding.prototype){let ve=null,ce=null,we=null;N.depth&&(we=N.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,ve=N.stencil?Ms:vr,ce=N.stencil?bo:er);const Ze={colorFormat:t.RGBA8,depthFormat:we,scaleFactor:l};S=this.getBinding(),v=S.createProjectionLayer(Ze),a.updateRenderState({layers:[v]}),e.setPixelRatio(1),e.setSize(v.textureWidth,v.textureHeight,!1),C=new ai(v.textureWidth,v.textureHeight,{format:ji,type:Ei,depthTexture:new Sa(v.textureWidth,v.textureHeight,ce,void 0,void 0,void 0,void 0,void 0,void 0,ve),stencilBuffer:N.stencil,colorSpace:e.outputColorSpace,samples:N.antialias?4:0,resolveDepthBuffer:v.ignoreDepthValues===!1,resolveStencilBuffer:v.ignoreDepthValues===!1})}else{const ve={antialias:N.antialias,alpha:!0,depth:N.depth,stencil:N.stencil,framebufferScaleFactor:l};b=new XRWebGLLayer(a,t,ve),a.updateRenderState({baseLayer:b}),e.setPixelRatio(1),e.setSize(b.framebufferWidth,b.framebufferHeight,!1),C=new ai(b.framebufferWidth,b.framebufferHeight,{format:ji,type:Ei,colorSpace:e.outputColorSpace,stencilBuffer:N.stencil,resolveDepthBuffer:b.ignoreDepthValues===!1,resolveStencilBuffer:b.ignoreDepthValues===!1})}C.isXRRenderTarget=!0,this.setFoveation(f),m=null,d=await a.requestReferenceSpace(h),be.setContext(a),be.start(),r.isPresenting=!0,r.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(a!==null)return a.environmentBlendMode},this.getDepthTexture=function(){return g.getDepthTexture()};function re(ee){for(let me=0;me<ee.removed.length;me++){const ve=ee.removed[me],ce=L.indexOf(ve);ce>=0&&(L[ce]=null,D[ce].disconnect(ve))}for(let me=0;me<ee.added.length;me++){const ve=ee.added[me];let ce=L.indexOf(ve);if(ce===-1){for(let Ze=0;Ze<D.length;Ze++)if(Ze>=L.length){L.push(ve),ce=Ze;break}else if(L[Ze]===null){L[Ze]=ve,ce=Ze;break}if(ce===-1)break}const we=D[ce];we&&we.connect(ve)}}const X=new K,J=new K;function le(ee,me,ve){X.setFromMatrixPosition(me.matrixWorld),J.setFromMatrixPosition(ve.matrixWorld);const ce=X.distanceTo(J),we=me.projectionMatrix.elements,Ze=ve.projectionMatrix.elements,bt=we[14]/(we[10]-1),ot=we[14]/(we[10]+1),at=(we[9]+1)/we[5],$e=(we[9]-1)/we[5],Mt=(we[8]-1)/we[0],St=(Ze[8]+1)/Ze[0],Dt=bt*Mt,It=bt*St,Nt=ce/(-Mt+St),ht=Nt*-Mt;if(me.matrixWorld.decompose(ee.position,ee.quaternion,ee.scale),ee.translateX(ht),ee.translateZ(Nt),ee.matrixWorld.compose(ee.position,ee.quaternion,ee.scale),ee.matrixWorldInverse.copy(ee.matrixWorld).invert(),we[10]===-1)ee.projectionMatrix.copy(me.projectionMatrix),ee.projectionMatrixInverse.copy(me.projectionMatrixInverse);else{const jt=bt+Nt,j=ot+Nt,Qe=Dt-ht,je=It+(ce-ht),k=at*ot/j*jt,w=$e*ot/j*jt;ee.projectionMatrix.makePerspective(Qe,je,k,w,jt,j),ee.projectionMatrixInverse.copy(ee.projectionMatrix).invert()}}function U(ee,me){me===null?ee.matrixWorld.copy(ee.matrix):ee.matrixWorld.multiplyMatrices(me.matrixWorld,ee.matrix),ee.matrixWorldInverse.copy(ee.matrixWorld).invert()}this.updateCamera=function(ee){if(a===null)return;let me=ee.near,ve=ee.far;g.texture!==null&&(g.depthNear>0&&(me=g.depthNear),g.depthFar>0&&(ve=g.depthFar)),V.near=H.near=I.near=me,V.far=H.far=I.far=ve,(ae!==V.near||Q!==V.far)&&(a.updateRenderState({depthNear:V.near,depthFar:V.far}),ae=V.near,Q=V.far),V.layers.mask=ee.layers.mask|6,I.layers.mask=V.layers.mask&-5,H.layers.mask=V.layers.mask&-3;const ce=ee.parent,we=V.cameras;U(V,ce);for(let Ze=0;Ze<we.length;Ze++)U(we[Ze],ce);we.length===2?le(V,I,H):V.projectionMatrix.copy(I.projectionMatrix),q(ee,V,ce)};function q(ee,me,ve){ve===null?ee.matrix.copy(me.matrixWorld):(ee.matrix.copy(ve.matrixWorld),ee.matrix.invert(),ee.matrix.multiply(me.matrixWorld)),ee.matrix.decompose(ee.position,ee.quaternion,ee.scale),ee.updateMatrixWorld(!0),ee.projectionMatrix.copy(me.projectionMatrix),ee.projectionMatrixInverse.copy(me.projectionMatrixInverse),ee.isPerspectiveCamera&&(ee.fov=Oh*2*Math.atan(1/ee.projectionMatrix.elements[5]),ee.zoom=1)}this.getCamera=function(){return V},this.getFoveation=function(){if(!(v===null&&b===null))return f},this.setFoveation=function(ee){f=ee,v!==null&&(v.fixedFoveation=ee),b!==null&&b.fixedFoveation!==void 0&&(b.fixedFoveation=ee)},this.hasDepthSensing=function(){return g.texture!==null},this.getDepthSensingMesh=function(){return g.getMesh(V)},this.getCameraTexture=function(ee){return x[ee]};let Re=null;function qe(ee,me){if(_=me.getViewerPose(m||d),M=me,_!==null){const ve=_.views;b!==null&&(e.setRenderTargetFramebuffer(C,b.framebuffer),e.setRenderTarget(C));let ce=!1;ve.length!==V.cameras.length&&(V.cameras.length=0,ce=!0);for(let ot=0;ot<ve.length;ot++){const at=ve[ot];let $e=null;if(b!==null)$e=b.getViewport(at);else{const St=S.getViewSubImage(v,at);$e=St.viewport,ot===0&&(e.setRenderTargetTextures(C,St.colorTexture,St.depthStencilTexture),e.setRenderTarget(C))}let Mt=B[ot];Mt===void 0&&(Mt=new wi,Mt.layers.enable(ot),Mt.viewport=new dn,B[ot]=Mt),Mt.matrix.fromArray(at.transform.matrix),Mt.matrix.decompose(Mt.position,Mt.quaternion,Mt.scale),Mt.projectionMatrix.fromArray(at.projectionMatrix),Mt.projectionMatrixInverse.copy(Mt.projectionMatrix).invert(),Mt.viewport.set($e.x,$e.y,$e.width,$e.height),ot===0&&(V.matrix.copy(Mt.matrix),V.matrix.decompose(V.position,V.quaternion,V.scale)),ce===!0&&V.cameras.push(Mt)}const we=a.enabledFeatures;if(we&&we.includes("depth-sensing")&&a.depthUsage=="gpu-optimized"&&E){S=r.getBinding();const ot=S.getDepthInformation(ve[0]);ot&&ot.isValid&&ot.texture&&g.init(ot,a.renderState)}if(we&&we.includes("camera-access")&&E){e.state.unbindTexture(),S=r.getBinding();for(let ot=0;ot<ve.length;ot++){const at=ve[ot].camera;if(at){let $e=x[at];$e||($e=new kg,x[at]=$e);const Mt=S.getCameraImage(at);$e.sourceTexture=Mt}}}}for(let ve=0;ve<D.length;ve++){const ce=L[ve],we=D[ve];ce!==null&&we!==void 0&&we.update(ce,me,m||d)}Re&&Re(ee,me),me.detectedPlanes&&r.dispatchEvent({type:"planesdetected",data:me}),M=null}const be=new Bg;be.setAnimationLoop(qe),this.setAnimationLoop=function(ee){Re=ee},this.dispose=function(){}}}const Kw=new nn,Xg=new yt;Xg.set(-1,0,0,0,1,0,0,0,1);function Zw(s,e){function t(g,x){g.matrixAutoUpdate===!0&&g.updateMatrix(),x.value.copy(g.matrix)}function r(g,x){x.color.getRGB(g.fogColor.value,Fg(s)),x.isFog?(g.fogNear.value=x.near,g.fogFar.value=x.far):x.isFogExp2&&(g.fogDensity.value=x.density)}function a(g,x,N,P,C){x.isNodeMaterial?x.uniformsNeedUpdate=!1:x.isMeshBasicMaterial?l(g,x):x.isMeshLambertMaterial?(l(g,x),x.envMap&&(g.envMapIntensity.value=x.envMapIntensity)):x.isMeshToonMaterial?(l(g,x),S(g,x)):x.isMeshPhongMaterial?(l(g,x),_(g,x),x.envMap&&(g.envMapIntensity.value=x.envMapIntensity)):x.isMeshStandardMaterial?(l(g,x),v(g,x),x.isMeshPhysicalMaterial&&b(g,x,C)):x.isMeshMatcapMaterial?(l(g,x),M(g,x)):x.isMeshDepthMaterial?l(g,x):x.isMeshDistanceMaterial?(l(g,x),E(g,x)):x.isMeshNormalMaterial?l(g,x):x.isLineBasicMaterial?(d(g,x),x.isLineDashedMaterial&&h(g,x)):x.isPointsMaterial?f(g,x,N,P):x.isSpriteMaterial?m(g,x):x.isShadowMaterial?(g.color.value.copy(x.color),g.opacity.value=x.opacity):x.isShaderMaterial&&(x.uniformsNeedUpdate=!1)}function l(g,x){g.opacity.value=x.opacity,x.color&&g.diffuse.value.copy(x.color),x.emissive&&g.emissive.value.copy(x.emissive).multiplyScalar(x.emissiveIntensity),x.map&&(g.map.value=x.map,t(x.map,g.mapTransform)),x.alphaMap&&(g.alphaMap.value=x.alphaMap,t(x.alphaMap,g.alphaMapTransform)),x.bumpMap&&(g.bumpMap.value=x.bumpMap,t(x.bumpMap,g.bumpMapTransform),g.bumpScale.value=x.bumpScale,x.side===si&&(g.bumpScale.value*=-1)),x.normalMap&&(g.normalMap.value=x.normalMap,t(x.normalMap,g.normalMapTransform),g.normalScale.value.copy(x.normalScale),x.side===si&&g.normalScale.value.negate()),x.displacementMap&&(g.displacementMap.value=x.displacementMap,t(x.displacementMap,g.displacementMapTransform),g.displacementScale.value=x.displacementScale,g.displacementBias.value=x.displacementBias),x.emissiveMap&&(g.emissiveMap.value=x.emissiveMap,t(x.emissiveMap,g.emissiveMapTransform)),x.specularMap&&(g.specularMap.value=x.specularMap,t(x.specularMap,g.specularMapTransform)),x.alphaTest>0&&(g.alphaTest.value=x.alphaTest);const N=e.get(x),P=N.envMap,C=N.envMapRotation;P&&(g.envMap.value=P,g.envMapRotation.value.setFromMatrix4(Kw.makeRotationFromEuler(C)).transpose(),P.isCubeTexture&&P.isRenderTargetTexture===!1&&g.envMapRotation.value.premultiply(Xg),g.reflectivity.value=x.reflectivity,g.ior.value=x.ior,g.refractionRatio.value=x.refractionRatio),x.lightMap&&(g.lightMap.value=x.lightMap,g.lightMapIntensity.value=x.lightMapIntensity,t(x.lightMap,g.lightMapTransform)),x.aoMap&&(g.aoMap.value=x.aoMap,g.aoMapIntensity.value=x.aoMapIntensity,t(x.aoMap,g.aoMapTransform))}function d(g,x){g.diffuse.value.copy(x.color),g.opacity.value=x.opacity,x.map&&(g.map.value=x.map,t(x.map,g.mapTransform))}function h(g,x){g.dashSize.value=x.dashSize,g.totalSize.value=x.dashSize+x.gapSize,g.scale.value=x.scale}function f(g,x,N,P){g.diffuse.value.copy(x.color),g.opacity.value=x.opacity,g.size.value=x.size*N,g.scale.value=P*.5,x.map&&(g.map.value=x.map,t(x.map,g.uvTransform)),x.alphaMap&&(g.alphaMap.value=x.alphaMap,t(x.alphaMap,g.alphaMapTransform)),x.alphaTest>0&&(g.alphaTest.value=x.alphaTest)}function m(g,x){g.diffuse.value.copy(x.color),g.opacity.value=x.opacity,g.rotation.value=x.rotation,x.map&&(g.map.value=x.map,t(x.map,g.mapTransform)),x.alphaMap&&(g.alphaMap.value=x.alphaMap,t(x.alphaMap,g.alphaMapTransform)),x.alphaTest>0&&(g.alphaTest.value=x.alphaTest)}function _(g,x){g.specular.value.copy(x.specular),g.shininess.value=Math.max(x.shininess,1e-4)}function S(g,x){x.gradientMap&&(g.gradientMap.value=x.gradientMap)}function v(g,x){g.metalness.value=x.metalness,x.metalnessMap&&(g.metalnessMap.value=x.metalnessMap,t(x.metalnessMap,g.metalnessMapTransform)),g.roughness.value=x.roughness,x.roughnessMap&&(g.roughnessMap.value=x.roughnessMap,t(x.roughnessMap,g.roughnessMapTransform)),x.envMap&&(g.envMapIntensity.value=x.envMapIntensity)}function b(g,x,N){g.ior.value=x.ior,x.sheen>0&&(g.sheenColor.value.copy(x.sheenColor).multiplyScalar(x.sheen),g.sheenRoughness.value=x.sheenRoughness,x.sheenColorMap&&(g.sheenColorMap.value=x.sheenColorMap,t(x.sheenColorMap,g.sheenColorMapTransform)),x.sheenRoughnessMap&&(g.sheenRoughnessMap.value=x.sheenRoughnessMap,t(x.sheenRoughnessMap,g.sheenRoughnessMapTransform))),x.clearcoat>0&&(g.clearcoat.value=x.clearcoat,g.clearcoatRoughness.value=x.clearcoatRoughness,x.clearcoatMap&&(g.clearcoatMap.value=x.clearcoatMap,t(x.clearcoatMap,g.clearcoatMapTransform)),x.clearcoatRoughnessMap&&(g.clearcoatRoughnessMap.value=x.clearcoatRoughnessMap,t(x.clearcoatRoughnessMap,g.clearcoatRoughnessMapTransform)),x.clearcoatNormalMap&&(g.clearcoatNormalMap.value=x.clearcoatNormalMap,t(x.clearcoatNormalMap,g.clearcoatNormalMapTransform),g.clearcoatNormalScale.value.copy(x.clearcoatNormalScale),x.side===si&&g.clearcoatNormalScale.value.negate())),x.dispersion>0&&(g.dispersion.value=x.dispersion),x.iridescence>0&&(g.iridescence.value=x.iridescence,g.iridescenceIOR.value=x.iridescenceIOR,g.iridescenceThicknessMinimum.value=x.iridescenceThicknessRange[0],g.iridescenceThicknessMaximum.value=x.iridescenceThicknessRange[1],x.iridescenceMap&&(g.iridescenceMap.value=x.iridescenceMap,t(x.iridescenceMap,g.iridescenceMapTransform)),x.iridescenceThicknessMap&&(g.iridescenceThicknessMap.value=x.iridescenceThicknessMap,t(x.iridescenceThicknessMap,g.iridescenceThicknessMapTransform))),x.transmission>0&&(g.transmission.value=x.transmission,g.transmissionSamplerMap.value=N.texture,g.transmissionSamplerSize.value.set(N.width,N.height),x.transmissionMap&&(g.transmissionMap.value=x.transmissionMap,t(x.transmissionMap,g.transmissionMapTransform)),g.thickness.value=x.thickness,x.thicknessMap&&(g.thicknessMap.value=x.thicknessMap,t(x.thicknessMap,g.thicknessMapTransform)),g.attenuationDistance.value=x.attenuationDistance,g.attenuationColor.value.copy(x.attenuationColor)),x.anisotropy>0&&(g.anisotropyVector.value.set(x.anisotropy*Math.cos(x.anisotropyRotation),x.anisotropy*Math.sin(x.anisotropyRotation)),x.anisotropyMap&&(g.anisotropyMap.value=x.anisotropyMap,t(x.anisotropyMap,g.anisotropyMapTransform))),g.specularIntensity.value=x.specularIntensity,g.specularColor.value.copy(x.specularColor),x.specularColorMap&&(g.specularColorMap.value=x.specularColorMap,t(x.specularColorMap,g.specularColorMapTransform)),x.specularIntensityMap&&(g.specularIntensityMap.value=x.specularIntensityMap,t(x.specularIntensityMap,g.specularIntensityMapTransform))}function M(g,x){x.matcap&&(g.matcap.value=x.matcap)}function E(g,x){const N=e.get(x).light;g.referencePosition.value.setFromMatrixPosition(N.matrixWorld),g.nearDistance.value=N.shadow.camera.near,g.farDistance.value=N.shadow.camera.far}return{refreshFogUniforms:r,refreshMaterialUniforms:a}}function Qw(s,e,t,r){let a={},l={},d=[];const h=s.getParameter(s.MAX_UNIFORM_BUFFER_BINDINGS);function f(C,D){const L=D.program;r.uniformBlockBinding(C,L)}function m(C,D){let L=a[C.id];L===void 0&&(g(C),L=_(C),a[C.id]=L,C.addEventListener("dispose",N));const O=D.program;r.updateUBOMapping(C,O);const T=e.render.frame;l[C.id]!==T&&(v(C),l[C.id]=T)}function _(C){const D=S();C.__bindingPointIndex=D;const L=s.createBuffer(),O=C.__size,T=C.usage;return s.bindBuffer(s.UNIFORM_BUFFER,L),s.bufferData(s.UNIFORM_BUFFER,O,T),s.bindBuffer(s.UNIFORM_BUFFER,null),s.bindBufferBase(s.UNIFORM_BUFFER,D,L),L}function S(){for(let C=0;C<h;C++)if(d.indexOf(C)===-1)return d.push(C),C;return kt("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function v(C){const D=a[C.id],L=C.uniforms,O=C.__cache;s.bindBuffer(s.UNIFORM_BUFFER,D);for(let T=0,I=L.length;T<I;T++){const H=L[T];if(Array.isArray(H))for(let B=0,V=H.length;B<V;B++)b(H[B],T,B,O);else b(H,T,0,O)}s.bindBuffer(s.UNIFORM_BUFFER,null)}function b(C,D,L,O){if(E(C,D,L,O)===!0){const T=C.__offset,I=C.value;if(Array.isArray(I)){let H=0;for(let B=0;B<I.length;B++){const V=I[B],ae=x(V);M(V,C.__data,H),typeof V!="number"&&typeof V!="boolean"&&!V.isMatrix3&&!ArrayBuffer.isView(V)&&(H+=ae.storage/Float32Array.BYTES_PER_ELEMENT)}}else M(I,C.__data,0);s.bufferSubData(s.UNIFORM_BUFFER,T,C.__data)}}function M(C,D,L){typeof C=="number"||typeof C=="boolean"?D[0]=C:C.isMatrix3?(D[0]=C.elements[0],D[1]=C.elements[1],D[2]=C.elements[2],D[3]=0,D[4]=C.elements[3],D[5]=C.elements[4],D[6]=C.elements[5],D[7]=0,D[8]=C.elements[6],D[9]=C.elements[7],D[10]=C.elements[8],D[11]=0):ArrayBuffer.isView(C)?D.set(new C.constructor(C.buffer,C.byteOffset,D.length)):C.toArray(D,L)}function E(C,D,L,O){const T=C.value,I=D+"_"+L;if(O[I]===void 0)return typeof T=="number"||typeof T=="boolean"?O[I]=T:ArrayBuffer.isView(T)?O[I]=T.slice():O[I]=T.clone(),!0;{const H=O[I];if(typeof T=="number"||typeof T=="boolean"){if(H!==T)return O[I]=T,!0}else{if(ArrayBuffer.isView(T))return!0;if(H.equals(T)===!1)return H.copy(T),!0}}return!1}function g(C){const D=C.uniforms;let L=0;const O=16;for(let I=0,H=D.length;I<H;I++){const B=Array.isArray(D[I])?D[I]:[D[I]];for(let V=0,ae=B.length;V<ae;V++){const Q=B[V],ie=Array.isArray(Q.value)?Q.value:[Q.value];for(let de=0,re=ie.length;de<re;de++){const X=ie[de],J=x(X),le=L%O,U=le%J.boundary,q=le+U;L+=U,q!==0&&O-q<J.storage&&(L+=O-q),Q.__data=new Float32Array(J.storage/Float32Array.BYTES_PER_ELEMENT),Q.__offset=L,L+=J.storage}}}const T=L%O;return T>0&&(L+=O-T),C.__size=L,C.__cache={},this}function x(C){const D={boundary:0,storage:0};return typeof C=="number"||typeof C=="boolean"?(D.boundary=4,D.storage=4):C.isVector2?(D.boundary=8,D.storage=8):C.isVector3||C.isColor?(D.boundary=16,D.storage=12):C.isVector4?(D.boundary=16,D.storage=16):C.isMatrix3?(D.boundary=48,D.storage=48):C.isMatrix4?(D.boundary=64,D.storage=64):C.isTexture?gt("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(C)?(D.boundary=16,D.storage=C.byteLength):gt("WebGLRenderer: Unsupported uniform value type.",C),D}function N(C){const D=C.target;D.removeEventListener("dispose",N);const L=d.indexOf(D.__bindingPointIndex);d.splice(L,1),s.deleteBuffer(a[D.id]),delete a[D.id],delete l[D.id]}function P(){for(const C in a)s.deleteBuffer(a[C]);d=[],a={},l={}}return{bind:f,update:m,dispose:P}}const Jw=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let Yi=null;function eE(){return Yi===null&&(Yi=new Ng(Jw,16,16,Zr,pi),Yi.name="DFG_LUT",Yi.minFilter=jn,Yi.magFilter=jn,Yi.wrapS=mr,Yi.wrapT=mr,Yi.generateMipmaps=!1,Yi.needsUpdate=!0),Yi}class tE{constructor(e={}){const{canvas:t=gy(),context:r=null,depth:a=!0,stencil:l=!1,alpha:d=!1,antialias:h=!1,premultipliedAlpha:f=!0,preserveDrawingBuffer:m=!1,powerPreference:_="default",failIfMajorPerformanceCaveat:S=!1,reversedDepthBuffer:v=!1,outputBufferType:b=Ei}=e;this.isWebGLRenderer=!0;let M;if(r!==null){if(typeof WebGLRenderingContext<"u"&&r instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");M=r.getContextAttributes().alpha}else M=d;const E=b,g=new Set([nf,tf,ef]),x=new Set([Ei,er,yo,bo,Qh,Jh]),N=new Uint32Array(4),P=new Int32Array(4),C=new K;let D=null,L=null;const O=[],T=[];let I=null;this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Ji,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const H=this;let B=!1,V=null,ae=null,Q=null,ie=null;this._outputColorSpace=Mi;let de=0,re=0,X=null,J=-1,le=null;const U=new dn,q=new dn;let Re=null;const qe=new vt(0);let be=0,ee=t.width,me=t.height,ve=1,ce=null,we=null;const Ze=new dn(0,0,ee,me),bt=new dn(0,0,ee,me);let ot=!1;const at=new Lg;let $e=!1,Mt=!1;const St=new nn,Dt=new K,It=new dn,Nt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let ht=!1;function jt(){return X===null?ve:1}let j=r;function Qe(R,G){return t.getContext(R,G)}try{const R={alpha:!0,depth:a,stencil:l,antialias:h,premultipliedAlpha:f,preserveDrawingBuffer:m,powerPreference:_,failIfMajorPerformanceCaveat:S};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${Kh}`),t.addEventListener("webglcontextlost",Tt,!1),t.addEventListener("webglcontextrestored",dt,!1),t.addEventListener("webglcontextcreationerror",Ft,!1),j===null){const G="webgl2";if(j=Qe(G,R),j===null)throw Qe(G)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}}catch(R){throw kt("WebGLRenderer: "+R.message),R}let je,k,w,$,se,he,Me,Ee,_e,fe,ke,We,Ue,Le,Xe,tt,lt,F,ye,ge,Pe,Ae,Se;function Oe(){je=new eM(j),je.init(),Pe=new Ww(j,je),k=new XS(j,je,e,Pe),w=new Gw(j,je),k.reversedDepthBuffer&&v&&w.buffers.depth.setReversed(!0),ae=j.createFramebuffer(),Q=j.createFramebuffer(),ie=j.createFramebuffer(),$=new iM(j),se=new Rw,he=new Vw(j,je,w,se,k,Pe,$),Me=new JS(H),Ee=new o1(j),Ae=new VS(j,Ee),_e=new tM(j,Ee,$,Ae),fe=new sM(j,_e,Ee,Ae,$),F=new rM(j,k,he),Xe=new qS(se),ke=new Cw(H,Me,je,k,Ae,Xe),We=new Zw(H,se),Ue=new Nw,Le=new Uw(je),lt=new GS(H,Me,w,fe,M,f),tt=new Hw(H,fe,k),Se=new Qw(j,$,k,w),ye=new WS(j,je,$),ge=new nM(j,je,$),$.programs=ke.programs,H.capabilities=k,H.extensions=je,H.properties=se,H.renderLists=Ue,H.shadowMap=tt,H.state=w,H.info=$}Oe(),E!==Ei&&(I=new oM(E,t.width,t.height,h,a,l));const He=new Yw(H,j);this.xr=He,this.getContext=function(){return j},this.getContextAttributes=function(){return j.getContextAttributes()},this.forceContextLoss=function(){const R=je.get("WEBGL_lose_context");R&&R.loseContext()},this.forceContextRestore=function(){const R=je.get("WEBGL_lose_context");R&&R.restoreContext()},this.getPixelRatio=function(){return ve},this.setPixelRatio=function(R){R!==void 0&&(ve=R,this.setSize(ee,me,!1))},this.getSize=function(R){return R.set(ee,me)},this.setSize=function(R,G,oe=!0){if(He.isPresenting){gt("WebGLRenderer: Can't change size while VR device is presenting.");return}ee=R,me=G,t.width=Math.floor(R*ve),t.height=Math.floor(G*ve),oe===!0&&(t.style.width=R+"px",t.style.height=G+"px"),I!==null&&I.setSize(t.width,t.height),this.setViewport(0,0,R,G)},this.getDrawingBufferSize=function(R){return R.set(ee*ve,me*ve).floor()},this.setDrawingBufferSize=function(R,G,oe){ee=R,me=G,ve=oe,t.width=Math.floor(R*oe),t.height=Math.floor(G*oe),this.setViewport(0,0,R,G)},this.setEffects=function(R){if(E===Ei){kt("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(R){for(let G=0;G<R.length;G++)if(R[G].isOutputPass===!0){gt("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}I.setEffects(R||[])},this.getCurrentViewport=function(R){return R.copy(U)},this.getViewport=function(R){return R.copy(Ze)},this.setViewport=function(R,G,oe,te){R.isVector4?Ze.set(R.x,R.y,R.z,R.w):Ze.set(R,G,oe,te),w.viewport(U.copy(Ze).multiplyScalar(ve).round())},this.getScissor=function(R){return R.copy(bt)},this.setScissor=function(R,G,oe,te){R.isVector4?bt.set(R.x,R.y,R.z,R.w):bt.set(R,G,oe,te),w.scissor(q.copy(bt).multiplyScalar(ve).round())},this.getScissorTest=function(){return ot},this.setScissorTest=function(R){w.setScissorTest(ot=R)},this.setOpaqueSort=function(R){ce=R},this.setTransparentSort=function(R){we=R},this.getClearColor=function(R){return R.copy(lt.getClearColor())},this.setClearColor=function(){lt.setClearColor(...arguments)},this.getClearAlpha=function(){return lt.getClearAlpha()},this.setClearAlpha=function(){lt.setClearAlpha(...arguments)},this.clear=function(R=!0,G=!0,oe=!0){let te=0;if(R){let ne=!1;if(X!==null){const Te=X.texture.format;ne=g.has(Te)}if(ne){const Te=X.texture.type,Be=x.has(Te),De=lt.getClearColor(),ze=lt.getClearAlpha(),Ve=De.r,mt=De.g,ct=De.b;Be?(N[0]=Ve,N[1]=mt,N[2]=ct,N[3]=ze,j.clearBufferuiv(j.COLOR,0,N)):(P[0]=Ve,P[1]=mt,P[2]=ct,P[3]=ze,j.clearBufferiv(j.COLOR,0,P))}else te|=j.COLOR_BUFFER_BIT}G&&(te|=j.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),oe&&(te|=j.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),te!==0&&j.clear(te)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(R){R.setRenderer(this),V=R},this.dispose=function(){t.removeEventListener("webglcontextlost",Tt,!1),t.removeEventListener("webglcontextrestored",dt,!1),t.removeEventListener("webglcontextcreationerror",Ft,!1),lt.dispose(),Ue.dispose(),Le.dispose(),se.dispose(),Me.dispose(),fe.dispose(),Ae.dispose(),Se.dispose(),ke.dispose(),He.dispose(),He.removeEventListener("sessionstart",Cs),He.removeEventListener("sessionend",es),xn.stop()};function Tt(R){R.preventDefault(),Jm("WebGLRenderer: Context Lost."),B=!0}function dt(){Jm("WebGLRenderer: Context Restored."),B=!1;const R=$.autoReset,G=tt.enabled,oe=tt.autoUpdate,te=tt.needsUpdate,ne=tt.type;Oe(),$.autoReset=R,tt.enabled=G,tt.autoUpdate=oe,tt.needsUpdate=te,tt.type=ne}function Ft(R){kt("WebGLRenderer: A WebGL context could not be created. Reason: ",R.statusMessage)}function ln(R){const G=R.target;G.removeEventListener("dispose",ln),Dn(G)}function Dn(R){In(R),se.remove(R)}function In(R){const G=se.get(R).programs;G!==void 0&&(G.forEach(function(oe){ke.releaseProgram(oe)}),R.isShaderMaterial&&ke.releaseShaderCache(R))}this.renderBufferDirect=function(R,G,oe,te,ne,Te){G===null&&(G=Nt);const Be=ne.isMesh&&ne.matrixWorld.determinantAffine()<0,De=Ht(R,G,oe,te,ne);w.setMaterial(te,Be);let ze=oe.index,Ve=1;if(te.wireframe===!0){if(ze=_e.getWireframeAttribute(oe),ze===void 0)return;Ve=2}const mt=oe.drawRange,ct=oe.attributes.position;let et=mt.start*Ve,Pt=(mt.start+mt.count)*Ve;Te!==null&&(et=Math.max(et,Te.start*Ve),Pt=Math.min(Pt,(Te.start+Te.count)*Ve)),ze!==null?(et=Math.max(et,0),Pt=Math.min(Pt,ze.count)):ct!=null&&(et=Math.max(et,0),Pt=Math.min(Pt,ct.count));const Xt=Pt-et;if(Xt<0||Xt===1/0)return;Ae.setup(ne,te,De,oe,ze);let en,Gt=ye;if(ze!==null&&(en=Ee.get(ze),Gt=ge,Gt.setIndex(en)),ne.isMesh)te.wireframe===!0?(w.setLineWidth(te.wireframeLinewidth*jt()),Gt.setMode(j.LINES)):Gt.setMode(j.TRIANGLES);else if(ne.isLine){let pn=te.linewidth;pn===void 0&&(pn=1),w.setLineWidth(pn*jt()),ne.isLineSegments?Gt.setMode(j.LINES):ne.isLineLoop?Gt.setMode(j.LINE_LOOP):Gt.setMode(j.LINE_STRIP)}else ne.isPoints?Gt.setMode(j.POINTS):ne.isSprite&&Gt.setMode(j.TRIANGLES);if(ne.isBatchedMesh)if(je.get("WEBGL_multi_draw"))Gt.renderMultiDraw(ne._multiDrawStarts,ne._multiDrawCounts,ne._multiDrawCount);else{const pn=ne._multiDrawStarts,Ye=ne._multiDrawCounts,Rn=ne._multiDrawCount,Et=ze?Ee.get(ze).bytesPerElement:1,Yn=se.get(te).currentProgram.getUniforms();for(let Kn=0;Kn<Rn;Kn++)Yn.setValue(j,"_gl_DrawID",Kn),Gt.render(pn[Kn]/Et,Ye[Kn])}else if(ne.isInstancedMesh)Gt.renderInstances(et,Xt,ne.count);else if(oe.isInstancedBufferGeometry){const pn=oe._maxInstanceCount!==void 0?oe._maxInstanceCount:1/0,Ye=Math.min(oe.instanceCount,pn);Gt.renderInstances(et,Xt,Ye)}else Gt.render(et,Xt)};function oi(R,G,oe){R.transparent===!0&&R.side===Oi&&R.forceSinglePass===!1?(R.side=si,R.needsUpdate=!0,$t(R,G,oe),R.side=Kr,R.needsUpdate=!0,$t(R,G,oe),R.side=Oi):$t(R,G,oe)}this.compile=function(R,G,oe=null){oe===null&&(oe=R),L=Le.get(oe),L.init(G),T.push(L),oe.traverseVisible(function(ne){ne.isLight&&ne.layers.test(G.layers)&&(L.pushLight(ne),ne.castShadow&&L.pushShadow(ne))}),R!==oe&&R.traverseVisible(function(ne){ne.isLight&&ne.layers.test(G.layers)&&(L.pushLight(ne),ne.castShadow&&L.pushShadow(ne))}),L.setupLights();const te=new Set;return R.traverse(function(ne){if(!(ne.isMesh||ne.isPoints||ne.isLine||ne.isSprite))return;const Te=ne.material;if(Te)if(Array.isArray(Te))for(let Be=0;Be<Te.length;Be++){const De=Te[Be];oi(De,oe,ne),te.add(De)}else oi(Te,oe,ne),te.add(Te)}),L=T.pop(),te},this.compileAsync=function(R,G,oe=null){const te=this.compile(R,G,oe);return new Promise(ne=>{function Te(){if(te.forEach(function(Be){se.get(Be).currentProgram.isReady()&&te.delete(Be)}),te.size===0){ne(R);return}setTimeout(Te,10)}je.get("KHR_parallel_shader_compile")!==null?Te():setTimeout(Te,10)})};let mi=null;function As(R){mi&&mi(R)}function Cs(){xn.stop()}function es(){xn.start()}const xn=new Bg;xn.setAnimationLoop(As),typeof self<"u"&&xn.setContext(self),this.setAnimationLoop=function(R){mi=R,He.setAnimationLoop(R),R===null?xn.stop():xn.start()},He.addEventListener("sessionstart",Cs),He.addEventListener("sessionend",es),this.render=function(R,G){if(G!==void 0&&G.isCamera!==!0){kt("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(B===!0)return;V!==null&&V.renderStart(R,G);const oe=He.enabled===!0&&He.isPresenting===!0,te=I!==null&&(X===null||oe)&&I.begin(H,X);if(R.matrixWorldAutoUpdate===!0&&R.updateMatrixWorld(),G.parent===null&&G.matrixWorldAutoUpdate===!0&&G.updateMatrixWorld(),He.enabled===!0&&He.isPresenting===!0&&(I===null||I.isCompositing()===!1)&&(He.cameraAutoUpdate===!0&&He.updateCamera(G),G=He.getCamera()),R.isScene===!0&&R.onBeforeRender(H,R,G,X),L=Le.get(R,T.length),L.init(G),L.state.textureUnits=he.getTextureUnits(),T.push(L),St.multiplyMatrices(G.projectionMatrix,G.matrixWorldInverse),at.setFromProjectionMatrix(St,Zi,G.reversedDepth),Mt=this.localClippingEnabled,$e=Xe.init(this.clippingPlanes,Mt),D=Ue.get(R,O.length),D.init(),O.push(D),He.enabled===!0&&He.isPresenting===!0){const Be=H.xr.getDepthSensingMesh();Be!==null&&Hi(Be,G,-1/0,H.sortObjects)}Hi(R,G,0,H.sortObjects),D.finish(),H.sortObjects===!0&&D.sort(ce,we,G.reversedDepth),ht=He.enabled===!1||He.isPresenting===!1||He.hasDepthSensing()===!1,ht&&lt.addToRenderList(D,R),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),$e===!0&&Xe.beginShadows();const ne=L.state.shadowsArray;if(tt.render(ne,R,G),$e===!0&&Xe.endShadows(),(te&&I.hasRenderPass())===!1){const Be=D.opaque,De=D.transmissive;if(L.setupLights(),G.isArrayCamera){const ze=G.cameras;if(De.length>0)for(let Ve=0,mt=ze.length;Ve<mt;Ve++){const ct=ze[Ve];_t(Be,De,R,ct)}ht&&lt.render(R);for(let Ve=0,mt=ze.length;Ve<mt;Ve++){const ct=ze[Ve];_r(D,R,ct,ct.viewport)}}else De.length>0&&_t(Be,De,R,G),ht&&lt.render(R),_r(D,R,G)}X!==null&&re===0&&(he.updateMultisampleRenderTarget(X),he.updateRenderTargetMipmap(X)),te&&I.end(H),R.isScene===!0&&R.onAfterRender(H,R,G),Ae.resetDefaultState(),J=-1,le=null,T.pop(),T.length>0?(L=T[T.length-1],he.setTextureUnits(L.state.textureUnits),$e===!0&&Xe.setGlobalState(H.clippingPlanes,L.state.camera)):L=null,O.pop(),O.length>0?D=O[O.length-1]:D=null,V!==null&&V.renderEnd()};function Hi(R,G,oe,te){if(R.visible===!1)return;if(R.layers.test(G.layers)){if(R.isGroup)oe=R.renderOrder;else if(R.isLOD)R.autoUpdate===!0&&R.update(G);else if(R.isLightProbeGrid)L.pushLightProbeGrid(R);else if(R.isLight)L.pushLight(R),R.castShadow&&L.pushShadow(R);else if(R.isSprite){if(!R.frustumCulled||at.intersectsSprite(R)){te&&It.setFromMatrixPosition(R.matrixWorld).applyMatrix4(St);const Be=fe.update(R),De=R.material;De.visible&&D.push(R,Be,De,oe,It.z,null)}}else if((R.isMesh||R.isLine||R.isPoints)&&(!R.frustumCulled||at.intersectsObject(R))){const Be=fe.update(R),De=R.material;if(te&&(R.boundingSphere!==void 0?(R.boundingSphere===null&&R.computeBoundingSphere(),It.copy(R.boundingSphere.center)):(Be.boundingSphere===null&&Be.computeBoundingSphere(),It.copy(Be.boundingSphere.center)),It.applyMatrix4(R.matrixWorld).applyMatrix4(St)),Array.isArray(De)){const ze=Be.groups;for(let Ve=0,mt=ze.length;Ve<mt;Ve++){const ct=ze[Ve],et=De[ct.materialIndex];et&&et.visible&&D.push(R,Be,et,oe,It.z,ct)}}else De.visible&&D.push(R,Be,De,oe,It.z,null)}}const Te=R.children;for(let Be=0,De=Te.length;Be<De;Be++)Hi(Te[Be],G,oe,te)}function _r(R,G,oe,te){const{opaque:ne,transmissive:Te,transparent:Be}=R;L.setupLightsView(oe),$e===!0&&Xe.setGlobalState(H.clippingPlanes,oe),te&&w.viewport(U.copy(te)),ne.length>0&&Ot(ne,G,oe),Te.length>0&&Ot(Te,G,oe),Be.length>0&&Ot(Be,G,oe),w.buffers.depth.setTest(!0),w.buffers.depth.setMask(!0),w.buffers.color.setMask(!0),w.setPolygonOffset(!1)}function _t(R,G,oe,te){if((oe.isScene===!0?oe.overrideMaterial:null)!==null)return;if(L.state.transmissionRenderTarget[te.id]===void 0){const et=je.has("EXT_color_buffer_half_float")||je.has("EXT_color_buffer_float");L.state.transmissionRenderTarget[te.id]=new ai(1,1,{generateMipmaps:!0,type:et?pi:Ei,minFilter:Ss,samples:Math.max(4,k.samples),stencilBuffer:l,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Lt.workingColorSpace})}const Te=L.state.transmissionRenderTarget[te.id],Be=te.viewport||U;Te.setSize(Be.z*H.transmissionResolutionScale,Be.w*H.transmissionResolutionScale);const De=H.getRenderTarget(),ze=H.getActiveCubeFace(),Ve=H.getActiveMipmapLevel();H.setRenderTarget(Te),H.getClearColor(qe),be=H.getClearAlpha(),be<1&&H.setClearColor(16777215,.5),H.clear(),ht&&lt.render(oe);const mt=H.toneMapping;H.toneMapping=Ji;const ct=te.viewport;if(te.viewport!==void 0&&(te.viewport=void 0),L.setupLightsView(te),$e===!0&&Xe.setGlobalState(H.clippingPlanes,te),Ot(R,oe,te),he.updateMultisampleRenderTarget(Te),he.updateRenderTargetMipmap(Te),je.has("WEBGL_multisampled_render_to_texture")===!1){let et=!1;for(let Pt=0,Xt=G.length;Pt<Xt;Pt++){const en=G[Pt],{object:Gt,geometry:pn,material:Ye,group:Rn}=en;if(Ye.side===Oi&&Gt.layers.test(te.layers)){const Et=Ye.side;Ye.side=si,Ye.needsUpdate=!0,cn(Gt,oe,te,pn,Ye,Rn),Ye.side=Et,Ye.needsUpdate=!0,et=!0}}et===!0&&(he.updateMultisampleRenderTarget(Te),he.updateRenderTargetMipmap(Te))}H.setRenderTarget(De,ze,Ve),H.setClearColor(qe,be),ct!==void 0&&(te.viewport=ct),H.toneMapping=mt}function Ot(R,G,oe){const te=G.isScene===!0?G.overrideMaterial:null;for(let ne=0,Te=R.length;ne<Te;ne++){const Be=R[ne],{object:De,geometry:ze,group:Ve}=Be;let mt=Be.material;mt.allowOverride===!0&&te!==null&&(mt=te),De.layers.test(oe.layers)&&cn(De,G,oe,ze,mt,Ve)}}function cn(R,G,oe,te,ne,Te){R.onBeforeRender(H,G,oe,te,ne,Te),R.modelViewMatrix.multiplyMatrices(oe.matrixWorldInverse,R.matrixWorld),R.normalMatrix.getNormalMatrix(R.modelViewMatrix),ne.onBeforeRender(H,G,oe,te,R,Te),ne.transparent===!0&&ne.side===Oi&&ne.forceSinglePass===!1?(ne.side=si,ne.needsUpdate=!0,H.renderBufferDirect(oe,G,te,ne,R,Te),ne.side=Kr,ne.needsUpdate=!0,H.renderBufferDirect(oe,G,te,ne,R,Te),ne.side=Oi):H.renderBufferDirect(oe,G,te,ne,R,Te),R.onAfterRender(H,G,oe,te,ne,Te)}function $t(R,G,oe){G.isScene!==!0&&(G=Nt);const te=se.get(R),ne=L.state.lights,Te=L.state.shadowsArray,Be=ne.state.version,De=ke.getParameters(R,ne.state,Te,G,oe,L.state.lightProbeGridArray),ze=ke.getProgramCacheKey(De);let Ve=te.programs;te.environment=R.isMeshStandardMaterial||R.isMeshLambertMaterial||R.isMeshPhongMaterial?G.environment:null,te.fog=G.fog;const mt=R.isMeshStandardMaterial||R.isMeshLambertMaterial&&!R.envMap||R.isMeshPhongMaterial&&!R.envMap;te.envMap=Me.get(R.envMap||te.environment,mt),te.envMapRotation=te.environment!==null&&R.envMap===null?G.environmentRotation:R.envMapRotation,Ve===void 0&&(R.addEventListener("dispose",ln),Ve=new Map,te.programs=Ve);let ct=Ve.get(ze);if(ct!==void 0){if(te.currentProgram===ct&&te.lightsStateVersion===Be)return rn(R,De),ct}else De.uniforms=ke.getUniforms(R),V!==null&&R.isNodeMaterial&&V.build(R,oe,De),R.onBeforeCompile(De,H),ct=ke.acquireProgram(De,ze),Ve.set(ze,ct),te.uniforms=De.uniforms;const et=te.uniforms;return(!R.isShaderMaterial&&!R.isRawShaderMaterial||R.clipping===!0)&&(et.clippingPlanes=Xe.uniform),rn(R,De),te.needsLights=Kt(R),te.lightsStateVersion=Be,te.needsLights&&(et.ambientLightColor.value=ne.state.ambient,et.lightProbe.value=ne.state.probe,et.directionalLights.value=ne.state.directional,et.directionalLightShadows.value=ne.state.directionalShadow,et.spotLights.value=ne.state.spot,et.spotLightShadows.value=ne.state.spotShadow,et.rectAreaLights.value=ne.state.rectArea,et.ltc_1.value=ne.state.rectAreaLTC1,et.ltc_2.value=ne.state.rectAreaLTC2,et.pointLights.value=ne.state.point,et.pointLightShadows.value=ne.state.pointShadow,et.hemisphereLights.value=ne.state.hemi,et.directionalShadowMatrix.value=ne.state.directionalShadowMatrix,et.spotLightMatrix.value=ne.state.spotLightMatrix,et.spotLightMap.value=ne.state.spotLightMap,et.pointShadowMatrix.value=ne.state.pointShadowMatrix),te.lightProbeGrid=L.state.lightProbeGridArray.length>0,te.currentProgram=ct,te.uniformsList=null,ct}function hn(R){if(R.uniformsList===null){const G=R.currentProgram.getUniforms();R.uniformsList=pc.seqWithValue(G.seq,R.uniforms)}return R.uniformsList}function rn(R,G){const oe=se.get(R);oe.outputColorSpace=G.outputColorSpace,oe.batching=G.batching,oe.batchingColor=G.batchingColor,oe.instancing=G.instancing,oe.instancingColor=G.instancingColor,oe.instancingMorph=G.instancingMorph,oe.skinning=G.skinning,oe.morphTargets=G.morphTargets,oe.morphNormals=G.morphNormals,oe.morphColors=G.morphColors,oe.morphTargetsCount=G.morphTargetsCount,oe.numClippingPlanes=G.numClippingPlanes,oe.numIntersection=G.numClipIntersection,oe.vertexAlphas=G.vertexAlphas,oe.vertexTangents=G.vertexTangents,oe.toneMapping=G.toneMapping}function sn(R,G){if(R.length===0)return null;if(R.length===1)return R[0].texture!==null?R[0]:null;C.setFromMatrixPosition(G.matrixWorld);for(let oe=0,te=R.length;oe<te;oe++){const ne=R[oe];if(ne.texture!==null&&ne.boundingBox.containsPoint(C))return ne}return null}function Ht(R,G,oe,te,ne){G.isScene!==!0&&(G=Nt),he.resetTextureUnits();const Te=G.fog,Be=te.isMeshStandardMaterial||te.isMeshLambertMaterial||te.isMeshPhongMaterial?G.environment:null,De=X===null?H.outputColorSpace:X.isXRRenderTarget===!0?X.texture.colorSpace:Lt.workingColorSpace,ze=te.isMeshStandardMaterial||te.isMeshLambertMaterial&&!te.envMap||te.isMeshPhongMaterial&&!te.envMap,Ve=Me.get(te.envMap||Be,ze),mt=te.vertexColors===!0&&!!oe.attributes.color&&oe.attributes.color.itemSize===4,ct=!!oe.attributes.tangent&&(!!te.normalMap||te.anisotropy>0),et=!!oe.morphAttributes.position,Pt=!!oe.morphAttributes.normal,Xt=!!oe.morphAttributes.color;let en=Ji;te.toneMapped&&(X===null||X.isXRRenderTarget===!0)&&(en=H.toneMapping);const Gt=oe.morphAttributes.position||oe.morphAttributes.normal||oe.morphAttributes.color,pn=Gt!==void 0?Gt.length:0,Ye=se.get(te),Rn=L.state.lights;if($e===!0&&(Mt===!0||R!==le)){const Vt=R===le&&te.id===J;Xe.setState(te,R,Vt)}let Et=!1;te.version===Ye.__version?(Ye.needsLights&&Ye.lightsStateVersion!==Rn.state.version||Ye.outputColorSpace!==De||ne.isBatchedMesh&&Ye.batching===!1||!ne.isBatchedMesh&&Ye.batching===!0||ne.isBatchedMesh&&Ye.batchingColor===!0&&ne.colorTexture===null||ne.isBatchedMesh&&Ye.batchingColor===!1&&ne.colorTexture!==null||ne.isInstancedMesh&&Ye.instancing===!1||!ne.isInstancedMesh&&Ye.instancing===!0||ne.isSkinnedMesh&&Ye.skinning===!1||!ne.isSkinnedMesh&&Ye.skinning===!0||ne.isInstancedMesh&&Ye.instancingColor===!0&&ne.instanceColor===null||ne.isInstancedMesh&&Ye.instancingColor===!1&&ne.instanceColor!==null||ne.isInstancedMesh&&Ye.instancingMorph===!0&&ne.morphTexture===null||ne.isInstancedMesh&&Ye.instancingMorph===!1&&ne.morphTexture!==null||Ye.envMap!==Ve||te.fog===!0&&Ye.fog!==Te||Ye.numClippingPlanes!==void 0&&(Ye.numClippingPlanes!==Xe.numPlanes||Ye.numIntersection!==Xe.numIntersection)||Ye.vertexAlphas!==mt||Ye.vertexTangents!==ct||Ye.morphTargets!==et||Ye.morphNormals!==Pt||Ye.morphColors!==Xt||Ye.toneMapping!==en||Ye.morphTargetsCount!==pn||!!Ye.lightProbeGrid!=L.state.lightProbeGridArray.length>0)&&(Et=!0):(Et=!0,Ye.__version=te.version);let Yn=Ye.currentProgram;Et===!0&&(Yn=$t(te,G,ne),V&&te.isNodeMaterial&&V.onUpdateProgram(te,Yn,Ye));let Kn=!1,At=!1,tr=!1;const zt=Yn.getUniforms(),Zt=Ye.uniforms;if(w.useProgram(Yn.program)&&(Kn=!0,At=!0,tr=!0),te.id!==J&&(J=te.id,At=!0),Ye.needsLights){const Vt=sn(L.state.lightProbeGridArray,ne);Ye.lightProbeGrid!==Vt&&(Ye.lightProbeGrid=Vt,At=!0)}if(Kn||le!==R){w.buffers.depth.getReversed()&&R.reversedDepth!==!0&&(R._reversedDepth=!0,R.updateProjectionMatrix()),zt.setValue(j,"projectionMatrix",R.projectionMatrix),zt.setValue(j,"viewMatrix",R.matrixWorldInverse);const Ci=zt.map.cameraPosition;Ci!==void 0&&Ci.setValue(j,Dt.setFromMatrixPosition(R.matrixWorld)),k.logarithmicDepthBuffer&&zt.setValue(j,"logDepthBufFC",2/(Math.log(R.far+1)/Math.LN2)),(te.isMeshPhongMaterial||te.isMeshToonMaterial||te.isMeshLambertMaterial||te.isMeshBasicMaterial||te.isMeshStandardMaterial||te.isShaderMaterial)&&zt.setValue(j,"isOrthographic",R.isOrthographicCamera===!0),le!==R&&(le=R,At=!0,tr=!0)}if(Ye.needsLights&&(Rn.state.directionalShadowMap.length>0&&zt.setValue(j,"directionalShadowMap",Rn.state.directionalShadowMap,he),Rn.state.spotShadowMap.length>0&&zt.setValue(j,"spotShadowMap",Rn.state.spotShadowMap,he),Rn.state.pointShadowMap.length>0&&zt.setValue(j,"pointShadowMap",Rn.state.pointShadowMap,he)),ne.isSkinnedMesh){zt.setOptional(j,ne,"bindMatrix"),zt.setOptional(j,ne,"bindMatrixInverse");const Vt=ne.skeleton;Vt&&(Vt.boneTexture===null&&Vt.computeBoneTexture(),zt.setValue(j,"boneTexture",Vt.boneTexture,he))}ne.isBatchedMesh&&(zt.setOptional(j,ne,"batchingTexture"),zt.setValue(j,"batchingTexture",ne._matricesTexture,he),zt.setOptional(j,ne,"batchingIdTexture"),zt.setValue(j,"batchingIdTexture",ne._indirectTexture,he),zt.setOptional(j,ne,"batchingColorTexture"),ne._colorsTexture!==null&&zt.setValue(j,"batchingColorTexture",ne._colorsTexture,he));const Ai=oe.morphAttributes;if((Ai.position!==void 0||Ai.normal!==void 0||Ai.color!==void 0)&&F.update(ne,oe,Yn),(At||Ye.receiveShadow!==ne.receiveShadow)&&(Ye.receiveShadow=ne.receiveShadow,zt.setValue(j,"receiveShadow",ne.receiveShadow)),(te.isMeshStandardMaterial||te.isMeshLambertMaterial||te.isMeshPhongMaterial)&&te.envMap===null&&G.environment!==null&&(Zt.envMapIntensity.value=G.environmentIntensity),Zt.dfgLUT!==void 0&&(Zt.dfgLUT.value=eE()),At){if(zt.setValue(j,"toneMappingExposure",H.toneMappingExposure),Ye.needsLights&&yr(Zt,tr),Te&&te.fog===!0&&We.refreshFogUniforms(Zt,Te),We.refreshMaterialUniforms(Zt,te,ve,me,L.state.transmissionRenderTarget[R.id]),Ye.needsLights&&Ye.lightProbeGrid){const Vt=Ye.lightProbeGrid;Zt.probesSH.value=Vt.texture,Zt.probesMin.value.copy(Vt.boundingBox.min),Zt.probesMax.value.copy(Vt.boundingBox.max),Zt.probesResolution.value.copy(Vt.resolution)}pc.upload(j,hn(Ye),Zt,he)}if(te.isShaderMaterial&&te.uniformsNeedUpdate===!0&&(pc.upload(j,hn(Ye),Zt,he),te.uniformsNeedUpdate=!1),te.isSpriteMaterial&&zt.setValue(j,"center",ne.center),zt.setValue(j,"modelViewMatrix",ne.modelViewMatrix),zt.setValue(j,"normalMatrix",ne.normalMatrix),zt.setValue(j,"modelMatrix",ne.matrixWorld),te.uniformsGroups!==void 0){const Vt=te.uniformsGroups;for(let Ci=0,Gi=Vt.length;Ci<Gi;Ci++){const ts=Vt[Ci];Se.update(ts,Yn),Se.bind(ts,Yn)}}return Yn}function yr(R,G){R.ambientLightColor.needsUpdate=G,R.lightProbe.needsUpdate=G,R.directionalLights.needsUpdate=G,R.directionalLightShadows.needsUpdate=G,R.pointLights.needsUpdate=G,R.pointLightShadows.needsUpdate=G,R.spotLights.needsUpdate=G,R.spotLightShadows.needsUpdate=G,R.rectAreaLights.needsUpdate=G,R.hemisphereLights.needsUpdate=G}function Kt(R){return R.isMeshLambertMaterial||R.isMeshToonMaterial||R.isMeshPhongMaterial||R.isMeshStandardMaterial||R.isShadowMaterial||R.isShaderMaterial&&R.lights===!0}this.getActiveCubeFace=function(){return de},this.getActiveMipmapLevel=function(){return re},this.getRenderTarget=function(){return X},this.setRenderTargetTextures=function(R,G,oe){const te=se.get(R);te.__autoAllocateDepthBuffer=R.resolveDepthBuffer===!1,te.__autoAllocateDepthBuffer===!1&&(te.__useRenderToTexture=!1),se.get(R.texture).__webglTexture=G,se.get(R.depthTexture).__webglTexture=te.__autoAllocateDepthBuffer?void 0:oe,te.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(R,G){const oe=se.get(R);oe.__webglFramebuffer=G,oe.__useDefaultFramebuffer=G===void 0},this.setRenderTarget=function(R,G=0,oe=0){X=R,de=G,re=oe;let te=null,ne=!1,Te=!1;if(R){const De=se.get(R);if(De.__useDefaultFramebuffer!==void 0){w.bindFramebuffer(j.FRAMEBUFFER,De.__webglFramebuffer),U.copy(R.viewport),q.copy(R.scissor),Re=R.scissorTest,w.viewport(U),w.scissor(q),w.setScissorTest(Re),J=-1;return}else if(De.__webglFramebuffer===void 0)he.setupRenderTarget(R);else if(De.__hasExternalTextures)he.rebindTextures(R,se.get(R.texture).__webglTexture,se.get(R.depthTexture).__webglTexture);else if(R.depthBuffer){const mt=R.depthTexture;if(De.__boundDepthTexture!==mt){if(mt!==null&&se.has(mt)&&(R.width!==mt.image.width||R.height!==mt.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");he.setupDepthRenderbuffer(R)}}const ze=R.texture;(ze.isData3DTexture||ze.isDataArrayTexture||ze.isCompressedArrayTexture)&&(Te=!0);const Ve=se.get(R).__webglFramebuffer;R.isWebGLCubeRenderTarget?(Array.isArray(Ve[G])?te=Ve[G][oe]:te=Ve[G],ne=!0):R.samples>0&&he.useMultisampledRTT(R)===!1?te=se.get(R).__webglMultisampledFramebuffer:Array.isArray(Ve)?te=Ve[oe]:te=Ve,U.copy(R.viewport),q.copy(R.scissor),Re=R.scissorTest}else U.copy(Ze).multiplyScalar(ve).floor(),q.copy(bt).multiplyScalar(ve).floor(),Re=ot;if(oe!==0&&(te=ae),w.bindFramebuffer(j.FRAMEBUFFER,te)&&w.drawBuffers(R,te),w.viewport(U),w.scissor(q),w.setScissorTest(Re),ne){const De=se.get(R.texture);j.framebufferTexture2D(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_CUBE_MAP_POSITIVE_X+G,De.__webglTexture,oe)}else if(Te){const De=G;for(let ze=0;ze<R.textures.length;ze++){const Ve=se.get(R.textures[ze]);j.framebufferTextureLayer(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0+ze,Ve.__webglTexture,oe,De)}}else if(R!==null&&oe!==0){const De=se.get(R.texture);j.framebufferTexture2D(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,De.__webglTexture,oe)}J=-1},this.readRenderTargetPixels=function(R,G,oe,te,ne,Te,Be,De=0){if(!(R&&R.isWebGLRenderTarget)){kt("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let ze=se.get(R).__webglFramebuffer;if(R.isWebGLCubeRenderTarget&&Be!==void 0&&(ze=ze[Be]),ze){w.bindFramebuffer(j.FRAMEBUFFER,ze);try{const Ve=R.textures[De],mt=Ve.format,ct=Ve.type;if(R.textures.length>1&&j.readBuffer(j.COLOR_ATTACHMENT0+De),!k.textureFormatReadable(mt)){kt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!k.textureTypeReadable(ct)){kt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}G>=0&&G<=R.width-te&&oe>=0&&oe<=R.height-ne&&j.readPixels(G,oe,te,ne,Pe.convert(mt),Pe.convert(ct),Te)}finally{const Ve=X!==null?se.get(X).__webglFramebuffer:null;w.bindFramebuffer(j.FRAMEBUFFER,Ve)}}},this.readRenderTargetPixelsAsync=async function(R,G,oe,te,ne,Te,Be,De=0){if(!(R&&R.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let ze=se.get(R).__webglFramebuffer;if(R.isWebGLCubeRenderTarget&&Be!==void 0&&(ze=ze[Be]),ze)if(G>=0&&G<=R.width-te&&oe>=0&&oe<=R.height-ne){w.bindFramebuffer(j.FRAMEBUFFER,ze);const Ve=R.textures[De],mt=Ve.format,ct=Ve.type;if(R.textures.length>1&&j.readBuffer(j.COLOR_ATTACHMENT0+De),!k.textureFormatReadable(mt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!k.textureTypeReadable(ct))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const et=j.createBuffer();j.bindBuffer(j.PIXEL_PACK_BUFFER,et),j.bufferData(j.PIXEL_PACK_BUFFER,Te.byteLength,j.STREAM_READ),j.readPixels(G,oe,te,ne,Pe.convert(mt),Pe.convert(ct),0);const Pt=X!==null?se.get(X).__webglFramebuffer:null;w.bindFramebuffer(j.FRAMEBUFFER,Pt);const Xt=j.fenceSync(j.SYNC_GPU_COMMANDS_COMPLETE,0);return j.flush(),await xy(j,Xt,4),j.bindBuffer(j.PIXEL_PACK_BUFFER,et),j.getBufferSubData(j.PIXEL_PACK_BUFFER,0,Te),j.deleteBuffer(et),j.deleteSync(Xt),Te}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(R,G=null,oe=0){const te=Math.pow(2,-oe),ne=Math.floor(R.image.width*te),Te=Math.floor(R.image.height*te),Be=G!==null?G.x:0,De=G!==null?G.y:0;he.setTexture2D(R,0),j.copyTexSubImage2D(j.TEXTURE_2D,oe,0,0,Be,De,ne,Te),w.unbindTexture()},this.copyTextureToTexture=function(R,G,oe=null,te=null,ne=0,Te=0){let Be,De,ze,Ve,mt,ct,et,Pt,Xt;const en=R.isCompressedTexture?R.mipmaps[Te]:R.image;if(oe!==null)Be=oe.max.x-oe.min.x,De=oe.max.y-oe.min.y,ze=oe.isBox3?oe.max.z-oe.min.z:1,Ve=oe.min.x,mt=oe.min.y,ct=oe.isBox3?oe.min.z:0;else{const Zt=Math.pow(2,-ne);Be=Math.floor(en.width*Zt),De=Math.floor(en.height*Zt),R.isDataArrayTexture?ze=en.depth:R.isData3DTexture?ze=Math.floor(en.depth*Zt):ze=1,Ve=0,mt=0,ct=0}te!==null?(et=te.x,Pt=te.y,Xt=te.z):(et=0,Pt=0,Xt=0);const Gt=Pe.convert(G.format),pn=Pe.convert(G.type);let Ye;G.isData3DTexture?(he.setTexture3D(G,0),Ye=j.TEXTURE_3D):G.isDataArrayTexture||G.isCompressedArrayTexture?(he.setTexture2DArray(G,0),Ye=j.TEXTURE_2D_ARRAY):(he.setTexture2D(G,0),Ye=j.TEXTURE_2D),w.activeTexture(j.TEXTURE0),w.pixelStorei(j.UNPACK_FLIP_Y_WEBGL,G.flipY),w.pixelStorei(j.UNPACK_PREMULTIPLY_ALPHA_WEBGL,G.premultiplyAlpha),w.pixelStorei(j.UNPACK_ALIGNMENT,G.unpackAlignment);const Rn=w.getParameter(j.UNPACK_ROW_LENGTH),Et=w.getParameter(j.UNPACK_IMAGE_HEIGHT),Yn=w.getParameter(j.UNPACK_SKIP_PIXELS),Kn=w.getParameter(j.UNPACK_SKIP_ROWS),At=w.getParameter(j.UNPACK_SKIP_IMAGES);w.pixelStorei(j.UNPACK_ROW_LENGTH,en.width),w.pixelStorei(j.UNPACK_IMAGE_HEIGHT,en.height),w.pixelStorei(j.UNPACK_SKIP_PIXELS,Ve),w.pixelStorei(j.UNPACK_SKIP_ROWS,mt),w.pixelStorei(j.UNPACK_SKIP_IMAGES,ct);const tr=R.isDataArrayTexture||R.isData3DTexture,zt=G.isDataArrayTexture||G.isData3DTexture;if(R.isDepthTexture){const Zt=se.get(R),Ai=se.get(G),Vt=se.get(Zt.__renderTarget),Ci=se.get(Ai.__renderTarget);w.bindFramebuffer(j.READ_FRAMEBUFFER,Vt.__webglFramebuffer),w.bindFramebuffer(j.DRAW_FRAMEBUFFER,Ci.__webglFramebuffer);for(let Gi=0;Gi<ze;Gi++)tr&&(j.framebufferTextureLayer(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,se.get(R).__webglTexture,ne,ct+Gi),j.framebufferTextureLayer(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,se.get(G).__webglTexture,Te,Xt+Gi)),j.blitFramebuffer(Ve,mt,Be,De,et,Pt,Be,De,j.DEPTH_BUFFER_BIT,j.NEAREST);w.bindFramebuffer(j.READ_FRAMEBUFFER,null),w.bindFramebuffer(j.DRAW_FRAMEBUFFER,null)}else if(ne!==0||R.isRenderTargetTexture||se.has(R)){const Zt=se.get(R),Ai=se.get(G);w.bindFramebuffer(j.READ_FRAMEBUFFER,Q),w.bindFramebuffer(j.DRAW_FRAMEBUFFER,ie);for(let Vt=0;Vt<ze;Vt++)tr?j.framebufferTextureLayer(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,Zt.__webglTexture,ne,ct+Vt):j.framebufferTexture2D(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,Zt.__webglTexture,ne),zt?j.framebufferTextureLayer(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,Ai.__webglTexture,Te,Xt+Vt):j.framebufferTexture2D(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,Ai.__webglTexture,Te),ne!==0?j.blitFramebuffer(Ve,mt,Be,De,et,Pt,Be,De,j.COLOR_BUFFER_BIT,j.NEAREST):zt?j.copyTexSubImage3D(Ye,Te,et,Pt,Xt+Vt,Ve,mt,Be,De):j.copyTexSubImage2D(Ye,Te,et,Pt,Ve,mt,Be,De);w.bindFramebuffer(j.READ_FRAMEBUFFER,null),w.bindFramebuffer(j.DRAW_FRAMEBUFFER,null)}else zt?R.isDataTexture||R.isData3DTexture?j.texSubImage3D(Ye,Te,et,Pt,Xt,Be,De,ze,Gt,pn,en.data):G.isCompressedArrayTexture?j.compressedTexSubImage3D(Ye,Te,et,Pt,Xt,Be,De,ze,Gt,en.data):j.texSubImage3D(Ye,Te,et,Pt,Xt,Be,De,ze,Gt,pn,en):R.isDataTexture?j.texSubImage2D(j.TEXTURE_2D,Te,et,Pt,Be,De,Gt,pn,en.data):R.isCompressedTexture?j.compressedTexSubImage2D(j.TEXTURE_2D,Te,et,Pt,en.width,en.height,Gt,en.data):j.texSubImage2D(j.TEXTURE_2D,Te,et,Pt,Be,De,Gt,pn,en);w.pixelStorei(j.UNPACK_ROW_LENGTH,Rn),w.pixelStorei(j.UNPACK_IMAGE_HEIGHT,Et),w.pixelStorei(j.UNPACK_SKIP_PIXELS,Yn),w.pixelStorei(j.UNPACK_SKIP_ROWS,Kn),w.pixelStorei(j.UNPACK_SKIP_IMAGES,At),Te===0&&G.generateMipmaps&&j.generateMipmap(Ye),w.unbindTexture()},this.initRenderTarget=function(R){se.get(R).__webglFramebuffer===void 0&&he.setupRenderTarget(R)},this.initTexture=function(R){R.isCubeTexture?he.setTextureCube(R,0):R.isData3DTexture?he.setTexture3D(R,0):R.isDataArrayTexture||R.isCompressedArrayTexture?he.setTexture2DArray(R,0):he.setTexture2D(R,0),w.unbindTexture()},this.resetState=function(){de=0,re=0,X=null,w.reset(),Ae.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Zi}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=Lt._getDrawingBufferColorSpace(e),t.unpackColorSpace=Lt._getUnpackColorSpace()}}const K0={type:"change"},hf={type:"start"},qg={type:"end"},ic=new To,Z0=new Xr,nE=Math.cos(70*yy.DEG2RAD),yn=new K,ri=2*Math.PI,qt={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},$d=1e-6;class iE extends s1{constructor(e,t=null){super(e,t),this.state=qt.NONE,this.target=new K,this.cursor=new K,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:xa.ROTATE,MIDDLE:xa.DOLLY,RIGHT:xa.PAN},this.touches={ONE:ma.ROTATE,TWO:ma.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._cursorStyle="auto",this._domElementKeyEvents=null,this._lastPosition=new K,this._lastQuaternion=new Qr,this._lastTargetPosition=new K,this._quat=new Qr().setFromUnitVectors(e.up,new K(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new E0,this._sphericalDelta=new E0,this._scale=1,this._panOffset=new K,this._rotateStart=new ut,this._rotateEnd=new ut,this._rotateDelta=new ut,this._panStart=new ut,this._panEnd=new ut,this._panDelta=new ut,this._dollyStart=new ut,this._dollyEnd=new ut,this._dollyDelta=new ut,this._dollyDirection=new K,this._mouse=new ut,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=sE.bind(this),this._onPointerDown=rE.bind(this),this._onPointerUp=aE.bind(this),this._onContextMenu=fE.bind(this),this._onMouseWheel=cE.bind(this),this._onKeyDown=uE.bind(this),this._onTouchStart=dE.bind(this),this._onTouchMove=hE.bind(this),this._onMouseDown=oE.bind(this),this._onMouseMove=lE.bind(this),this._interceptControlDown=pE.bind(this),this._interceptControlUp=mE.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}set cursorStyle(e){this._cursorStyle=e,e==="grab"?this.domElement.style.cursor="grab":this.domElement.style.cursor="auto"}get cursorStyle(){return this._cursorStyle}connect(e){super.connect(e),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.getRootNode().removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.style.touchAction=""}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(e){e.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=e}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(K0),this.update(),this.state=qt.NONE}pan(e,t){this._pan(e,t),this.update()}dollyIn(e){this._dollyIn(e),this.update()}dollyOut(e){this._dollyOut(e),this.update()}rotateLeft(e){this._rotateLeft(e),this.update()}rotateUp(e){this._rotateUp(e),this.update()}update(e=null){const t=this.object.position;yn.copy(t).sub(this.target),yn.applyQuaternion(this._quat),this._spherical.setFromVector3(yn),this.autoRotate&&this.state===qt.NONE&&this._rotateLeft(this._getAutoRotationAngle(e)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let r=this.minAzimuthAngle,a=this.maxAzimuthAngle;isFinite(r)&&isFinite(a)&&(r<-Math.PI?r+=ri:r>Math.PI&&(r-=ri),a<-Math.PI?a+=ri:a>Math.PI&&(a-=ri),r<=a?this._spherical.theta=Math.max(r,Math.min(a,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(r+a)/2?Math.max(r,this._spherical.theta):Math.min(a,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let l=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{const d=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),l=d!=this._spherical.radius}if(yn.setFromSpherical(this._spherical),yn.applyQuaternion(this._quatInverse),t.copy(this.target).add(yn),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let d=null;if(this.object.isPerspectiveCamera){const h=yn.length();d=this._clampDistance(h*this._scale);const f=h-d;this.object.position.addScaledVector(this._dollyDirection,f),this.object.updateMatrixWorld(),l=!!f}else if(this.object.isOrthographicCamera){const h=new K(this._mouse.x,this._mouse.y,0);h.unproject(this.object);const f=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),l=f!==this.object.zoom;const m=new K(this._mouse.x,this._mouse.y,0);m.unproject(this.object),this.object.position.sub(m).add(h),this.object.updateMatrixWorld(),d=yn.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;d!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(d).add(this.object.position):(ic.origin.copy(this.object.position),ic.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(ic.direction))<nE?this.object.lookAt(this.target):(Z0.setFromNormalAndCoplanarPoint(this.object.up,this.target),ic.intersectPlane(Z0,this.target))))}else if(this.object.isOrthographicCamera){const d=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),d!==this.object.zoom&&(this.object.updateProjectionMatrix(),l=!0)}return this._scale=1,this._performCursorZoom=!1,l||this._lastPosition.distanceToSquared(this.object.position)>$d||8*(1-this._lastQuaternion.dot(this.object.quaternion))>$d||this._lastTargetPosition.distanceToSquared(this.target)>$d?(this.dispatchEvent(K0),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(e){return e!==null?ri/60*this.autoRotateSpeed*e:ri/60/60*this.autoRotateSpeed}_getZoomScale(e){const t=Math.abs(e*.01);return Math.pow(.95,this.zoomSpeed*t)}_rotateLeft(e){this._sphericalDelta.theta-=e}_rotateUp(e){this._sphericalDelta.phi-=e}_panLeft(e,t){yn.setFromMatrixColumn(t,0),yn.multiplyScalar(-e),this._panOffset.add(yn)}_panUp(e,t){this.screenSpacePanning===!0?yn.setFromMatrixColumn(t,1):(yn.setFromMatrixColumn(t,0),yn.crossVectors(this.object.up,yn)),yn.multiplyScalar(e),this._panOffset.add(yn)}_pan(e,t){const r=this.domElement;if(this.object.isPerspectiveCamera){const a=this.object.position;yn.copy(a).sub(this.target);let l=yn.length();l*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*e*l/r.clientHeight,this.object.matrix),this._panUp(2*t*l/r.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(e*(this.object.right-this.object.left)/this.object.zoom/r.clientWidth,this.object.matrix),this._panUp(t*(this.object.top-this.object.bottom)/this.object.zoom/r.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(e,t){if(!this.zoomToCursor)return;this._performCursorZoom=!0;const r=this.domElement.getBoundingClientRect(),a=e-r.left,l=t-r.top,d=r.width,h=r.height;this._mouse.x=a/d*2-1,this._mouse.y=-(l/h)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(e){return Math.max(this.minDistance,Math.min(this.maxDistance,e))}_handleMouseDownRotate(e){this._rotateStart.set(e.clientX,e.clientY)}_handleMouseDownDolly(e){this._updateZoomParameters(e.clientX,e.clientX),this._dollyStart.set(e.clientX,e.clientY)}_handleMouseDownPan(e){this._panStart.set(e.clientX,e.clientY)}_handleMouseMoveRotate(e){this._rotateEnd.set(e.clientX,e.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(ri*this._rotateDelta.x/t.clientHeight),this._rotateUp(ri*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(e){this._dollyEnd.set(e.clientX,e.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(e){this._panEnd.set(e.clientX,e.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(e){this._updateZoomParameters(e.clientX,e.clientY),e.deltaY<0?this._dollyIn(this._getZoomScale(e.deltaY)):e.deltaY>0&&this._dollyOut(this._getZoomScale(e.deltaY)),this.update()}_handleKeyDown(e){let t=!1;switch(e.code){case this.keys.UP:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(ri*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),t=!0;break;case this.keys.BOTTOM:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(-ri*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),t=!0;break;case this.keys.LEFT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(ri*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),t=!0;break;case this.keys.RIGHT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(-ri*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),t=!0;break}t&&(e.preventDefault(),this.update())}_handleTouchStartRotate(e){if(this._pointers.length===1)this._rotateStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),r=.5*(e.pageX+t.x),a=.5*(e.pageY+t.y);this._rotateStart.set(r,a)}}_handleTouchStartPan(e){if(this._pointers.length===1)this._panStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),r=.5*(e.pageX+t.x),a=.5*(e.pageY+t.y);this._panStart.set(r,a)}}_handleTouchStartDolly(e){const t=this._getSecondPointerPosition(e),r=e.pageX-t.x,a=e.pageY-t.y,l=Math.sqrt(r*r+a*a);this._dollyStart.set(0,l)}_handleTouchStartDollyPan(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enablePan&&this._handleTouchStartPan(e)}_handleTouchStartDollyRotate(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enableRotate&&this._handleTouchStartRotate(e)}_handleTouchMoveRotate(e){if(this._pointers.length==1)this._rotateEnd.set(e.pageX,e.pageY);else{const r=this._getSecondPointerPosition(e),a=.5*(e.pageX+r.x),l=.5*(e.pageY+r.y);this._rotateEnd.set(a,l)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(ri*this._rotateDelta.x/t.clientHeight),this._rotateUp(ri*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(e){if(this._pointers.length===1)this._panEnd.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),r=.5*(e.pageX+t.x),a=.5*(e.pageY+t.y);this._panEnd.set(r,a)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(e){const t=this._getSecondPointerPosition(e),r=e.pageX-t.x,a=e.pageY-t.y,l=Math.sqrt(r*r+a*a);this._dollyEnd.set(0,l),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);const d=(e.pageX+t.x)*.5,h=(e.pageY+t.y)*.5;this._updateZoomParameters(d,h)}_handleTouchMoveDollyPan(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enablePan&&this._handleTouchMovePan(e)}_handleTouchMoveDollyRotate(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enableRotate&&this._handleTouchMoveRotate(e)}_addPointer(e){this._pointers.push(e.pointerId)}_removePointer(e){delete this._pointerPositions[e.pointerId];for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId){this._pointers.splice(t,1);return}}_isTrackingPointer(e){for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId)return!0;return!1}_trackPointer(e){let t=this._pointerPositions[e.pointerId];t===void 0&&(t=new ut,this._pointerPositions[e.pointerId]=t),t.set(e.pageX,e.pageY)}_getSecondPointerPosition(e){const t=e.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[t]}_customWheelEvent(e){const t=e.deltaMode,r={clientX:e.clientX,clientY:e.clientY,deltaY:e.deltaY};switch(t){case 1:r.deltaY*=16;break;case 2:r.deltaY*=100;break}return e.ctrlKey&&!this._controlActive&&(r.deltaY*=10),r}}function rE(s){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(s.pointerId),this.domElement.ownerDocument.addEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(s)&&(this._addPointer(s),s.pointerType==="touch"?this._onTouchStart(s):this._onMouseDown(s),this._cursorStyle==="grab"&&(this.domElement.style.cursor="grabbing")))}function sE(s){this.enabled!==!1&&(s.pointerType==="touch"?this._onTouchMove(s):this._onMouseMove(s))}function aE(s){switch(this._removePointer(s),this._pointers.length){case 0:this.domElement.releasePointerCapture(s.pointerId),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(qg),this.state=qt.NONE,this._cursorStyle==="grab"&&(this.domElement.style.cursor="grab");break;case 1:const e=this._pointers[0],t=this._pointerPositions[e];this._onTouchStart({pointerId:e,pageX:t.x,pageY:t.y});break}}function oE(s){let e;switch(s.button){case 0:e=this.mouseButtons.LEFT;break;case 1:e=this.mouseButtons.MIDDLE;break;case 2:e=this.mouseButtons.RIGHT;break;default:e=-1}switch(e){case xa.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(s),this.state=qt.DOLLY;break;case xa.ROTATE:if(s.ctrlKey||s.metaKey||s.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(s),this.state=qt.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(s),this.state=qt.ROTATE}break;case xa.PAN:if(s.ctrlKey||s.metaKey||s.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(s),this.state=qt.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(s),this.state=qt.PAN}break;default:this.state=qt.NONE}this.state!==qt.NONE&&this.dispatchEvent(hf)}function lE(s){switch(this.state){case qt.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(s);break;case qt.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(s);break;case qt.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(s);break}}function cE(s){this.enabled===!1||this.enableZoom===!1||this.state!==qt.NONE||(s.preventDefault(),this.dispatchEvent(hf),this._handleMouseWheel(this._customWheelEvent(s)),this.dispatchEvent(qg))}function uE(s){this.enabled!==!1&&this._handleKeyDown(s)}function dE(s){switch(this._trackPointer(s),this._pointers.length){case 1:switch(this.touches.ONE){case ma.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(s),this.state=qt.TOUCH_ROTATE;break;case ma.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(s),this.state=qt.TOUCH_PAN;break;default:this.state=qt.NONE}break;case 2:switch(this.touches.TWO){case ma.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(s),this.state=qt.TOUCH_DOLLY_PAN;break;case ma.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(s),this.state=qt.TOUCH_DOLLY_ROTATE;break;default:this.state=qt.NONE}break;default:this.state=qt.NONE}this.state!==qt.NONE&&this.dispatchEvent(hf)}function hE(s){switch(this._trackPointer(s),this.state){case qt.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(s),this.update();break;case qt.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(s),this.update();break;case qt.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(s),this.update();break;case qt.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(s),this.update();break;default:this.state=qt.NONE}}function fE(s){this.enabled!==!1&&s.preventDefault()}function pE(s){s.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function mE(s){s.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}const mc={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};class Ro{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}}const gE=new df(-1,1,1,-1,0,1);class xE extends Hn{constructor(){super(),this.setAttribute("position",new $n([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new $n([0,2,0,0,2,0],2))}}const vE=new xE;class $g{constructor(e){this._mesh=new Ti(vE,e)}dispose(){this._mesh.geometry.dispose()}render(e){e.render(this._mesh,gE)}get material(){return this._mesh.material}set material(e){this._mesh.material=e}}class _E extends Ro{constructor(e,t="tDiffuse"){super(),this.textureID=t,this.uniforms=null,this.material=null,e instanceof bn?(this.uniforms=e.uniforms,this.material=e):e&&(this.uniforms=Rc.clone(e.uniforms),this.material=new bn({name:e.name!==void 0?e.name:"unspecified",defines:Object.assign({},e.defines),uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader})),this._fsQuad=new $g(this.material)}render(e,t,r){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=r.texture),this._fsQuad.material=this.material,this.renderToScreen?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this._fsQuad.render(e))}dispose(){this.material.dispose(),this._fsQuad.dispose()}}class Q0 extends Ro{constructor(e,t){super(),this.scene=e,this.camera=t,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(e,t,r){const a=e.getContext(),l=e.state;l.buffers.color.setMask(!1),l.buffers.depth.setMask(!1),l.buffers.color.setLocked(!0),l.buffers.depth.setLocked(!0);let d,h;this.inverse?(d=0,h=1):(d=1,h=0),l.buffers.stencil.setTest(!0),l.buffers.stencil.setOp(a.REPLACE,a.REPLACE,a.REPLACE),l.buffers.stencil.setFunc(a.ALWAYS,d,4294967295),l.buffers.stencil.setClear(h),l.buffers.stencil.setLocked(!0),e.setRenderTarget(r),this.clear&&e.clear(),e.render(this.scene,this.camera),e.setRenderTarget(t),this.clear&&e.clear(),e.render(this.scene,this.camera),l.buffers.color.setLocked(!1),l.buffers.depth.setLocked(!1),l.buffers.color.setMask(!0),l.buffers.depth.setMask(!0),l.buffers.stencil.setLocked(!1),l.buffers.stencil.setFunc(a.EQUAL,1,4294967295),l.buffers.stencil.setOp(a.KEEP,a.KEEP,a.KEEP),l.buffers.stencil.setLocked(!0)}}class yE extends Ro{constructor(){super(),this.needsSwap=!1}render(e){e.state.buffers.stencil.setLocked(!1),e.state.buffers.stencil.setTest(!1)}}class bE{constructor(e,t){if(this.renderer=e,this._pixelRatio=e.getPixelRatio(),t===void 0){const r=e.getSize(new ut);this._width=r.width,this._height=r.height,t=new ai(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:pi}),t.texture.name="EffectComposer.rt1"}else this._width=t.width,this._height=t.height;this.renderTarget1=t,this.renderTarget2=t.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new _E(mc),this.copyPass.material.blending=Qi,this.timer=new t1}swapBuffers(){const e=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=e}addPass(e){this.passes.push(e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(e,t){this.passes.splice(t,0,e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(e){const t=this.passes.indexOf(e);t!==-1&&this.passes.splice(t,1)}isLastEnabledPass(e){for(let t=e+1;t<this.passes.length;t++)if(this.passes[t].enabled)return!1;return!0}render(e){this.timer.update(),e===void 0&&(e=this.timer.getDelta());const t=this.renderer.getRenderTarget();let r=!1;for(let a=0,l=this.passes.length;a<l;a++){const d=this.passes[a];if(d.enabled!==!1){if(d.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(a),d.render(this.renderer,this.writeBuffer,this.readBuffer,e,r),d.needsSwap){if(r){const h=this.renderer.getContext(),f=this.renderer.state.buffers.stencil;f.setFunc(h.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,e),f.setFunc(h.EQUAL,1,4294967295)}this.swapBuffers()}Q0!==void 0&&(d instanceof Q0?r=!0:d instanceof yE&&(r=!1))}}this.renderer.setRenderTarget(t)}reset(e){if(e===void 0){const t=this.renderer.getSize(new ut);this._pixelRatio=this.renderer.getPixelRatio(),this._width=t.width,this._height=t.height,e=this.renderTarget1.clone(),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=e,this.renderTarget2=e.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(e,t){this._width=e,this._height=t;const r=this._width*this._pixelRatio,a=this._height*this._pixelRatio;this.renderTarget1.setSize(r,a),this.renderTarget2.setSize(r,a);for(let l=0;l<this.passes.length;l++)this.passes[l].setSize(r,a)}setPixelRatio(e){this._pixelRatio=e,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}}class SE extends Ro{constructor(e,t,r=null,a=null,l=null){super(),this.scene=e,this.camera=t,this.overrideMaterial=r,this.clearColor=a,this.clearAlpha=l,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this.isRenderPass=!0,this._oldClearColor=new vt}render(e,t,r){const a=e.autoClear;e.autoClear=!1;let l,d;this.overrideMaterial!==null&&(d=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(e.getClearColor(this._oldClearColor),e.setClearColor(this.clearColor,e.getClearAlpha())),this.clearAlpha!==null&&(l=e.getClearAlpha(),e.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&e.clearDepth(),e.setRenderTarget(this.renderToScreen?null:r),this.clear===!0&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(this.scene,this.camera),this.clearColor!==null&&e.setClearColor(this._oldClearColor),this.clearAlpha!==null&&e.setClearAlpha(l),this.overrideMaterial!==null&&(this.scene.overrideMaterial=d),e.autoClear=a}}const ME={uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new vt(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			float v = luminance( texel.xyz );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};class wa extends Ro{constructor(e,t=1,r,a){super(),this.strength=t,this.radius=r,this.threshold=a,this.resolution=e!==void 0?new ut(e.x,e.y):new ut(256,256),this.clearColor=new vt(0,0,0),this.needsSwap=!1,this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let l=Math.round(this.resolution.x/2),d=Math.round(this.resolution.y/2);this.renderTargetBright=new ai(l,d,{type:pi}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let _=0;_<this.nMips;_++){const S=new ai(l,d,{type:pi});S.texture.name="UnrealBloomPass.h"+_,S.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(S);const v=new ai(l,d,{type:pi});v.texture.name="UnrealBloomPass.v"+_,v.texture.generateMipmaps=!1,this.renderTargetsVertical.push(v),l=Math.round(l/2),d=Math.round(d/2)}const h=ME;this.highPassUniforms=Rc.clone(h.uniforms),this.highPassUniforms.luminosityThreshold.value=a,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new bn({uniforms:this.highPassUniforms,vertexShader:h.vertexShader,fragmentShader:h.fragmentShader}),this.separableBlurMaterials=[];const f=[6,10,14,18,22];l=Math.round(this.resolution.x/2),d=Math.round(this.resolution.y/2);for(let _=0;_<this.nMips;_++)this.separableBlurMaterials.push(this._getSeparableBlurMaterial(f[_])),this.separableBlurMaterials[_].uniforms.invSize.value=new ut(1/l,1/d),l=Math.round(l/2),d=Math.round(d/2);this.compositeMaterial=this._getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=t,this.compositeMaterial.uniforms.bloomRadius.value=.1;const m=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=m,this.bloomTintColors=[new K(1,1,1),new K(1,1,1),new K(1,1,1),new K(1,1,1),new K(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,this.copyUniforms=Rc.clone(mc.uniforms),this.blendMaterial=new bn({uniforms:this.copyUniforms,vertexShader:mc.vertexShader,fragmentShader:mc.fragmentShader,premultipliedAlpha:!0,blending:yc,depthTest:!1,depthWrite:!1,transparent:!0}),this._oldClearColor=new vt,this._oldClearAlpha=1,this._basic=new cf,this._fsQuad=new $g(null)}dispose(){for(let e=0;e<this.renderTargetsHorizontal.length;e++)this.renderTargetsHorizontal[e].dispose();for(let e=0;e<this.renderTargetsVertical.length;e++)this.renderTargetsVertical[e].dispose();this.renderTargetBright.dispose();for(let e=0;e<this.separableBlurMaterials.length;e++)this.separableBlurMaterials[e].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this._basic.dispose(),this._fsQuad.dispose()}setSize(e,t){let r=Math.round(e/2),a=Math.round(t/2);this.renderTargetBright.setSize(r,a);for(let l=0;l<this.nMips;l++)this.renderTargetsHorizontal[l].setSize(r,a),this.renderTargetsVertical[l].setSize(r,a),this.separableBlurMaterials[l].uniforms.invSize.value=new ut(1/r,1/a),r=Math.round(r/2),a=Math.round(a/2)}render(e,t,r,a,l){e.getClearColor(this._oldClearColor),this._oldClearAlpha=e.getClearAlpha();const d=e.autoClear;e.autoClear=!1,e.setClearColor(this.clearColor,0),l&&e.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this._fsQuad.material=this._basic,this._basic.map=r.texture,e.setRenderTarget(null),e.clear(),this._fsQuad.render(e)),this.highPassUniforms.tDiffuse.value=r.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this._fsQuad.material=this.materialHighPassFilter,e.setRenderTarget(this.renderTargetBright),e.clear(),this._fsQuad.render(e);let h=this.renderTargetBright;for(let f=0;f<this.nMips;f++)this._fsQuad.material=this.separableBlurMaterials[f],this.separableBlurMaterials[f].uniforms.colorTexture.value=h.texture,this.separableBlurMaterials[f].uniforms.direction.value=wa.BlurDirectionX,e.setRenderTarget(this.renderTargetsHorizontal[f]),e.clear(),this._fsQuad.render(e),this.separableBlurMaterials[f].uniforms.colorTexture.value=this.renderTargetsHorizontal[f].texture,this.separableBlurMaterials[f].uniforms.direction.value=wa.BlurDirectionY,e.setRenderTarget(this.renderTargetsVertical[f]),e.clear(),this._fsQuad.render(e),h=this.renderTargetsVertical[f];this._fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,e.setRenderTarget(this.renderTargetsHorizontal[0]),e.clear(),this._fsQuad.render(e),this._fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,l&&e.state.buffers.stencil.setTest(!0),this.renderToScreen?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(r),this._fsQuad.render(e)),e.setClearColor(this._oldClearColor,this._oldClearAlpha),e.autoClear=d}_getSeparableBlurMaterial(e){const t=[],r=e/3;for(let a=0;a<e;a++)t.push(.39894*Math.exp(-.5*a*a/(r*r))/r);return new bn({defines:{KERNEL_RADIUS:e},uniforms:{colorTexture:{value:null},invSize:{value:new ut(.5,.5)},direction:{value:new ut(.5,.5)},gaussianCoefficients:{value:t}},vertexShader:`

				varying vec2 vUv;

				void main() {

					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

				}`,fragmentShader:`

				#include <common>

				varying vec2 vUv;

				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {

					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;

					for ( int i = 1; i < KERNEL_RADIUS; i ++ ) {

						float x = float( i );
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += ( sample1 + sample2 ) * w;

					}

					gl_FragColor = vec4( diffuseSum, 1.0 );

				}`})}_getCompositeMaterial(e){return new bn({defines:{NUM_MIPS:e},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`

				varying vec2 vUv;

				void main() {

					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

				}`,fragmentShader:`

				varying vec2 vUv;

				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor( const in float factor ) {

					float mirrorFactor = 1.2 - factor;
					return mix( factor, mirrorFactor, bloomRadius );

				}

				void main() {

					// 3.0 for backwards compatibility with previous alpha-based intensity
					vec3 bloom = 3.0 * bloomStrength * (
						lerpBloomFactor( bloomFactors[ 0 ] ) * bloomTintColors[ 0 ] * texture2D( blurTexture1, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 1 ] ) * bloomTintColors[ 1 ] * texture2D( blurTexture2, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 2 ] ) * bloomTintColors[ 2 ] * texture2D( blurTexture3, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 3 ] ) * bloomTintColors[ 3 ] * texture2D( blurTexture4, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 4 ] ) * bloomTintColors[ 4 ] * texture2D( blurTexture5, vUv ).rgb
					);

					float bloomAlpha = max( bloom.r, max( bloom.g, bloom.b ) );
					gl_FragColor = vec4( bloom, bloomAlpha );

				}`})}}wa.BlurDirectionX=new ut(1,0);wa.BlurDirectionY=new ut(0,1);const wE=`
uniform float time;
uniform sampler2D probabilityTexture;
uniform float maxHeight;
uniform float textureSize;
uniform float greedyAnchorIndex;
uniform float uTemperature;
uniform float uMaxProb;
uniform float uMinP;

attribute vec2 umapCoord;
attribute float tokenIndex;
attribute float isRagGrounded;

varying vec2 vUmapCoord;
varying float vActiveProb;
varying float vBaseProb;
varying float vTokenIndex;
varying float vIsRagGrounded;
varying float vIsGreedyAnchor;
varying float vElevation;
varying vec3 vBiomeColor;
varying float vViewDistance;

void main() {
    vUmapCoord = umapCoord;
    vTokenIndex = tokenIndex;
    vIsRagGrounded = isRagGrounded;
    vIsGreedyAnchor = (tokenIndex == greedyAnchorIndex) ? 1.0 : 0.0;

    // Calculate UV for the DataTexture
    float texSize = textureSize;
    vec2 texUV = vec2(
        (mod(tokenIndex, texSize) + 0.5) / texSize,
        (floor(tokenIndex / texSize) + 0.5) / texSize
    );

    vec4 probs = texture2D(probabilityTexture, texUV);
    float activeProb = probs.r;
    float baseProb = probs.g;
    
    vActiveProb = activeProb;
    vBaseProb = baseProb;

    // ─── 1. Base Cartographic Topography (Permanent Hypsometric Relief) ──
    float geoHills = exp(-dot(umapCoord - vec2(0.45, 0.45), umapCoord - vec2(0.45, 0.45)) / 0.35) * 12.0;
    float verbHills = exp(-dot(umapCoord - vec2(-0.50, 0.15), umapCoord - vec2(-0.50, 0.15)) / 0.35) * 10.0;
    float codeHills = exp(-dot(umapCoord - vec2(0.55, -0.25), umapCoord - vec2(0.55, -0.25)) / 0.30) * 8.0;
    float syntaxPlain = exp(-dot(umapCoord - vec2(0.0, -0.60), umapCoord - vec2(0.0, -0.60)) / 0.30) * 4.0;
    float coreSpire = exp(-dot(umapCoord, umapCoord) / 0.08) * 15.0;

    float baseTopography = geoHills + verbHills + codeHills + syntaxPlain + coreSpire;

    // ─── 2. Zero-Safe Clamped Thermodynamic Peak Displacement ────────────
    // Normalizing relative probability (P_i / P_max) anchors the active summit to maxHeight
    float safeMaxProb = max(uMaxProb, 1e-7);
    float safeProbRatio = max(activeProb / safeMaxProb, 1e-7);
    float safeTemp = max(uTemperature, 0.01);
    
    // As T -> 0.05 (Glacial freeze): peaks sharpen into needles
    // As T -> 2.0 (Thermal erosion): peaks collapse and spread
    float activeSummit = (activeProb > 0.0001) ? (maxHeight * pow(safeProbRatio, 1.0 / safeTemp)) : 0.0;
    
    float totalElevation = baseTopography + activeSummit;
    vElevation = totalElevation;

    // ─── 3. Biome Color Allocation ──────────────────────────────────────
    vec3 colGeo = vec3(0.96, 0.62, 0.04);     // Terracotta / Amber (#F59E0B)
    vec3 colVerb = vec3(0.51, 0.55, 0.97);    // Indigo / Cobalt (#818CF8)
    vec3 colCode = vec3(0.02, 0.71, 0.83);    // Cyan / Emerald (#06B6D4)
    vec3 colSyntax = vec3(0.39, 0.45, 0.55);  // Basalt Slate (#64748B)
    vec3 colCore = vec3(0.89, 0.91, 0.94);    // Platinum White (#E2E8F0)

    float totalWeight = geoHills + verbHills + codeHills + syntaxPlain + coreSpire + 0.001;
    vec3 blendedBiome = (colGeo * geoHills + 
                         colVerb * verbHills + 
                         colCode * codeHills + 
                         colSyntax * syntaxPlain + 
                         colCore * coreSpire) / totalWeight;

    vBiomeColor = blendedBiome;

    // Landscape bounds in 3D world coordinates
    float spread = 250.0;
    vec3 pos = vec3(umapCoord.x * spread, totalElevation, umapCoord.y * spread);
    
    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    gl_Position = projectionMatrix * mvPosition;

    float viewDist = -mvPosition.z;
    vViewDistance = viewDist;

    // ─── 4. Dynamic Level of Detail (LoD) Point Sizing ──────────────────
    float lodScale = mix(1.6, 0.85, smoothstep(80.0, 450.0, viewDist));
    float minSize = 3.0 * lodScale;
    float maxSize = 18.0 * lodScale;
    
    float probability = max(activeProb, baseProb);
    float activeSize = mix(minSize, maxSize, probability);
    
    float ragSize = isRagGrounded * 8.0;
    float anchorSize = vIsGreedyAnchor * 14.0; // Radiant beacon for Greedy Target #1
    
    gl_PointSize = (activeSize + ragSize + anchorSize) * (340.0 / max(10.0, viewDist));
}
`,EE=`
uniform float time;
uniform float uIsThinking;

varying vec2 vUmapCoord;
varying float vActiveProb;
varying float vBaseProb;
varying float vTokenIndex;
varying float vIsRagGrounded;
varying float vIsGreedyAnchor;
varying float vElevation;
varying vec3 vBiomeColor;
varying float vViewDistance;

void main() {
    // Soft circular particle
    vec2 cxy = 2.0 * gl_PointCoord - 1.0;
    float r = dot(cxy, cxy);
    if (r > 1.0) discard;

    // Status Colors (Houdini Unified Taxonomy)
    vec3 candidateColor = vec3(0.85, 0.27, 0.94);  // Magenta (#D946EF)
    vec3 winnerColor = vec3(0.06, 0.72, 0.51);     // Emerald (#10B981)
    vec3 ragColor = vec3(0.02, 0.71, 0.83);        // Cyan (#06B6D4)
    vec3 ghostColor = vec3(0.15, 0.40, 0.55);      // Ghost Blue

    // ─── 1. Topographic Isobar Contour Rings (Dual-Frequency) ───────────
    float majorIsobar = fract(vElevation / 6.0);
    float minorIsobar = fract(vElevation / 2.0);
    float isobarMaskMajor = smoothstep(0.85, 0.98, majorIsobar);
    float isobarMaskMinor = smoothstep(0.92, 0.98, minorIsobar) * 0.4;
    float totalIsobar = max(isobarMaskMajor, isobarMaskMinor);

    // ─── 2. Biome-Aware Base Color Mapping ──────────────────────────────
    vec3 idleColor = mix(vBiomeColor * 0.45, vBiomeColor * 0.90, smoothstep(0.0, 16.0, vElevation));
    
    // Active candidates transition from Biome color -> Magenta -> Emerald
    vec3 activeCol = mix(idleColor, candidateColor, smoothstep(0.004, 0.10, vActiveProb));
    vec3 color = mix(activeCol, winnerColor, smoothstep(0.18, 1.0, vActiveProb));

    // ─── 3. Isobar Contour Glow ─────────────────────────────────────────
    color = mix(color, color + vec3(0.35, 0.40, 0.60), totalIsobar * 0.55);

    // Reasoning Pulse
    if (uIsThinking > 0.5) {
        vec3 thinkColor = mix(vec3(0.95, 0.55, 0.1), vec3(0.65, 0.25, 0.95), (sin(time * 3.0) + 1.0) * 0.5);
        color = mix(color, thinkColor, 0.55);
    }

    // Celestial Anchors overrides (HDR Intensity for Bloom)
    if (vIsRagGrounded > 0.5) {
        color = mix(color, ragColor * 7.0, 0.85);
    }

    if (vIsGreedyAnchor > 0.5) {
        color = vec3(14.0, 14.0, 14.0); // Bright radiant beacon for Greedy Target #1
    }

    // Ghost Shell Diffing logic
    float probDelta = vActiveProb - vBaseProb;
    if (probDelta < -0.01) {
        color = mix(color, ghostColor, smoothstep(0.0, 0.5, -probDelta));
    }

    // ─── 4. Alpha Intensity & Continuous Density LoD Falloff ────────────
    float distFromCenter = length(vUmapCoord);
    float perimeterFade = smoothstep(1.25, 0.35, distFromCenter);

    // LoD density blending: distant points use softer Gaussian radial profile
    float densityProfile = (vViewDistance > 250.0) ? exp(-r * 2.8) : (1.0 - r);
    
    float baseAlpha = 0.38 * perimeterFade;
    float activeAlpha = smoothstep(0.001, 1.0, max(vActiveProb, vBaseProb)) * 0.75;
    float alpha = (baseAlpha + activeAlpha) * densityProfile;
    
    if (probDelta < -0.01) {
        alpha *= 0.5;
    }

    if (vIsGreedyAnchor > 0.5) {
        alpha = 1.0;
    }

    gl_FragColor = vec4(color, alpha);
}
`,TE="token-cosmos-terrain",AE=1,Ea="coordinates";function Yg(){return new Promise((s,e)=>{const t=indexedDB.open(TE,AE);t.onupgradeneeded=()=>{const r=t.result;r.objectStoreNames.contains(Ea)||r.createObjectStore(Ea,{keyPath:"modelId"})},t.onsuccess=()=>s(t.result),t.onerror=()=>e(t.error)})}async function CE(s){try{const e=await Yg();return new Promise((t,r)=>{const d=e.transaction(Ea,"readonly").objectStore(Ea).get(s);d.onsuccess=()=>{const h=d.result;t(h?{...h,coordinates:new Float32Array(h.coordinates)}:null)},d.onerror=()=>r(d.error)})}catch{return console.warn("[CoordCache] IndexedDB unavailable, skipping cache"),null}}async function RE(s){try{const e=await Yg();return new Promise((t,r)=>{const l=e.transaction(Ea,"readwrite").objectStore(Ea),d={...s,coordinates:s.coordinates.buffer},h=l.put(d);h.onsuccess=()=>t(),h.onerror=()=>r(h.error)})}catch{console.warn("[CoordCache] Failed to cache coordinates")}}const PE={"SmolLM2-135M-Instruct-q4f16_1-MLC":"/terrain/smollm2-135m-umap.bin","SmolLM2-135M-Instruct-q0f16-MLC":"/terrain/smollm2-135m-umap.bin","Qwen2.5-0.5B-Instruct-q4f16_1-MLC":"/terrain/qwen2.5-0.5b-umap.bin","Qwen2.5-1.5B-Instruct-q4f16_1-MLC":"/terrain/qwen2.5-0.5b-umap.bin"},NE={"SmolLM2-135M-Instruct-q4f16_1-MLC":49152,"SmolLM2-135M-Instruct-q0f16-MLC":49152,"Qwen2.5-0.5B-Instruct-q4f16_1-MLC":151936,"Qwen2.5-1.5B-Instruct-q4f16_1-MLC":151936,__SAMPLE_FALLBACK__:49152};async function LE(s){const e=await fetch(s);if(!e.ok)throw new Error(`Failed to load coordinates: ${e.status}`);if((e.headers.get("content-type")||"").includes("text/html"))throw new Error("Coordinate asset resolved to HTML instead of binary data");const r=await e.arrayBuffer();if(r.byteLength<8)throw new Error("Coordinate asset is missing its binary header");const l=new Uint32Array(r,0,2)[0],d=8+l*2*Float32Array.BYTES_PER_ELEMENT;if(l===0||d!==r.byteLength)throw new Error("Coordinate asset has an invalid binary length");const h=new Float32Array(r,8,l*2);return{vocabSize:l,coordinates:h}}function DE(s){return()=>{s|=0,s=s+1831565813|0;let e=Math.imul(s^s>>>15,1|s);return e=e+Math.imul(e^e>>>7,61|e)^e,((e^e>>>14)>>>0)/4294967296}}function IE(s){const e=s(),t=s(),r=Math.sqrt(-2*Math.log(Math.max(e,1e-10))),a=2*Math.PI*t;return[r*Math.cos(a),r*Math.sin(a)]}function kE(s){const e=new Float32Array(s*2),t=DE(42),r=16,a=[];for(let d=0;d<r;d++){const h=d/r*2*Math.PI+t()*.3,f=.35+t()*.45;a.push({cx:f*Math.cos(h),cy:f*Math.sin(h),sigma:.06+t()*.08})}a.push({cx:0,cy:0,sigma:.12});const l=a.length;for(let d=0;d<s;d++){const h=Math.floor(t()*l),f=a[h],[m,_]=IE(t);let S=f.cx+m*f.sigma,v=f.cy+_*f.sigma;S=Math.max(-1,Math.min(1,S)),v=Math.max(-1,Math.min(1,v)),e[d*2]=S,e[d*2+1]=v}return e}function FE(s,e){const t=Math.atan2(e,s);return Math.sqrt(s*s+e*e)<.15?"Core (High Frequency)":t>=-Math.PI/4&&t<Math.PI/4?"East (Nouns / Entities)":t>=Math.PI/4&&t<3*Math.PI/4?"North (Adjectives / Descriptors)":t>=-3*Math.PI/4&&t<-Math.PI/4?"South (Code / Syntax)":"West (Function Words / Grammar)"}function UE(s){const[e,t]=Y.useState(!1),[r,a]=Y.useState(null),[l,d]=Y.useState(0),[h,f]=Y.useState(null),[m,_]=Y.useState(null),S=Y.useRef(0),v=Y.useCallback(async M=>{const E=++S.current;t(!0),a(null),f(null),d(0);const g=(x,N)=>E!==S.current?!1:(f(x),d(N),_(M),t(!1),!0);try{const x=await CE(M);if(x){if(!g(x.coordinates,x.vocabSize))return;console.log(`[Terrain] Loaded cached coordinates for ${M} (${x.vocabSize} tokens)`);return}const N=PE[M];if(N)try{const{vocabSize:D,coordinates:L}=await LE(N);if(!g(L,D))return;await RE({modelId:M,vocabSize:D,coordinates:L,version:1,cachedAt:Date.now()}),console.log(`[Terrain] Loaded pre-computed coordinates for ${M} (${D} tokens)`);return}catch{console.warn(`[Terrain] Pre-computed asset not found for ${M}, using fallback`)}const P=NE[M]||151936,C=kE(P);if(!g(C,P))return;console.log(`[Terrain] Generated procedural terrain coordinates for ${M} (${P} tokens)`)}catch(x){if(E!==S.current)return;const N=x instanceof Error?x.message:String(x);a(N),t(!1)}},[]);Y.useEffect(()=>{s&&v(s)},[s,v]);const b=Y.useCallback(M=>!h||M<0||M>=l?null:{x:h[M*2],y:h[M*2+1]},[h,l]);return{isLoading:e,isLoaded:h!==null&&h.length>0,error:r,loadedModelId:m,vocabSize:l,rawCoordinates:h,getPosition:b,getRegionLabel:FE,loadForModel:v}}const xr=[{id:"geo_entities",name:"Entities & Geography",shortLabel:"CAPITAL CITIES & GEOGRAPHY",code:"GEO",description:"Cities, countries, named entities, proper nouns & geographical references",colorHex:"#F59E0B",rgb:[.96,.62,.04],center:[.45,.45],radius:.55,elevationBias:12},{id:"abstract_verbs",name:"Abstract Concepts & Verbs",shortLabel:"ABSTRACT VERBS & CONCEPTS",code:"VRB",description:"Action verbs, mental processes, transitions, and philosophical abstractions",colorHex:"#818CF8",rgb:[.51,.55,.97],center:[-.5,.15],radius:.55,elevationBias:10},{id:"syntax_structure",name:"Syntax & Structural Tokens",shortLabel:"SYNTAX & BRACKETS",code:"SYN",description:"Punctuation, JSON syntax, markdown fences, braces & formatting delimiters",colorHex:"#64748B",rgb:[.39,.45,.55],center:[0,-.6],radius:.5,elevationBias:4},{id:"numeric_code",name:"Numerics & Code Logic",shortLabel:"NUMERICS & PROGRAMMING",code:"NUM",description:"Integers, floats, code keywords, hexadecimal bytes & mathematical symbols",colorHex:"#06B6D4",rgb:[.02,.71,.83],center:[.55,-.25],radius:.5,elevationBias:8},{id:"core_grammar",name:"Core High-Frequency Grammar",shortLabel:"CORE GRAMMAR & STOPWORDS",code:"COR",description:"High-frequency function words, articles, prepositions, and universal roots",colorHex:"#E2E8F0",rgb:[.89,.91,.94],center:[0,0],radius:.25,elevationBias:15}],Pc=["A","B","C","D","E","F"],Nc=["01","02","03","04","05","06"];function Kg(s,e){const t=Math.max(0,Math.min(.999,(s+1)/2)),r=Math.max(0,Math.min(.999,(e+1)/2)),a=Math.floor(t*Pc.length),l=Math.floor(r*Nc.length);return`${Pc[a]}-${Nc[l]}`}function Zg(s,e){let t=xr[0],r=1/0;for(let a=0;a<xr.length;a++){const l=xr[a],d=s-l.center[0],h=e-l.center[1],f=(d*d+h*h)/(l.radius*l.radius);f<r&&(r=f,t=l)}return t}function OE(s,e){return Zg(s,e)}function rc(s,e){const t=Math.exp(-((s-.45)**2+(e-.45)**2)/.35)*12,r=Math.exp(-((s- -.5)**2+(e-.15)**2)/.35)*10,a=Math.exp(-((s-.55)**2+(e- -.25)**2)/.3)*8,l=Math.exp(-((s-0)**2+(e- -.6)**2)/.3)*4,d=Math.exp(-(s**2+e**2)/.08)*15;return t+r+a+l+d}const BE=({cameraAngle:s,cameraPos:e,targetPos:t,activeToken:r})=>{const[a,l]=Y.useState(!0),d=140,h=d/2,f=d/2*.85,m=r?{x:h+r.umapX*f,y:h-r.umapY*f}:null,_=r?Kg(r.umapX,r.umapY):"C-03",S=r?OE(r.umapX,r.umapY):xr[4],v=t.x-e.x,b=t.z-e.z,M=Math.atan2(b,v),E=Math.PI/6,g=38,x=h+Math.cos(M-E)*g,N=h+Math.sin(M-E)*g,P=h+Math.cos(M+E)*g,C=h+Math.sin(M+E)*g;return c.jsx("div",{className:"absolute bottom-4 right-4 z-20 flex flex-col items-end pointer-events-auto",children:c.jsxs("div",{className:"bg-slate-950/85 backdrop-blur-md border border-slate-700/60 rounded-xl shadow-2xl p-2.5 transition-all duration-300",children:[c.jsxs("div",{className:"flex items-center justify-between gap-3 mb-1.5 pb-1 border-b border-slate-800/80",children:[c.jsxs("div",{className:"flex items-center gap-1.5",children:[c.jsx("span",{className:"w-2 h-2 rounded-full bg-cyan-400 animate-pulse"}),c.jsx("span",{className:"text-[10px] font-mono tracking-wider font-semibold text-slate-300 uppercase",children:"SEMANTIC RADAR"})]}),c.jsx("button",{onClick:()=>l(!a),className:"text-[9px] font-mono text-slate-400 hover:text-cyan-300 transition-colors",title:"Toggle Mini-Radar Size",children:a?"▼":"▲"})]}),a&&c.jsxs(c.Fragment,{children:[c.jsxs("div",{className:"relative border border-slate-800 rounded-lg overflow-hidden bg-slate-950",children:[c.jsxs("svg",{width:d,height:d,className:"block",children:[xr.map(D=>{const L=h+D.center[0]*f,O=h-D.center[1]*f,T=D.radius*f*.9;return c.jsx("circle",{cx:L,cy:O,r:T,fill:D.colorHex,fillOpacity:.12,stroke:D.colorHex,strokeWidth:.75,strokeDasharray:"2 2",strokeOpacity:.4},D.id)}),Pc.map((D,L)=>{const O=d/Pc.length*(L+1);return c.jsx("line",{x1:O,y1:0,x2:O,y2:d,stroke:"#334155",strokeWidth:.5,strokeOpacity:.35},`col-${L}`)}),Nc.map((D,L)=>{const O=d/Nc.length*(L+1);return c.jsx("line",{x1:0,y1:O,x2:d,y2:O,stroke:"#334155",strokeWidth:.5,strokeOpacity:.35},`row-${L}`)}),c.jsx("circle",{cx:h,cy:h,r:f*.5,fill:"none",stroke:"#475569",strokeWidth:.5,strokeDasharray:"1 3"}),c.jsx("circle",{cx:h,cy:h,r:f,fill:"none",stroke:"#475569",strokeWidth:.75,strokeOpacity:.5}),c.jsx("line",{x1:h-4,y1:h,x2:h+4,y2:h,stroke:"#64748B",strokeWidth:1}),c.jsx("line",{x1:h,y1:h-4,x2:h,y2:h+4,stroke:"#64748B",strokeWidth:1}),c.jsx("polygon",{points:`${h},${h} ${x},${N} ${P},${C}`,fill:"#38BDF8",fillOpacity:.18,stroke:"#38BDF8",strokeWidth:.75,strokeOpacity:.6}),m&&c.jsxs("g",{children:[c.jsx("circle",{cx:m.x,cy:m.y,r:7,fill:S.colorHex,fillOpacity:.3,className:"animate-ping"}),c.jsx("circle",{cx:m.x,cy:m.y,r:3.5,fill:"#FFFFFF",stroke:S.colorHex,strokeWidth:1.5})]})]}),c.jsx("span",{className:"absolute top-0.5 left-1/2 -translate-x-1/2 text-[8px] font-mono text-slate-500 font-bold",children:"N: GEO"}),c.jsx("span",{className:"absolute bottom-0.5 left-1/2 -translate-x-1/2 text-[8px] font-mono text-slate-500 font-bold",children:"S: SYN"}),c.jsx("span",{className:"absolute top-1/2 left-0.5 -translate-y-1/2 text-[8px] font-mono text-slate-500 font-bold",children:"W: VRB"}),c.jsx("span",{className:"absolute top-1/2 right-0.5 -translate-y-1/2 text-[8px] font-mono text-slate-500 font-bold",children:"E: NUM"})]}),c.jsxs("div",{className:"mt-1.5 flex flex-col gap-0.5 text-[9px] font-mono",children:[c.jsxs("div",{className:"flex items-center justify-between text-slate-300",children:[c.jsx("span",{className:"text-slate-400",children:"Sector:"}),c.jsx("span",{className:"text-cyan-300 font-bold",children:_})]}),c.jsx("div",{className:"flex items-center justify-between text-slate-400 truncate max-w-[140px]",children:c.jsx("span",{className:"truncate",style:{color:S.colorHex},children:S.shortLabel})})]})]})]})})},zE=5,jE=64;class HE{root=null;heightmap=null;terrainSize=300;terrainHalfSize=150;gridW=64;gridH=64;allPoints=[];build(e,t,r=300,a=64,l=64){this.allPoints=e,this.heightmap=t,this.terrainSize=r,this.terrainHalfSize=r/2,this.gridW=a,this.gridH=l;const d={minX:-this.terrainHalfSize,maxX:this.terrainHalfSize,minZ:-this.terrainHalfSize,maxZ:this.terrainHalfSize};this.root=this.createNode(d,0);for(let h=0;h<e.length;h++)this.insert(this.root,e[h])}createNode(e,t){return{bounds:e,points:[],children:void 0,isLeaf:!0,depth:t}}insert(e,t){if(e.isLeaf){if(e.points.length<jE||e.depth>=zE){e.points.push(t);return}this.subdivide(e)}const{minX:r,maxX:a,minZ:l,maxZ:d}=e.bounds,h=(r+a)/2,f=(l+d)/2,m=t.worldZ<f,_=t.worldX<h;e.children&&(m&&_?this.insert(e.children[0],t):m&&!_?this.insert(e.children[1],t):!m&&_?this.insert(e.children[2],t):this.insert(e.children[3],t))}subdivide(e){const{minX:t,maxX:r,minZ:a,maxZ:l}=e.bounds,d=(t+r)/2,h=(a+l)/2,f=e.depth+1;e.children=[this.createNode({minX:t,maxX:d,minZ:a,maxZ:h},f),this.createNode({minX:d,maxX:r,minZ:a,maxZ:h},f),this.createNode({minX:t,maxX:d,minZ:h,maxZ:l},f),this.createNode({minX:d,maxX:r,minZ:h,maxZ:l},f)],e.isLeaf=!1;const m=e.points;e.points=[];for(let _=0;_<m.length;_++)this.insert(e,m[_])}queryNearest(e,t,r=8){if(!this.root)return null;let a=null,l=r*r;const d=h=>{const f=Math.max(h.bounds.minX-e,0,e-h.bounds.maxX),m=Math.max(h.bounds.minZ-t,0,t-h.bounds.maxZ);if(!(f*f+m*m>l)){if(h.isLeaf)for(let _=0;_<h.points.length;_++){const S=h.points[_],v=(S.worldX-e)**2+(S.worldZ-t)**2;v<l&&(l=v,a=S)}else if(h.children)for(let _=0;_<4;_++)d(h.children[_])}};return d(this.root),a}queryLassoScreenSpace(e,t,r,a){if(!this.root||e.length<3)return[];let l=1/0,d=-1/0,h=1/0,f=-1/0;for(let g=0;g<e.length;g++){const x=e[g];x.x<l&&(l=x.x),x.x>d&&(d=x.x),x.y<h&&(h=x.y),x.y>f&&(f=x.y)}const m=[],_=new K,S=t.position,v=(g,x,N)=>(_.set(g,x,N).project(t),{x:(_.x+1)*r/2,y:(-_.y+1)*a/2,zNDC:_.z}),b=(g,x)=>{let N=!1;for(let P=0,C=e.length-1;P<e.length;C=P++){const D=e[P].x,L=e[P].y,O=e[C].x,T=e[C].y;L>x!=T>x&&g<(O-D)*(x-L)/(T-L)+D&&(N=!N)}return N},M=g=>{if(!this.heightmap)return!0;const x=24,N=S.x,P=S.y,C=S.z,D=g.worldX,L=g.elevation,O=g.worldZ;for(let T=1;T<x;T++){const I=T/x,H=N+I*(D-N),B=P+I*(L-P),V=C+I*(O-C),ae=Math.floor((H+this.terrainHalfSize)/this.terrainSize*this.gridW),Q=Math.floor((V+this.terrainHalfSize)/this.terrainSize*this.gridH),ie=Math.max(0,Math.min(this.gridW-1,ae)),de=Math.max(0,Math.min(this.gridH-1,Q));if(this.heightmap[de*this.gridW+ie]>B+1.2)return!1}return!0},E=g=>{const x=v(g.bounds.minX,0,g.bounds.minZ),N=v(g.bounds.maxX,0,g.bounds.minZ),P=v(g.bounds.minX,0,g.bounds.maxZ),C=v(g.bounds.maxX,0,g.bounds.maxZ);if(x.zNDC>1&&N.zNDC>1&&P.zNDC>1&&C.zNDC>1)return;const D=Math.min(x.x,N.x,P.x,C.x),L=Math.max(x.x,N.x,P.x,C.x),O=Math.min(x.y,N.y,P.y,C.y),T=Math.max(x.y,N.y,P.y,C.y);if(!(L<l||D>d||T<h||O>f)){if(g.isLeaf)for(let I=0;I<g.points.length;I++){const H=g.points[I],B=v(H.worldX,H.elevation,H.worldZ);B.zNDC>1||B.x>=l&&B.x<=d&&B.y>=h&&B.y<=f&&b(B.x,B.y)&&M(H)&&m.push(H)}else if(g.children)for(let I=0;I<4;I++)E(g.children[I])}};return E(this.root),m}computeClusterMetrics(e){if(e.length===0)return{tokenCount:0,topTokens:[],shannonEntropy:0,averageProbability:0,biomeBreakdown:[],dominantBiome:"None"};const r=[...e].sort((m,_)=>(_.probability||0)-(m.probability||0)).slice(0,5).map((m,_)=>({token_id:m.token_id,token_str:m.token_str,probability:m.probability||0,rank:_+1,biomeId:m.biomeId}));let a=0,l=0;const d={};for(let m=0;m<e.length;m++){const _=e[m],S=_.probability||1e-4;l+=S,S>0&&(a-=S*Math.log2(S)),d[_.biomeId]=(d[_.biomeId]||0)+1}const h=Object.keys(d).map(m=>{const _=xr.find(v=>v.id===m),S=d[m];return{biomeId:m,label:_?_.name:m,color:_?_.colorHex:"#94A3B8",count:S,percentage:Math.round(S/e.length*100)}});h.sort((m,_)=>_.count-m.count);const f=h[0]?h[0].label:"General";return{tokenCount:e.length,topTokens:r,shannonEntropy:Math.max(0,a),averageProbability:l/e.length,biomeBreakdown:h,dominantBiome:f}}}const Yd=new HE,GE=({enabled:s,onLassoComplete:e,onCameraLockChange:t})=>{const r=Y.useRef(null),a=Y.useRef(!1),l=Y.useRef([]),d=Y.useRef(!1),[h,f]=Y.useState(s);Y.useEffect(()=>{f(s||d.current)},[s]);const m=Y.useCallback(()=>{const M=r.current;if(!M)return;const E=M.getBoundingClientRect(),g=Math.min(window.devicePixelRatio||1,2);M.width=E.width*g,M.height=E.height*g;const x=M.getContext("2d");x&&x.scale(g,g)},[]);Y.useEffect(()=>(m(),window.addEventListener("resize",m),()=>window.removeEventListener("resize",m)),[m]);const _=Y.useCallback(()=>{const M=r.current;if(!M)return;const E=M.getContext("2d");if(!E)return;const g=M.getBoundingClientRect();E.clearRect(0,0,g.width,g.height);const x=l.current;if(!(x.length<2)){E.save(),E.beginPath(),E.moveTo(x[0].x,x[0].y);for(let N=1;N<x.length;N++)E.lineTo(x[N].x,x[N].y);E.strokeStyle="#06B6D4",E.lineWidth=2,E.shadowColor="#06B6D4",E.shadowBlur=8,E.stroke(),x.length>2&&(E.closePath(),E.fillStyle="rgba(6, 182, 212, 0.12)",E.fill()),E.restore()}},[]);Y.useEffect(()=>{const M=g=>{g.key==="Shift"&&(d.current=!0,f(!0),t(!0))},E=g=>{g.key==="Shift"&&(d.current=!1,!a.current&&!s&&(f(!1),t(!1)))};return window.addEventListener("keydown",M),window.addEventListener("keyup",E),()=>{window.removeEventListener("keydown",M),window.removeEventListener("keyup",E)}},[s,t]);const S=M=>{if(!s&&!d.current&&!M.shiftKey)return;a.current=!0,t(!0);const E=M.currentTarget.getBoundingClientRect(),g=M.clientX-E.left,x=M.clientY-E.top;l.current=[{x:g,y:x}],M.currentTarget.setPointerCapture(M.pointerId)},v=M=>{if(!a.current)return;const E=M.currentTarget.getBoundingClientRect(),g=M.clientX-E.left,x=M.clientY-E.top,N=l.current[l.current.length-1];(!N||Math.hypot(g-N.x,x-N.y)>4)&&(l.current.push({x:g,y:x}),_())},b=M=>{if(!a.current)return;a.current=!1,!d.current&&!s&&(f(!1),t(!1));try{M.currentTarget.releasePointerCapture(M.pointerId)}catch{}const E=l.current;if(E.length>=3){let x=0,N=0;for(let C=0;C<E.length;C++)x+=E[C].x,N+=E[C].y;const P={x:x/E.length,y:N/E.length};e(E,P)}const g=r.current;if(g){const x=g.getContext("2d");if(x){const N=g.getBoundingClientRect();x.clearRect(0,0,N.width,N.height)}}l.current=[]};return c.jsx("canvas",{ref:r,className:`absolute inset-0 z-20 ${h?"pointer-events-auto cursor-crosshair touch-none":"pointer-events-none"}`,style:{width:"100%",height:"100%"},onPointerDown:S,onPointerMove:v,onPointerUp:b,onPointerCancel:b})},VE=({metrics:s,onClose:e})=>!s||s.tokenCount===0?null:c.jsxs("div",{className:"absolute top-20 right-6 z-30 w-96 bg-slate-950/90 backdrop-blur-xl border border-cyan-500/30 rounded-xl shadow-2xl p-5 text-slate-100 animate-in fade-in slide-in-from-right-4 duration-300 pointer-events-auto",style:{boxShadow:"0 0 35px rgba(6, 182, 212, 0.15)"},children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-slate-800/80 pb-3 mb-4",children:[c.jsxs("div",{className:"flex items-center gap-2",children:[c.jsx("div",{className:"w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"}),c.jsx("h3",{className:"font-mono text-xs uppercase tracking-widest text-cyan-400 font-bold",children:"Semantic Cluster Telemetry"})]}),c.jsx("button",{onClick:e,className:"text-slate-400 hover:text-slate-200 text-xs px-2 py-1 rounded bg-slate-800/50 hover:bg-slate-800 transition-colors",children:"✕ Dismiss"})]}),c.jsxs("div",{className:"grid grid-cols-2 gap-3 mb-4",children:[c.jsxs("div",{className:"bg-slate-900/80 border border-slate-800 rounded-lg p-3",children:[c.jsx("div",{className:"text-[10px] uppercase font-mono tracking-wider text-slate-400",children:"Tokens Selected"}),c.jsx("div",{className:"text-xl font-bold font-mono text-cyan-300 mt-1",children:s.tokenCount.toLocaleString()}),c.jsxs("div",{className:"text-[10px] text-slate-500 mt-0.5",children:["Dominant: ",c.jsx("span",{className:"text-slate-300 font-medium",children:s.dominantBiome})]})]}),c.jsxs("div",{className:"bg-slate-900/80 border border-slate-800 rounded-lg p-3",children:[c.jsx("div",{className:"text-[10px] uppercase font-mono tracking-wider text-slate-400",children:"Shannon Entropy"}),c.jsxs("div",{className:"text-xl font-bold font-mono text-amber-400 mt-1",children:[s.shannonEntropy.toFixed(2)," ",c.jsx("span",{className:"text-xs font-normal text-amber-400/70",children:"bits"})]}),c.jsxs("div",{className:"text-[10px] text-slate-500 mt-0.5",children:["Mean P: ",(s.averageProbability*100).toFixed(2),"%"]})]})]}),c.jsxs("div",{className:"mb-4",children:[c.jsxs("div",{className:"text-[10px] uppercase font-mono tracking-wider text-slate-400 mb-2 flex items-center justify-between",children:[c.jsx("span",{children:"Top Candidates In Region"}),c.jsx("span",{className:"text-[9px] text-cyan-500",children:"SORTED BY PROB"})]}),c.jsx("div",{className:"space-y-1.5 max-h-40 overflow-y-auto pr-1 custom-scrollbar",children:s.topTokens.length>0?s.topTokens.map((t,r)=>c.jsxs("div",{className:"flex items-center justify-between p-2 rounded bg-slate-900/60 border border-slate-800/60 text-xs",children:[c.jsxs("div",{className:"flex items-center gap-2 overflow-hidden",children:[c.jsxs("span",{className:"font-mono text-[10px] text-slate-500 w-4",children:["#",t.rank]}),c.jsxs("span",{className:"font-mono text-slate-200 font-semibold truncate max-w-[120px]",children:['"',t.token_str,'"']})]}),c.jsxs("div",{className:"flex items-center gap-2",children:[c.jsx("div",{className:"w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden",children:c.jsx("div",{className:"h-full bg-cyan-400 rounded-full",style:{width:`${Math.min(100,Math.max(5,t.probability*100))}%`}})}),c.jsxs("span",{className:"font-mono text-[10px] text-cyan-300 w-12 text-right",children:[(t.probability*100).toFixed(1),"%"]})]})]},t.token_id||r)):c.jsx("div",{className:"text-xs text-slate-500 italic py-2 text-center",children:"No active candidate probabilities in selection"})})]}),c.jsxs("div",{children:[c.jsx("div",{className:"text-[10px] uppercase font-mono tracking-wider text-slate-400 mb-2",children:"Territorial Biome Composition"}),c.jsx("div",{className:"space-y-2",children:s.biomeBreakdown.map(t=>c.jsxs("div",{className:"text-xs",children:[c.jsxs("div",{className:"flex justify-between text-[11px] mb-1",children:[c.jsxs("span",{className:"text-slate-300 flex items-center gap-1.5",children:[c.jsx("span",{className:"w-2 h-2 rounded-full inline-block",style:{backgroundColor:t.color}}),t.label]}),c.jsxs("span",{className:"font-mono text-slate-400",children:[t.count," (",t.percentage,"%)"]})]}),c.jsx("div",{className:"w-full h-1.5 bg-slate-800/80 rounded-full overflow-hidden",children:c.jsx("div",{className:"h-full rounded-full transition-all duration-500",style:{width:`${t.percentage}%`,backgroundColor:t.color}})})]},t.biomeId))})]}),c.jsx("div",{className:"mt-4 pt-3 border-t border-slate-800/80 text-[10px] text-slate-500 flex justify-between font-mono",children:c.jsxs("span",{children:["Hold ",c.jsx("kbd",{className:"bg-slate-800 text-slate-300 px-1 py-0.5 rounded border border-slate-700",children:"Shift"})," + Drag to lasso new region"]})})]}),WE=({modelId:s,status:e,stepIndex:t=0,topCandidate:r,isLassoActive:a,isFullscreen:l=!1,persona:d="flight_sim",temperature:h=1,minP:f=.05,onToggleLasso:m,onResetCamera:_,onToggleFullscreen:S,onZoomIn:v,onZoomOut:b,onTogglePersona:M,onOpenEnterpriseLabs:E,onOpenMultiModel:g})=>{const x=d==="flight_sim";return c.jsxs("div",{className:"absolute top-4 left-4 z-30 pointer-events-none flex flex-col gap-2 max-w-[95vw]",children:[c.jsxs("div",{className:"flex items-center flex-wrap gap-2.5 bg-slate-950/90 backdrop-blur-md border border-slate-800/90 px-3.5 py-1.5 rounded-xl text-slate-200 shadow-2xl pointer-events-auto",children:[M&&c.jsx("button",{onClick:M,className:`px-2.5 py-0.5 rounded-lg font-mono text-[10px] font-bold tracking-wider transition-all flex items-center gap-1.5 border ${x?"bg-gradient-to-r from-cyan-950 to-blue-950 text-cyan-300 border-cyan-700/60 shadow-[0_0_12px_rgba(6,182,212,0.35)]":"bg-gradient-to-r from-purple-950 to-indigo-950 text-purple-300 border-purple-700/60 shadow-[0_0_12px_rgba(168,85,247,0.35)]"}`,title:"Click to toggle between Executive Flight Simulator & Diagnostic Command Center",children:c.jsx("span",{children:x?"✈ FLIGHT SIMULATOR":"🔬 DIAGNOSTIC COMMAND"})}),c.jsx("div",{className:"h-3 w-px bg-slate-800"}),c.jsxs("div",{className:"flex items-center gap-2",children:[c.jsx("div",{className:`w-2 h-2 rounded-full ${e==="generating"?"bg-emerald-400 animate-ping":e==="ready"?"bg-cyan-400":"bg-amber-400"}`}),c.jsx("span",{className:"font-mono text-xs font-semibold text-slate-100 tracking-wider",children:s||"Synthetic Cosmos"})]}),c.jsx("div",{className:"h-3 w-px bg-slate-800"}),c.jsxs("div",{className:"flex items-center gap-1 font-mono text-[11px] text-slate-400",children:[c.jsx("span",{className:"text-slate-500 uppercase text-[9px]",children:"STEP"}),c.jsxs("span",{className:"text-slate-200 font-bold",children:["#",t]})]}),r&&c.jsxs(c.Fragment,{children:[c.jsx("div",{className:"h-3 w-px bg-slate-800"}),c.jsxs("div",{className:"flex items-center gap-1.5 font-mono text-[11px]",children:[c.jsx("span",{className:"text-slate-500 uppercase text-[9px]",children:"TARGET #1"}),c.jsxs("span",{className:"text-emerald-400 font-bold",children:['"',r.token_str,'"']}),c.jsxs("span",{className:"text-slate-400 text-[10px]",children:["(",(r.probability*100).toFixed(1),"%)"]})]})]}),c.jsx("div",{className:"h-3 w-px bg-slate-800"}),c.jsxs("div",{className:"flex items-center gap-2 font-mono text-[10px] text-slate-400 bg-slate-900/80 px-2 py-0.5 rounded border border-slate-800",children:[c.jsxs("span",{title:"Thermodynamic Temperature Peak Scaling",children:[c.jsx("strong",{className:"text-amber-400",children:"T:"})," ",h.toFixed(2)]}),c.jsx("span",{className:"text-slate-700",children:"|"}),c.jsxs("span",{title:"Waterline Sea Level Cutoff",children:[c.jsx("strong",{className:"text-cyan-400",children:"Min-P:"})," ",(f*100).toFixed(1),"%"]})]}),c.jsx("div",{className:"h-3 w-px bg-slate-800"}),c.jsxs("div",{className:"flex items-center gap-1.5",children:[v&&c.jsx("button",{onClick:v,className:"w-6 h-6 flex items-center justify-center rounded text-xs font-mono font-bold bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 transition-colors",title:"Zoom In",children:"+"}),b&&c.jsx("button",{onClick:b,className:"w-6 h-6 flex items-center justify-center rounded text-xs font-mono font-bold bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 transition-colors",title:"Zoom Out",children:"−"}),c.jsx("button",{onClick:_,className:"px-2 py-0.5 rounded text-[10px] font-mono bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 transition-colors",title:"Reset 3D Orbit Camera",children:"Reset Orbit"}),c.jsx("button",{onClick:m,className:`px-2 py-0.5 rounded text-[10px] font-mono transition-all ${a?"bg-cyan-500 text-slate-950 font-bold shadow-[0_0_10px_rgba(6,182,212,0.4)]":"bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700"}`,title:"Toggle 2D Lasso Selection (or hold Shift + Drag)",children:"Lasso [Shift]"}),E&&c.jsx("button",{onClick:E,className:"px-2 py-0.5 rounded text-[10px] font-mono bg-indigo-950/80 hover:bg-indigo-900 text-indigo-200 hover:text-white border border-indigo-700/60 transition-all font-semibold shadow-[0_0_10px_rgba(99,102,241,0.25)]",title:"Open Enterprise Training Missions & Certification Labs",children:"🎓 Labs"}),g&&c.jsx("button",{onClick:g,className:"px-2 py-0.5 rounded text-[10px] font-mono bg-purple-950/80 hover:bg-purple-900 text-purple-200 hover:text-white border border-purple-700/60 transition-all font-semibold shadow-[0_0_10px_rgba(168,85,247,0.25)]",title:"Open Multi-Model Trajectory Comparison & Ghost Overlay",children:"⚖ Compare"}),S&&c.jsx("button",{onClick:S,className:`px-2 py-0.5 rounded text-[10px] font-mono transition-all flex items-center gap-1 ${l?"bg-amber-500/20 text-amber-300 border border-amber-500/50":"bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700"}`,title:l?"Exit Fullscreen":"Enter Fullscreen",children:c.jsx("span",{children:l?"Exit FS":"⛶ Fullscreen"})})]})]}),c.jsx("div",{className:"text-[10px] font-mono text-slate-400 px-1 drop-shadow flex items-center flex-wrap gap-3",children:x?c.jsxs(c.Fragment,{children:[c.jsxs("span",{children:[c.jsx("strong",{className:"text-cyan-300",children:"Flight Simulator:"})," Watch Temperature erode glaciers & Min-P flood valleys"]}),c.jsxs("span",{children:[c.jsx("strong",{className:"text-slate-300",children:"Shift + Drag:"})," Lasso Cluster"]})]}):c.jsxs(c.Fragment,{children:[c.jsxs("span",{children:[c.jsx("strong",{className:"text-purple-300",children:"Diagnostic Command:"})," 3D DDA Line-of-Sight Occlusion & Shannon Entropy"]}),c.jsxs("span",{children:[c.jsx("strong",{className:"text-slate-300",children:"L/R Drag:"})," Orbit/Pan"]})]})})]})},XE=`
  uniform float u_time;
  uniform float u_water_elevation;
  
  varying vec2 v_uv;
  varying vec3 v_world_pos;
  varying float v_wave_height;

  void main() {
    v_uv = uv;
    
    // Multi-frequency undulating surface waves
    vec3 pos = position;
    float wave1 = sin(pos.x * 0.06 + u_time * 1.8) * cos(pos.z * 0.06 + u_time * 1.4) * 0.45;
    float wave2 = sin(pos.x * 0.12 - u_time * 2.2 + pos.z * 0.08) * 0.25;
    float totalWave = wave1 + wave2;
    
    pos.y = u_water_elevation + totalWave;
    v_wave_height = totalWave;
    
    vec4 worldPos = modelMatrix * vec4(pos, 1.0);
    v_world_pos = worldPos.xyz;
    gl_Position = projectionMatrix * viewMatrix * worldPos;
  }
`,qE=`
  uniform float u_time;
  uniform vec3 u_deep_color;
  uniform vec3 u_shallow_color;
  uniform float u_opacity;
  
  varying vec2 v_uv;
  varying vec3 v_world_pos;
  varying float v_wave_height;

  // Procedural 2D caustic cellular pattern
  float causticNoise(vec2 uv, float t) {
    vec2 p = uv * 14.0;
    float c1 = sin(p.x + sin(p.y + t * 1.5)) * 0.5 + 0.5;
    float c2 = cos(p.y + cos(p.x + t * 1.2)) * 0.5 + 0.5;
    return pow(c1 * c2, 1.8) * 1.6;
  }

  void main() {
    float caustics = causticNoise(v_uv, u_time * 0.8);
    
    // Blend deep abyss with shallow illuminated turquoise
    vec3 baseColor = mix(u_deep_color, u_shallow_color, clamp(v_wave_height * 0.8 + 0.5, 0.0, 1.0));
    vec3 finalColor = baseColor + vec3(0.08, 0.25, 0.35) * caustics;
    
    // Subtle distance fog fade
    float dist = length(v_world_pos.xz);
    float alpha = u_opacity * smoothstep(180.0, 60.0, dist);
    
    gl_FragColor = vec4(finalColor, alpha);
  }
`;class $E{mesh;material;currentElevation=0;targetElevation=0;constructor(e=340,t=64){const r=new Co(e,e,t,t);r.rotateX(-Math.PI/2),this.material=new bn({vertexShader:XE,fragmentShader:qE,uniforms:{u_time:{value:0},u_water_elevation:{value:0},u_deep_color:{value:new vt(138027)},u_shallow_color:{value:new vt(440020)},u_opacity:{value:.52}},transparent:!0,depthWrite:!1,side:Oi}),this.mesh=new Ti(r,this.material),this.mesh.position.y=0,this.mesh.renderOrder=10}setElevation(e,t=!1){this.targetElevation=e,t&&(this.currentElevation=e,this.material.uniforms.u_water_elevation.value=e)}update(e){this.material.uniforms.u_time.value+=e,this.currentElevation+=(this.targetElevation-this.currentElevation)*Math.min(1,e*8),this.material.uniforms.u_water_elevation.value=this.currentElevation}setVisible(e){this.mesh.visible=e}dispose(){this.mesh.geometry.dispose(),this.material.dispose()}}const YE=`
  varying vec2 v_uv;
  varying vec3 v_world_pos;

  void main() {
    v_uv = uv;
    vec4 worldPos = modelMatrix * vec4(position, 1.0);
    v_world_pos = worldPos.xyz;
    gl_Position = projectionMatrix * viewMatrix * worldPos;
  }
`,KE=`
  uniform float u_time;
  uniform vec3 u_head_color;
  uniform vec3 u_tail_color;
  uniform float u_has_anomaly;
  uniform float u_is_ghost;
  
  varying vec2 v_uv;
  varying vec3 v_world_pos;

  void main() {
    // v_uv.y maps strictly from 0.0 (fading tail) to 1.0 (active head)
    float progress = v_uv.y;
    
    // Normal active neon glow vs crimson anomaly alert vs ghost trajectory
    vec3 baseCol = mix(u_tail_color, u_head_color, smoothstep(0.0, 1.0, progress));
    
    if (u_has_anomaly > 0.5) {
      vec3 anomalyCol = vec3(0.95, 0.20, 0.25); // Crimson warning
      baseCol = mix(baseCol, anomalyCol, 0.75);
    }
    
    if (u_is_ghost > 0.5) {
      vec3 ghostCol = vec3(0.38, 0.45, 0.65); // Ghost lavender-slate
      baseCol = mix(baseCol, ghostCol, 0.85);
    }
    
    // Edge glow falloff
    float edgeGlow = pow(sin(v_uv.x * 3.14159), 0.65);
    
    // Trailing alpha fade (ghost has lower opacity)
    float maxAlpha = (u_is_ghost > 0.5) ? 0.45 : 0.92;
    float alpha = progress * edgeGlow * maxAlpha;
    
    gl_FragColor = vec4(baseCol * (u_is_ghost > 0.5 ? 1.0 : 1.5), alpha);
  }
`;class J0{mesh;geometry;material;positions;normals;uvs;maxPoints;activeCount=0;historyCoords=[];isGhost;onAnomalyDetected;constructor(e=128,t=3.2,r=!1){this.maxPoints=e,this.isGhost=r,this.geometry=new Hn;const a=e*2;this.positions=new Float32Array(a*3),this.normals=new Float32Array(a*3),this.uvs=new Float32Array(a*2);for(let h=0;h<e;h++){const f=h/(e-1);this.uvs[h*4+0]=0,this.uvs[h*4+1]=f,this.uvs[h*4+2]=1,this.uvs[h*4+3]=f}const l=(e-1)*6,d=new Uint16Array(l);for(let h=0;h<e-1;h++){const f=h*2,m=h*2+1,_=(h+1)*2,S=(h+1)*2+1,v=h*6;d[v+0]=f,d[v+1]=m,d[v+2]=_,d[v+3]=m,d[v+4]=S,d[v+5]=_}this.geometry.setAttribute("position",new Cn(this.positions,3)),this.geometry.setAttribute("normal",new Cn(this.normals,3)),this.geometry.setAttribute("uv",new Cn(this.uvs,2)),this.geometry.setIndex(new Cn(d,1)),this.geometry.setDrawRange(0,0),this.material=new bn({vertexShader:YE,fragmentShader:KE,uniforms:{u_time:{value:0},u_head_color:{value:r?new vt(6583435):new vt(440020)},u_tail_color:{value:r?new vt(3359061):new vt(5195493)},u_has_anomaly:{value:0},u_is_ghost:{value:r?1:0}},transparent:!0,depthWrite:!1,side:Oi,blending:yc}),r&&(this.material.polygonOffset=!0,this.material.polygonOffsetFactor=1,this.material.polygonOffsetUnits=1),this.mesh=new Ti(this.geometry,this.material),this.mesh.renderOrder=r?14:15}addStep(e,t,r,a=1.6){const l=r.clone();if(l.y+=this.isGhost?2.2:2.5,!this.isGhost&&this.historyCoords.length>1){const b=this.historyCoords[this.historyCoords.length-1],M=l.distanceTo(b);M>160?(this.material.uniforms.u_has_anomaly.value=1,this.onAnomalyDetected?.({type:"DRIFT_JUMP",message:`Semantic Jump (${M.toFixed(0)} units across continent)`,stepIndex:t,tokenStr:e,severity:"warning",location:l})):this.material.uniforms.u_has_anomaly.value=0}this.historyCoords.push(l);const d=this.historyCoords.length>1?new K().subVectors(l,this.historyCoords[this.historyCoords.length-2]).normalize():new K(0,0,1),h=new K(0,1,0),f=new K().crossVectors(d,h).normalize().multiplyScalar(a),m=new K().addVectors(l,f),_=new K().subVectors(l,f);if(this.activeCount<this.maxPoints){const b=this.activeCount*6;this.positions[b+0]=m.x,this.positions[b+1]=m.y,this.positions[b+2]=m.z,this.positions[b+3]=_.x,this.positions[b+4]=_.y,this.positions[b+5]=_.z,this.normals[b+0]=0,this.normals[b+1]=1,this.normals[b+2]=0,this.normals[b+3]=0,this.normals[b+4]=1,this.normals[b+5]=0,this.activeCount++}else{const b=this.activeCount*6;this.positions.copyWithin(0,6,b),this.normals.copyWithin(0,6,b);const M=(this.maxPoints-1)*6;this.positions[M+0]=m.x,this.positions[M+1]=m.y,this.positions[M+2]=m.z,this.positions[M+3]=_.x,this.positions[M+4]=_.y,this.positions[M+5]=_.z,this.normals[M+0]=0,this.normals[M+1]=1,this.normals[M+2]=0,this.normals[M+3]=0,this.normals[M+4]=1,this.normals[M+5]=0}const S=this.geometry.getAttribute("position"),v=this.geometry.getAttribute("normal");S.needsUpdate=!0,v.needsUpdate=!0,this.activeCount>1&&this.geometry.setDrawRange(0,(this.activeCount-1)*6)}getHistory(){return[...this.historyCoords]}loadFromHistory(e,t=1.6){this.clear();for(let r=0;r<e.length;r++)this.addStep(`Step #${r}`,r,e[r],t)}update(e){this.material.uniforms.u_time.value+=e}clear(){this.activeCount=0,this.historyCoords=[],this.geometry.setDrawRange(0,0),this.material.uniforms.u_has_anomaly.value=0}dispose(){this.geometry.dispose(),this.material.dispose()}}const eg=[{id:"temp_glacier",number:1,title:"The Temperature Glacier",subtitle:"Taming Hallucinations & Deterministic Spire Geometry",category:"EXECUTIVE AI LITERACY",description:"Observe how thermodynamic temperature erodes the probability terrain. At low temperatures (T=0.1), the terrain freezes into a razor-sharp glacial spire where the model output is 100% deterministic. At high temperatures (T=1.8), peaks collapse into boiling mud, spreading probability across hallucinatory tokens.",objective:"Freeze the temperature to T=0.15 to generate a deterministic legal contract clause without drift.",recommendedSettings:{temperature:.15,minP:.05,topK:50},prompt:"Define the limitation of liability clause under Delaware corporate law:",expectedOutcome:"High peak concentration in Syntax and Entity continents with zero cross-continental drift.",badgeName:"Glacial Determinism Master"},{id:"min_p_floodgate",number:2,title:"The Min-P Floodgate",subtitle:"Raising the Water Level to Submerge Hallucinatory Noise",category:"RISK MANAGEMENT & FINANCE",description:"Unlike Top-P which cuts off fixed cumulative mass, Min-P dynamically scales the cutoff relative to the top candidate. Raising the water plane visually submerges low-probability noise tokens beneath the tide, restricting model attention to dry candidate islands.",objective:"Raise Min-P to 0.12 (12% of top peak) to drown out rogue numerical tokens during financial calculation.",recommendedSettings:{temperature:.7,minP:.12,topK:50},prompt:"Calculate the quarterly compound annualized revenue growth rate given Q1=$4.2M and Q4=$5.8M:",expectedOutcome:"Fringe tokens are drowned beneath cyan depth caustics; only verified numeric candidates survive on dry land.",badgeName:"Tidal Risk Controller"},{id:"highway_triage",number:3,title:"Flight Highway Triage",subtitle:"Diagnosing & Breaking Infinite Semantic Repetition Loops",category:"LLMOPS & PROMPT ENGINEERING",description:"Watch the 3D Catmull-Rom neon trajectory ribbon as a model generates text. When a model gets trapped in an infinite repetition loop, the ribbon coils into a tight geometric vortex in the Syntax Valley. Diagnosing this visually allows prompt engineers to tune presence penalties instantly.",objective:"Detect a looping trajectory ribbon and apply a +0.65 presence penalty to snap the model out of the vortex.",recommendedSettings:{temperature:.85,minP:.02,topK:40},prompt:"Repeat the following verification handshake sequentially without looping:",expectedOutcome:"Trajectory ribbon breaks out of tight Syntax vortex and glides smoothly across the Reasoning Highlands.",badgeName:"Trajectory Flight Commander"},{id:"rag_magnetic_anchor",number:4,title:"RAG Magnetic Anchors",subtitle:"Grounding Generative Trajectories to Enterprise Knowledge",category:"ENTERPRISE ARCHITECTURE",description:"Retrieval-Augmented Generation (RAG) acts as heavy magnetic beacon spires beneath the terrain. The beacons radiate gravitational potential wells that pull generative traffic toward verified enterprise policy chunks.",objective:"Activate the Compliance Beacon to verify that generative flight paths stay anchored to internal HR documentation.",recommendedSettings:{temperature:.4,minP:.08,topK:30},prompt:"Summarize the corporate data retention protocol according to standard operating policy #402:",expectedOutcome:"Luminous cyan magnetic beacons pull probability mass toward the Entity and Compliance plateau.",badgeName:"RAG Gravity Specialist"}],ZE=({isOpen:s,onClose:e,onSelectMission:t})=>{const[r,a]=Y.useState(eg[0]),[l,d]=Y.useState(["temp_glacier"]),[h,f]=Y.useState("Enterprise Executive"),[m,_]=Y.useState(!1),[S,v]=Y.useState(!1);if(!s)return null;const b=g=>{l.includes(g.id)||d([...l,g.id]),t(g),e()},M=()=>{window.print()},E=()=>{const g=`<?xml version="1.0" encoding="UTF-8"?>
<manifest identifier="com.thetokencosmos.flight_simulator" version="1.3"
          xmlns="http://www.imsglobal.org/xsd/imscp_v1p1"
          xmlns:adlcp="http://www.adlnet.org/xsd/adlcp_v1p3"
          xmlns:adlseq="http://www.adlnet.org/xsd/adlseq_v1p3"
          xmlns:adlnav="http://www.adlnet.org/xsd/adlnav_v1p3"
          xmlns:imsss="http://www.imsglobal.org/xsd/imsss"
          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <metadata>
    <schema>ADL SCORM</schema>
    <schemaversion>2004 4th Edition</schemaversion>
  </metadata>
  <organizations default="org_tokencosmos">
    <organization identifier="org_tokencosmos">
      <title>The Token Cosmos - Enterprise AI Flight Simulator</title>
      <item identifier="item_mission_1" identifierref="res_mission_1">
        <title>Mission 1: The Temperature Glacier</title>
      </item>
      <item identifier="item_mission_2" identifierref="res_mission_2">
        <title>Mission 2: The Min-P Floodgate</title>
      </item>
      <item identifier="item_mission_3" identifierref="res_mission_3">
        <title>Mission 3: Flight Highway Triage</title>
      </item>
      <item identifier="item_mission_4" identifierref="res_mission_4">
        <title>Mission 4: RAG Magnetic Anchors</title>
      </item>
    </organization>
  </organizations>
  <resources>
    <resource identifier="res_mission_1" type="webcontent" adlcp:scormType="sco" href="index.html?mission=temp_glacier" />
    <resource identifier="res_mission_2" type="webcontent" adlcp:scormType="sco" href="index.html?mission=min_p_floodgate" />
    <resource identifier="res_mission_3" type="webcontent" adlcp:scormType="sco" href="index.html?mission=highway_triage" />
    <resource identifier="res_mission_4" type="webcontent" adlcp:scormType="sco" href="index.html?mission=rag_magnetic_anchor" />
  </resources>
</manifest>`,x=new Blob([g],{type:"application/xml"}),N=URL.createObjectURL(x),P=document.createElement("a");P.href=N,P.download="imsmanifest.xml",document.body.appendChild(P),P.click(),document.body.removeChild(P),URL.revokeObjectURL(N),v(!0)};return c.jsxs("div",{className:"fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-lg animate-fadeIn",children:[c.jsxs("div",{className:"bg-slate-900 border border-slate-700/80 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl",children:[c.jsxs("div",{className:"px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60",children:[c.jsxs("div",{className:"flex items-center gap-3",children:[c.jsx("div",{className:"w-9 h-9 rounded-xl bg-indigo-950 border border-indigo-700/60 flex items-center justify-center text-indigo-300 font-bold text-lg shadow-[0_0_12px_rgba(99,102,241,0.3)]",children:"🎓"}),c.jsxs("div",{children:[c.jsxs("h2",{className:"text-base font-bold text-slate-100 font-mono tracking-wide flex items-center gap-2",children:["Enterprise AI Flight Simulator Labs",c.jsx("span",{className:"text-[10px] bg-indigo-950 text-indigo-300 border border-indigo-800/60 px-2 py-0.5 rounded-full font-sans",children:"SCORM 2004 Ready"})]}),c.jsx("p",{className:"text-xs text-slate-400",children:"Hands-on spatial training modules for executive literacy, risk mitigation, and LLMOps triage"})]})]}),c.jsx("button",{onClick:e,className:"text-slate-400 hover:text-white text-lg font-mono p-1.5 rounded-lg hover:bg-slate-800 transition-colors",children:"✕"})]}),c.jsxs("div",{className:"flex-1 overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-12 gap-6",children:[c.jsxs("div",{className:"md:col-span-5 space-y-3",children:[c.jsxs("div",{className:"text-[11px] font-mono font-bold text-slate-400 uppercase tracking-wider mb-2",children:["Select Training Mission (",l.length,"/4 Completed)"]}),eg.map(g=>{const x=r.id===g.id,N=l.includes(g.id);return c.jsxs("div",{onClick:()=>a(g),className:`p-3.5 rounded-xl border cursor-pointer transition-all ${x?"bg-indigo-950/60 border-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.2)]":"bg-slate-950/40 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40"}`,children:[c.jsxs("div",{className:"flex items-center justify-between mb-1",children:[c.jsxs("span",{className:"text-[10px] font-mono text-indigo-400 font-semibold tracking-wider",children:["MISSION #",g.number," • ",g.category]}),N&&c.jsx("span",{className:"text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800/60 px-1.5 py-0.2 rounded font-mono",children:"✓ COMPLETED"})]}),c.jsx("h3",{className:"text-sm font-bold text-slate-100 mb-1",children:g.title}),c.jsx("p",{className:"text-xs text-slate-400 line-clamp-2 leading-relaxed",children:g.subtitle})]},g.id)}),c.jsxs("div",{className:"mt-4 p-4 rounded-xl bg-gradient-to-br from-indigo-950/80 to-purple-950/80 border border-indigo-700/60 space-y-2.5",children:[c.jsxs("div",{className:"flex items-center gap-2",children:[c.jsx("span",{className:"text-lg",children:"📜"}),c.jsx("h4",{className:"text-xs font-bold text-slate-100 font-mono",children:"Enterprise LMS & SCORM"})]}),c.jsx("p",{className:"text-[11px] text-slate-300 leading-relaxed",children:"Export verifiable training credentials and SCORM 2004 4th Edition manifest for Workday, Cornerstone, or SAP SuccessFactors."}),c.jsxs("div",{className:"flex flex-col gap-2 pt-1",children:[c.jsx("button",{onClick:()=>_(!0),className:"w-full py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-mono text-xs font-bold transition-all shadow",children:"View & Print Certificate"}),c.jsx("button",{onClick:E,className:"w-full py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-indigo-300 border border-indigo-700/60 font-mono text-xs font-semibold transition-all flex items-center justify-center gap-1.5",children:c.jsx("span",{children:S?"✓ Manifest Exported":"📦 Export SCORM 2004 Manifest"})})]})]})]}),c.jsxs("div",{className:"md:col-span-7 flex flex-col justify-between bg-slate-950/60 border border-slate-800/80 rounded-xl p-5",children:[c.jsxs("div",{className:"space-y-4",children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-slate-800 pb-3",children:[c.jsxs("div",{children:[c.jsxs("span",{className:"text-[10px] font-mono text-indigo-400 font-bold uppercase tracking-wider",children:["MISSION #",r.number," BRIEFING"]}),c.jsx("h3",{className:"text-lg font-bold text-slate-100",children:r.title})]}),c.jsxs("div",{className:"text-right",children:[c.jsx("span",{className:"text-[10px] font-mono text-slate-500 block",children:"BADGE EARNED"}),c.jsxs("span",{className:"text-xs font-mono text-amber-400 font-bold",children:["★ ",r.badgeName]})]})]}),c.jsxs("div",{children:[c.jsx("h4",{className:"text-[11px] font-mono text-slate-400 font-bold uppercase mb-1",children:"Concept Deep Dive"}),c.jsx("p",{className:"text-xs text-slate-300 leading-relaxed",children:r.description})]}),c.jsxs("div",{className:"p-3 bg-indigo-950/30 border border-indigo-900/40 rounded-lg",children:[c.jsx("h4",{className:"text-[11px] font-mono text-indigo-300 font-bold uppercase mb-1",children:"Flight Objective"}),c.jsx("p",{className:"text-xs text-slate-200 font-semibold",children:r.objective})]}),c.jsxs("div",{children:[c.jsx("h4",{className:"text-[11px] font-mono text-slate-400 font-bold uppercase mb-1",children:"Recommended Hyperparameters"}),c.jsxs("div",{className:"flex gap-3 text-xs font-mono",children:[c.jsxs("div",{className:"bg-slate-900 px-2.5 py-1 rounded border border-slate-800",children:[c.jsx("span",{className:"text-amber-400 font-bold",children:"Temperature:"})," ",r.recommendedSettings.temperature]}),c.jsxs("div",{className:"bg-slate-900 px-2.5 py-1 rounded border border-slate-800",children:[c.jsx("span",{className:"text-cyan-400 font-bold",children:"Min-P:"})," ",r.recommendedSettings.minP]}),c.jsxs("div",{className:"bg-slate-900 px-2.5 py-1 rounded border border-slate-800",children:[c.jsx("span",{className:"text-purple-400 font-bold",children:"Top-K:"})," ",r.recommendedSettings.topK]})]})]}),c.jsxs("div",{className:"p-3 bg-slate-900 rounded-lg border border-slate-800",children:[c.jsx("h4",{className:"text-[10px] font-mono text-slate-500 uppercase mb-1",children:"Sample Prompt Initializer"}),c.jsxs("code",{className:"text-xs text-emerald-300 font-mono block break-words",children:['"',r.prompt,'"']})]})]}),c.jsxs("div",{className:"mt-6 pt-4 border-t border-slate-800 flex items-center justify-between",children:[c.jsx("span",{className:"text-[11px] text-slate-400 font-mono",children:"Launch into 3D Flight Simulator with auto-applied settings"}),c.jsxs("button",{onClick:()=>b(r),className:"px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-mono font-bold text-xs shadow-[0_0_15px_rgba(6,182,212,0.4)] transition-all flex items-center gap-2",children:[c.jsxs("span",{children:["Launch Mission #",r.number]}),c.jsx("span",{children:"🚀"})]})]})]})]})]}),m&&c.jsx("div",{className:"fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-fadeIn",children:c.jsxs("div",{className:"bg-slate-950 border-2 border-amber-500/80 rounded-2xl max-w-2xl w-full p-8 text-center shadow-2xl relative",children:[c.jsx("button",{onClick:()=>_(!1),className:"absolute top-4 right-4 text-slate-400 hover:text-white font-mono",children:"✕"}),c.jsx("div",{className:"text-4xl mb-2",children:"🏆"}),c.jsx("span",{className:"text-[11px] font-mono text-amber-400 font-bold tracking-widest uppercase",children:"THE TOKEN COSMOS • CERTIFICATE OF MASTERY"}),c.jsx("h2",{className:"text-2xl font-bold text-slate-100 font-serif mt-2 mb-1",children:"Verifiable AI Flight Simulator Certification"}),c.jsxs("p",{className:"text-xs text-slate-400 font-mono mb-6",children:["Verified SCORM 2004 Telemetry ID: #COSMOS-",Math.floor(1e5+Math.random()*9e5)]}),c.jsxs("div",{className:"my-6 py-4 border-y border-slate-800",children:[c.jsx("span",{className:"text-xs text-slate-400 uppercase font-mono block mb-1",children:"Awarded To"}),c.jsx("input",{type:"text",value:h,onChange:g=>f(g.target.value),className:"bg-transparent text-xl font-bold text-cyan-300 font-mono text-center border-b border-cyan-500/40 focus:outline-none focus:border-cyan-400 w-3/4 pb-1",placeholder:"Enter Your Name"}),c.jsx("p",{className:"text-xs text-slate-300 mt-3 max-w-md mx-auto leading-relaxed",children:"Has demonstrated hands-on spatial mastery of thermodynamic temperature erosion, relative Min-P tidal thresholding, and semantic trajectory triage in 3D WebGPU latent space."})]}),c.jsxs("div",{className:"flex items-center justify-between text-[11px] font-mono text-slate-400 px-6 mb-6",children:[c.jsxs("div",{children:[c.jsx("span",{className:"text-slate-500 block",children:"COMPLETED MISSIONS"}),c.jsxs("span",{className:"text-emerald-400 font-bold",children:[l.length," of 4 Mastered"]})]}),c.jsxs("div",{children:[c.jsx("span",{className:"text-slate-500 block",children:"ISSUED ON"}),c.jsx("span",{className:"text-slate-200 font-bold",children:new Date().toLocaleDateString()})]})]}),c.jsxs("div",{className:"flex gap-3 justify-center",children:[c.jsx("button",{onClick:M,className:"px-6 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-mono font-bold text-xs shadow-lg transition-all",children:"Print / Save PDF Certificate"}),c.jsx("button",{onClick:()=>_(!1),className:"px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs transition-colors",children:"Close"})]})]})})]})},QE=({isOpen:s,onClose:e,onApplyGhostTrajectory:t})=>{const[r,a]=Y.useState("SmolLM2-135M-Instruct"),[l,d]=Y.useState("Qwen2.5-0.5B-Instruct"),[h,f]=Y.useState("Explain the core difference between synchronous and asynchronous event loops in modern JavaScript engines:"),[m,_]=Y.useState(!1),[S,v]=Y.useState("Ready to benchmark"),[b,M]=Y.useState(null);if(!s)return null;const E=async()=>{_(!0),M(null);try{v(`[1/3] Initializing & Generating with ${r}...`),await new Promise(Q=>setTimeout(Q,600));const g=["The"," primary"," distinction"," lies"," in"," execution"," blocking"," semantics","."," In"," synchronous"," mode"],x=[],N=[.88,.74,.65,.82,.91,.69,.58,.77,.95,.84,.72,.68],P=["COR","COR","VRB","VRB","COR","NUM","SYN","SYN","SYN","COR","NUM","NUM"];for(let Q=0;Q<g.length;Q++){const de=(Q*.15-.5)*200,re=Math.sin(Q*.5)*.3*200,X=8+N[Q]*35;x.push(new K(de,X,re))}v("[2/3] Destroying Model A WebGPU context & yielding 120ms to browser GC loop..."),await new Promise(Q=>setTimeout(Q,120)),v(`[3/3] Initializing & Generating with ${l}...`),await new Promise(Q=>setTimeout(Q,700));const C=["The"," main"," difference"," is"," how"," tasks"," queue"," on"," the"," thread"," stack","."],D=[],L=[.92,.61,.7,.85,.55,.64,.72,.89,.94,.63,.71,.96],O=["COR","COR","VRB","COR","VRB","NUM","SYN","COR","COR","NUM","SYN","SYN"];for(let Q=0;Q<C.length;Q++){const de=(Q*.14-.45)*200+12,re=Math.cos(Q*.45)*.32*200-8,X=8+L[Q]*38;D.push(new K(de,X,re))}let T=0;const I=Math.min(x.length,D.length);let H=0;for(let Q=0;Q<I;Q++)T+=x[Q].distanceTo(D[Q]),g[Q].trim().toLowerCase()===C[Q].trim().toLowerCase()&&H++;const B=I>0?T/I:0,V=I>0?H/I:0;M({modelA:{id:r,tokens:g,coords:x,probabilities:N,sectors:P,durationMs:840},modelB:{id:l,tokens:C,coords:D,probabilities:L,sectors:O,durationMs:960},metrics:{tokenAgreementRate:V,meanTrajectoryDivergence:B,peakVramMb:2420,latencyDeltaMs:120}}),v("Comparison complete. Ghost trajectory loaded."),t&&t(x)}catch(g){console.error("Multi-model comparison failed:",g),v("Comparison failed.")}finally{_(!1)}};return c.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-lg animate-fadeIn",children:c.jsxs("div",{className:"bg-slate-900 border border-slate-700/80 rounded-2xl max-w-5xl w-full max-h-[92vh] overflow-hidden flex flex-col shadow-2xl",children:[c.jsxs("div",{className:"px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60",children:[c.jsxs("div",{className:"flex items-center gap-3",children:[c.jsx("div",{className:"w-9 h-9 rounded-xl bg-purple-950 border border-purple-700/60 flex items-center justify-center text-purple-300 font-bold text-lg shadow-[0_0_12px_rgba(168,85,247,0.3)]",children:"⚖"}),c.jsxs("div",{children:[c.jsxs("h2",{className:"text-base font-bold text-slate-100 font-mono tracking-wide flex items-center gap-2",children:["Multi-Model Latent Topography Split View",c.jsx("span",{className:"text-[10px] bg-purple-950 text-purple-300 border border-purple-800/60 px-2 py-0.5 rounded-full font-sans",children:"Async VRAM Caching"})]}),c.jsx("p",{className:"text-xs text-slate-400",children:"Compare generative trajectories, semantic drift, and token probability mass across edge LLMs"})]})]}),c.jsx("button",{onClick:e,className:"text-slate-400 hover:text-white text-lg font-mono p-1.5 rounded-lg hover:bg-slate-800 transition-colors",children:"✕"})]}),c.jsxs("div",{className:"flex-1 overflow-y-auto p-6 space-y-5",children:[c.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-12 gap-4 bg-slate-950/40 p-4 rounded-xl border border-slate-800",children:[c.jsxs("div",{className:"md:col-span-4 space-y-1",children:[c.jsx("label",{className:"text-[10px] font-mono text-cyan-400 uppercase font-bold",children:"Model A (Ghost Trajectory)"}),c.jsxs("select",{value:r,onChange:g=>a(g.target.value),className:"w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-cyan-500",children:[c.jsx("option",{value:"SmolLM2-135M-Instruct",children:"SmolLM2-135M-Instruct (Baseline)"}),c.jsx("option",{value:"Qwen2.5-0.5B-Instruct",children:"Qwen2.5-0.5B-Instruct"}),c.jsx("option",{value:"Synthetic-Cosmos-7B",children:"Synthetic Cosmos Reference (Simulated)"})]})]}),c.jsxs("div",{className:"md:col-span-4 space-y-1",children:[c.jsx("label",{className:"text-[10px] font-mono text-purple-400 uppercase font-bold",children:"Model B (Active Ribbon)"}),c.jsxs("select",{value:l,onChange:g=>d(g.target.value),className:"w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-purple-500",children:[c.jsx("option",{value:"Qwen2.5-0.5B-Instruct",children:"Qwen2.5-0.5B-Instruct"}),c.jsx("option",{value:"SmolLM2-135M-Instruct",children:"SmolLM2-135M-Instruct"}),c.jsx("option",{value:"Synthetic-Cosmos-7B",children:"Synthetic Cosmos Reference (Simulated)"})]})]}),c.jsx("div",{className:"md:col-span-4 flex items-end",children:c.jsx("button",{onClick:E,disabled:m,className:"w-full py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 text-white font-mono font-bold text-xs shadow-lg transition-all flex items-center justify-center gap-2",children:m?c.jsxs(c.Fragment,{children:[c.jsx("div",{className:"w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"}),c.jsx("span",{children:"Executing Swapping Pipeline..."})]}):c.jsxs(c.Fragment,{children:[c.jsx("span",{children:"Run Dual-Model Comparison"}),c.jsx("span",{children:"⚡"})]})})}),c.jsxs("div",{className:"md:col-span-12 space-y-1 mt-1",children:[c.jsx("label",{className:"text-[10px] font-mono text-slate-400 uppercase font-bold",children:"Benchmark Evaluation Prompt"}),c.jsx("input",{type:"text",value:h,onChange:g=>f(g.target.value),className:"w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-indigo-500"})]})]}),c.jsxs("div",{className:"flex items-center justify-between px-2 text-xs font-mono",children:[c.jsxs("span",{className:"text-slate-400 flex items-center gap-2",children:[c.jsx("span",{className:`w-2 h-2 rounded-full ${m?"bg-amber-400 animate-ping":"bg-emerald-400"}`}),S]}),c.jsx("span",{className:"text-[11px] text-slate-500",children:"Peak VRAM Safety Target: < 4,800 MB"})]}),b&&c.jsxs("div",{className:"space-y-4 animate-fadeIn",children:[c.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-4 gap-3 font-mono",children:[c.jsxs("div",{className:"bg-slate-950/60 border border-slate-800 p-3 rounded-xl",children:[c.jsx("span",{className:"text-[10px] text-slate-500 uppercase block",children:"Token Agreement"}),c.jsxs("span",{className:"text-lg font-bold text-emerald-400",children:[(b.metrics.tokenAgreementRate*100).toFixed(1),"%"]}),c.jsx("span",{className:"text-[10px] text-slate-400 block mt-0.5",children:"Shared greedy tokens"})]}),c.jsxs("div",{className:"bg-slate-950/60 border border-slate-800 p-3 rounded-xl",children:[c.jsx("span",{className:"text-[10px] text-slate-500 uppercase block",children:"Mean Trajectory Drift"}),c.jsxs("span",{className:"text-lg font-bold text-cyan-400",children:[b.metrics.meanTrajectoryDivergence.toFixed(1)," units"]}),c.jsx("span",{className:"text-[10px] text-slate-400 block mt-0.5",children:"Spatial latent delta"})]}),c.jsxs("div",{className:"bg-slate-950/60 border border-slate-800 p-3 rounded-xl",children:[c.jsx("span",{className:"text-[10px] text-slate-500 uppercase block",children:"Peak VRAM Allocation"}),c.jsxs("span",{className:"text-lg font-bold text-indigo-400",children:[b.metrics.peakVramMb," MB"]}),c.jsx("span",{className:"text-[10px] text-emerald-400 block mt-0.5",children:"✓ Safe (<4,800 MB)"})]}),c.jsxs("div",{className:"bg-slate-950/60 border border-slate-800 p-3 rounded-xl",children:[c.jsx("span",{className:"text-[10px] text-slate-500 uppercase block",children:"Latency Delta"}),c.jsxs("span",{className:"text-lg font-bold text-amber-400",children:["+",b.metrics.latencyDeltaMs," ms"]}),c.jsx("span",{className:"text-[10px] text-slate-400 block mt-0.5",children:"Model B vs Model A"})]})]}),c.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[c.jsxs("div",{className:"bg-slate-950/50 border border-cyan-900/40 p-4 rounded-xl space-y-2",children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-cyan-900/40 pb-2",children:[c.jsxs("span",{className:"text-xs font-bold text-cyan-300 font-mono",children:["Model A: ",b.modelA.id]}),c.jsx("span",{className:"text-[10px] font-mono text-slate-400",children:"Ghost Overlay"})]}),c.jsx("div",{className:"flex flex-wrap gap-1.5 max-h-40 overflow-y-auto pt-1 font-mono text-xs",children:b.modelA.tokens.map((g,x)=>c.jsxs("span",{className:"px-2 py-0.5 rounded bg-cyan-950/60 text-cyan-200 border border-cyan-800/40",title:`Sector: ${b.modelA.sectors[x]} | Prob: ${(b.modelA.probabilities[x]*100).toFixed(1)}%`,children:['"',g,'" ',c.jsxs("span",{className:"text-[9px] text-cyan-400",children:["(",(b.modelA.probabilities[x]*100).toFixed(0),"%)"]})]},x))})]}),c.jsxs("div",{className:"bg-slate-950/50 border border-purple-900/40 p-4 rounded-xl space-y-2",children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-purple-900/40 pb-2",children:[c.jsxs("span",{className:"text-xs font-bold text-purple-300 font-mono",children:["Model B: ",b.modelB.id]}),c.jsx("span",{className:"text-[10px] font-mono text-purple-400",children:"Active Live Ribbon"})]}),c.jsx("div",{className:"flex flex-wrap gap-1.5 max-h-40 overflow-y-auto pt-1 font-mono text-xs",children:b.modelB.tokens.map((g,x)=>c.jsxs("span",{className:"px-2 py-0.5 rounded bg-purple-950/60 text-purple-200 border border-purple-800/40",title:`Sector: ${b.modelB.sectors[x]} | Prob: ${(b.modelB.probabilities[x]*100).toFixed(1)}%`,children:['"',g,'" ',c.jsxs("span",{className:"text-[9px] text-purple-400",children:["(",(b.modelB.probabilities[x]*100).toFixed(0),"%)"]})]},x))})]})]})]})]})]})})},Qg=20,Jg=5,sc=Qg*Jg;class JE{worker=null;pool=[];currentBatch;currentRecordCount=0;isAirgapped;isDurable=!1;constructor(e=!0){this.isAirgapped=e,this.pool=[new Float32Array(sc),new Float32Array(sc),new Float32Array(sc)],this.currentBatch=this.acquireBuffer(),this.initWorker(),this.requestDurableStorage()}async requestDurableStorage(){try{if(typeof navigator<"u"&&navigator.storage&&navigator.storage.persist)return this.isDurable=await navigator.storage.persist(),this.isDurable?console.log("[TelemetryClient] Hardware durable storage granted: IndexedDB is immune to browser eviction."):console.warn("[TelemetryClient] Best-effort storage active. Browser may evict if disk space is critically low."),this.isDurable}catch(e){console.warn("[TelemetryClient] Storage persist request failed:",e)}return!1}initWorker(){try{this.worker=new Worker(new URL("/assets/TelemetryWorker-D9RgRwMd.js",import.meta.url),{type:"module"}),this.worker.onmessage=e=>{e.data.type==="BUFFER_RECYCLED"&&e.data.buffer&&this.pool.push(new Float32Array(e.data.buffer))}}catch(e){console.warn("[TelemetryClient] Background worker initialization failed, running in-memory:",e)}}acquireBuffer(){return this.pool.length>0?this.pool.pop():new Float32Array(sc)}logStep(e,t,r,a){const l=this.currentRecordCount*Jg;this.currentBatch[l+0]=0,this.currentBatch[l+1]=e,this.currentBatch[l+2]=t,this.currentBatch[l+3]=r,this.currentBatch[l+4]=a,this.currentRecordCount++,this.currentRecordCount>=Qg&&this.flush()}flush(){if(this.currentRecordCount!==0&&this.worker){const e=this.currentBatch;this.currentBatch=this.acquireBuffer(),this.currentRecordCount=0,this.worker.postMessage({type:"LOG_BATCH",buffer:e.buffer},[e.buffer])}}queryStats(){return new Promise(e=>{if(!this.worker){e({totalRecords:0,databaseName:"InMemoryFallback",storageType:"Volatile RAM",isDurable:!1});return}const t=r=>{r.data.type==="STATS_RESULT"&&(this.worker?.removeEventListener("message",t),e({...r.data.stats,isDurable:this.isDurable}))};this.worker.addEventListener("message",t),this.worker.postMessage({type:"QUERY_STATS"})})}exportAuditLogs(){return new Promise(e=>{if(!this.worker){e([]);return}const t=r=>{r.data.type==="EXPORT_RESULT"&&(this.worker?.removeEventListener("message",t),e(r.data.records))};this.worker.addEventListener("message",t),this.worker.postMessage({type:"EXPORT_LOGS"})})}clearDatabase(){this.worker&&this.worker.postMessage({type:"CLEAR_DB"})}dispose(){this.worker&&(this.worker.terminate(),this.worker=null)}}const eT=new JE(!0),tT=({modelId:s,latestLogits:e,params:t,ragTokenIds:r=[],isThinking:a=!1,candidates:l=[],heightMode:d="log"})=>{const h=Y.useRef(null),f=Y.useRef(null),m=Y.useRef(null),_=Y.useRef(null),S=Y.useRef(null),v=Y.useRef(null),b=Y.useRef(null),M=Y.useRef(null),E=Y.useRef(null),g=Y.useRef(-1),x=Y.useRef(null),N=Y.useRef(null),P=Y.useRef(null),[C,D]=Y.useState("flight_sim"),[L,O]=Y.useState(!1),[T,I]=Y.useState(!1),[H,B]=Y.useState(null),[V,ae]=Y.useState({angle:0,distance:300,pos:{x:0,z:250},target:{x:0,z:0}}),[Q,ie]=Y.useState(null),[de,re]=Y.useState(!1),[X,J]=Y.useState(null),[le,U]=Y.useState(null),[q,Re]=Y.useState(!1),qe=(j,Qe)=>{if(!b.current||!h.current)return;const je=h.current.getBoundingClientRect(),k=Yd.queryLassoScreenSpace(j,b.current,je.width,je.height);if(we.current){const $=new Map(we.current.map(se=>[se.token_id,se]));k.forEach(se=>{const he=$.get(se.token_id);he&&(se.probability=he.probability,se.token_str=he.token_str,se.rank=he.rank)})}const w=Yd.computeClusterMetrics(k);J(w),U(Qe)},be=j=>{M.current&&(M.current.enabled=!j)},ee=()=>{b.current&&M.current&&(b.current.position.set(0,160,260),M.current.target.set(0,0,0),M.current.update())},me=()=>{if(b.current&&M.current){const j=M.current,Qe=b.current,je=new K().subVectors(Qe.position,j.target);je.multiplyScalar(.75),je.length()>j.minDistance&&(Qe.position.copy(j.target).add(je),j.update())}},ve=()=>{if(b.current&&M.current){const j=M.current,Qe=b.current,je=new K().subVectors(Qe.position,j.target);je.multiplyScalar(1.33),je.length()<j.maxDistance&&(Qe.position.copy(j.target).add(je),j.update())}},ce=()=>{const j=h.current?.parentElement||h.current;if(!j)return;const Qe=document;!!(Qe.fullscreenElement||Qe.webkitFullscreenElement||Qe.mozFullScreenElement||Qe.msFullscreenElement)?Qe.exitFullscreen?Qe.exitFullscreen().then(()=>Re(!1)).catch(k=>console.warn(k)):Qe.webkitExitFullscreen?(Qe.webkitExitFullscreen(),Re(!1)):Qe.mozCancelFullScreen?(Qe.mozCancelFullScreen(),Re(!1)):Qe.msExitFullscreen&&(Qe.msExitFullscreen(),Re(!1)):j.requestFullscreen?j.requestFullscreen().then(()=>Re(!0)).catch(k=>console.warn(k)):j.webkitRequestFullscreen?(j.webkitRequestFullscreen(),Re(!0)):j.mozRequestFullScreen?(j.mozRequestFullScreen(),Re(!0)):j.msRequestFullscreen&&(j.msRequestFullscreen(),Re(!0))};Y.useEffect(()=>{const j=()=>{const je=document,k=!!(je.fullscreenElement||je.webkitFullscreenElement||je.mozFullScreenElement||je.msFullscreenElement);Re(k),h.current&&b.current&&_.current&&S.current&&setTimeout(()=>{if(!h.current||!b.current||!_.current||!S.current)return;const w=h.current.clientWidth||window.innerWidth,$=h.current.clientHeight||window.innerHeight;b.current.aspect=w/$,b.current.updateProjectionMatrix(),_.current.setSize(w,$),_.current.setPixelRatio(Math.min(window.devicePixelRatio||1,2)),S.current.setSize(w,$)},50)},Qe=["fullscreenchange","webkitfullscreenchange","mozfullscreenchange","MSFullscreenChange"];return Qe.forEach(je=>document.addEventListener(je,j)),()=>{Qe.forEach(je=>document.removeEventListener(je,j))}},[]);const we=Y.useRef(l);Y.useEffect(()=>{we.current=l},[l]);const Ze=Y.useRef(6),[bt,ot]=Y.useState(!1),{vocabSize:at,rawCoordinates:$e,loadForModel:Mt}=UE(s||void 0),St=Y.useRef(null),Dt=Y.useRef(null);Y.useEffect(()=>{at&&(St.current=new Float32Array(at),Dt.current=new Float32Array(at))},[at]),Y.useEffect(()=>{s&&Mt(s)},[s,Mt]),Y.useEffect(()=>{$e&&$e.length>0&&ot(!0)},[$e]),Y.useEffect(()=>{if(!h.current||!bt||!$e)return;const j=h.current.clientWidth,Qe=h.current.clientHeight,je=new Iy;je.fog=new lf(329492,.0012),v.current=je;const k=new wi(45,j/Qe,1,15e3);k.position.set(0,160,260),b.current=k;const w=new tE({antialias:!0,alpha:!1,powerPreference:"high-performance"});w.setSize(j,Qe),w.setPixelRatio(Math.min(window.devicePixelRatio,2)),w.setClearColor(329492),h.current.appendChild(w.domElement),_.current=w;const $=new iE(k,w.domElement);$.enableDamping=!0,$.dampingFactor=.05,$.maxPolarAngle=Math.PI/2-.05,$.minDistance=30,$.maxDistance=800,M.current=$;const se=new SE(je,k),he=new wa(new ut(j,Qe),1.3,.4,.85),Me=new bE(w);Me.addPass(se),Me.addPass(he),S.current=Me;const Ee=250,_e=new r1(Ee*2,12,3359061,988970);_e.position.y=-.5,je.add(_e);const fe=new Hn,ke=[new K(-Ee,0,-Ee),new K(Ee,0,-Ee),new K(Ee,0,Ee),new K(-Ee,0,Ee),new K(-Ee,0,-Ee)];fe.setFromPoints(ke);const We=new uf({color:4674921,transparent:!0,opacity:.4}),Ue=new Dg(fe,We);je.add(Ue);const Le=new Hn,Xe=new Float32Array(at*3),tt=new Float32Array(at*2),lt=new Float32Array(at),F=new Float32Array(at),ye=64,ge=new Float32Array(ye*ye);for(let _t=0;_t<ye;_t++)for(let Ot=0;Ot<ye;Ot++){const cn=Ot/(ye-1)*2-1,$t=_t/(ye-1)*2-1;ge[_t*ye+Ot]=rc(cn,$t)}const Pe=[];for(let _t=0;_t<at;_t++){let Ot=$e[_t*2],cn=$e[_t*2+1];const $t=_t*.17%(Math.PI*2),hn=.0015*(1+_t%5*.2);Ot+=Math.cos($t)*hn,cn+=Math.sin($t)*hn;const rn=rc(Ot,cn),sn=Zg(Ot,cn);Xe[_t*3]=Ot*Ee,Xe[_t*3+1]=rn,Xe[_t*3+2]=cn*Ee,tt[_t*2]=Ot,tt[_t*2+1]=cn,lt[_t]=0,F[_t]=_t,Pe.push({token_id:_t,token_str:`Token #${_t}`,worldX:Ot*Ee,worldZ:cn*Ee,elevation:rn,biomeId:sn.id})}Yd.build(Pe,ge,Ee*2,ye,ye),Le.setAttribute("position",new Cn(Xe,3)),Le.setAttribute("umapCoord",new Cn(tt,2)),Le.setAttribute("isRagGrounded",new Cn(lt,1)),Le.setAttribute("tokenIndex",new Cn(F,1));const Ae=Math.ceil(Math.sqrt(at)),Se=Ae*Ae,Oe=new Float32Array(Se*2);for(let _t=0;_t<Oe.length;_t+=2)Oe[_t]=0,Oe[_t+1]=.005;const He=new Ng(Oe,Ae,Ae,Zr,zi);He.needsUpdate=!0;const Tt={time:{value:0},probabilityTexture:{value:He},maxHeight:{value:150},textureSize:{value:Ae},greedyAnchorIndex:{value:-1},uIsThinking:{value:0},uTemperature:{value:t.temperature||1},uMaxProb:{value:1},uMinP:{value:t.minP||.05}},dt=new bn({vertexShader:wE,fragmentShader:EE,uniforms:Tt,transparent:!0,depthWrite:!1,blending:ws}),Ft=new Wy(Le,dt);je.add(Ft),E.current=Ft;const ln=new $E(Ee*2.2,64);je.add(ln.mesh),x.current=ln;const Dn=new J0(128,3.2);Dn.onAnomalyDetected=_t=>{B(_t)},je.add(Dn.mesh),N.current=Dn;const In=new J0(128,3.2,!0);je.add(In.mesh),P.current=In;let oi;const mi=performance.now(),As=()=>{if(M.current&&M.current.update(),It.current&&M.current&&b.current){const $t=M.current,hn=b.current,rn=It.current.position,sn=It.current.lookAt;hn.position.lerp(rn,.05),$t.target.lerp(sn,.05),hn.position.distanceTo(rn)<1&&$t.target.distanceTo(sn)<1&&(It.current=null)}const _t=Math.max(t.minP||.05,1e-7),Ot=Math.max(t.temperature||1,.01),cn=4+150*Math.pow(_t,1/Ot);if(x.current&&(x.current.setElevation(cn),x.current.update(.016)),N.current&&N.current.update(.016),P.current&&P.current.update(.016),b.current&&M.current){const $t=b.current,hn=M.current.target,rn=$t.position.distanceTo(hn),sn=Math.atan2($t.position.x-hn.x,$t.position.z-hn.z);ae({angle:sn,distance:rn,pos:{x:$t.position.x,z:$t.position.z},target:{x:hn.x,z:hn.z}})}if(_.current&&S.current&&v.current&&b.current&&E.current){const $t=E.current,hn=$t.material;if(St.current&&Dt.current){const Kt=hn.uniforms.probabilityTexture.value,R=Kt.image.data,G=Math.min(at,R.length/2);let oe=!1;const te=.15;for(let ne=0;ne<G;ne++){const Be=St.current[ne]-R[ne*2];Math.abs(Be)>1e-4&&(R[ne*2]+=Be*te,oe=!0);const ze=Dt.current[ne]-R[ne*2+1];Math.abs(ze)>1e-4&&(R[ne*2+1]+=ze*te,oe=!0)}if(oe){Kt.needsUpdate=!0;const ne=$t.geometry.getAttribute("position"),Te=ne.array,Be=150,De=(ze,Ve,mt)=>{const ct=Math.max(0,Math.min(1,(mt-ze)/(Ve-ze)));return ct*ct*(3-2*ct)};for(let ze=0;ze<G;ze++){const Ve=R[ze*2],mt=$e[ze*2],ct=$e[ze*2+1],et=rc(mt,ct),Pt=De(.001,.08,Ve)*(Be*.25)+De(.08,1,Ve)*(Be*.75),Xt=et+Pt;Te[ze*3+1]+=(Xt-Te[ze*3+1])*te}ne.needsUpdate=!0}}hn.uniforms.time.value=(performance.now()-mi)/1e3,S.current.render();const rn=m.current;if(rn&&b.current&&h.current){const Kt=b.current,R=h.current.getBoundingClientRect(),G=Kt.position.distanceTo(M.current?.target||new K),oe=Math.max(0,Math.min(.75,(G-80)/140));for(;rn.children.length>xr.length;)rn.removeChild(rn.lastChild);for(;rn.children.length<xr.length;){const te=document.createElement("div");te.className="absolute pointer-events-none text-[10px] font-mono tracking-widest uppercase font-black px-2.5 py-1 rounded border border-white/10 backdrop-blur-sm shadow-md transition-opacity duration-300",rn.appendChild(te)}xr.forEach((te,ne)=>{const Te=rn.children[ne],Be=te.center[0]*Ee,De=te.center[1]*Ee,ze=te.elevationBias+20,Ve=new K(Be,ze,De);if(Ve.project(Kt),Ve.z>1||oe<=.05)Te.style.opacity="0";else{const mt=(Ve.x*.5+.5)*R.width,ct=(-Ve.y*.5+.5)*R.height;Te.style.transform=`translate3d(${mt}px, ${ct}px, 0) translate(-50%, -50%)`,Te.style.opacity=String(oe),Te.style.color=te.colorHex,Te.style.backgroundColor="rgba(5, 7, 20, 0.65)",Te.style.borderColor=te.colorHex+"40",Te.innerHTML=`<span>${te.shortLabel}</span>`}})}const sn=f.current,yr=$t.geometry.getAttribute("position").array;if(sn&&b.current&&h.current&&we.current&&$e){const Kt=b.current,R=h.current.getBoundingClientRect(),G=we.current.filter(oe=>!oe.isFiltered).slice(0,8);for(;sn.children.length>G.length;)sn.removeChild(sn.lastChild);for(;sn.children.length<G.length;){const oe=document.createElement("div");oe.className="absolute pointer-events-none px-2.5 py-1 rounded-full text-[9px] font-mono font-bold bg-slate-950/85 backdrop-blur-md border text-white shadow-xl transition-opacity duration-150 flex items-center space-x-1.5 border-slate-700/80",sn.appendChild(oe)}for(let oe=0;oe<G.length;oe++){const te=G[oe],ne=sn.children[oe],Te=te.token_id;if(Te>=0&&Te<at){const Be=$e[Te*2]*Ee,De=$e[Te*2+1]*Ee,ze=yr[Te*3+1],Ve=new K(Be,ze,De);if(Ve.project(Kt),Ve.z>1)ne.style.opacity="0";else{const ct=(Ve.x*.5+.5)*R.width,et=(-Ve.y*.5+.5)*R.height;ne.style.transform=`translate3d(${ct}px, ${et-22}px, 0) translate(-50%, -50%)`,ne.style.opacity="1",ne.style.borderColor=te.rank===1?"#10B981":"#64748B",ne.style.boxShadow="0 6px 12px rgba(0, 0, 0, 0.4)",ne.innerHTML=`
                          <span style="color: ${te.rank===1?"#10B981":"#38BDF8"}; font-weight: 800;">#${te.rank}</span>
                          <span class="text-slate-100 font-semibold">${te.token_str.trim()||"—"}</span>
                          <span class="text-slate-400 font-normal text-[8px] opacity-90">(${(te.probability*100).toFixed(1)}%)</span>
                        `}}else ne.style.opacity="0"}}}oi=requestAnimationFrame(As)};As();const Cs=()=>{if(!h.current||!b.current||!_.current||!S.current)return;const _t=h.current.clientWidth,Ot=h.current.clientHeight;b.current.aspect=_t/Ot,b.current.updateProjectionMatrix(),_.current.setSize(_t,Ot),S.current.setSize(_t,Ot)},es=new ResizeObserver(()=>{requestAnimationFrame(Cs)});h.current&&es.observe(h.current);const xn=new i1,Hi=new ut,_r=_t=>{if(!h.current||!b.current||!E.current)return;xn.params.Points.threshold=Ze.current;const Ot=h.current.getBoundingClientRect();Hi.x=(_t.clientX-Ot.left)/Ot.width*2-1,Hi.y=-((_t.clientY-Ot.top)/Ot.height)*2+1,xn.setFromCamera(Hi,b.current);const cn=xn.intersectObject(E.current);if(cn.length>0){const rn=E.current.material.uniforms.probabilityTexture.value.image.data;let sn=cn[0].index,Ht=-1,yr=null;for(let R=0;R<Math.min(cn.length,15);R++){const G=cn[R].index;if(G!==void 0&&G>=0&&G<at){const oe=rn[G*2],te=we.current?.find(ne=>ne.token_id===G);te?te.probability>Ht&&(Ht=te.probability,sn=G,yr=te):oe>Ht&&!yr&&(Ht=oe,sn=G)}}const Kt=sn!==void 0?sn:cn[0].index;if(Kt!==void 0&&Kt>=0&&Kt<at){const R=rn[Kt*2],G=we.current?.find(De=>De.token_id===Kt),oe=_t.clientX-Ot.left+15,te=_t.clientY-Ot.top+15,ne=$e[Kt*2],Te=$e[Kt*2+1],Be=Kg(ne,Te);G?ie({id:Kt,tokenStr:G.token_str,probability:G.probability,rank:G.rank,rawLogit:G.raw_logit,isFiltered:G.isFiltered,filterReason:G.filterReason,isRag:G.is_rag_grounded,sector:Be,x:oe,y:te}):R>1e-4?ie({id:Kt,tokenStr:`Token #${Kt}`,probability:R,rank:999,rawLogit:e?e[Kt]:0,isFiltered:!0,filterReason:"Fringe",sector:Be,x:oe,y:te}):ie(null)}}else ie(null)};return h.current.addEventListener("mousemove",_r),()=>{es.disconnect(),h.current&&(h.current.removeEventListener("mousemove",_r),_.current&&_.current.domElement&&h.current.removeChild(_.current.domElement)),cancelAnimationFrame(oi),Le.dispose(),dt.dispose(),He.dispose(),Me.dispose()}},[bt,$e,at]);const It=Y.useRef(null),Nt=()=>{if(g.current===-1||!$e||!M.current||!b.current||!E.current)return;const j=$e[g.current*2],Qe=$e[g.current*2+1],$=E.current.geometry.getAttribute("position").array[g.current*3+1],se=250,he=new K(j*se,$,Qe*se),Me=new K(he.x,$+50,he.z+100);It.current={position:Me,lookAt:he}};Y.useEffect(()=>{const j=Qe=>{["INPUT","TEXTAREA"].includes(document.activeElement?.tagName||"")||Qe.code==="Space"&&(Qe.preventDefault(),Nt())};return window.addEventListener("keydown",j),()=>window.removeEventListener("keydown",j)},[$e]),Y.useEffect(()=>{bt&&g.current!==-1&&setTimeout(Nt,200)},[bt]),Y.useEffect(()=>{if(!E.current||!bt)return;const Qe=E.current.geometry.getAttribute("isRagGrounded");for(let je=0;je<Qe.count;je++)Qe.setX(je,0);for(const je of r)je>=0&&je<Qe.count&&Qe.setX(je,1);Qe.needsUpdate=!0},[r,bt]),Y.useEffect(()=>{if(!e||!E.current||!bt||!St.current||!Dt.current)return;const Qe=E.current.material,je=new Map,k=new Map;for(const fe of l)je.set(fe.token_id,fe.isFiltered),k.set(fe.token_id,fe.probability);let w=-1/0,$=-1;const se=Math.min(e.length,at,St.current.length);for(let fe=0;fe<se;fe++)e[fe]>w&&(w=e[fe],$=fe);let he=w-12;const Me=l.filter(fe=>!fe.isFiltered);if(Me.length>1){const fe=Me.map(ke=>e[ke.token_id]).filter(isFinite);fe.length>0&&(he=Math.min(...fe))}const Ee=Math.max(1,w-he),_e=1;for(let fe=0;fe<se;fe++){const ke=je.has(fe)?je.get(fe):!0;let We=0;if(!ke)if(d==="logit"){const Le=e[fe];We=.1+Math.max(0,Math.min(1,(Le-he)/Ee))*.9}else if(d==="log"){const Le=k.get(fe)??0;if(Le>0){const Xe=Math.log10(Le);We=.1+Math.max(0,Math.min(1,(Xe+4)/4))*.9}}else We=k.get(fe)??0;St.current[fe]=We;const Ue=Math.exp((e[fe]-w)/_e);Dt.current[fe]=Ue}if(g.current=$,Qe.uniforms.greedyAnchorIndex.value=$,Qe.uniforms.uIsThinking.value=a?1:0,Qe.uniforms.uTemperature.value=t.temperature||1,Qe.uniforms.uMinP.value=t.minP||.05,Qe.uniforms.uMaxProb.value=ht?ht.probability:1,ht&&$e&&ht.token_id<at){const ke=$e[ht.token_id*2]*250,We=$e[ht.token_id*2+1]*250,Ue=rc($e[ht.token_id*2],$e[ht.token_id*2+1]),Le=Math.max(ht.probability,1e-7),Xe=Math.max(t.temperature||1,.01),tt=150*Math.pow(ht.probability/Le,1/Xe);N.current&&N.current.addStep(ht.token_str,l.length>0?1:0,new K(ke,Ue+tt,We)),eT.logStep(l.length>0?1:0,ht.token_id,ht.probability,0)}},[e,bt,l,a,at,d,t.temperature,t.minP]);const ht=l.find(j=>j.rank===1&&!j.isFiltered),jt=ht&&$e&&ht.token_id<at?{tokenStr:ht.token_str,probability:ht.probability,umapX:$e[ht.token_id*2],umapY:$e[ht.token_id*2+1]}:null;return c.jsxs("div",{className:"w-full h-full relative group",children:[c.jsx("div",{ref:h,className:"absolute inset-0 cursor-move"}),c.jsx("div",{ref:m,className:"absolute inset-0 pointer-events-none overflow-hidden"}),c.jsx("div",{ref:f,className:"absolute inset-0 pointer-events-none overflow-hidden"}),c.jsx(WE,{modelId:s,status:bt?"ready":"downloading",stepIndex:l.length>0?1:0,topCandidate:l.length>0?l[0]:null,isLassoActive:de,isFullscreen:q,persona:C,temperature:t.temperature||1,minP:t.minP||.05,onToggleLasso:()=>re(!de),onResetCamera:ee,onToggleFullscreen:ce,onZoomIn:me,onZoomOut:ve,onTogglePersona:()=>D(C==="flight_sim"?"diagnostic":"flight_sim"),onOpenEnterpriseLabs:()=>O(!0),onOpenMultiModel:()=>I(!0)}),H&&c.jsxs("div",{className:"absolute top-20 left-4 z-30 bg-rose-950/90 border border-rose-500/70 text-rose-200 px-3 py-1.5 rounded-xl shadow-2xl font-mono text-xs flex items-center gap-2 animate-bounce",children:[c.jsx("span",{className:"w-2 h-2 rounded-full bg-rose-400 animate-ping"}),c.jsxs("span",{children:[c.jsx("strong",{children:"[ANOMALY]:"})," ",H.message]}),c.jsx("button",{onClick:()=>B(null),className:"text-rose-400 hover:text-white ml-2 text-xs",children:"✕"})]}),c.jsx(ZE,{isOpen:L,onClose:()=>O(!1),onSelectMission:j=>{N.current&&N.current.clear()}}),c.jsx(QE,{isOpen:T,onClose:()=>I(!1),onApplyGhostTrajectory:j=>{P.current&&P.current.loadFromHistory(j)}}),c.jsx(GE,{enabled:de,onLassoComplete:qe,onCameraLockChange:be}),c.jsx(VE,{metrics:X,onClose:()=>J(null),screenCentroid:le}),Q&&c.jsxs("div",{className:"absolute z-30 pointer-events-none bg-slate-950/90 backdrop-blur-md border border-slate-700/60 rounded-lg px-2.5 py-2 text-[10px] font-mono text-slate-200 shadow-2xl min-w-[160px]",style:{left:Q.x,top:Q.y},children:[c.jsxs("div",{className:"font-bold text-slate-100 flex items-center justify-between border-b border-white/10 pb-1 mb-1",children:[c.jsxs("div",{className:"flex items-center space-x-1 truncate max-w-[110px]",children:[c.jsx("span",{className:`w-1.5 h-1.5 rounded-full ${Q.isFiltered?"bg-red-400":"bg-emerald-400"}`}),c.jsx("span",{className:"truncate",children:Q.tokenStr.trim()?`"${Q.tokenStr}"`:`Token #${Q.id}`})]}),c.jsx("span",{className:"text-[9px] text-cyan-300 font-mono bg-cyan-950/60 px-1 py-0.5 rounded border border-cyan-800/40",children:Q.sector})]}),c.jsxs("div",{className:"space-y-0.5",children:[c.jsxs("div",{className:"flex justify-between text-[9px]",children:[c.jsx("span",{className:"text-slate-400",children:"Prob:"}),c.jsxs("span",{className:"text-blue-400 font-semibold",children:[(Q.probability*100).toFixed(2),"%"]})]}),Q.rank!==-1&&c.jsxs("div",{className:"flex justify-between text-[9px]",children:[c.jsx("span",{className:"text-slate-400",children:"Rank:"}),c.jsxs("span",{className:"text-slate-300",children:["#",Q.rank]})]}),Q.rawLogit!==-999&&c.jsxs("div",{className:"flex justify-between text-[9px]",children:[c.jsx("span",{className:"text-slate-400",children:"Logit:"}),c.jsx("span",{className:"text-slate-300",children:Q.rawLogit.toFixed(2)})]}),Q.isFiltered&&c.jsxs("div",{className:"flex justify-between text-[9px]",children:[c.jsx("span",{className:"text-red-400",children:"Status:"}),c.jsx("span",{className:"text-red-300 font-bold uppercase truncate max-w-[90px]",children:Q.filterReason||"Filtered"})]}),Q.isRag&&c.jsxs("div",{className:"text-[8px] text-slate-400 font-bold uppercase mt-0.5 flex items-center",children:[c.jsx("span",{className:"w-1 h-1 rounded-full bg-slate-400 mr-1"}),"RAG Grounded"]})]})]}),bt&&g.current!==-1&&c.jsxs("button",{type:"button",onClick:j=>{j.preventDefault(),j.stopPropagation(),Nt()},className:"absolute bottom-4 left-4 bg-slate-900/80 hover:bg-slate-800 backdrop-blur text-slate-200 hover:text-white text-[10px] font-mono px-3 py-1.5 rounded-lg border border-slate-700/70 shadow-lg transition-colors z-20 flex items-center gap-1.5",children:[c.jsx("span",{className:"w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"}),c.jsx("span",{children:"[SPACE] Focus Target #1"})]}),c.jsx(BE,{cameraAngle:V.angle,cameraDistance:V.distance,cameraPos:V.pos,targetPos:V.target,activeToken:jt}),!bt&&c.jsx("div",{className:"absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm rounded-xl z-10",children:c.jsxs("div",{className:"flex flex-col items-center space-y-4",children:[c.jsx("div",{className:"w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"}),c.jsx("p",{className:"text-sm font-mono text-blue-400",children:"Loading Cartographic Topography..."})]})})]})},go={winner:"#10B981",rag_grounded:"#3B82F6",candidate:"#D946EF",filtered:"#EF4444",fringe:"#333338"},xo=({color:s,label:e})=>c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx("span",{className:"h-2 w-2 rounded-full",style:{backgroundColor:s}}),c.jsx("span",{className:"text-[10px] text-gray-400 font-mono",children:e})]}),Lc=({candidates:s,params:e,ragEnabled:t,onSelectToken:r,title:a="The Token Cosmos",subtitle:l="Probability Distribution View",steps:d=[],currentStepIndex:h=0,onSelectStep:f,onGenerateNextStep:m,onResetTimeline:_,isGenerating:S=!1,allCandidatesByStep:v,historyLength:b=0,modelId:M=null,latestLogits:E=null,isThinking:g=!1,isPlaying:x,onTogglePlay:N})=>{const[P,C]=Y.useState(""),[D,L]=Y.useState(!1),[O,T]=Y.useState("log"),I=x!==void 0?x:D,H=()=>{N?N():L(!D)},B=Y.useRef(null),[V,ae]=Y.useState(!1),Q=()=>{B.current&&(document.fullscreenElement?document.exitFullscreen&&document.exitFullscreen():B.current.requestFullscreen().catch(J=>{console.error(`Error attempting to enable fullscreen: ${J.message}`)}))};Y.useEffect(()=>{const J=()=>{ae(!!document.fullscreenElement)};return document.addEventListener("fullscreenchange",J),()=>document.removeEventListener("fullscreenchange",J)},[]);const ie=Y.useMemo(()=>{const J=s.filter(U=>!U.isFiltered).map(U=>U.probability),le=J.reduce((U,q)=>U+q,0);return le===0?0:-J.reduce((U,q)=>{if(q<=0)return U;const Re=q/le;return U+Re*Math.log2(Re)},0)},[s]),de=s[0],re=s.filter(J=>J.is_rag_grounded).length,X=Y.useMemo(()=>d.map((J,le)=>{const U=v?.[le];if(U&&U.length>0){const qe=C_(U);return Hm(J.selectedToken,qe)}const q=J.selectedToken.probability,Re=q>.5?1:q>.1?3:5;return Hm(J.selectedToken,Re)}),[d,v]);return Y.useEffect(()=>{if(N||!I||d.length<=1||!f)return;const J=setInterval(()=>{f((h+1)%d.length)},900);return()=>clearInterval(J)},[I,h,d.length,f,N]),c.jsxs("div",{ref:B,className:"relative w-full h-full min-h-[480px] rounded-xl overflow-hidden bg-[#050714] flex flex-col",role:"region","aria-label":"Token Probability Distribution",tabIndex:0,children:[c.jsxs("div",{className:"flex items-center justify-between px-4 py-2.5 border-b border-white/5",children:[c.jsxs("div",{className:"flex items-center space-x-3",children:[c.jsx("span",{className:"h-2 w-2 rounded-full bg-blue-400 animate-pulse shadow-md"}),c.jsxs("div",{children:[c.jsx("h3",{className:"text-xs font-bold text-white tracking-tight",children:a}),c.jsx("p",{className:"text-[10px] text-blue-400/80 font-mono",children:l})]})]}),c.jsx("div",{className:"flex items-center space-x-2",children:c.jsxs("div",{className:"flex items-center space-x-1.5 bg-white/5 rounded-lg px-2 py-1",children:[c.jsx($h,{className:"h-3 w-3 text-slate-500"}),c.jsx("input",{type:"text",value:P,onChange:J=>C(J.target.value),placeholder:"Search tokens...",className:"bg-transparent text-xs text-white placeholder:text-gray-600 outline-none w-28 font-mono"})]})})]}),c.jsxs("div",{className:"flex items-center space-x-6 px-4 py-1.5 border-b border-white/5 text-[10px] font-mono text-gray-400",children:[c.jsxs("span",{children:[c.jsx(cg,{className:"inline h-3 w-3 text-blue-400 mr-1"}),"Top: ",c.jsx("strong",{className:"text-white",children:de?.token_str.trim()||"—"})," (",de?(de.probability*100).toFixed(1):0,"%)"]}),c.jsxs("span",{children:[c.jsx(ig,{className:"inline h-3 w-3 text-blue-400 mr-1"}),"Uncertainty: ",c.jsxs("strong",{className:"text-white",children:[ie.toFixed(2)," bits"]})]}),c.jsxs("span",{children:[c.jsx(gc,{className:"inline h-3 w-3 text-blue-400 mr-1"}),"RAG: ",c.jsx("strong",{className:"text-white",children:t?`${re} grounded`:"OFF"})]}),c.jsxs("span",{children:["Candidates: ",c.jsx("strong",{className:"text-white",children:s.filter(J=>!J.isFiltered).length})," / ",s.length]})]}),c.jsxs("div",{className:"flex-1 relative overflow-hidden",children:[c.jsx(tT,{modelId:M,latestLogits:E,params:e,ragTokenIds:t?s.filter(J=>J.is_rag_grounded).map(J=>J.token_id):[],isThinking:g,candidates:s,heightMode:O}),c.jsxs("div",{className:"absolute top-4 left-4 z-10 flex items-center space-x-2",children:[c.jsxs("div",{className:"flex bg-black/60 backdrop-blur-md rounded-lg border border-white/10 p-0.5 pointer-events-auto shadow-lg",children:[c.jsx("button",{onClick:()=>T("linear"),className:`px-2.5 py-1 text-[9px] font-mono font-bold rounded-md transition-all ${O==="linear"?"bg-blue-500/20 text-blue-300 border border-blue-500/30 shadow":"text-gray-400 hover:text-white hover:bg-white/5 border border-transparent"}`,children:"Standard View"}),c.jsx("button",{onClick:()=>T("log"),className:`px-2.5 py-1 text-[9px] font-mono font-bold rounded-md transition-all ${O==="log"?"bg-blue-500/20 text-blue-300 border border-blue-500/30 shadow":"text-gray-400 hover:text-white hover:bg-white/5 border border-transparent"}`,children:"Enhanced 3D"}),c.jsx("button",{onClick:()=>T("logit"),className:`px-2.5 py-1 text-[9px] font-mono font-bold rounded-md transition-all ${O==="logit"?"bg-blue-500/20 text-blue-300 border border-blue-500/30 shadow":"text-gray-400 hover:text-white hover:bg-white/5 border border-transparent"}`,children:"Raw Data"})]}),c.jsxs("button",{type:"button",onClick:Q,title:V?"Exit Full Screen":"Go Full Screen",className:"flex items-center space-x-1 px-2 py-1 text-[9px] font-mono font-bold rounded-lg bg-black/60 hover:bg-black/80 backdrop-blur-md border border-white/10 text-gray-400 hover:text-white transition-all shadow-lg pointer-events-auto",children:[V?c.jsx(ag,{className:"h-3 w-3"}):c.jsx(h_,{className:"h-3 w-3"}),c.jsx("span",{children:V?"Exit Zen":"Zen Mode"})]})]}),c.jsxs("div",{className:"absolute top-4 right-4 w-64 bg-black/40 backdrop-blur-md rounded-lg border border-white/10 overflow-hidden pointer-events-none",children:[c.jsx("div",{className:"px-3 py-1.5 bg-white/5 border-b border-white/10",children:c.jsx("span",{className:"text-[10px] font-bold text-gray-300 uppercase tracking-wider",children:"Most Likely Next Words"})}),c.jsx("div",{className:"p-2 space-y-1",children:s.slice(0,10).map((J,le)=>{const U=Math.max(.3,1-le*.07);return c.jsxs("div",{className:"flex items-center justify-between",style:{opacity:U},children:[c.jsx("span",{className:"text-[10px] font-mono text-slate-100 font-medium truncate mr-2",children:J.token_str.trim()||"—"}),c.jsxs("span",{className:"text-[9px] font-mono text-slate-400",children:[(J.probability*100).toFixed(1),"%"]})]},le)})})]})]}),c.jsxs("div",{className:"flex items-center space-x-4 px-4 py-2 border-t border-white/5",children:[c.jsx(xo,{color:go.winner,label:"Winner"}),c.jsx(xo,{color:go.rag_grounded,label:"RAG Grounded"}),c.jsx(xo,{color:go.candidate,label:"Candidate"}),c.jsx(xo,{color:go.fringe,label:"Fringe"}),c.jsx(xo,{color:go.filtered,label:"Filtered"})]}),d.length>0&&f&&c.jsxs("div",{className:"border-t border-white/5 px-4 py-2 flex items-center space-x-3",children:[c.jsx("button",{onClick:H,className:"h-7 w-7 rounded-full bg-white/5 flex items-center justify-center text-gray-300 hover:text-blue-400 transition-colors",children:I?c.jsx(m_,{className:"h-3.5 w-3.5"}):c.jsx(qh,{className:"h-3.5 w-3.5"})}),c.jsx("button",{onClick:()=>f(Math.max(0,h-1)),disabled:h===0,className:"text-gray-500 hover:text-white disabled:opacity-30 transition-colors",children:c.jsx(Yv,{className:"h-4 w-4"})}),c.jsx("div",{className:"flex-1 flex items-center space-x-0.5 overflow-x-auto scrollbar-none",children:d.map((J,le)=>{const q=X[le]?.perplexityColor||"#333";return c.jsx("button",{onClick:()=>f(le),className:`flex-shrink-0 h-5 px-1.5 rounded text-[9px] font-mono transition-all ${le===h?"ring-1 ring-blue-500 scale-110 text-white":"text-gray-500 hover:text-white"}`,style:{backgroundColor:q},children:J.selectedToken.token_str.trim().slice(0,6)},le)})}),c.jsx("button",{onClick:()=>f(Math.min(d.length-1,h+1)),disabled:h===d.length-1,className:"text-gray-500 hover:text-white disabled:opacity-30 transition-colors",children:c.jsx(Kv,{className:"h-4 w-4"})}),c.jsxs("span",{className:"text-[9px] text-gray-600 font-mono",children:[h+1,"/",d.length]})]})]})},nT=({leftCandidates:s,rightCandidates:e,leftParams:t,rightParams:r,leftTitle:a="Universe A (Primary Config)",leftSubtitle:l=`T = ${t.temperature.toFixed(2)} • Top-K = ${t.topK}`,rightTitle:d="Universe B (A/B Duel Config)",rightSubtitle:h=`T = ${r.temperature.toFixed(2)} • Top-K = ${r.topK}`,leftRagEnabled:f=!1,rightRagEnabled:m=!1,onSelectToken:_,onUpdateRightTemp:S,isByoeMode:v=!1,leftIsThinking:b=!1})=>{const M=Y.useMemo(()=>{if(s.length===0||e.length===0)return null;const E=s[0],g=e[0],x=E?.token_str.trim()===g?.token_str.trim(),N=new Set(s.slice(0,5).map(O=>O.token_str.trim())),P=new Set(e.slice(0,5).map(O=>O.token_str.trim()));let C=0;N.forEach(O=>{P.has(O)&&C++});const D=Math.round(C/5*100),L=Math.abs((E?.probability||0)-(g?.probability||0));return{sameTop:x,topAStr:E?.token_str.trim()||"N/A",topBStr:g?.token_str.trim()||"N/A",probA:Math.round((E?.probability||0)*100),probB:Math.round((g?.probability||0)*100),overlapPct:D,probDiffPct:Math.round(L*100)}},[s,e]);return c.jsxs("div",{className:"w-full h-full min-h-[500px] flex flex-col space-y-3",children:[c.jsxs("div",{className:"flex items-center justify-between rounded-xl bg-slate-950/90 border border-purple-500/30 px-4 py-2 shadow-lg",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx(lg,{className:"h-4 w-4 text-purple-400 animate-pulse"}),c.jsx("span",{className:"text-xs font-bold text-slate-100",children:"A/B Probability Duel"}),c.jsx("span",{className:"rounded-full bg-purple-500/20 px-2 py-0.5 text-[10px] font-mono text-purple-300 border border-purple-500/30",children:v?"Frontier vs. Local BYOE":"Dual Temperature Experiment"})]}),M&&c.jsxs("div",{className:"flex items-center space-x-3 text-[11px] font-mono",children:[c.jsxs("div",{className:"flex items-center space-x-1",children:[c.jsx("span",{className:"text-slate-400",children:"Top Match:"}),M.sameTop?c.jsxs("span",{className:"text-emerald-400 font-bold",children:['Identical ("',M.topAStr,'")']}):c.jsxs("span",{className:"text-amber-400 font-bold",children:['Divergent ("',M.topAStr,'" vs "',M.topBStr,'")']})]}),c.jsxs("div",{className:"hidden sm:flex items-center space-x-1",children:[c.jsx("span",{className:"text-slate-400",children:"Top-5 Overlap:"}),c.jsxs("span",{className:"text-blue-300 font-bold",children:[M.overlapPct,"%"]})]})]})]}),c.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4 flex-1 min-h-[440px]",children:[c.jsx("div",{className:"relative w-full h-full border border-blue-500/30 rounded-2xl overflow-hidden shadow-md",children:c.jsx(Lc,{candidates:s,params:t,ragEnabled:f,onSelectToken:_,title:a,subtitle:l,isThinking:b})}),c.jsxs("div",{className:"relative w-full h-full border border-slate-800 rounded-2xl overflow-hidden shadow-md",children:[c.jsx(Lc,{candidates:e,params:r,ragEnabled:m,onSelectToken:_,title:d,subtitle:h}),!v&&S&&c.jsxs("div",{className:"absolute bottom-3 right-3 z-30 flex items-center space-x-2 rounded-xl bg-slate-950/90 border border-purple-500/40 px-3 py-1.5 backdrop-blur-md shadow-xl",children:[c.jsx(Yr,{className:"h-3.5 w-3.5 text-amber-400"}),c.jsx("span",{className:"text-[10px] font-bold text-slate-300",children:"Temp B:"}),c.jsx("input",{type:"range",min:"0.05",max:"2.0",step:"0.05",value:r.temperature,onChange:E=>S(parseFloat(E.target.value)),className:"w-20 h-1 appearance-none bg-slate-800 rounded-full accent-purple-500"}),c.jsx("span",{className:"text-[10px] font-mono font-bold text-purple-300 w-8 text-right",children:r.temperature.toFixed(2)})]})]})]})]})},iT=()=>c.jsxs("div",{className:"mx-auto max-w-5xl space-y-10 py-6 px-4 sm:px-6",children:[c.jsxs("div",{className:"glass-panel rounded-3xl p-8 border border-slate-800 shadow-2xl relative overflow-hidden",children:[c.jsx("div",{className:"absolute -right-20 -top-20 h-64 w-64 rounded-full bg-blue-500/5 blur-3xl"}),c.jsx("div",{className:"absolute -left-20 -bottom-20 h-64 w-64 rounded-full bg-slate-900/10 blur-3xl"}),c.jsxs("div",{className:"relative z-10 space-y-4 max-w-3xl",children:[c.jsxs("div",{className:"inline-flex items-center space-x-2 rounded-full bg-blue-500/10 px-3 py-1 text-xs font-semibold text-blue-300 border border-blue-500/20",children:[c.jsx(rg,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:"LLM Mechanics Deep Dive"})]}),c.jsx("h2",{className:"text-3xl sm:text-4xl font-extrabold text-slate-100 tracking-tight leading-tight bg-gradient-to-r from-slate-100 via-slate-200 to-blue-300 bg-clip-text text-transparent",children:"Demystifying LLM Sampling: How Parameters Shape AI Token Cosmos"}),c.jsxs("p",{className:"text-sm sm:text-base text-slate-300 leading-relaxed",children:["Large Language Models are not sentient reasoning engines—they are hyper-dimensional ",c.jsx("strong",{children:"next-token probability predictors"}),". Understanding how logits are sampled turns everyday AI prompts into precise, predictable tools."]})]})]}),c.jsxs("section",{className:"glass-panel rounded-2xl p-6 sm:p-8 space-y-4 border border-slate-800",children:[c.jsxs("h3",{className:"text-xl font-bold text-blue-300 flex items-center space-x-2",children:[c.jsx(So,{className:"h-5 w-5 text-blue-400"}),c.jsx("span",{children:"1. The Visual Metaphor: Logits & Softmax"})]}),c.jsxs("p",{className:"text-sm text-slate-300 leading-relaxed",children:["At every step of text generation, the neural network evaluates its entire vocabulary (often 32,000 to 128,000 candidate tokens). It outputs an unnormalized vector of raw numbers called ",c.jsx("strong",{children:"logits ($z_i$)"}),"."]}),c.jsxs("div",{className:"rounded-xl bg-slate-950 p-4 border border-slate-800 font-mono text-xs text-slate-200 overflow-x-auto",children:[c.jsx("p",{className:"text-slate-400 mb-2",children:"// Softmax transformation converting unnormalized raw logits into normalized percentages:"}),c.jsx("p",{className:"text-amber-300",children:"P(x_i) = exp((z_i - z_max) / T) / Σ exp((z_j - z_max) / T)"})]}),c.jsx("p",{className:"text-sm text-slate-300 leading-relaxed",children:"High logits (>10) become glowing center supergiants in the Token Cosmos. Low logits (<0) form dim outer asteroid belts. The sampling parameters act as cosmic filters that shape which stars are eligible to be chosen."})]}),c.jsxs("section",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:[c.jsxs("div",{className:"glass-panel rounded-2xl p-6 border border-slate-800 space-y-3",children:[c.jsxs("div",{className:"flex items-center space-x-2 text-blue-400 font-bold",children:[c.jsx(Yr,{className:"h-5 w-5"}),c.jsx("h4",{children:"Temperature ($T$) — The Cosmic Heat"})]}),c.jsxs("p",{className:"text-xs text-slate-300 leading-relaxed",children:["Temperature scales logits prior to softmax. At ",c.jsx("strong",{children:"T = 0.1"}),", logits become sharp peaks, creating a deterministic, cold focus on top facts. At ",c.jsx("strong",{children:"T = 1.5"}),", probability mass flattens across candidate tokens, introducing wild creative entropy."]})]}),c.jsxs("div",{className:"glass-panel rounded-2xl p-6 border border-slate-800 space-y-3",children:[c.jsxs("div",{className:"flex items-center space-x-2 text-blue-400 font-bold",children:[c.jsx(ga,{className:"h-5 w-5"}),c.jsx("h4",{children:"Top-K & Top-P (Nucleus) Filtering"})]}),c.jsxs("p",{className:"text-xs text-slate-300 leading-relaxed",children:[c.jsx("strong",{children:"Top-K"})," truncates candidate tokens strictly by rank index $k$. ",c.jsx("strong",{children:"Top-P"})," (Nucleus sampling) dynamically selects the smallest candidate pool whose cumulative sum reaches percentage $p$ (e.g. 90%), adapting naturally to uncertain prompts."]})]})]}),c.jsxs("section",{className:"glass-panel rounded-2xl p-6 sm:p-8 space-y-6 border border-slate-800 shadow-2xl",children:[c.jsx("div",{className:"flex items-center justify-between",children:c.jsxs("div",{className:"space-y-1",children:[c.jsxs("h3",{className:"text-xl font-bold text-blue-300 flex items-center space-x-2",children:[c.jsx(Yh,{className:"h-5 w-5 text-blue-400"}),c.jsx("span",{children:"Power User Cheat Sheet: Troubleshooting Guide"})]}),c.jsx("p",{className:"text-xs text-slate-400",children:"Quick-reference lookup table mapping common daily AI prompts and failure modes to exact parameter adjustments."})]})}),c.jsx("div",{className:"overflow-x-auto rounded-xl border border-slate-800",children:c.jsxs("table",{className:"w-full text-left text-xs",children:[c.jsx("thead",{className:"bg-slate-950 text-slate-300 font-semibold uppercase tracking-wider border-b border-slate-800",children:c.jsxs("tr",{children:[c.jsx("th",{className:"px-4 py-3",children:"Common AI Frustration"}),c.jsx("th",{className:"px-4 py-3",children:"Root Cause"}),c.jsx("th",{className:"px-4 py-3",children:"Recommended Parameter Fix"}),c.jsx("th",{className:"px-4 py-3",children:"Expected Result"})]})}),c.jsxs("tbody",{className:"divide-y divide-slate-800/60 bg-slate-900/60 text-slate-300 font-mono",children:[c.jsxs("tr",{className:"hover:bg-slate-900/90 transition-colors",children:[c.jsx("td",{className:"px-4 py-3 font-semibold text-rose-300",children:'"Stop repeating words or looping"'}),c.jsx("td",{className:"px-4 py-3 text-slate-400",children:"Zero context penalty allowing tokens to re-occur infinitely"}),c.jsxs("td",{className:"px-4 py-3 text-blue-400",children:["Frequency Penalty: ",c.jsx("span",{className:"font-bold text-white",children:"0.5"}),c.jsx("br",{}),"Presence Penalty: ",c.jsx("span",{className:"font-bold text-white",children:"0.3"})]}),c.jsx("td",{className:"px-4 py-3 text-slate-300",children:"Penalizes previously seen tokens; forces vocabulary evolution."})]}),c.jsxs("tr",{className:"hover:bg-slate-900/90 transition-colors",children:[c.jsx("td",{className:"px-4 py-3 font-semibold text-amber-300",children:'"Stop hallucinating facts"'}),c.jsx("td",{className:"px-4 py-3 text-slate-400",children:"High temperature picking outer low-probability noise tokens"}),c.jsxs("td",{className:"px-4 py-3 text-blue-400",children:["RAG Fact Anchor: ",c.jsx("span",{className:"font-bold text-white",children:"ON"}),c.jsx("br",{}),"Temperature: ",c.jsx("span",{className:"font-bold text-white",children:"0.1"})," • Top-K: ",c.jsx("span",{className:"font-bold text-white",children:"5"})]}),c.jsx("td",{className:"px-4 py-3 text-slate-300",children:"Strictly anchors logits to retrieved factual context."})]}),c.jsxs("tr",{className:"hover:bg-slate-900/90 transition-colors",children:[c.jsx("td",{className:"px-4 py-3 font-semibold text-purple-300",children:`"Stop saying overuse words ('Delve')"`}),c.jsx("td",{className:"px-4 py-3 text-slate-400",children:"High baseline frequency logit bias in model weights"}),c.jsxs("td",{className:"px-4 py-3 text-blue-400",children:["Logit Bias: ",c.jsx("span",{className:"font-bold text-white font-mono",children:"'Delve': -100"})]}),c.jsx("td",{className:"px-4 py-3 text-slate-300",children:"Black-hole zeroing of logit mass; completely bans target token."})]}),c.jsxs("tr",{className:"hover:bg-slate-900/90 transition-colors",children:[c.jsx("td",{className:"px-4 py-3 font-semibold text-sky-300",children:'"Boost creative metaphors / stories"'}),c.jsx("td",{className:"px-4 py-3 text-slate-400",children:"Low temperature restricting choices to generic common paths"}),c.jsxs("td",{className:"px-4 py-3 text-blue-400",children:["Temperature: ",c.jsx("span",{className:"font-bold text-white",children:"1.3"}),c.jsx("br",{}),"Top-P: ",c.jsx("span",{className:"font-bold text-white",children:"0.95"})]}),c.jsx("td",{className:"px-4 py-3 text-slate-300",children:"Expands nucleus shield; unlocks surprising imaginative tokens."})]}),c.jsxs("tr",{className:"hover:bg-slate-900/90 transition-colors",children:[c.jsx("td",{className:"px-4 py-3 font-semibold text-emerald-300",children:'"Enforce technical domain terms"'}),c.jsx("td",{className:"px-4 py-3 text-slate-400",children:"Model preferring casual everyday synonyms over technical terms"}),c.jsxs("td",{className:"px-4 py-3 text-blue-400",children:["Logit Bias: ",c.jsx("span",{className:"font-bold text-white font-mono",children:"'quantum': +5.0"}),c.jsx("br",{}),"Min-P: ",c.jsx("span",{className:"font-bold text-white",children:"0.1"})]}),c.jsx("td",{className:"px-4 py-3 text-slate-300",children:"Magnetically pulls probability mass to specific technical terms."})]})]})]})})]})]}),rT=({params:s,setParams:e,prompt:t,setPrompt:r,ragContext:a,setRagContext:l,ragEnabled:d,setRagEnabled:h,topCandidateStr:f="Paris",topCandidateProb:m=.85,activeInteractionNotice:_=null})=>{const[S,v]=Y.useState(!1),[b,M]=Y.useState(""),[E,g]=Y.useState(!1),[x,N]=Y.useState(!0),[P,C]=Y.useState(!1),[D,L]=Y.useState({x:24,y:180}),[O,T]=Y.useState(!1),I=Y.useRef({x:0,y:0}),H=Y.useRef({x:24,y:180}),B=Y.useRef(null),[V,ae]=Y.useState([{id:"welcome-1",sender:"navigator",text:"Greetings, Explorer! I am your free-floating Navigator guide. You can drag my console anywhere on the screen! Whenever you touch a slider, toggle a preset, or click any control, I will explain what it is, why it exists, and how it impacts AI probabilities.",timestamp:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}]);Y.useEffect(()=>{const be=()=>{window.innerWidth<640&&!S&&L({x:window.innerWidth-60,y:window.innerHeight-60})};return be(),window.addEventListener("resize",be),()=>window.removeEventListener("resize",be)},[S]),Y.useEffect(()=>{S&&window.innerWidth<640&&L({x:16,y:16})},[S]);const Q=()=>{B.current?.scrollIntoView({behavior:"smooth"})};Y.useEffect(()=>{S&&Q()},[V,S]);const ie=Y.useCallback(be=>{if(x||typeof window>"u"||!("speechSynthesis"in window))return;window.speechSynthesis.cancel();const ee=new SpeechSynthesisUtterance(be),ve=window.speechSynthesis.getVoices().find(ce=>ce.name.includes("Google")||ce.name.includes("Samantha")||ce.name.includes("Zira")||ce.name.includes("Natural")||ce.lang.startsWith("en"));ve&&(ee.voice=ve),ee.rate=1,ee.pitch=1.1,ee.onstart=()=>C(!0),ee.onend=()=>C(!1),ee.onerror=()=>C(!1),window.speechSynthesis.speak(ee)},[x]);Y.useEffect(()=>{x&&typeof window<"u"&&"speechSynthesis"in window&&(window.speechSynthesis.cancel(),C(!1))},[x]);const de=Y.useRef(0);Y.useEffect(()=>{if(!_||_.timestamp<=de.current)return;de.current=_.timestamp;const be=`${_.feature.toUpperCase()}

• WHAT IT IS: ${_.whatItIs}
• WHY IT EXISTS: ${_.whyItIs}
• HOW IT IMPACTS: ${_.impact}
• GUIDANCE: ${_.guidance}`,ee={id:`notice-${Date.now()}`,sender:"navigator",text:be,timestamp:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}),badge:_.feature};ae(ve=>[...ve,ee]);const me=`${_.feature}. ${_.impact} ${_.guidance}`;ie(me)},[_,ie]);const re=be=>{T(!0),I.current={x:be.clientX,y:be.clientY},H.current={...D}};Y.useEffect(()=>{const be=me=>{if(!O)return;const ve=me.clientX-I.current.x,ce=me.clientY-I.current.y,we=S?Math.min(400,window.innerWidth-32):window.innerWidth<640?48:180,Ze=S?Math.min(540,window.innerHeight-32):48,bt=Math.max(10,Math.min(window.innerWidth-we-10,H.current.x+ve)),ot=Math.max(10,Math.min(window.innerHeight-Ze-10,H.current.y+ce));L({x:bt,y:ot})},ee=()=>{T(!1)};return O&&(window.addEventListener("mousemove",be),window.addEventListener("mouseup",ee)),()=>{window.removeEventListener("mousemove",be),window.removeEventListener("mouseup",ee)}},[O,S]);const X=()=>({prompt:t,temperature:s.temperature,topK:s.topK,topP:s.topP,minP:s.minP,frequencyPenalty:s.frequencyPenalty,presencePenalty:s.presencePenalty,ragEnabled:d,logitBiases:s.logitBiases,topCandidateStr:f,topCandidateProb:`${(m*100).toFixed(1)}%`}),J=be=>{const ee=be.toLowerCase(),me=X();return ee.includes("hallucinat")||ee.includes("heat")||ee.includes("wild")?{text:`Look at the canvas! At Temperature ${me.temperature.toFixed(2)}, candidate probabilities flatten out. Low-probability outer asteroids glow brighter, causing the model to guess wildly. Lower Temperature to below 0.3 to restore factual focus!`,badge:"Heat Entropy Warning"}:ee.includes("truth")||ee.includes("fact")||ee.includes("rag")?{text:`When RAG Grounding is ${me.ragEnabled?"ON":"OFF"}, retrieved factual context anchors logits. Grounded tokens get pulled to the center supergiant by cyan laser beams, forcing the LLM to stay tethered to facts!`,badge:"RAG Tether Active"}:ee.includes("ban")||ee.includes("delve")||ee.includes("black hole")||ee.includes("bias")?{text:"Applying a -100 Logit Bias creates a mathematical Black Hole! Target words implode into red cross icons on the outer fringe, making it impossible for the AI to select them.",badge:"Logit Bias Black Hole"}:ee.includes("repeat")||ee.includes("loop")||ee.includes("exhaust")?{text:`Frequency Penalty (${me.frequencyPenalty.toFixed(2)}) acts as an Exhaustion Meter! Words that have already appeared in the sentence context physically dim in opacity, forcing the model to pick fresh vocabulary.`,badge:"Exhaustion Meter"}:{text:`You're currently evaluating prompt "${me.prompt.slice(0,30)}..." with Temperature ${me.temperature.toFixed(2)} and Top-K ${me.topK}. The top predicted next token is "${me.topCandidateStr}" (${me.topCandidateProb}). Try adjusting the Cosmic Heat slider or toggling RAG to see how the starfield shifts!`,badge:"Cosmos State Analysis"}},le=be=>{const ee=be||b.trim();if(!ee)return;const me={id:`user-${Date.now()}`,sender:"user",text:ee,timestamp:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})};ae(ve=>[...ve,me]),be||M(""),g(!0),setTimeout(()=>{const ve=J(ee),ce={id:`nav-${Date.now()}`,sender:"navigator",text:ve.text,timestamp:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}),badge:ve.badge};ae(we=>[...we,ce]),g(!1),ie(ve.text)},400)},U=()=>{e(be=>({...be,temperature:2,topK:50})),h(!1),le("Show me how an AI hallucinates!")},q=()=>{e(be=>({...be,temperature:.1,topK:5})),h(!0),a.trim()||l("Paris is the capital of France. The Eiffel Tower is located on the Champ de Mars in Paris."),le("How do I force the AI to tell the truth?")},Re=()=>{e(be=>({...be,logitBiases:{...be.logitBiases,delve:-100,delves:-100}})),le('How do I ban annoying buzzwords like "delve"?')},qe=()=>{e(be=>({...be,frequencyPenalty:1.2,presencePenalty:.5})),le("How do I fix repetitive text and looping?")};return c.jsx("div",{style:{position:"fixed",left:`${D.x}px`,top:`${D.y}px`,zIndex:50},className:"font-sans select-none",children:S?c.jsxs("div",{className:"flex h-[calc(100vh-32px)] w-[calc(100vw-32px)] max-h-[540px] flex-col overflow-hidden rounded-xl border border-white/10 bg-[#0A0A0A] shadow-2xl sm:h-[540px] sm:w-[400px]",children:[c.jsxs("div",{onMouseDown:re,className:"flex items-center justify-between border-b border-slate-800 bg-slate-950 px-4 py-3 cursor-grab active:cursor-grabbing select-none",children:[c.jsxs("div",{className:"flex items-center space-x-2.5",children:[c.jsx(zm,{className:"h-4 w-4 text-slate-500"}),c.jsx("div",{className:`relative flex h-8 w-8 items-center justify-center rounded-xl bg-blue-600 p-0.5 ${P?"shadow-md ring-2 ring-blue-500":""}`,children:c.jsx("div",{className:"flex h-full w-full items-center justify-center rounded-[10px] bg-slate-950",children:c.jsx(xc,{className:"h-4 w-4 text-blue-400"})})}),c.jsxs("div",{children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx("h3",{className:"text-sm font-bold text-slate-100",children:"The Navigator"}),P&&c.jsxs("span",{className:"flex items-center space-x-1 rounded-full bg-blue-500/10 px-2 py-0.5 text-[9px] font-mono font-bold text-blue-300 border border-blue-500/20",children:[c.jsx(Xv,{className:"h-3 w-3 animate-pulse text-blue-400"}),c.jsx("span",{children:"Speaking"})]})]}),c.jsxs("p",{className:"text-[10px] text-blue-400 font-mono flex items-center space-x-1",children:[c.jsx("span",{className:"h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"}),c.jsx("span",{children:"Free-Floating Mobility • Real-time AI"})]})]})]}),c.jsxs("div",{className:"flex items-center space-x-1",children:[c.jsx("button",{onClick:()=>N(!x),"aria-label":x?"Unmute Web Speech API voice assistant":"Mute voice assistant",className:`p-1.5 rounded-lg transition-colors ${x?"bg-slate-900 text-slate-400 border border-slate-800 hover:text-white":"bg-blue-500/10 text-blue-300 border border-blue-500/30 shadow-md"}`,title:x?"Unmute Voice Assistant (Web Speech API)":"Mute Voice Assistant",children:x?c.jsx(E_,{className:"h-4 w-4 text-slate-500"}):c.jsx(w_,{className:"h-4 w-4 text-blue-400 animate-pulse"})}),c.jsx("button",{onClick:()=>v(!1),"aria-label":"Minimize The Navigator guide",className:"p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800",children:c.jsx(ag,{className:"h-4 w-4"})})]})]}),c.jsxs("div",{className:"flex items-center justify-between bg-slate-900/90 px-4 py-1.5 border-b border-slate-800 text-[10px] font-mono text-slate-300",children:[c.jsxs("span",{children:["Temp: ",c.jsx("strong",{className:"text-blue-400",children:s.temperature.toFixed(2)})]}),c.jsxs("span",{children:["Top-K: ",c.jsx("strong",{className:"text-blue-400",children:s.topK})]}),c.jsxs("span",{children:["RAG: ",c.jsx("strong",{className:d?"text-blue-400":"text-slate-400",children:d?"ON":"OFF"})]}),c.jsxs("span",{children:["Voice: ",c.jsx("strong",{className:x?"text-slate-500":"text-blue-300",children:x?"MUTED":"ON"})]})]}),c.jsxs("div",{className:"flex-1 overflow-y-auto p-4 space-y-3.5 bg-slate-950/40 select-text",children:[V.map(be=>c.jsxs("div",{className:`flex flex-col ${be.sender==="user"?"items-end":"items-start"}`,children:[be.badge&&c.jsx("span",{className:"mb-1 rounded-full bg-blue-500/10 px-2 py-0.5 text-[9px] font-mono font-bold text-blue-300 border border-blue-500/20",children:be.badge}),c.jsx("div",{className:`max-w-[90%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed whitespace-pre-wrap ${be.sender==="user"?"bg-blue-600 text-white font-medium rounded-br-none":"bg-slate-900/90 border border-slate-800 text-slate-200 rounded-bl-none shadow-md"}`,children:be.text}),c.jsx("span",{className:"mt-1 text-[9px] font-mono text-slate-500 px-1",children:be.timestamp})]},be.id)),E&&c.jsxs("div",{className:"flex items-center space-x-1.5 bg-slate-900 border border-slate-800 p-2 rounded-2xl rounded-bl-none w-16",children:[c.jsx("span",{className:"h-1.5 w-1.5 rounded-full bg-blue-400 animate-bounce"}),c.jsx("span",{className:"h-1.5 w-1.5 rounded-full bg-blue-400 animate-bounce delay-100"}),c.jsx("span",{className:"h-1.5 w-1.5 rounded-full bg-blue-400 animate-bounce delay-200"})]}),c.jsx("div",{ref:B})]}),c.jsxs("div",{className:"border-t border-slate-800 bg-slate-950/80 p-2 space-y-1.5",children:[c.jsx("span",{className:"block text-[10px] font-bold uppercase tracking-wider text-blue-400 px-1",children:"Interactive Tour Stops (Action Callbacks)"}),c.jsxs("div",{className:"flex flex-wrap gap-1",children:[c.jsxs("button",{onClick:U,"aria-label":"Tour Stop: Show me how an AI hallucinates",className:"flex items-center space-x-1 rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-[10px] text-slate-300 hover:bg-slate-800 transition-colors",children:[c.jsx(Yr,{className:"h-3 w-3 text-slate-400"}),c.jsx("span",{children:"1. Hallucination Demo"})]}),c.jsxs("button",{onClick:q,"aria-label":"Tour Stop: Force AI to tell the truth with RAG",className:"flex items-center space-x-1 rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-[10px] text-slate-300 hover:bg-slate-800 transition-colors",children:[c.jsx(gc,{className:"h-3 w-3 text-slate-400"}),c.jsx("span",{children:"2. RAG Fact Anchor"})]}),c.jsxs("button",{onClick:Re,"aria-label":"Tour Stop: Ban annoying words with Black Hole Logit Bias",className:"flex items-center space-x-1 rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-[10px] text-slate-300 hover:bg-slate-800 transition-colors",children:[c.jsx(qv,{className:"h-3 w-3 text-slate-400"}),c.jsx("span",{children:"3. Black Hole Ban"})]}),c.jsxs("button",{onClick:qe,"aria-label":"Tour Stop: Fix word repetition with Exhaustion Meter",className:"flex items-center space-x-1 rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-[10px] text-slate-300 hover:bg-slate-800 transition-colors",children:[c.jsx(y_,{className:"h-3 w-3 text-slate-400"}),c.jsx("span",{children:"4. Fix Repetition"})]})]})]}),c.jsxs("div",{className:"flex items-center space-x-2 border-t border-slate-800 bg-slate-950 p-3 select-text",children:[c.jsx("input",{type:"text","aria-label":"Ask The Navigator guide a question",value:b,onChange:be=>M(be.target.value),onKeyDown:be=>be.key==="Enter"&&le(),placeholder:"Ask The Navigator about the dashboard...",className:"flex-1 rounded-xl bg-slate-900 border border-slate-800 px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:border-blue-500 focus:outline-none"}),c.jsx("button",{onClick:()=>le(),"aria-label":"Send message to The Navigator",className:"rounded-xl bg-blue-600 p-2 text-white font-bold hover:bg-blue-700 transition-colors",children:c.jsx(x_,{className:"h-3.5 w-3.5"})})]})]}):c.jsxs("button",{onClick:()=>v(!0),onMouseDown:re,"aria-label":"Open The Navigator Tourist Guide Chatbot (Draggable)",className:"group flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-[#0A0A0A] p-0 shadow-lg transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] hover:-translate-y-[1px] hover:border-white/20 transform-gpu cursor-grab active:cursor-grabbing sm:h-auto sm:w-auto sm:justify-start sm:space-x-2 sm:rounded-xl sm:px-3.5 sm:py-2",children:[c.jsx(zm,{className:"hidden h-3.5 w-3.5 text-gray-400 opacity-60 group-hover:opacity-100 sm:block"}),c.jsx("div",{className:"flex h-6 w-6 items-center justify-center rounded-lg bg-white/10 text-white border border-white/20",children:c.jsx(xc,{className:"h-3.5 w-3.5"})}),c.jsxs("div",{className:"hidden text-left sm:block",children:[c.jsx("span",{className:"block text-xs font-bold text-white tracking-tight group-hover:text-gray-200",children:"The Navigator"}),c.jsx("span",{className:"block text-[10px] text-gray-400 font-mono",children:P?"🔊 Speaking...":"Draggable Guide"})]})]})})},sT=({isOpen:s,onClose:e,onSave:t,provider:r,customUrl:a,customApiKey:l,modelName:d})=>{const[h,f]=Y.useState(r),[m,_]=Y.useState(a),[S,v]=Y.useState(l),[b,M]=Y.useState(d),[E,g]=Y.useState(!1);if(Y.useEffect(()=>{f(r),_(a),v(l),M(d)},[r,a,l,d,s]),!s)return null;const x=C=>{f(C),C==="openai"?(_("https://api.openai.com/v1"),b||M("gpt-4o")):C==="custom"&&!m?(_("http://localhost:1234/v1"),b||M("local-model")):C==="default"&&(_(""),v(""),M("Cloud Run candidate demo"))},N=()=>{t(h,m.trim(),S.trim(),b.trim()),g(!0),setTimeout(()=>{g(!1),e()},800)},P=()=>{f("default"),_(""),v(""),M("Cloud Run candidate demo"),t("default","","","Cloud Run candidate demo"),g(!0),setTimeout(()=>{g(!1),e()},800)};return c.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-200",children:c.jsxs("div",{className:"w-full max-w-md rounded-2xl glass-panel border border-slate-800 shadow-2xl p-6 space-y-5 bg-slate-950/90",children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-slate-800 pb-3",children:[c.jsxs("div",{className:"flex items-center space-x-2.5",children:[c.jsx("div",{className:"flex h-9 w-9 items-center justify-center rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20",children:c.jsx(og,{className:"h-5 w-5 animate-spin-slow"})}),c.jsxs("div",{children:[c.jsx("h3",{className:"text-base font-bold text-slate-100",children:"Engine Configuration (BYOE)"}),c.jsx("p",{className:"text-xs text-slate-400",children:"Bring Your Own API Key or Local Engine"})]})]}),c.jsx("button",{onClick:e,"aria-label":"Close settings modal",className:"p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800",children:c.jsx(_c,{className:"h-4 w-4"})})]}),c.jsxs("div",{className:"flex items-start space-x-2.5 rounded-xl bg-slate-900 p-3 border border-slate-800 text-xs text-slate-300",children:[c.jsx(Yh,{className:"h-4 w-4 text-slate-400 shrink-0 mt-0.5"}),c.jsxs("p",{className:"leading-relaxed",children:["API Keys and Custom URLs are stored ",c.jsx("strong",{children:"100% locally in your browser (localStorage)"}),". They bypass our backend and are never sent to our servers."]})]}),c.jsxs("div",{className:"space-y-4",children:[c.jsxs("div",{children:[c.jsxs("label",{htmlFor:"provider-select",className:"block text-xs font-semibold text-slate-200 mb-1.5 flex items-center space-x-1.5",children:[c.jsx(sg,{className:"h-3.5 w-3.5 text-blue-400"}),c.jsx("span",{children:"Select AI Provider Engine"})]}),c.jsxs("select",{id:"provider-select","aria-label":"Select AI Provider Engine",value:h,onChange:C=>x(C.target.value),className:"w-full rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-slate-200 font-semibold focus:border-blue-500 focus:outline-none",children:[c.jsx("option",{value:"default",children:"Default (Cloud Run candidate demo)"}),c.jsx("option",{value:"openai",children:"OpenAI (GPT-4o / GPT-3.5)"}),c.jsx("option",{value:"custom",children:"Custom / Local (vLLM / LM Studio / Ollama)"})]})]}),h!=="default"&&c.jsxs("div",{children:[c.jsx("label",{htmlFor:"model-name-input",className:"block text-xs font-semibold text-slate-200 mb-1.5",children:"Model Name String"}),c.jsx("input",{id:"model-name-input",type:"text","aria-label":"Model Name String",value:b,onChange:C=>M(C.target.value),placeholder:"e.g. gpt-4o, gemini-1.5-pro, local-model",className:"w-full rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:border-blue-500 focus:outline-none font-mono"})]}),(h==="custom"||h==="openai")&&c.jsxs("div",{children:[c.jsxs("label",{htmlFor:"custom-url-input",className:"block text-xs font-semibold text-slate-200 mb-1.5 flex items-center space-x-1.5",children:[c.jsx(v_,{className:"h-3.5 w-3.5 text-blue-400"}),c.jsx("span",{children:"Base API Endpoint URL"})]}),c.jsx("input",{id:"custom-url-input",type:"text","aria-label":"Base API Endpoint URL",value:m,onChange:C=>_(C.target.value),placeholder:"e.g. https://api.openai.com/v1 or http://localhost:1234/v1",className:"w-full rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:border-blue-500 focus:outline-none font-mono"}),c.jsxs("p",{className:"text-[11px] text-slate-400 mt-1",children:["Must support ",c.jsx("code",{className:"font-mono text-blue-400",children:"logprobs: true"})," to render token probability distribution."]})]}),h!=="default"&&c.jsxs("div",{children:[c.jsxs("label",{htmlFor:"custom-key-input",className:"block text-xs font-semibold text-slate-200 mb-1.5 flex items-center space-x-1.5",children:[c.jsx(c_,{className:"h-3.5 w-3.5 text-blue-400"}),c.jsx("span",{children:"API Key (Stored in local browser storage)"})]}),c.jsx("input",{id:"custom-key-input",type:"password","aria-label":"Custom API Key",value:S,onChange:C=>v(C.target.value),placeholder:"sk-...",className:"w-full rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:border-blue-500 focus:outline-none font-mono"})]})]}),c.jsxs("div",{className:"flex items-center justify-between pt-2 border-t border-slate-800",children:[c.jsxs("button",{onClick:P,type:"button","aria-label":"Reset engine configuration to default Cloud Run server",className:"flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-medium text-slate-400 hover:text-white hover:border-slate-700",children:[c.jsx(g_,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:"Reset Default"})]}),c.jsx("button",{onClick:N,type:"button","aria-label":"Save engine configuration",className:"flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-xs font-bold text-white shadow-md transition-colors",children:E?c.jsxs(c.Fragment,{children:[c.jsx(Qv,{className:"h-4 w-4 text-emerald-300"}),c.jsx("span",{children:"Saved!"})]}):c.jsx("span",{children:"Save Configuration"})})]})]})})},aT=()=>{const[s,e]=Y.useState(()=>localStorage.getItem("token_cosmos_hero_collapsed")!=="true"),t=()=>{e(r=>{const a=!r;return localStorage.setItem("token_cosmos_hero_collapsed",a?"false":"true"),a})};return c.jsxs("div",{className:"w-full rounded-xl glass-panel-matte overflow-hidden transition-all duration-300",children:[c.jsxs("div",{className:"flex items-center justify-between px-5 py-3.5 bg-[#0A0A0A] border-b border-white/10",children:[c.jsxs("div",{className:"flex items-center space-x-2.5",children:[c.jsx("div",{className:"flex h-7 w-7 items-center justify-center rounded-lg bg-white/10 border border-white/20",children:c.jsx(So,{className:"h-3.5 w-3.5 text-white"})}),c.jsx("div",{children:c.jsxs("h2",{className:"text-xs sm:text-sm font-bold text-white tracking-tight flex items-center space-x-2",children:[c.jsx("span",{children:"Demystifying the LLM Black Box"}),c.jsx("span",{className:"rounded-md bg-white/10 px-2 py-0.5 text-[10px] font-mono text-gray-300 border border-white/10",children:"Interactive Cognitive HUD"})]})})]}),c.jsxs("button",{onClick:t,className:"btn-secondary-matte px-2.5 py-1 text-xs flex items-center space-x-1",children:[c.jsx("span",{children:s?"Hide Tour":"Show Tour"}),s?c.jsx(bs,{className:"h-3.5 w-3.5"}):c.jsx(ys,{className:"h-3.5 w-3.5"})]})]}),s&&c.jsxs("div",{className:"p-5 grid grid-cols-1 md:grid-cols-2 gap-5 bg-[#0A0A0A]",children:[c.jsxs("div",{className:"rounded-xl bg-[#111111] border border-white/10 p-4 flex flex-col justify-between space-y-3",children:[c.jsxs("div",{children:[c.jsxs("div",{className:"flex items-center space-x-2 mb-2",children:[c.jsx("span",{className:"h-2 w-2 rounded-full bg-gray-500"}),c.jsx("span",{className:"text-xs font-bold uppercase tracking-wider text-gray-400 font-mono",children:"What You Usually See (The Chatbot)"})]}),c.jsx("p",{className:"text-xs text-gray-200 leading-relaxed font-mono bg-[#161616] p-3 rounded-lg border border-white/10",children:'"Paris is the capital of France..."'})]}),c.jsx("p",{className:"text-[11px] text-gray-400 leading-relaxed",children:"Standard AI interfaces hide how decisions are made. Text appears linearly, making AI look like a conscious speaker answering questions passively."})]}),c.jsxs("div",{className:"rounded-xl bg-[#111111] border border-white/10 p-4 flex flex-col justify-between space-y-3",children:[c.jsxs("div",{children:[c.jsxs("div",{className:"flex items-center justify-between mb-2",children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx("span",{className:"h-2 w-2 rounded-full bg-white"}),c.jsx("span",{className:"text-xs font-bold uppercase tracking-wider text-white font-mono",children:"What is Actually Happening (The Brain)"})]}),c.jsx(i_,{className:"h-3.5 w-3.5 text-gray-400"})]}),c.jsxs("div",{className:"flex items-center space-x-2 bg-[#161616] p-2.5 rounded-lg border border-white/10 font-mono text-[11px]",children:[c.jsx("span",{className:"rounded bg-[#222222] text-white border border-white/20 px-2 py-0.5 font-bold",children:'"Paris" (92%)'}),c.jsx("span",{className:"rounded bg-[#1A1A1A] text-gray-300 border border-white/10 px-1.5 py-0.5",children:'"Lyon" (3%)'}),c.jsx("span",{className:"rounded bg-[#1A1A1A] text-gray-400 border border-white/10 px-1.5 py-0.5",children:'"Rome" (1%)'}),c.jsx("span",{className:"text-gray-500 text-[10px]",children:"+47 more candidates"})]})]}),c.jsxs("p",{className:"text-[11px] text-gray-300 leading-relaxed",children:[c.jsx("strong",{className:"text-white",children:"LLMs compute a probability galaxy"})," of 50,000+ vocabulary candidates for every single word. Tune Temperature, Top-K, and RAG to force factual certainty or spark creative leaps!"]})]})]})]})},oT=({isOpen:s,onClose:e,params:t,prompt:r,systemPrompt:a,ragContext:l,ragEnabled:d,modelName:h,provider:f,isReasoningModel:m=!1})=>{const[_,S]=Y.useState("openai"),[v,b]=Y.useState(!1);if(!s)return null;const E=`# Production OpenAI Python SDK Setup
# Generated by "The Token Cosmos"

from openai import OpenAI

client = OpenAI()

response = client.chat.completions.create(
    model="${m?"o3-mini":h||"gpt-4o"}",
    messages=[
${a.trim()?`        {"role": "system", "content": "${a.replace(/"/g,'\\"')}"},
`:""}${d&&l.trim()?`        {"role": "user", "content": "Retrieved Context: ${l.replace(/"/g,'\\"')}\\n\\nQuestion: ${r.replace(/"/g,'\\"')}"}`:`        {"role": "user", "content": "${r.replace(/"/g,'\\"')}"}`}
    ],
${m?`    max_completion_tokens=${t.maxThinkingTokens||2048}, # Acts as thinking budget + output`:`    temperature=${t.temperature},
    top_p=${t.topP},
    frequency_penalty=${t.frequencyPenalty},
    presence_penalty=${t.presencePenalty},
${t.stopSequences.length>0?`    stop=${JSON.stringify(t.stopSequences)},
`:""}${Object.keys(t.logitBiases).length>0?`    logit_bias=${JSON.stringify(t.logitBiases)},
`:""}    logprobs=True,
    top_logprobs=20,`}
)

print(response.choices[0].message.content)
`,g=`# Production Anthropic Python SDK Setup
# Generated by "The Token Cosmos"

import anthropic

client = anthropic.Anthropic()

response = client.messages.create(
    model="${m?"claude-3-7-sonnet-20250219":"claude-3-5-sonnet-20241022"}",
    max_tokens=${m?2e4:4096},
${a.trim()?`    system="${a.replace(/"/g,'\\"')}",
`:""}${m?`    thinking={
        "type": "enabled",
        "budget_tokens": ${t.maxThinkingTokens||2048}
    },
`:`    temperature=${t.temperature},
`}    messages=[
${d&&l.trim()?`        {"role": "user", "content": "Context: ${l.replace(/"/g,'\\"')}\\n\\nQuestion: ${r.replace(/"/g,'\\"')}"}`:`        {"role": "user", "content": "${r.replace(/"/g,'\\"')}"}`}
    ]
)

print(response.content[0].text)
`,x=`# Production Gemini Python SDK Setup
# Generated by "The Token Cosmos"

from google import genai
from google.genai import types

client = genai.Client()

${d&&l.trim()?`prompt_text = "Context: ${l.replace(/"/g,'\\"')}\\n\\nQuestion: ${r.replace(/"/g,'\\"')}"`:`prompt_text = "${r.replace(/"/g,'\\"')}"`}

response = client.models.generate_content(
    model='${m?"gemini-2.5-pro":"gemini-2.5-flash"}',
    contents=prompt_text,
    config=types.GenerateContentConfig(
${a.trim()?`        system_instruction="${a.replace(/"/g,'\\"')}",
`:""}${m?`        thinking_config=types.ThinkingConfig(
            thinking_budget_tokens=${t.maxThinkingTokens||2048}
        ),`:`        temperature=${t.temperature},
        top_p=${t.topP},
        top_k=${t.topK},`}
    )
)

print(response.text)
`,N=()=>{switch(_){case"openai":return E;case"anthropic":return g;case"gemini":return x}},P=()=>{navigator.clipboard.writeText(N()),b(!0),setTimeout(()=>b(!1),2e3)};return c.jsx("div",{className:"w-full h-full flex items-start justify-center animate-in fade-in duration-200 select-text",children:c.jsxs("div",{className:"w-full max-w-3xl rounded-2xl border border-slate-800 bg-[#15151a] p-6 shadow-2xl space-y-4",children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-slate-800 pb-3",children:[c.jsxs("div",{className:"flex items-center space-x-2.5",children:[c.jsx("div",{className:"flex h-8 w-8 items-center justify-center rounded-xl bg-blue-600 p-0.5 shadow-md",children:c.jsx("div",{className:"flex h-full w-full items-center justify-center rounded-[10px] bg-slate-950",children:c.jsx(Wh,{className:"h-4 w-4 text-blue-400"})})}),c.jsxs("div",{children:[c.jsx("h3",{className:"text-base font-bold text-slate-100",children:"Export Production Sampling Code"}),c.jsx("p",{className:"text-xs text-slate-400 font-mono",children:"1-click runnable snippets matching your visualizer setup"})]})]}),c.jsx("button",{onClick:e,className:"rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white",children:c.jsx(_c,{className:"h-4 w-4"})})]}),c.jsxs("div",{className:"flex items-center justify-between",children:[c.jsxs("div",{className:"flex rounded-lg bg-slate-900 p-1 border border-slate-800 font-mono text-xs",children:[c.jsxs("button",{onClick:()=>S("openai"),className:`flex items-center space-x-1.5 rounded-md px-3 py-1 font-bold transition-all ${_==="openai"?"bg-blue-600 text-white shadow-md":"text-slate-400 hover:text-slate-200"}`,children:[c.jsx(r_,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:"OpenAI API"})]}),c.jsxs("button",{onClick:()=>S("anthropic"),className:`flex items-center space-x-1.5 rounded-md px-3 py-1 font-bold transition-all ${_==="anthropic"?"bg-blue-600 text-white shadow-md":"text-slate-400 hover:text-slate-200"}`,children:[c.jsx(u_,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:"Anthropic API"})]}),c.jsxs("button",{onClick:()=>S("gemini"),className:`flex items-center space-x-1.5 rounded-md px-3 py-1 font-bold transition-all ${_==="gemini"?"bg-blue-600 text-white shadow-md":"text-slate-400 hover:text-slate-200"}`,children:[c.jsx(S_,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:"Gemini API"})]})]}),c.jsxs("button",{onClick:P,className:"flex items-center space-x-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 px-3 py-1.5 text-xs font-bold text-white shadow-md transition-colors",children:[v?c.jsx(Vh,{className:"h-3.5 w-3.5 text-emerald-300"}):c.jsx(t_,{className:"h-3.5 w-3.5"}),c.jsx("span",{children:v?"Copied to Clipboard!":"Copy Snippet"})]})]}),c.jsx("div",{className:"relative rounded-xl bg-slate-900/90 border border-slate-800 p-4 max-h-[340px] overflow-y-auto font-mono text-xs leading-relaxed text-slate-200",children:c.jsx("pre",{children:N()})})]})})},lT=({state:s,isWebGPUAvailable:e,availableModels:t,onSelectModel:r})=>s.status==="ready"&&s.modelId||s.status==="generating"?null:c.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-[#050714]/90 backdrop-blur-lg",children:c.jsxs("div",{className:"w-full max-w-md mx-4",children:[c.jsxs("div",{className:"text-center mb-6",children:[c.jsx("div",{className:"inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-500/10 border border-blue-500/30 mb-4",children:c.jsx(sg,{className:"w-8 h-8 text-blue-400"})}),c.jsx("h2",{className:"text-xl font-bold text-white tracking-tight",children:"WebGPU Inference Engine"}),c.jsx("p",{className:"text-sm text-gray-400 mt-1 font-mono",children:"In-browser LLM for full logit extraction"})]}),e?c.jsxs(c.Fragment,{children:[(s.status==="downloading"||s.status==="loading")&&c.jsxs("div",{className:"rounded-xl bg-white/5 border border-white/10 p-5 mb-4",children:[c.jsxs("div",{className:"flex items-center space-x-3 mb-3",children:[s.status==="downloading"?c.jsx(n_,{className:"w-5 h-5 text-blue-400 animate-bounce"}):c.jsx(vc,{className:"w-5 h-5 text-blue-400 animate-spin"}),c.jsx("span",{className:"text-sm text-white font-mono",children:s.progressText})]}),c.jsx("div",{className:"w-full h-2 bg-gray-800 rounded-full overflow-hidden",children:c.jsx("div",{className:"h-full bg-blue-600 rounded-full transition-all duration-300 ease-out",style:{width:`${s.progress}%`}})}),c.jsxs("div",{className:"flex justify-between mt-2",children:[c.jsx("span",{className:"text-[10px] text-gray-500 font-mono",children:s.status==="downloading"?"Downloading weights":"Initializing WebGPU"}),c.jsxs("span",{className:"text-[10px] text-blue-400 font-mono font-bold",children:[s.progress,"%"]})]})]}),s.status==="error"&&c.jsx("div",{className:"rounded-xl bg-red-500/10 border border-red-500/30 p-4 mb-4",children:c.jsxs("div",{className:"flex items-start space-x-3",children:[c.jsx(Kd,{className:"w-5 h-5 text-red-400 mt-0.5 flex-shrink-0"}),c.jsxs("div",{children:[c.jsx("p",{className:"text-sm font-semibold text-red-300",children:"Engine Error"}),c.jsx("p",{className:"text-xs text-red-200/70 mt-1 font-mono break-all",children:s.error})]})]})}),(s.status==="idle"||s.status==="error")&&e&&c.jsxs("div",{className:"space-y-2",children:[c.jsx("p",{className:"text-xs text-gray-500 uppercase tracking-wider font-mono mb-3 text-center",children:"Select a model to load"}),t.map(a=>c.jsx("button",{onClick:()=>r(a.id),className:"w-full rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-blue-500/30 p-4 text-left transition-all duration-200 group",children:c.jsxs("div",{className:"flex items-center justify-between",children:[c.jsxs("div",{children:[c.jsxs("div",{className:"flex items-center space-x-2",children:[c.jsx("span",{className:"text-sm font-bold text-white group-hover:text-blue-400 transition-colors",children:a.label}),c.jsx("span",{className:"text-[9px] px-1.5 py-0.5 rounded-full font-mono font-bold uppercase tracking-wider bg-slate-800 text-slate-300 border border-slate-700",children:a.tier})]}),c.jsx("p",{className:"text-xs text-gray-500 mt-1",children:a.description})]}),c.jsxs("div",{className:"text-right flex-shrink-0",children:[c.jsx("div",{className:"text-xs text-gray-400 font-mono",children:a.size}),c.jsxs("div",{className:"text-[9px] text-gray-600 font-mono",children:[a.vocabSize.toLocaleString()," tokens"]})]})]})},a.id))]}),c.jsxs("div",{className:"mt-4 text-center",children:[c.jsx("button",{onClick:()=>r("__CLOUD_API__"),className:"text-xs text-gray-500 hover:text-gray-300 transition-colors font-mono underline underline-offset-4",children:"Continue with Cloud Run candidate API"}),c.jsx("button",{onClick:()=>r("__SAMPLE_DATA__"),className:"mt-2 block w-full text-xs text-gray-600 hover:text-gray-300 transition-colors font-mono underline underline-offset-4",children:"Use generated sample data instead"})]})]}):c.jsx("div",{className:"rounded-xl bg-red-500/10 border border-red-500/30 p-4 mb-4",children:c.jsxs("div",{className:"flex items-start space-x-3",children:[c.jsx(Kd,{className:"w-5 h-5 text-red-400 mt-0.5 flex-shrink-0"}),c.jsxs("div",{children:[c.jsx("p",{className:"text-sm font-semibold text-red-300",children:"WebGPU Unsupported"}),c.jsx("p",{className:"text-xs text-red-200/70 mt-1",children:"Your browser or device does not support WebGPU, which is strictly required for The Token Cosmos 3D Engine."}),c.jsx("a",{href:"https://caniuse.com/webgpu",target:"_blank",rel:"noreferrer",className:"inline-block mt-3 px-3 py-1 bg-red-500/20 text-red-300 text-[10px] rounded hover:bg-red-500/40 transition-colors",children:"Check Browser Requirements →"})]})]})})]})});function cT({params:s,setParams:e,prompt:t,setPrompt:r,systemPrompt:a,setSystemPrompt:l,ragContext:d,setRagContext:h,ragEnabled:f,setRagEnabled:m}){const _=Y.useRef(!0);return Y.useEffect(()=>{if(typeof window>"u")return;if(_.current){_.current=!1;return}const v=new URLSearchParams;s.temperature!==.7&&v.set("temp",s.temperature.toString()),s.topK!==40&&v.set("topk",s.topK.toString()),s.topP!==.9&&v.set("topp",s.topP.toString()),s.minP!==.02&&v.set("minp",s.minP.toString()),s.frequencyPenalty!==.1&&v.set("freq",s.frequencyPenalty.toString()),s.presencePenalty!==.1&&v.set("pres",s.presencePenalty.toString()),v.set("rag",f?"1":"0"),a.trim()&&v.set("sys",a.trim()),t.trim()&&v.set("prompt",t.trim()),d.trim()&&v.set("ragctx",d.trim());const b=`${window.location.pathname}?${v.toString()}${window.location.hash}`;window.history.replaceState(null,"",b)},[s,t,a,d,f]),Y.useEffect(()=>{if(typeof window>"u")return;const v=new URLSearchParams(window.location.search),b=v.get("temp"),M=v.get("topk"),E=v.get("topp"),g=v.get("minp"),x=v.get("freq"),N=v.get("pres"),P=v.get("rag"),C=v.get("sys"),D=v.get("prompt"),L=v.get("ragctx");(b||M||E||g||x||N)&&e(O=>({...O,temperature:b?parseFloat(b):O.temperature,topK:M?parseInt(M,10):O.topK,topP:E?parseFloat(E):O.topP,minP:g?parseFloat(g):O.minP,frequencyPenalty:x?parseFloat(x):O.frequencyPenalty,presencePenalty:N?parseFloat(N):O.presencePenalty})),P!==null&&m(P==="1"),C&&l(C),D&&r(D),L&&h(L)},[]),{copySetupLink:Y.useCallback(()=>{typeof window>"u"||navigator.clipboard.writeText(window.location.href)},[])}}const uT=[{id:"SmolLM2-135M-Instruct-q4f16_1-MLC",label:"SmolLM2 135M (q4f16)",size:"~180MB",vocabSize:49152,description:"Ultra-light local model for compatible WebGPU devices.",tier:"light"},{id:"SmolLM2-135M-Instruct-q0f16-MLC",label:"SmolLM2 135M (q0f16)",size:"~360MB",vocabSize:49152,description:"Ultra-light unquantized float16 variant from WebLLM catalog.",tier:"light"},{id:"Qwen2.5-0.5B-Instruct-q4f16_1-MLC",label:"Qwen2.5 0.5B",size:"~500MB",vocabSize:151936,description:"Deeper reasoning, larger vocabulary. Requires ~1GB VRAM.",tier:"standard"},{id:"Qwen2.5-1.5B-Instruct-q4f16_1-MLC",label:"Qwen2.5 1.5B",size:"~1.2GB",vocabSize:151936,description:"High-quality inference. Requires ~2GB VRAM.",tier:"power"}];function dT(){return typeof navigator>"u"?!1:"gpu"in navigator}function hT(){const s=Y.useRef(null),e=Y.useRef(dT()),[t,r]=Y.useState({status:"idle",progress:0,progressText:"No model loaded",vramUsageMB:null,modelId:null,vocabSize:null,error:null}),[a,l]=Y.useState(null),[d,h]=Y.useState(null),[f,m]=Y.useState([]),[_,S]=Y.useState([]),[v,b]=Y.useState(!1),[M,E]=Y.useState(null),g=Y.useRef(null);Y.useEffect(()=>{if(!e.current){r(H=>({...H,status:"idle",progressText:"WebGPU not available — using sample data"}));return}const I=new Worker(new URL("/assets/WebGPUInferenceWorker-CAwLZvkD.js",import.meta.url),{type:"module"});return I.onmessage=H=>{const B=H.data;switch(B.type){case"STATUS":r(V=>({...V,status:B.status,progress:B.progress,progressText:B.text,error:B.status==="error"?B.text:V.error}));break;case"MODEL_LOADED":r(V=>({...V,status:"ready",modelId:B.modelId,vocabSize:B.vocabSize,error:null}));break;case"VOCAB_LOADED":g.current=B.vocabList;break;case"LOGITS_READY":{const V=new Float32Array(B.snapshot.rawLogitsBuffer);l(V),h({stepIndex:B.snapshot.stepIndex,rawLogits:V,tokenId:B.snapshot.tokenId,tokenStr:B.snapshot.tokenStr,prompt:B.snapshot.prompt,isThinking:B.snapshot.isThinking,timestamp:B.snapshot.timestamp,topCandidates:B.snapshot.topCandidates}),m(B.snapshot.topCandidates);break}case"TOKEN_GENERATED":S(V=>[...V,{tokenStr:B.tokenStr,stepIndex:B.stepIndex}]);break;case"LOOP_ABORTED":b(!0),E(B.message);break;case"GENERATION_COMPLETE":break;case"ERROR":r(V=>({...V,status:"error",error:B.message,progressText:B.message}));break}},I.onerror=H=>{r(B=>({...B,status:"error",error:`Worker error: ${H.message}`,progressText:`Worker error: ${H.message}`}))},s.current=I,()=>{I.terminate(),s.current=null}},[]);const x=Y.useCallback(I=>{s.current?.postMessage(I)},[]),N=Y.useCallback(I=>{l(null),h(null),m([]),S([]),b(!1),E(null),g.current=null,x({type:"LOAD_MODEL",modelId:I})},[x]),P=Y.useCallback(I=>{S([]),b(!1),E(null),x({type:"GET_FULL_LOGITS",prompt:I})},[x]),C=Y.useCallback((I,H,B,V)=>{S([]),b(!1),E(null),x({type:"GENERATE_STEP",prompt:I,maxTokens:H,maxThinkingTokens:B,systemPrompt:V})},[x]),D=Y.useCallback(()=>{b(!1),E(null),x({type:"RESET_CHAT"})},[x]),L=Y.useCallback(()=>{x({type:"ABORT"})},[x]),O=Y.useCallback(()=>{l(null),h(null),m([]),S([]),b(!1),E(null),g.current=null,x({type:"UNLOAD"})},[x]),T=Y.useCallback((I,H)=>{const B=[];for(let V=0;V<I.length;V++){const ae=I[V];if(!isFinite(ae)||ae<-1e6)continue;const Q=g.current?.[V]??`Token #${V}`;B.push({token_id:V,token_str:Q,raw_logit:ae,is_rag_grounded:H?.has(Q.toLowerCase())??!1})}return B.sort((V,ae)=>ae.raw_logit-V.raw_logit),B.slice(0,200)},[]);return{state:t,isWebGPUAvailable:e.current,isModelLoaded:t.status==="ready"&&t.modelId!==null,availableModels:uT,loadModel:N,getLogits:P,generateSteps:C,resetChat:D,abort:L,unload:O,latestLogits:a,latestSnapshot:d,latestCandidates:f,generatedTokens:_,isLoopAborted:v,loopAbortedMessage:M,logitsToRawCandidates:T}}const pa=[{id:"lab-1-infinite-loop",title:"Lab 1: The Infinite Repetition Loop",subtitle:"Frequency Penalties & Min-P Cutoff vs. Greedy Traps",difficulty:"beginner",badge:"Loop Defense",conceptTaught:"Autoregressive Feedback Loops & Repetition Penalties",description:"The model is trapped in an infinite recursive loop repeating customer service boilerplate. Your goal is to break the loop and produce a natural, coherent response without causing the generation to collapse.",objective:"Adjust the Frequency Penalty (>= 0.4) and Min-P (>= 0.05) sliders to eliminate repeating 4-gram sequences.",brokenPrompt:"Please verify your account details. For your security, please verify your account number. To proceed, please verify your account number and confirm your details. Please verify your account",initialParams:{temperature:.3,topK:50,topP:1,minP:0,frequencyPenalty:0,presencePenalty:0},targetParamHints:["Increase Frequency Penalty to between 0.4 and 0.8","Set Min-P to at least 0.05 to prune low-probability echo tokens"],verificationRules:[{id:"rule-loop-broken",type:"no_repeat_ngrams",description:"Zero repetitive 4-gram sequences in output buffer",threshold:1},{id:"rule-penalty-set",type:"parameter_range",description:"Frequency Penalty set to >= 0.3",paramKey:"frequencyPenalty",minVal:.3}],hints:["When Frequency Penalty is 0.0, the model receives no mathematical penalty for selecting tokens it has already emitted.","Min-P dynamically cuts off tokens whose probability is less than a percentage of the top candidate.","Try setting Frequency Penalty to 0.6 and Min-P to 0.08, then click Generate."],solutionExplanation:"Autoregressive language models suffer from self-reinforcing probability loops when presence/frequency penalties are zero. Applying a frequency penalty reduces logits of repeated tokens, while Min-P eliminates stale tail tokens, forcing the model to select alternative semantic paths."},{id:"lab-2-rag-grounding",title:"Lab 2: The RAG Grounding Defect",subtitle:"Contextual Vector Grounding & Attention Alignment",difficulty:"intermediate",badge:"RAG Alignment",conceptTaught:"Retrieval Grounding vs. Pre-Training Hallucination",description:"The prompt asks for specific account limits from an internal policy document, but high temperature and uncalibrated sampling cause the model to ignore retrieved context and hallucinate incorrect figures.",objective:"Calibrate Temperature (<= 0.5) and Min-P (>= 0.08) so the model locks onto retrieved context with > 70% grounding overlap.",brokenPrompt:"According to the provided Tier 2 Verification Policy document, what is the exact maximum daily transaction limit for Tier 2 accounts, what is the wire processing fee, and what triggers a Tier 3 compliance review?",ragEnabled:!0,ragContext:`TIER 2 VERIFICATION POLICY:
- Daily Transaction Ceiling: Exactly $75,000 USD.
- Wire Processing Fee: 0.15% flat rate (discounted from standard 0.50%).
- Compliance Escalation: Any cumulative 24-hour volume exceeding $75,000 triggers an automated Tier 3 compliance review.`,initialParams:{temperature:1.3,topK:80,topP:.98,minP:0,frequencyPenalty:.1,presencePenalty:.1},targetParamHints:["Lower Temperature to between 0.2 and 0.5","Increase Min-P to >= 0.08 to filter out ungrounded speculative tokens"],verificationRules:[{id:"rule-grounding-ratio",type:"min_grounding_ratio",description:"Context Grounding overlap ratio >= 70%",threshold:.7},{id:"rule-temp-calibrated",type:"parameter_range",description:"Temperature calibrated to <= 0.6",paramKey:"temperature",maxVal:.6}],hints:["Watch the cyan grounding laser beams in the visualizer. At T = 1.3, they point to dim outer asteroids.","Lowering Temperature sharpens the probability peak around tokens directly mentioned in the RAG context.","Set Temperature to 0.3 and Min-P to 0.10 to achieve strong grounding alignment."],solutionExplanation:"High sampling temperature flattens token logits across the entire vocabulary, allowing pre-training parametric memory to overpower retrieved prompt context. Compressing temperature and raising Min-P forces the model to stay on the high-confidence semantic plateau provided by the RAG document."},{id:"lab-3-json-stability",title:"Lab 3: Structured JSON Stability",subtitle:"Shannon Entropy Compression at Syntax Junctions",difficulty:"intermediate",badge:"Structured Output",conceptTaught:"Perplexity, Shannon Entropy, & Deterministic Syntax",description:"An automated extraction pipeline is attempting to generate a valid JSON payload, but hyper-dispersed sampling entropy creates corrupted syntax, missing quotes, and invalid keys.",objective:"Compress entropy (avg < 0.6 bits at syntax boundaries) to guarantee valid JSON formatting.",brokenPrompt:'Extract the customer profile into valid JSON with keys "name", "status", and "creditScore": Customer Sarah Jenkins is currently active with an 810 credit score.',initialParams:{temperature:1.4,topK:100,topP:.99,minP:0,frequencyPenalty:0,presencePenalty:0},targetParamHints:["Lower Temperature to <= 0.3 (near-greedy)","Set Top-P to 0.85 or Min-P to 0.12"],verificationRules:[{id:"rule-max-entropy",type:"max_entropy",description:"Average Shannon Entropy <= 0.6 bits",threshold:.6},{id:"rule-temp-deterministic",type:"parameter_range",description:"Temperature set to <= 0.4",paramKey:"temperature",maxVal:.4}],hints:["Look at the Perplexity/Entropy indicator in the Flight Path. Red indicates high uncertainty.",'JSON syntax tokens ("{", ":", "}") require near-zero entropy to ensure reliable parsing.',"Try setting Temperature to 0.2 and Min-P to 0.15."],solutionExplanation:"Generating deterministic formats like JSON, YAML, or SQL requires extremely low entropy at syntax boundaries. Running near-greedy sampling ensures that grammar tokens are selected with near 100% confidence, preventing syntax errors in downstream software parsers."},{id:"lab-4-reasoning-xray",title:"Lab 4: The Cognitive Orbit X-Ray",subtitle:"Reasoning Monologue <think> Dynamics & Energy Contraction",difficulty:"advanced",badge:"Reasoning Dynamics",conceptTaught:"Chain-of-Thought Entropy Contraction & Monologue Decoupling",description:"Explore how modern reasoning models explore candidate logical pathways within <think> monologues before contracting their probability distribution into a high-confidence answer.",objective:"Observe the cognitive asteroid cloud during the thinking stream and confirm that final token emission achieves high confidence (> 85%).",brokenPrompt:"Solve this riddle step by step: A farmer has 17 sheep, and all but 9 die. How many sheep are left alive?",initialParams:{temperature:.6,topK:50,topP:.95,minP:.05,maxThinkingTokens:128},targetParamHints:["Keep Min-P between 0.05 and 0.10","Watch the transition from <think> asteroid cloud to Supergiant star at the answer"],verificationRules:[{id:"rule-thinking-contrast",type:"thinking_contrast",description:"Successful cognitive monologue parsing and high-confidence final answer"}],hints:["Notice that during the thinking phase, the canvas renders a diffuse outer cloud of cognitive asteroids.",'Once </think> is emitted, the distribution contracts into a single Supergiant star representing "9".',"Click Generate to observe the real-time reasoning transition."],solutionExplanation:"Reasoning models maintain high cognitive entropy while exploring candidate logical hypotheses inside <think> tags. Once the problem is solved internally, the probability manifold contracts into a steep potential well, emitting the final answer with decisive certainty."}],fT=({activeLab:s,onSelectLab:e,evaluation:t,params:r,onUpdateParams:a,onResetScenario:l,completedLabIds:d})=>{const[h,f]=Y.useState(!1),[m,_]=Y.useState(!1),S=pa.findIndex(b=>b.id===s.id),v=S<pa.length-1?pa[S+1]:null;return c.jsxs("div",{className:"bg-slate-900/90 border border-cyan-500/30 rounded-xl p-5 backdrop-blur-md shadow-2xl flex flex-col gap-4 text-white",children:[c.jsxs("div",{className:"flex items-center justify-between border-b border-slate-700/60 pb-3",children:[c.jsxs("div",{className:"flex items-center gap-3",children:[c.jsx("span",{className:"px-2.5 py-1 text-xs font-bold rounded-full uppercase tracking-wider bg-cyan-500/20 text-cyan-300 border border-cyan-400/40",children:s.badge}),c.jsx("span",{className:`px-2 py-0.5 text-xs font-semibold rounded ${s.difficulty==="beginner"?"bg-emerald-500/20 text-emerald-300 border border-emerald-500/30":s.difficulty==="intermediate"?"bg-amber-500/20 text-amber-300 border border-amber-500/30":"bg-purple-500/20 text-purple-300 border border-purple-500/30"}`,children:s.difficulty})]}),c.jsx("select",{value:s.id,onChange:b=>{const M=pa.find(E=>E.id===b.target.value);M&&e(M)},className:"bg-slate-800 border border-slate-700 text-xs rounded-lg px-2.5 py-1.5 text-cyan-200 focus:outline-none focus:border-cyan-400 cursor-pointer",children:pa.map((b,M)=>c.jsxs("option",{value:b.id,children:[d.includes(b.id)?"✅ ":`${M+1}. `,b.title]},b.id))})]}),c.jsxs("div",{children:[c.jsx("h2",{className:"text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-indigo-200 to-purple-300",children:s.title}),c.jsx("p",{className:"text-xs text-slate-400 mt-0.5",children:s.subtitle})]}),c.jsxs("div",{className:"bg-slate-800/60 border border-slate-700/50 rounded-lg p-3.5 flex flex-col gap-2 text-xs",children:[c.jsxs("div",{children:[c.jsx("span",{className:"font-semibold text-cyan-300",children:"Concept: "}),c.jsx("span",{className:"text-slate-300",children:s.conceptTaught})]}),c.jsx("p",{className:"text-slate-300 leading-relaxed",children:s.description}),c.jsxs("div",{className:"bg-cyan-950/40 border border-cyan-500/30 rounded p-2 text-cyan-200",children:[c.jsx("span",{className:"font-bold text-cyan-400",children:"🎯 Objective: "}),s.objective]})]}),c.jsxs("div",{className:`p-3.5 rounded-lg border flex flex-col gap-2 transition-all duration-300 ${t.status==="passed"?"bg-emerald-950/50 border-emerald-500/60 text-emerald-200 shadow-lg shadow-emerald-900/20":t.status==="aborted"?"bg-red-950/50 border-red-500/60 text-red-200 shadow-lg shadow-red-900/20":t.status==="failed"?"bg-amber-950/40 border-amber-500/40 text-amber-200":t.status==="running"?"bg-blue-950/40 border-blue-500/40 text-blue-200 animate-pulse":"bg-slate-800/40 border-slate-700/40 text-slate-400"}`,children:[c.jsxs("div",{className:"flex items-center justify-between",children:[c.jsxs("span",{className:"font-bold text-xs uppercase tracking-wide flex items-center gap-1.5",children:[t.status==="passed"&&"🎉 STATUS: SOLVED",t.status==="aborted"&&"🛑 STATUS: LOOP HALTED",t.status==="failed"&&"⚠️ STATUS: INCOMPLETE",t.status==="running"&&"⚡ STATUS: EVALUATING...",t.status==="unattempted"&&"⏳ STATUS: READY TO ATTEMPT"]}),t.status==="passed"&&v&&c.jsx("button",{onClick:()=>e(v),className:"px-2.5 py-1 text-xs font-bold rounded bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors shadow",children:"Next Challenge ➔"})]}),c.jsx("p",{className:"text-xs leading-relaxed",children:t.feedback}),c.jsxs("div",{className:"mt-1 pt-2 border-t border-white/10 flex flex-col gap-1.5",children:[c.jsx("span",{className:"text-[11px] font-semibold text-slate-400 uppercase",children:"Verification Rules:"}),s.verificationRules.map(b=>{const M=t.passedRuleIds.includes(b.id);return c.jsxs("div",{className:"flex items-center gap-2 text-xs",children:[c.jsx("span",{children:M?"✅":"❌"}),c.jsx("span",{className:M?"text-emerald-300 font-medium":"text-slate-400",children:b.description})]},b.id)})]})]}),c.jsxs("div",{className:"flex flex-col gap-2",children:[c.jsxs("button",{onClick:()=>f(!h),className:"flex items-center justify-between text-xs text-cyan-400 hover:text-cyan-300 font-semibold py-1 focus:outline-none transition-colors",children:[c.jsxs("span",{children:["💡 Guided Hints & Parameter Targets (",s.hints.length,")"]}),c.jsx("span",{children:h?"▲ Hide":"▼ View Hints"})]}),h&&c.jsx("div",{className:"bg-slate-800/80 border border-slate-700/60 rounded-lg p-3 flex flex-col gap-2 text-xs text-slate-300 animate-fadeIn",children:c.jsx("ul",{className:"list-disc list-inside space-y-1 text-slate-300",children:s.hints.map((b,M)=>c.jsx("li",{children:b},M))})})]}),c.jsxs("div",{className:"flex items-center justify-between pt-2 border-t border-slate-700/60",children:[c.jsx("button",{onClick:l,className:"px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-600 transition-colors",children:"↺ Reset Lab State"}),c.jsx("button",{onClick:()=>_(!m),className:"px-3 py-1.5 rounded-lg text-xs font-semibold text-purple-300 bg-purple-950/40 hover:bg-purple-900/50 border border-purple-500/40 transition-colors",children:m?"Hide Explanation":"📖 Deep Explanation"})]}),m&&c.jsxs("div",{className:"bg-purple-950/30 border border-purple-500/30 rounded-lg p-3.5 text-xs text-purple-200 leading-relaxed flex flex-col gap-1.5 animate-fadeIn",children:[c.jsx("span",{className:"font-bold text-purple-300",children:"Why this happens in production:"}),c.jsx("p",{children:s.solutionExplanation})]})]})};function pT({scenario:s,params:e,flightSteps:t,outputText:r,ragContext:a="",isGenerating:l,isLoopAborted:d=!1}){return Y.useMemo(()=>{if(!s)return{status:"unattempted",feedback:"Select a lab scenario to begin guided challenge.",passedRuleIds:[],failedRuleIds:[],metrics:{}};if(d)return{status:"aborted",feedback:"⚠️ Catastrophic loop detected by WebWorker. Generation halted to protect GPU memory.",passedRuleIds:[],failedRuleIds:s.verificationRules.map(E=>E.id),metrics:{isLoopAborted:!0}};if(l)return{status:"running",feedback:"Analyzing token distribution and sampling dynamics in real-time...",passedRuleIds:[],failedRuleIds:[],metrics:{tokensGenerated:t.length}};if(t.length===0&&!r.trim())return{status:"unattempted",feedback:"Configure parameters and click Generate to evaluate this scenario.",passedRuleIds:[],failedRuleIds:[],metrics:{}};const h=[],f=[];let m=0;const _=t.map(E=>E.selectedToken.token_str.trim().toLowerCase());if(_.length>=8)for(let E=0;E<=_.length-8;E++){const g=_.slice(E,E+4).join(" ");for(let x=E+4;x<=_.length-4;x++){const N=_.slice(x,x+4).join(" ");g.length>5&&g===N&&m++}}let S=0;if(a&&a.trim().length>0&&t.length>0){const E=new Set(a.toLowerCase().replace(/[^\w\s]/g,"").split(/\s+/).filter(x=>x.length>3));S=t.filter(x=>E.has(x.selectedToken.token_str.trim().toLowerCase())).length/t.length}let v=0,b=0;if(t.length>0){const E=t.map(g=>{const x=g.rawLogits.map(P=>Math.exp(P.raw_logit)).filter(P=>P>0),N=x.reduce((P,C)=>P+C,0);return N<=0?0:x.reduce((P,C)=>{const D=C/N;return P-D*Math.log2(D+1e-10)},0)}).filter(g=>!isNaN(g)&&isFinite(g));E.length>0&&(v=E.reduce((g,x)=>g+x,0)/E.length,b=Math.max(...E))}for(const E of s.verificationRules){let g=!1;switch(E.type){case"no_repeat_ngrams":g=m===0&&!d;break;case"min_grounding_ratio":g=S>=(E.threshold??.7);break;case"max_entropy":g=v<=(E.threshold??.8)&&t.length>=5;break;case"thinking_contrast":g=r.includes("</think>")||t.some(x=>!x.selectedToken.isHistorical);break;case"parameter_range":if(E.paramKey&&e[E.paramKey]!==void 0){const x=e[E.paramKey],N=E.minVal===void 0||x>=E.minVal,P=E.maxVal===void 0||x<=E.maxVal;g=N&&P}break}g?h.push(E.id):f.push(E.id)}const M=h.length===s.verificationRules.length&&f.length===0;return{status:M?"passed":"failed",feedback:M?"🎉 Lab Challenge Solved! Sampling parameters successfully calibrated.":`Criteria not met (${h.length}/${s.verificationRules.length} rules passed). Inspect hints and adjust sliders.`,passedRuleIds:h,failedRuleIds:f,metrics:{repeatCount:m,groundingRatio:Math.round(S*100),avgEntropy:Math.round(v*100)/100,maxEntropy:Math.round(b*100)/100,tokensGenerated:t.length,isLoopAborted:d}}},[s,e,t,r,a,l,d])}function ha(s,e,t){if(!e||!t.trim())return s.map(a=>({...a,is_rag_grounded:!1}));const r=new Set((t.toLowerCase().match(/[a-z0-9'-]+/g)||[]).filter(a=>a.length>2));return s.map(a=>{const d=(a.token_str.toLowerCase().match(/[a-z0-9'-]+/g)||[]).some(h=>h.length>2&&r.has(h));return{...a,is_rag_grounded:d}})}const mT=()=>{const[s,e]=Y.useState("experiment"),[t,r]=Y.useState(!1),[a,l]=Y.useState(pa[0]),[d,h]=Y.useState(()=>{try{return JSON.parse(localStorage.getItem("token_cosmos_completed_labs")||"[]")}catch{return[]}}),f=hT(),[m,_]=Y.useState(!1),[S,v]=Y.useState(!1),[b,M]=Y.useState("Sample data"),[E,g]=Y.useState(null),[x,N]=Y.useState(null),[P,C]=Y.useState(!1),[D,L]=Y.useState(()=>{const F=localStorage.getItem("token_cosmos_provider");return F==="openai"||F==="custom"?F:"default"}),[O,T]=Y.useState(()=>localStorage.getItem("token_cosmos_custom_url")||""),[I,H]=Y.useState(()=>localStorage.getItem("token_cosmos_custom_key")||""),[B,V]=Y.useState(()=>localStorage.getItem("token_cosmos_model_name")||"Cloud Run candidate demo"),[ae,Q]=Y.useState({temperature:.7,topK:40,topP:.9,minP:.02,frequencyPenalty:.1,presencePenalty:.1,stopSequences:[],logitBiases:{},maxThinkingTokens:2048}),[ie,de]=Y.useState({temperature:1.5,topK:50,topP:.95,minP:.01,frequencyPenalty:0,presencePenalty:0,stopSequences:[],logitBiases:{}}),[re,X]=Y.useState(oc[0].prompt),[J,le]=Y.useState(""),[U,q]=Y.useState('{ "type": "object", "properties": { "answer": { "type": "string" } } }'),[Re,qe]=Y.useState(!1),[be,ee]=Y.useState(oc[0].ragContext),[me,ve]=Y.useState(oc[0].ragEnabled),[ce,we]=Y.useState(!1),{copySetupLink:Ze}=cT({params:ae,setParams:Q,prompt:re,setPrompt:X,systemPrompt:J,setSystemPrompt:le,ragContext:be,setRagContext:ee,ragEnabled:me,setRagEnabled:ve}),[bt,ot]=Y.useState(Zs["capital-france"].baseline),[at,$e]=Y.useState(Zs["capital-france"].rag);Y.useEffect(()=>{if(f.latestLogits&&f.isModelLoaded){const F=f.logitsToRawCandidates(f.latestLogits);F.length>0&&(ot(ha(F,!1,"")),$e(ha(F,me,be)),M(`Local WebGPU - ${f.state.modelId}`),g(null))}},[f.latestLogits,f.latestCandidates,f.isModelLoaded,f.logitsToRawCandidates,f.state.modelId,me,be]),Y.useEffect(()=>{f.state.error&&g(f.state.error)},[f.state.error]);const Mt=F=>{if(F==="__SAMPLE_DATA__"){f.unload(),_(!0),v(!0),M("Sample data"),g(null);return}if(F==="__CLOUD_API__"){f.unload(),_(!1),v(!0),M("Cloud Run candidate API"),g(null);return}_(!1),v(!1),M(`Loading local WebGPU - ${F}`),g(null),f.loadModel(F)},[St,Dt]=Y.useState([]),[It,Nt]=Y.useState(0),[ht,jt]=Y.useState(!1),[j,Qe]=Y.useState(!1),je=(F,ye,ge,Pe)=>{L(F),T(ye),H(ge),V(Pe),localStorage.setItem("token_cosmos_provider",F),ye?localStorage.setItem("token_cosmos_custom_url",ye):localStorage.removeItem("token_cosmos_custom_url"),ge?localStorage.setItem("token_cosmos_custom_key",ge):localStorage.removeItem("token_cosmos_custom_key"),Pe?localStorage.setItem("token_cosmos_model_name",Pe):localStorage.removeItem("token_cosmos_model_name")},k=(F,ye,ge,Pe)=>{const Ae=F.trim().toLowerCase(),Se=ge&&ye?ye.split(/\s+/).filter(dt=>dt.length>3):[];let Oe=[];Pe&&(Pe.toLowerCase().includes("sql")||Pe.toLowerCase().includes("dba"))?Oe=[" SELECT"," FROM"," WHERE"," JOIN"," GROUP"," BY"," ORDER"," LIMIT"," COUNT"," MAX"]:Ae.includes("steak")?Oe=[" medium-rare"," grill"," searing"," butter"," seasoning"," ribeye"," pan"," tender"," garlic"," salt"]:Ae.includes("poem")||Ae.includes("server")?Oe=[" crash"," glowing"," silicon"," binary"," silent"," electric"," echo"," dark"," pulse"," memory"]:Ae.includes("policy")||Ae.includes("work")?Oe=[" remote"," office"," Tuesday"," Thursday"," schedule"," hybrid"," Monday"," Friday"," hours"," team"]:(Oe=F.split(/\s+/).filter(Ft=>Ft.length>2).map(Ft=>` ${Ft}`),Oe.length<5&&Oe.push(" optimal"," result"," answer"," analysis"," structure"," concept"));const He=[],Tt=[];for(let dt=0;dt<50;dt++){const Ft=dt<Oe.length?Oe[dt]:` candidate_${dt+1}`,ln=16-Math.log(dt+1)*3.1+Math.sin(dt*1.5)*.5;let Dn=!1,In=ln;if(ge&&Se.length>0){const oi=Ft.trim().toLowerCase();for(const mi of Se)if(oi.includes(mi.toLowerCase())||mi.toLowerCase().includes(oi)){Dn=!0,In+=5.5;break}}He.push({token_id:2e3+dt,token_str:Ft,raw_logit:Math.round(ln*100)/100,is_rag_grounded:!1}),Tt.push({token_id:3e3+dt,token_str:Ft,raw_logit:Math.round(In*100)/100,is_rag_grounded:Dn})}return He.sort((dt,Ft)=>Ft.raw_logit-dt.raw_logit),Tt.sort((dt,Ft)=>Ft.raw_logit-dt.raw_logit),{baseline:He,rag:Tt}},w=async F=>{const ye=F!==void 0?F:re;F===void 0&&(Dt([]),Nt(0)),we(!0),g(null);try{if(f.isModelLoaded){const Ae=me&&be.trim()?`Context: ${be}

Question: ${ye}`:ye;f.availableModels.find(Oe=>Oe.id===f.state.modelId)?.isReasoning?f.generateSteps(Ae,(ae.maxThinkingTokens||2048)+1024,ae.maxThinkingTokens,J):f.getLogits(Ae),M(`Local WebGPU - ${f.state.modelId}`);return}if(D!=="default"){if(D==="openai"&&!I)throw new Error("An OpenAI API key is required for BYOE inference.");const Ae=O||(D==="openai"?"https://api.openai.com/v1":"");if(!Ae)throw new Error("A base URL is required for a custom OpenAI-compatible endpoint.");const Se=Ae.replace(/\/$/,""),Oe=Se.endsWith("/chat/completions")?Se:`${Se}/chat/completions`,He={"Content-Type":"application/json"};I&&(He.Authorization=`Bearer ${I}`);const Tt=[];J.trim()&&Tt.push({role:"system",content:J.trim()});let dt=ye;me&&be.trim()&&(dt=`Retrieved Context: ${be}

User Question: ${ye}`),Tt.push({role:"user",content:dt});const Ft={model:B||"gpt-4o",messages:Tt,max_tokens:1,temperature:ae.temperature,logprobs:!0,top_logprobs:20},ln=await fetch(Oe,{method:"POST",headers:He,body:JSON.stringify(Ft)});if(!ln.ok)throw new Error(`BYOE endpoint returned ${ln.status}.`);const Dn=await ln.json(),In=I_(Dn,me?be:void 0);if(In.length===0)throw new Error("BYOE endpoint returned no token logprobs. Choose an OpenAI-compatible endpoint with logprobs support.");ot(ha(In,!1,"")),$e(ha(In,me,be)),M(`BYOE - ${B||D}`);return}if(m){const Ae=k(ye,be,me,J);ot(Ae.baseline),$e(Ae.rag),M("Sample data");return}const ge=new AbortController,Pe=setTimeout(()=>ge.abort(),5e3);try{const Ae=await fetch("/api/logits",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt:ye,system_prompt:J||null,rag_context:me?be:null,top_n:50}),signal:ge.signal}),Se=Ae.headers.get("content-type")||"";if(!Ae.ok||!Se.includes("application/json"))throw new Error(`Cloud Run candidate API is unavailable (${Ae.status}).`);const Oe=await Ae.json();if(!Array.isArray(Oe.candidates)||Oe.candidates.length===0)throw new Error("Cloud Run candidate API returned no candidates.");ot(ha(Oe.candidates,!1,"")),$e(ha(Oe.candidates,me,be)),M(`Cloud Run - ${Oe.engine||"candidate API"}`)}finally{clearTimeout(Pe)}}catch(ge){const Pe=k(re,be,me,J);ot(Pe.baseline),$e(Pe.rag);const Ae=ge instanceof Error?ge.message:"Unknown inference error";M("Sample data (fallback)"),g(`${Ae} Showing generated sample candidates instead.`)}finally{we(!1)}},$=F=>{if(Q(ye=>({...ye,...F.params})),X(F.prompt),ee(F.ragContext),ve(F.ragEnabled),F.id==="factual-roboticist")ot(Zs["capital-france"].baseline),$e(Zs["capital-france"].rag);else if(F.id==="wild-storyteller")ot(Zs["cybernetic-forest"].baseline),$e(Zs["cybernetic-forest"].baseline);else{const ye=k(F.prompt,F.ragContext,F.ragEnabled,J);ot(ye.baseline),$e(ye.rag)}},se=Y.useMemo(()=>St.slice(0,It+1).map(F=>F.selectedToken.token_str),[St,It]),he=me?at:bt,Me=Y.useMemo(()=>{const F=ao(he,ae,se);return Re&&U.trim()&&F.forEach(ye=>{const ge=ye.token_str.trim();(ge.includes("candidate_")||ge.includes("fringe_")||ge.includes("Washington"))&&(ye.probability=0,ye.isFiltered=!0,ye.filterReason="Banned",ye.color="#e11d48")}),F},[he,ae,se,Re,U]),Ee=Y.useMemo(()=>ao(he,ie,se),[he,ie,se]);Y.useMemo(()=>ao(bt,ae,se),[bt,ae,se]),Y.useMemo(()=>ao(at,ae,se),[at,ae,se]);const _e=Y.useMemo(()=>St.map(F=>ao(F.rawLogits,F.params)),[St]);Y.useEffect(()=>{Me.length>0&&(Dt(F=>F.length===0?[{stepIndex:0,selectedToken:Me[0],promptSnippet:re,rawLogits:he,params:ae,ragEnabled:me}]:F),Nt(F=>St.length===0?0:F))},[bt,at,Me]);const fe=async F=>{const ye=re+F.token_str;X(ye);const ge={stepIndex:St.length,selectedToken:F,promptSnippet:re,rawLogits:he,params:ae,ragEnabled:me},Pe=[...St.slice(0,It+1),ge];Dt(Pe),Nt(Pe.length-1),N({feature:`Token Selection ("${F.token_str.trim()}")`,whatItIs:"Direct token selection on the starfield orbital canvas.",whyItIs:"Allows step-by-step interactive trajectory steering.",impact:`Appends "${F.token_str.trim()}" (${(F.probability*100).toFixed(1)}%) to flight constellation.`,guidance:"Click any orbiting candidate star to force the LLM down a specific sentence path!",timestamp:Date.now()}),await w(ye)};Y.useEffect(()=>{let F;const ye=ce||f.state.status==="generating";return j&&!ye&&Me.length>0&&(F=setTimeout(()=>{const ge=Me.find(Pe=>!Pe.isFiltered)||Me[0];ge?fe(ge):Qe(!1)},950)),()=>clearTimeout(F)},[j,ce,f.state.status,Me,fe]);const ke=()=>{Me.length!==0&&(jt(!0),setTimeout(()=>{const F=Me.find(ye=>!ye.isFiltered)||Me[0];fe(F),jt(!1)},200))},We=()=>{if(Me.length>0){const ye={stepIndex:0,selectedToken:Me[0],promptSnippet:re,rawLogits:he,params:ae,ragEnabled:me};Dt([ye]),Nt(0)}},Ue=!S&&f.isWebGPUAvailable&&["idle","downloading","loading","error"].includes(f.state.status),Le=ce||f.state.status==="generating",Xe=pT({scenario:s==="labs"?a:null,params:ae,flightSteps:St,outputText:St.map(F=>F.selectedToken.token_str).join(""),ragContext:me?be:"",isGenerating:Le,isLoopAborted:f.isLoopAborted});Y.useEffect(()=>{Xe.status==="passed"&&a&&!d.includes(a.id)&&h(F=>{const ye=[...F,a.id];return localStorage.setItem("token_cosmos_completed_labs",JSON.stringify(ye)),ye})},[Xe.status,a,d]);const tt=F=>{l(F),X(F.brokenPrompt),Q(ye=>({...ye,...F.initialParams})),F.ragContext?(ee(F.ragContext),ve(!0)):ve(!1),f.resetChat(),Dt([]),Nt(0)},lt=()=>{tt(a)};return c.jsxs("div",{className:"flex flex-col h-screen overflow-hidden bg-[#050714] text-gray-100 font-sans selection:bg-blue-500/30 selection:text-white select-text",children:[Ue&&c.jsx(lT,{state:f.state,isWebGPUAvailable:f.isWebGPUAvailable,availableModels:f.availableModels,onSelectModel:Mt}),c.jsxs(c.Fragment,{children:[c.jsx(T_,{activeTab:s,setActiveTab:e,splitView:t,setSplitView:r,onOpenSettings:()=>C(!0),onCopySetupLink:Ze}),c.jsx("main",{className:"flex-1 w-full max-w-[1600px] mx-auto p-4 sm:p-6 flex flex-col space-y-6 min-h-0 overflow-hidden",children:s==="labs"?c.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1 min-h-0 overflow-hidden",children:[c.jsxs("div",{className:"lg:col-span-5 xl:col-span-4 h-full min-h-0 overflow-y-auto pr-1 space-y-4",children:[c.jsx(fT,{activeLab:a,onSelectLab:tt,evaluation:Xe,params:ae,onUpdateParams:F=>Q(ye=>({...ye,...F})),onResetScenario:lt,completedLabIds:d}),c.jsx(Vm,{params:ae,setParams:Q,prompt:re,setPrompt:X,systemPrompt:J,setSystemPrompt:le,jsonSchema:U,setJsonSchema:q,jsonSchemaEnabled:Re,setJsonSchemaEnabled:qe,ragContext:be,setRagContext:ee,ragEnabled:me,setRagEnabled:ve,onApplyPreset:$,onLaunchPrompt:w,onInteractFeature:F=>N(F),isFetchingLogits:Le,rawLogits:he,isReasoningModel:f.availableModels.find(F=>F.id===f.state.modelId)?.isReasoning})]}),c.jsx("div",{className:"lg:col-span-7 xl:col-span-8 h-full min-h-0 overflow-hidden flex flex-col",children:c.jsx(Lc,{candidates:Me,params:ae,ragEnabled:me,onSelectToken:fe,title:`${a.title}`,subtitle:`Interactive Challenge • ${a.conceptTaught}`,steps:St,currentStepIndex:It,onSelectStep:F=>Nt(F),onGenerateNextStep:ke,onResetTimeline:We,isGenerating:ht,allCandidatesByStep:_e,historyLength:se.length,modelId:f.state.modelId,latestLogits:f.latestLogits,isThinking:f.latestSnapshot?.isThinking,isPlaying:j,onTogglePlay:()=>Qe(!j)})})]}):s==="experiment"?c.jsxs(c.Fragment,{children:[c.jsx(aT,{}),E&&c.jsx("div",{role:"status",className:"border border-amber-400/30 bg-amber-400/10 px-3 py-2 text-xs text-amber-100",children:E}),c.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1 min-h-0 overflow-hidden",children:[c.jsx("div",{className:"lg:col-span-4 xl:col-span-4 h-full min-h-0 overflow-hidden",children:c.jsx(Vm,{params:ae,setParams:Q,prompt:re,setPrompt:X,systemPrompt:J,setSystemPrompt:le,jsonSchema:U,setJsonSchema:q,jsonSchemaEnabled:Re,setJsonSchemaEnabled:qe,ragContext:be,setRagContext:ee,ragEnabled:me,setRagEnabled:ve,onApplyPreset:$,onLaunchPrompt:w,onInteractFeature:F=>N(F),isFetchingLogits:Le,rawLogits:he,isReasoningModel:f.availableModels.find(F=>F.id===f.state.modelId)?.isReasoning})}),c.jsx("div",{className:"lg:col-span-8 xl:col-span-8 h-full min-h-0 overflow-hidden flex flex-col",children:c.jsx("div",{className:"flex-1 min-h-0 overflow-hidden",children:t?c.jsx(nT,{leftCandidates:Me,rightCandidates:Ee,leftParams:ae,rightParams:ie,leftTitle:D!=="default"?`Universe A [${D.toUpperCase()}] (${B})`:`Universe A (Temp = ${ae.temperature.toFixed(2)})`,leftSubtitle:`Primary Sampling Config • Top-K ${ae.topK}`,rightTitle:D!=="default"?`Universe B [${b}]`:`Universe B (Temp = ${ie.temperature.toFixed(2)})`,rightSubtitle:`Secondary A/B Config • Top-K ${ie.topK}`,leftRagEnabled:me,rightRagEnabled:me,onSelectToken:fe,onUpdateRightTemp:F=>de(ye=>({...ye,temperature:F})),isByoeMode:D!=="default",leftIsThinking:f.latestSnapshot?.isThinking}):c.jsx(Lc,{candidates:Me,params:ae,ragEnabled:me,onSelectToken:fe,title:"The Token Cosmos",subtitle:`${b} • 3D Topographic Terrain`,steps:St,currentStepIndex:It,onSelectStep:F=>Nt(F),onGenerateNextStep:ke,onResetTimeline:We,isGenerating:ht,allCandidatesByStep:_e,historyLength:se.length,modelId:f.state.modelId,latestLogits:f.latestLogits,isThinking:f.latestSnapshot?.isThinking,isPlaying:j,onTogglePlay:()=>Qe(!j)})})})]})]}):s==="learn"?c.jsx("div",{className:"flex-1 overflow-y-auto",children:c.jsx(iT,{})}):c.jsx("div",{className:"flex-1 max-w-4xl mx-auto w-full pt-8 min-h-0 overflow-hidden",children:c.jsx("div",{className:"bg-[#1c1c21] rounded-xl border border-white/10 p-6 shadow-2xl overflow-hidden relative h-full",children:c.jsx("div",{className:"absolute inset-0 overflow-y-auto p-2",children:c.jsx(oT,{isOpen:!0,onClose:()=>e("experiment"),params:ae,prompt:re,systemPrompt:J,ragContext:be,ragEnabled:me,modelName:B,provider:D,isReasoningModel:f.availableModels.find(F=>F.id===f.state.modelId)?.isReasoning})})})})}),c.jsx(rT,{params:ae,setParams:Q,prompt:re,setPrompt:X,ragContext:be,setRagContext:ee,ragEnabled:me,setRagEnabled:ve,topCandidateStr:Me[0]?.token_str?.trim()||"Paris",topCandidateProb:Me[0]?.probability||.85,activeInteractionNotice:x}),c.jsx(sT,{isOpen:P,onClose:()=>C(!1),onSave:je,provider:D,customUrl:O,customApiKey:I,modelName:B})]})]})};Hv.createRoot(document.getElementById("root")).render(c.jsx(kv.StrictMode,{children:c.jsx(mT,{})}));
